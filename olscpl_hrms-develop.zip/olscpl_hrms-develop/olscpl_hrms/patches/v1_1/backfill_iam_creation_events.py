"""
olscpl_hrms/patches/v1_1/backfill_iam_creation_events.py

One-time backfill: publish a CREATION event for every currently-active
Employee that already has a linked user_id, so User IAM has a complete
picture before we start relying on live Kafka events for anything new.

Employees without a user_id are intentionally skipped here — per the
custom_iam_synced design (see events/iam_sync.py), they'll get their
CREATION event automatically the first time a user_id gets linked to
them, whenever that happens.

Depends on olscpl_hrms.patches.v1_1.add_iam_synced_field having already
run (custom_iam_synced field must exist).

Register in olscpl_hrms/patches.txt:
    olscpl_hrms.patches.v1_1.backfill_iam_creation_events

Run manually first on uat-copy.local via:
    bench --site uat-copy.local execute olscpl_hrms.patches.v1_1.backfill_iam_creation_events.execute

before adding it to patches.txt for automatic execution on `bench migrate`,
so you can control exactly when the backfill fires against a shared/UAT
Kafka topic. Safe to re-run: employees already marked custom_iam_synced=1
are skipped.
"""

import frappe

from olscpl_hrms.events.iam_sync import build_iam_payload
from olscpl_hrms.utils.kafka_producer import publish_employee_event


def execute():
	employees = frappe.get_all(
		"Employee",
		filters={
			"status": "Active",
			"user_id": ["is", "set"],
			"custom_iam_synced": ["!=", 1],
		},
		pluck="name",
	)

	published, failed = 0, 0
	for name in employees:
		try:
			doc = frappe.get_doc("Employee", name)
			publish_employee_event("CREATION", build_iam_payload(doc))
			frappe.db.set_value("Employee", name, "custom_iam_synced", 1, update_modified=False)
			published += 1
		except Exception:
			failed += 1
			frappe.log_error(
				title="IAM backfill failed for employee",
				message=f"{name}\n{frappe.get_traceback()}",
			)

	skipped_no_user = frappe.db.count(
		"Employee", filters={"status": "Active", "user_id": ["in", ["", None]]}
	)

	frappe.logger("iam_kafka").info(
		f"IAM backfill complete: {published} published, {failed} failed, "
		f"{skipped_no_user} active employees skipped (no user_id yet, will sync automatically later)"
	)
