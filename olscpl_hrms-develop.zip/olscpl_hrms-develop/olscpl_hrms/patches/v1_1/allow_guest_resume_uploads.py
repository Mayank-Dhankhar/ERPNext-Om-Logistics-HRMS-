# olscpl_hrms/patches/v1_1/allow_guest_resume_uploads.py
#
# Root cause of "resume upload just shows a red X, no message" on the public
# Job Application web form (reported both on desktop and mobile - it was
# never actually browser/device-specific): frappe.handler.upload_file()
# unconditionally raises frappe.PermissionError for Guest uploads unless
# System Settings.allow_guests_to_upload_files is on:
#
#   if frappe.session.user == "Guest":
#       if frappe.get_system_settings("allow_guests_to_upload_files"):
#           ...
#       else:
#           raise frappe.PermissionError
#
# Confirmed live against atlas.omone.in on 2026-09-14: POST
# /api/method/upload_file -> 403 PermissionError from that exact line,
# for every file, every browser - the setting was simply off. (Separately,
# a real Frappe-core bug - a `console.warning` typo in FileUploader.vue's
# parse_error_response, should be console.warn - throws while parsing that
# 403's body and blanks out the error message the UI would otherwise show,
# which is why it looked like a silent, message-less failure instead of a
# clear "Not permitted" banner. That part lives in apps/frappe so it's not
# fixed here; the actual fix is this setting.)
#
# Turns the setting on only. It deliberately does NOT fill
# allowed_doctypes_for_guest_uploads: a Web Form file upload has no form
# object, so FileUploader sends no doctype (frappe attach.js only sets
# options.doctype when this.frm exists), and handler.py then compares
# None against that list and rejects the upload whenever the list is
# non-empty - even with "Job Applicant" in it. An earlier version of this
# patch added "Job Applicant" to the list on every migrate, which broke
# resume uploads again each time. Leave the list empty.
#
# Uses frappe.db.set_value (not doc.save()) since System Settings validation
# has unrelated side effects (timezone/language re-application etc.) that
# don't need to run for a two-field config change. Registered under both
# patches.txt and hooks.py's after_migrate like this app's other patches,
# so it reapplies if the setting is ever reset.
import frappe


def execute():
	current = frappe.db.get_singles_dict("System Settings")
	updates = {}

	if not current.get("allow_guests_to_upload_files"):
		updates["allow_guests_to_upload_files"] = 1

	if not updates:
		return

	for fieldname, value in updates.items():
		frappe.db.set_value("System Settings", "System Settings", fieldname, value)

	frappe.db.commit()
	frappe.clear_cache()
