# olscpl_hrms/patches/v1_1/setup_company_letterheads.py
#
# Creates one Letter Head per group company from the header/footer crops
# in public/files/letterheads/ (source originals: OLSCPL Letter Head.pdf,
# SANJVIK Letter Head.jpg, Telecom Letter Head New.jpg - rasterized/cropped
# once, not regenerated here) and sets it as that Company's default_letter
# _head, so it's picked up automatically by every print format that
# checks the company's own letterhead (ERPNext's accounts_controller.py,
# HRMS's Salary Slip print dialog, "With Letterhead" on any Print Format)
# - the Letter Head doctype's own is_default flag only covers a single
# site-wide fallback, this is what actually wires it up per company.
#
# Idempotent - re-running (every migrate) just re-syncs the image paths/
# widths in case the assets are ever replaced, rather than only running
# once ever.
import contextlib
import os

import frappe

from olscpl_hrms.api.employee_data import company_letterhead_urls

# Letter Head record name per company - the header/footer image paths
# themselves come from company_letterhead_urls() (employee_data.py), the
# one shared source of which company maps to which asset prefix.
LETTER_HEAD_NAME = {
	"OM Logistics Supply Chain PVT. LTD.": "OLSCPL Letterhead",
	"SANJVIK TERMINALS PVT LTD": "SANJVIK Letterhead",
	"OM TELECOM LOGISTICS PVT LTD": "OM Telecom Letterhead",
	"OPEN SOURCE BUSINESS SOLUTIONS PVT LTD": "RapidShyp Letterhead",
	"TRANSAFE SERVICES LTD": "Transafe Services Limited",
}

# 750px - a safe, fits-any-print-format content width (the generic
# "Standard" print view's own CSS would have scaled a wider image down
# automatically, but not every custom Print Format in this system has
# that same reset, and an unconstrained 2480px-wide source image just
# overflows/clips on those instead of scaling).
IMAGE_WIDTH = 750


@contextlib.contextmanager
def _no_fixture_export():
	original = frappe.conf.get("developer_mode")
	frappe.conf.developer_mode = 0
	try:
		yield
	finally:
		frappe.conf.developer_mode = original


def _versioned(url):
	if not url:
		return url
	path = frappe.get_app_path("olscpl_hrms", "public", url.split("/assets/olscpl_hrms/", 1)[-1])
	return f"{url}?v={int(os.path.getmtime(path))}" if os.path.exists(path) else url


def execute():
	with _no_fixture_export():
		for company, lh_name in LETTER_HEAD_NAME.items():
			if not frappe.db.exists("Company", company):
				continue  # this company doesn't exist on this site - nothing to link

			header_url, footer_url = company_letterhead_urls(company)
			if not header_url:
				continue
			# ?v=<file time>: browsers fetch a replaced image instead of a cached old one
			header_url, footer_url = _versioned(header_url), _versioned(footer_url)

			if frappe.db.exists("Letter Head", lh_name):
				doc = frappe.get_doc("Letter Head", lh_name)
			else:
				doc = frappe.new_doc("Letter Head")
				doc.letter_head_name = lh_name

			doc.source = "Image"
			doc.image = header_url
			doc.image_width = IMAGE_WIDTH
			doc.align = "Center"
			doc.footer_source = "Image"
			doc.footer_image = footer_url
			doc.footer_image_width = IMAGE_WIDTH
			doc.footer_align = "Center"
			doc.disabled = 0
			doc.save(ignore_permissions=True)

			frappe.db.set_value("Company", company, "default_letter_head", lh_name)

		frappe.db.commit()
