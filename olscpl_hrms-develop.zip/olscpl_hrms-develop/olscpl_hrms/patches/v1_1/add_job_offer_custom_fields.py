import frappe

STATE_OPTIONS = (
	"\nDelhi\nMaharashtra\nKarnataka\nGujarat\nWest Bengal\nAndhra Pradesh\n"
	"Telangana\nTamil Nadu\nMadhya Pradesh\nOdisha\nPunjab\nAssam\nBihar\n"
	"Chhattisgarh\nJharkhand\nKerala\nManipur\nPuducherry\nSikkim\n"
	"Uttar Pradesh\nRajasthan\nJammu and Kashmir\nUttarakhand\n"
	"Himachal Pradesh\nGoa\nHaryana\nDadra and Nagar Haveli\nDaman and Diu\n"
	"Chandigarh\nAndaman and Nicobar Islands"
)

CUSTOM_FIELDS = [
	{"fieldname": "custom_salary_annexure",   "fieldtype": "Tab Break",   "label": "Salary Annexure", "insert_after": "language"},
	{"fieldname": "custom_state",             "fieldtype": "Select",     "label": "State",           "options": STATE_OPTIONS,           "insert_after": "custom_salary_annexure"},
	{"fieldname": "custom_sitting_location",  "fieldtype": "Select",     "label": "Sitting State Location", "options": STATE_OPTIONS,     "insert_after": "custom_state"},
	{"fieldname": "custom_loi_salary_structure", "fieldtype": "Link",    "label": "LOI Salary Structure", "options": "Salary Structure", "insert_after": "custom_sitting_location"},
	{"fieldname": "custom_gender",            "fieldtype": "Select",     "label": "Gender",          "options": "\nMale\nFemale\nOther", "insert_after": "custom_loi_salary_structure"},
	{"fieldname": "custom_column_break_becka", "fieldtype": "Column Break", "label": "",             "insert_after": "custom_gender"},
	{"fieldname": "custom_base_salary",       "fieldtype": "Currency",   "label": "Base Salary",     "insert_after": "custom_column_break_becka"},
	{"fieldname": "custom_pf_applicable",     "fieldtype": "Select",     "label": "PF Applicable",   "options": "\nYes\nNo\nCeiling",     "insert_after": "custom_base_salary"},
	{"fieldname": "custom_section_break_c9i9a", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_pf_applicable"},
	{"fieldname": "custom_salary_breakup",    "fieldtype": "Table",      "label": "Salary Breakup",  "options": "LOI Salary Breakup",     "insert_after": "custom_section_break_c9i9a"},
	{"fieldname": "custom_section_break_q9h7k", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_salary_breakup"},
	{"fieldname": "custom_total_breakupmonth", "fieldtype": "Currency",  "label": "Total Breakup/Month", "insert_after": "custom_section_break_q9h7k"},
	{"fieldname": "custom_column_break_wceaj", "fieldtype": "Column Break", "label": "",             "insert_after": "custom_total_breakupmonth"},
	{"fieldname": "custom_total_breakupannum", "fieldtype": "Currency",  "label": "Total Breakup/Annum", "insert_after": "custom_column_break_wceaj"},
	{"fieldname": "custom_section_break_qy7rz", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_total_breakupannum"},
	{"fieldname": "custom_allowances",        "fieldtype": "Table",      "label": "Allowances",      "options": "LOI Allowance",           "insert_after": "custom_section_break_qy7rz"},
	{"fieldname": "custom_section_break_czcb1", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_allowances"},
	{"fieldname": "custom_total_allowmonth",  "fieldtype": "Currency",   "label": "Total Allow/Month", "insert_after": "custom_section_break_czcb1"},
	{"fieldname": "custom_gross_salarymonth", "fieldtype": "Currency",   "label": "Gross Salary/Month", "insert_after": "custom_total_allowmonth"},
	{"fieldname": "custom_column_break_nlopu", "fieldtype": "Column Break", "label": "",             "insert_after": "custom_gross_salarymonth"},
	{"fieldname": "custom_total_allowannum",  "fieldtype": "Currency",   "label": "Total Allow/Annum", "insert_after": "custom_column_break_nlopu"},
	{"fieldname": "custom_gross_salaryannum", "fieldtype": "Currency",   "label": "Gross Salary/Annum", "insert_after": "custom_total_allowannum"},
	{"fieldname": "custom_section_break_eulxd", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_gross_salaryannum"},
	{"fieldname": "custom_deductions",        "fieldtype": "Table",      "label": "Deductions",      "options": "LOI Deduction",           "insert_after": "custom_section_break_eulxd"},
	{"fieldname": "custom_section_break_i6qm8", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_deductions"},
	{"fieldname": "custom_total_deductmonth", "fieldtype": "Currency",   "label": "Total Deduct/Month", "insert_after": "custom_section_break_i6qm8"},
	{"fieldname": "custom_column_break_doygf", "fieldtype": "Column Break", "label": "",             "insert_after": "custom_total_deductmonth"},
	{"fieldname": "custom_total_deductannum", "fieldtype": "Currency",   "label": "Total Deduct/Annum", "insert_after": "custom_column_break_doygf"},
	{"fieldname": "custom_section_break_2osdr", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_total_deductannum"},
	{"fieldname": "custom_other_benefits",    "fieldtype": "Table",      "label": "Other Benefits",  "options": "LOI Other Benefit",       "insert_after": "custom_section_break_2osdr"},
	{"fieldname": "custom_section_break_avxso", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_other_benefits"},
	{"fieldname": "custom_total_benefitmonth", "fieldtype": "Currency",  "label": "Total Benefit/Month", "insert_after": "custom_section_break_avxso"},
	{"fieldname": "custom_column_break_p59dv", "fieldtype": "Column Break", "label": "",             "insert_after": "custom_total_benefitmonth"},
	{"fieldname": "custom_total_benefitannum", "fieldtype": "Currency",  "label": "Total Benefit/Annum", "insert_after": "custom_column_break_p59dv"},
	{"fieldname": "custom_section_break_lghbd", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_total_benefitannum"},
	{"fieldname": "custom_benefits",          "fieldtype": "Table",      "label": "Benefits",        "options": "LOI Benefit",             "insert_after": "custom_section_break_lghbd"},
	{"fieldname": "custom_section_break_1c9sz", "fieldtype": "Section Break", "label": "",           "insert_after": "custom_benefits"},
	{"fieldname": "custom_ctcmonth",          "fieldtype": "Currency",   "label": "CTC/Month",       "insert_after": "custom_section_break_1c9sz"},
	{"fieldname": "custom_net_salarymonth",   "fieldtype": "Currency",   "label": "Net Salary/Month", "insert_after": "custom_ctcmonth"},
	{"fieldname": "custom_column_break_tblrx", "fieldtype": "Column Break", "label": "",             "insert_after": "custom_net_salarymonth"},
	{"fieldname": "custom_ctcannum",          "fieldtype": "Currency",   "label": "CTC/Annum",       "insert_after": "custom_column_break_tblrx"},
	{"fieldname": "custom_net_salaryannum",   "fieldtype": "Currency",   "label": "Net Salary/Annum", "insert_after": "custom_ctcannum"},
]


def execute():
	for field in CUSTOM_FIELDS:
		docname = f"Job Offer-{field['fieldname']}"
		if frappe.db.exists("Custom Field", docname):
			continue

		doc_dict = {
			"doctype": "Custom Field",
			"dt": "Job Offer",
			"fieldname": field["fieldname"],
			"fieldtype": field["fieldtype"],
			"label": field["label"],
			"insert_after": field["insert_after"],
		}
		if "options" in field:
			doc_dict["options"] = field["options"]

		frappe.get_doc(doc_dict).insert(ignore_permissions=True)

	frappe.db.commit()