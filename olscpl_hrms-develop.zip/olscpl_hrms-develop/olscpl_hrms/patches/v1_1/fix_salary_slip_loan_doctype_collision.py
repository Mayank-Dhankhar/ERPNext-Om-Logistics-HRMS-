# olscpl_hrms/patches/v1_1/fix_salary_slip_loan_doctype_collision.py
#
# The Loan/EMI feature's child doctype was named "Salary Slip Loan" -
# unknowingly colliding with a REAL standard doctype HRMS core already
# ships under that exact name (hrms/payroll/doctype/salary_slip_loan/,
# for HRMS's own optional integration with Frappe's separate "lending"
# app - fields loan/loan_product/loan_account/interest_income_account/
# etc., none of which we use). Because it's a real module doctype (not
# a Custom DocType), `bench migrate`'s disk-sync step re-asserts HRMS
# core's own field list on every migrate, so our fixture's differing
# 3-field version (employee_loan/installment_number/emi_amount) never
# actually took hold on any site that already had this doctype - the
# Salary Slip "loan" Table field just ended up pointing at HRMS core's
# unrelated "Loan"-app doctype instead, and since "Loan" isn't installed
# here, simply opening the Salary Slip list threw "Missing DocType -
# Field loan is referring to non-existing doctype Loan."
#
# Fixed by renaming our child doctype to "Salary Slip Loan EMI" (see
# fixtures/doctype.json) - a fixture sync then inserts it cleanly as a
# genuinely new record, same as any other new fixture. The one thing a
# fixture sync can't do is update the Salary Slip "loan" Custom Field's
# `options`, since that field already exists on any site this bug has
# shipped to - that's what this patch does.
import frappe


def execute():
	if not frappe.db.exists("Custom Field", "Salary Slip-loan"):
		return

	frappe.db.set_value("Custom Field", "Salary Slip-loan", "options", "Salary Slip Loan EMI")
	frappe.clear_cache(doctype="Salary Slip")
	frappe.db.commit()
