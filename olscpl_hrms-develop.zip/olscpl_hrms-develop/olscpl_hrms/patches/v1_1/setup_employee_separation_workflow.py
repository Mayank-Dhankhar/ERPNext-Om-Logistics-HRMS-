# olscpl_hrms/patches/v1_1/setup_employee_separation_workflow.py
#
# Phase 1 of replicating the SCM system's (scm.omlogistics.co.in,
# HRIS_EMPEXIT table) employee exit process onto stock hrms's Employee
# Separation doctype: the exit request itself and its 3-stage approval
# workflow (Employee -> Manager -> HR, or a Direct-HR fast path when HR
# initiates on the employee's behalf). Department clearance chain and
# Full & Final settlement are separate, later phases - not built here.
#
# Reference field mapping (SCM column -> our custom field):
#   EXIT_YTPE          -> exit_type
#   EXIT_REASON        -> exit_reason
#   LWD                -> last_working_day
#   MANGER_ID          -> separation_manager
#   EMP_COMMENT        -> employee_comment
#   MGR_COMMENT        -> manager_comment
#   MGR_APPROVAL_DATE  -> manager_approval_date
#   HR_COMMENT         -> hr_comment
#   HR_APPROVAL_DATE   -> hr_approval_date
#   REHIRE_ELIGIBLE    -> rehire_eligible
#   NOTIFY_EMAIL       -> notify_emails
#   STATE              -> workflow_state (Frappe's native Workflow feature,
#                         not a plain field - matches how this app already
#                         does Job Requisition/Leave Application approval)
import frappe
from frappe.permissions import add_permission, update_permission_property


def _grant(doctype, role, write=0, create=0, submit=0, read=1):
	if not frappe.db.exists("DocType", doctype):
		return
	add_permission(doctype, role, 0)
	update_permission_property(doctype, role, 0, "read", read)
	update_permission_property(doctype, role, 0, "write", write)
	update_permission_property(doctype, role, 0, "create", create)
	if submit:
		update_permission_property(doctype, role, 0, "submit", 1)


def _ensure_custom_field(doctype, fieldname, **kwargs):
	name = f"{doctype}-{fieldname}"
	if frappe.db.exists("Custom Field", name):
		return
	frappe.get_doc(
		{
			"doctype": "Custom Field",
			"dt": doctype,
			"fieldname": fieldname,
			**kwargs,
		}
	).insert(ignore_permissions=True)


def _ensure_workflow_state(state_name):
	if not frappe.db.exists("Workflow State", state_name):
		frappe.get_doc({"doctype": "Workflow State", "workflow_state_name": state_name}).insert(
			ignore_permissions=True
		)


def _ensure_workflow_action(action_name):
	if not frappe.db.exists("Workflow Action Master", action_name):
		frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": action_name}).insert(
			ignore_permissions=True
		)


def _ensure_workflow_transition(state, action, next_state, allowed):
	"""Add one more (state, action, allowed) transition row to the workflow
	if it's not already there - lets a role be added to an existing
	transition on a site where the Workflow doc was already created,
	without touching the other rows. Frappe workflows support multiple
	transition rows for the same state+action, each gated to a different
	role: the button shows if the user has ANY of them."""
	wf_name = "Employee Separation Workflow"
	if not frappe.db.exists("Workflow", wf_name):
		return
	wf = frappe.get_doc("Workflow", wf_name)
	exists = any(
		t.state == state and t.action == action and t.allowed == allowed for t in wf.transitions
	)
	if exists:
		return
	wf.append(
		"transitions",
		{"state": state, "action": action, "next_state": next_state, "allowed": allowed},
	)
	wf.save(ignore_permissions=True)


def execute():
	# ---- 0. Doctype permissions - only System Manager has any access to
	# Employee Separation out of the box (checked directly against the
	# stock hrms doctype JSON: no HR User/HR Manager/Employee/Manager
	# role at all), same gap this whole doctype has always had. ----
	_grant("Employee Separation", "HR Manager", write=1, create=1, submit=1)
	_grant("Employee Separation", "HR User", write=1, create=1, submit=1)
	_grant("Employee Separation", "Manager", write=1, create=0, submit=1)
	_grant("Employee Separation", "Employee", write=1, create=1)

	# ---- 1. Custom fields on Employee Separation ----
	_ensure_custom_field(
		"Employee Separation",
		"exit_type",
		label="Exit Type",
		fieldtype="Select",
		options="Via Manager\nDirect HR",
		default="Via Manager",
		insert_after="employee_separation_template",
	)
	_ensure_custom_field(
		"Employee Separation",
		"exit_reason",
		label="Exit Reason",
		fieldtype="Select",
		options=(
			"\nJob Location/Transfer\nPoor Performer\nBetter Opportunity\nAbscond\nFamily Issue\n"
			"Work Environment/Culture\nMisconduct\nPersonal\nCompany Policy\nOthers\nBlacklist\nExpired"
		),
		insert_after="exit_type",
	)
	_ensure_custom_field(
		"Employee Separation",
		"last_working_day",
		label="Last Working Day",
		fieldtype="Date",
		insert_after="exit_reason",
	)
	_ensure_custom_field(
		"Employee Separation",
		"separation_manager",
		label="Manager",
		fieldtype="Link",
		options="Employee",
		insert_after="last_working_day",
		description="The manager who approves this request - defaults from the employee's reports_to, but recorded explicitly here (like the reference system) so it stays accurate even if reporting lines change later.",
		# A site-configured User Permission restricting an employee to
		# "their own" Employee record (a common self-service HR setup, with
		# apply_to_all_doctypes on) would otherwise block them from ever
		# opening their own Employee Separation - this field almost never
		# equals their own id, that's the whole point of it. The custom
		# has_permission/permission_query_conditions hooks already
		# implement the real scoping rule (self/manager/HR) correctly on
		# their own; this stock mechanism was redundantly fighting them.
		ignore_user_permissions=1,
	)
	_ensure_custom_field(
		"Employee Separation",
		"employee_comment",
		label="Employee's Reason (in their own words)",
		fieldtype="Small Text",
		insert_after="separation_manager",
	)
	_ensure_custom_field(
		"Employee Separation",
		"manager_comment",
		label="Manager Comment",
		fieldtype="Small Text",
		insert_after="employee_comment",
	)
	_ensure_custom_field(
		"Employee Separation",
		"manager_approval_date",
		label="Manager Approval Date",
		fieldtype="Datetime",
		read_only=1,
		insert_after="manager_comment",
	)
	_ensure_custom_field(
		"Employee Separation",
		"hr_comment",
		label="HR Comment",
		fieldtype="Small Text",
		insert_after="manager_approval_date",
	)
	_ensure_custom_field(
		"Employee Separation",
		"hr_approval_date",
		label="HR Approval Date",
		fieldtype="Datetime",
		read_only=1,
		insert_after="hr_comment",
	)
	_ensure_custom_field(
		"Employee Separation",
		"rehire_eligible",
		label="Rehire Eligible",
		fieldtype="Select",
		options="\nYes\nNo",
		insert_after="hr_approval_date",
	)
	_ensure_custom_field(
		"Employee Separation",
		"notify_emails",
		label="Additional Notify Emails",
		fieldtype="Data",
		insert_after="rehire_eligible",
	)

	# separation_manager's ignore_user_permissions=1 above only takes for a
	# brand-new field - a site where it already existed before that change
	# needs its own retroactive fixup, same idempotent-update pattern used
	# throughout this file (e.g. _ensure_workflow_transition).
	if frappe.db.exists("Custom Field", "Employee Separation-separation_manager"):
		frappe.db.set_value(
			"Custom Field", "Employee Separation-separation_manager", "ignore_user_permissions", 1
		)

	# The stock "employee" field on Employee Separation is owned by hrms,
	# not this app - a Property Setter (not a direct edit of hrms's own
	# doctype file) is the correct way to override one property on it
	# without touching apps/hrms. Same reasoning as separation_manager
	# above: a manager/approver reading this record via their own role
	# (not because they ARE the resigning employee) can be blocked by an
	# unrelated User Permission scoped to their own Employee id, since
	# this field points at someone else entirely from their perspective.
	if not frappe.db.exists(
		"Property Setter", {"doc_type": "Employee Separation", "field_name": "employee", "property": "ignore_user_permissions"}
	):
		frappe.get_doc(
			{
				"doctype": "Property Setter",
				"doctype_or_field": "DocField",
				"doc_type": "Employee Separation",
				"field_name": "employee",
				"property": "ignore_user_permissions",
				"property_type": "Check",
				"value": "1",
			}
		).insert(ignore_permissions=True)

	# ---- 2. Workflow states/actions (idempotent masters, same convention
	# as this app's existing Leave Application/Job Requisition workflows) ----
	for state in ("Initiated", "Submitted to Manager", "Submitted to HR", "Signed Off", "Rejected"):
		_ensure_workflow_state(state)
	for action in ("Submit to Manager", "Submit to HR Directly", "Approve", "Reject", "Send Back"):
		_ensure_workflow_action(action)

	# ---- 3. The workflow itself ----
	if not frappe.db.exists("Workflow", "Employee Separation Workflow"):
		wf = frappe.get_doc(
			{
				"doctype": "Workflow",
				"workflow_name": "Employee Separation Workflow",
				"document_type": "Employee Separation",
				"workflow_state_field": "workflow_state",
				"is_active": 1,
				"send_email_alert": 0,
				"states": [
					{"state": "Initiated", "doc_status": "0", "allow_edit": "Employee"},
					{"state": "Submitted to Manager", "doc_status": "0", "allow_edit": "Manager"},
					{"state": "Submitted to HR", "doc_status": "0", "allow_edit": "HR Manager"},
					{"state": "Signed Off", "doc_status": "1", "allow_edit": "HR Manager"},
					{"state": "Rejected", "doc_status": "0", "allow_edit": "HR Manager"},
				],
				"transitions": [
					{
						"state": "Initiated",
						"action": "Submit to Manager",
						"next_state": "Submitted to Manager",
						"allowed": "Employee",
					},
					{
						# The reference system's "Direct-HR" fast path - HR
						# initiates and signs off without a manager stage.
						"state": "Initiated",
						"action": "Submit to HR Directly",
						"next_state": "Submitted to HR",
						"allowed": "HR Manager",
					},
					{
						# Employees can also skip straight to HR themselves
						# (same action name/next_state as the HR Manager row
						# above - two rows, one per role, both visible to
						# whichever role the logged-in user actually has).
						"state": "Initiated",
						"action": "Submit to HR Directly",
						"next_state": "Submitted to HR",
						"allowed": "Employee",
					},
					{
						"state": "Submitted to Manager",
						"action": "Approve",
						"next_state": "Submitted to HR",
						"allowed": "Manager",
					},
					{
						"state": "Submitted to Manager",
						"action": "Reject",
						"next_state": "Rejected",
						"allowed": "Manager",
					},
					{
						"state": "Submitted to Manager",
						"action": "Send Back",
						"next_state": "Initiated",
						"allowed": "Manager",
					},
					{
						"state": "Submitted to HR",
						"action": "Approve",
						"next_state": "Signed Off",
						"allowed": "HR Manager",
					},
					{
						"state": "Submitted to HR",
						"action": "Reject",
						"next_state": "Rejected",
						"allowed": "HR Manager",
					},
					{
						"state": "Submitted to HR",
						"action": "Send Back",
						"next_state": "Initiated",
						"allowed": "HR Manager",
					},
				],
			}
		)
		wf.insert(ignore_permissions=True)

	# Employee-role "Submit to HR Directly" row - added after the fact, so
	# a site where the workflow already existed before this needs its own
	# idempotent fixup rather than relying on the fresh-install list above.
	_ensure_workflow_transition("Initiated", "Submit to HR Directly", "Submitted to HR", "Employee")

	# ---- 4. "Initiate Clearance" / "Clearance Status" button on the
	# Employee Separation form - without this the whole clearance chain
	# (initiate_clearance(), Employee Separation Clearance) is real but
	# invisible: nothing on the Employee Separation record itself points
	# to it or explains it exists. ----
	_ensure_clearance_button_client_script()

	# ---- 5. Exit dashboard charts (monthly count + reason breakdown)
	# above the Employee Separation list view - matches the reference
	# system's own "Yearly exit dashboard" / "Reason Analysis" charts. ----
	_ensure_exit_dashboard_client_script()

	# ---- 6. Full & Final settlement - stock hrms already has a real,
	# working Full and Final Statement doctype (auto-pulls Gratuity,
	# Leave Encashment, Bonus, Expense Claims, Employee Advances, asset
	# recovery; generates a real Journal Entry; proper Paid/Unpaid
	# submit workflow) - an earlier pass here built a second, separate
	# doctype duplicating this by hand with static fields and no real
	# calculation logic, instead of just connecting to what already
	# exists. This field is the only thing actually missing from the
	# stock doctype to make that connection - everything else (its
	# permissions included) was already there. ----
	_ensure_custom_field(
		"Full and Final Statement",
		"employee_separation",
		label="Employee Separation",
		fieldtype="Link",
		options="Employee Separation",
		insert_after="employee_name",
		ignore_user_permissions=1,
	)

	frappe.db.commit()

CLEARANCE_BUTTON_SCRIPT = r"""frappe.ui.form.on("Employee Separation", {
	refresh: function (frm) {
		if (frm.is_new() || !frm.doc.workflow_state) {
			return;
		}

		frappe.db.get_list("Employee Separation Clearance", {
			filters: { employee_separation: frm.doc.name },
			fields: ["name", "status"],
			limit: 0,
		}).then((rows) => {
			if (rows && rows.length) {
				const cleared = rows.filter((r) => r.status === "Cleared").length;
				frm.add_custom_button(
					__("Clearance Status ({0}/{1} Cleared)", [cleared, rows.length]),
					function () {
						show_clearance_status_dialog(frm);
					}
				);
			} else if (
				frm.doc.workflow_state === "Signed Off" &&
				(frappe.user.has_role("HR Manager") || frappe.user.has_role("HR User"))
			) {
				frm.add_custom_button(__("Initiate Clearance"), function () {
					show_initiate_clearance_dialog(frm);
				});
			}
		});

		if (
			frm.doc.boarding_status === "Completed" &&
			(frappe.user.has_role("HR Manager") || frappe.user.has_role("HR User"))
		) {
			frappe.db.get_value(
				"Full and Final Statement",
				{ employee_separation: frm.doc.name },
				"name"
			).then((r) => {
				if (r.message && r.message.name) {
					frm.add_custom_button(__("View Full & Final Settlement"), function () {
						frappe.set_route("Form", "Full and Final Statement", r.message.name);
					});
				} else {
					frm.add_custom_button(__("Start Full & Final Settlement"), function () {
						// Full and Final Statement.relieving_date is fetch_from
						// employee.relieving_date (read-only) - it can't be
						// prefilled directly on the new form, the Employee
						// record needs it set first, which is what this call
						// does (from our own last_working_day) before opening
						// the new form, so the stock doctype's own
						// before_insert (get_outstanding_statements) can
						// actually auto-pull Gratuity/Leave Encashment/Bonus
						// etc. right away instead of erroring for a missing
						// relieving_date.
						frappe.call({
							method: "olscpl_hrms.events.employee_separation.prepare_full_and_final",
							args: { employee_separation: frm.doc.name },
							freeze: true,
							callback: function () {
								frappe.new_doc("Full and Final Statement", {
									employee_separation: frm.doc.name,
									employee: frm.doc.employee,
								});
							},
						});
					});
				}
			});
		}
	},
});

const CLEARANCE_TYPES = [
	"Manager and Department",
	"Accounts",
	"Audit",
	"Admin",
	"PTP CCD",
	"POD (DBP Dept.)",
	"IT",
	"TDS",
	"Regional HR",
];

function show_initiate_clearance_dialog(frm) {
	const fields = CLEARANCE_TYPES.map((type) => ({
		fieldname: "approver_" + frappe.scrub(type),
		fieldtype: "Link",
		options: "Employee",
		label: type,
		reqd: 1,
		default: type === "Manager and Department" ? frm.doc.separation_manager : undefined,
	}));

	const dialog = new frappe.ui.Dialog({
		title: __("Initiate No-Dues Clearance"),
		fields: fields,
		primary_action_label: __("Initiate"),
		primary_action: function (values) {
			const approvers = {};
			CLEARANCE_TYPES.forEach((type) => {
				approvers[type] = values["approver_" + frappe.scrub(type)];
			});
			frappe.call({
				method: "olscpl_hrms.events.employee_separation.initiate_clearance",
				args: {
					employee_separation: frm.doc.name,
					approvers: approvers,
				},
				freeze: true,
				callback: function (r) {
					if (r.message) {
						dialog.hide();
						frappe.show_alert({
							message: __("Clearance initiated - {0} stages created.", [r.message.created.length]),
							indicator: "green",
						});
						frm.reload_doc();
					}
				},
			});
		},
	});
	dialog.show();
}

// Shows every clearance stage for this separation in one table - status
// and remarks are only ever rendered as editable inputs for a stage the
// viewer is actually allowed to change (their own assigned stage, or
// HR); everyone else, including the resigning employee looking at their
// own progress, sees plain read-only text. The server enforces this for
// real (update_clearance_rows re-checks permission per row, and the
// doctype's own validate() is the final backstop) - the editable flag
// here only controls what gets rendered as an input in the first place.
function show_clearance_status_dialog(frm) {
	frappe.call({
		method: "olscpl_hrms.events.employee_separation.get_clearance_status",
		args: { employee_separation: frm.doc.name },
		freeze: true,
		callback: function (r) {
			render_clearance_status_dialog(frm, r.message || []);
		},
	});
}

function render_clearance_status_dialog(frm, rows) {
	const STATUS_OPTIONS = ["Pending", "Cleared"];

	function status_cell(row) {
		if (!row.editable) {
			const color = row.status === "Cleared" ? "green" : "orange";
			return `<span class="indicator-pill ${color}" style="white-space: nowrap;">${__(row.status)}</span>`;
		}
		const options = STATUS_OPTIONS.map(
			(s) => `<option value="${s}" ${s === row.status ? "selected" : ""}>${__(s)}</option>`
		).join("");
		return `<select class="form-control form-control-sm clearance-status-input">${options}</select>`;
	}

	function remarks_cell(row) {
		const value = frappe.utils.escape_html(row.remarks || "");
		if (!row.editable) {
			return `<span class="text-muted">${value || "-"}</span>`;
		}
		return `<input type="text" class="form-control form-control-sm clearance-remarks-input" value="${value}" placeholder="${__("Remarks")}">`;
	}

	function row_html(row) {
		return `<tr data-name="${row.name}" data-editable="${row.editable ? 1 : 0}">
			<td>${frappe.utils.escape_html(row.clearance_type)}</td>
			<td>${frappe.utils.escape_html(row.approver_name || row.approver || "")}</td>
			<td>${status_cell(row)}</td>
			<td>${remarks_cell(row)}</td>
		</tr>`;
	}

	const $table = $(`<div class="clearance-status-table-wrapper">
		<table class="table table-bordered" style="margin-bottom: 0;">
			<thead>
				<tr>
					<th>${__("Clearance Type")}</th>
					<th>${__("Approver")}</th>
					<th style="width: 140px;">${__("Status")}</th>
					<th>${__("Remarks")}</th>
				</tr>
			</thead>
			<tbody>
				${rows.map(row_html).join("")}
			</tbody>
		</table>
	</div>`);

	const dialog = new frappe.ui.Dialog({
		title: __("Clearance Status"),
		size: "large",
		fields: [{ fieldtype: "HTML", fieldname: "clearance_table_html" }],
		primary_action_label: __("Save Changes"),
		secondary_action_label: __("Download PDF"),
		secondary_action: function () {
			window.open(
				"/api/method/olscpl_hrms.events.employee_separation.download_clearance_pdf?employee_separation=" +
					encodeURIComponent(frm.doc.name),
				"_blank",
			);
		},
		primary_action: function () {
			const updates = [];
			$table.find('tr[data-editable="1"]').each(function () {
				updates.push({
					name: $(this).attr("data-name"),
					status: $(this).find(".clearance-status-input").val(),
					remarks: $(this).find(".clearance-remarks-input").val(),
				});
			});

			if (!updates.length) {
				dialog.hide();
				return;
			}

			frappe.call({
				method: "olscpl_hrms.events.employee_separation.update_clearance_rows",
				args: { updates: updates },
				freeze: true,
				callback: function (r) {
					const results = r.message || [];
					const failed = results.filter((x) => !x.ok);
					if (failed.length) {
						frappe.msgprint({
							title: __("Some updates failed"),
							message: failed.map((f) => `${f.name}: ${f.error}`).join("<br>"),
							indicator: "red",
						});
					} else {
						frappe.show_alert({ message: __("Clearance updated."), indicator: "green" });
					}
					dialog.hide();
					frm.reload_doc();
				},
			});
		},
	});

	dialog.fields_dict.clearance_table_html.$wrapper.html($table);
	dialog.show();

	if (!rows.some((row) => row.editable)) {
		// Nobody who can even open this dialog can change anything shown
		// in it (e.g. the resigning employee viewing their own progress) -
		// a "Save Changes" button with nothing to save is just confusing.
		dialog.get_primary_btn().hide();
	}
}
"""


def _ensure_clearance_button_client_script():
	name = "Employee Separation Clearance Button"
	if frappe.db.exists("Client Script", name):
		frappe.db.set_value("Client Script", name, "script", CLEARANCE_BUTTON_SCRIPT)
		return
	frappe.get_doc(
		{
			"doctype": "Client Script",
			"name": name,
			"dt": "Employee Separation",
			"view": "Form",
			"script": CLEARANCE_BUTTON_SCRIPT,
			"enabled": 1,
		}
	).insert(ignore_permissions=True)


EXIT_DASHBOARD_SCRIPT = r"""frappe.listview_settings["Employee Separation"] = frappe.listview_settings["Employee Separation"] || {};
frappe.listview_settings["Employee Separation"].onload = function (listview) {
	if (listview.$exit_dashboard_added) {
		return;
	}
	listview.$exit_dashboard_added = true;

	// Explicit inline colors rather than .btn-primary/.btn-default - this
	// app's own theme (and arjun_theme, loaded after it) both re-theme
	// .btn-primary to their own accent color, not a plain blue, so
	// depending on that class here would inherit whichever one wins the
	// cascade instead of what was actually asked for.
	const ACTIVE_BLUE = "#2490ef";
	const INACTIVE_STYLE = "background-color: #ffffff; color: #36414c; border: 1px solid #d1d8dd;";
	const ACTIVE_STYLE = `background-color: ${ACTIVE_BLUE}; color: #ffffff; border: 1px solid ${ACTIVE_BLUE};`;
	const REASON_COLORS = ["#7cd6fd", "#ffa00a", "#ff5858", "#743ee2", ACTIVE_BLUE, "#98d85b", "#00b6c7"];

	const current_year = new Date().getFullYear();
	// A fixed 6-year window (this year plus the 5 before it) rather than
	// querying the real min/max years with data - simpler, one less
	// round trip, and comfortably covers realistic usage without ever
	// showing a year that's obviously too far out to matter.
	const YEAR_OPTIONS = [0, 1, 2, 3, 4, 5].map((i) => current_year - i);

	const $wrapper = $(
		`<div class="exit-dashboard-charts" style="margin-bottom: 24px;">
			<div class="exit-dashboard-tabs flex align-items-center" style="margin-bottom: 12px; justify-content: space-between;">
				<div>
					<button type="button" class="btn btn-sm" data-tab="month" style="${ACTIVE_STYLE}">${__("Month-wise Analysis")}</button>
					<button type="button" class="btn btn-sm" data-tab="reason" style="${INACTIVE_STYLE}">${__("Reason Analysis")}</button>
				</div>
				<select class="form-control form-control-sm" id="exit-dashboard-year" style="width: auto;">
					${YEAR_OPTIONS.map(
						(y) => `<option value="${y}" ${y === current_year ? "selected" : ""}>${y}</option>`
					).join("")}
				</select>
			</div>
			<div id="exit-dashboard-chart" style="width: 100%;"></div>
			<div id="exit-dashboard-legend" style="display: flex; flex-wrap: wrap; gap: 16px 28px; justify-content: center; margin-top: 8px;"></div>
		</div>`
	);
	listview.$frappe_list.prepend($wrapper);

	const months = [
		__("January"), __("February"), __("March"), __("April"), __("May"), __("June"),
		__("July"), __("August"), __("September"), __("October"), __("November"), __("December"),
	];

	let active_tab = "month";
	let active_data = null;
	let active_year = current_year;

	function render_month_chart() {
		$("#exit-dashboard-chart").empty();
		$("#exit-dashboard-legend").empty();
		new frappe.Chart("#exit-dashboard-chart", {
			title: __("Yearly Exit Dashboard ({0})", [active_year]),
			data: {
				labels: months,
				datasets: [{ name: __("Exit Requests"), values: active_data.monthly }],
			},
			type: "bar",
			height: 300,
			colors: [ACTIVE_BLUE],
		});
	}

	function render_reason_chart() {
		$("#exit-dashboard-chart").empty();
		$("#exit-dashboard-legend").empty();
		if (!active_data.reasons || !active_data.reasons.length) {
			$("#exit-dashboard-chart").html(`<p class="text-muted">${__("No data yet")}</p>`);
			return;
		}
		new frappe.Chart("#exit-dashboard-chart", {
			title: __("Reason Analysis ({0})", [active_year]),
			data: {
				labels: active_data.reasons.map((x) => x.label),
				datasets: [{ values: active_data.reasons.map((x) => x.count) }],
			},
			type: "pie",
			height: 300,
			colors: REASON_COLORS,
			// frappe-charts' own pie/donut legend divides the total
			// width evenly across items by column count, not by
			// actual text width - long labels like "Better
			// Opportunity" run straight into the next item. A plain
			// HTML legend below (built next) doesn't have that
			// problem, so the built-in one is switched off here.
			showLegend: 0,
		});
		active_data.reasons.forEach((item, i) => {
			const color = REASON_COLORS[i % REASON_COLORS.length];
			$("#exit-dashboard-legend").append(
				`<div style="display:flex; align-items:center; gap:8px; font-size:13px;">
					<span style="width:12px; height:12px; border-radius:2px; background:${color}; display:inline-block; flex-shrink:0;"></span>
					<span><b>${frappe.utils.escape_html(item.label)}</b> (${item.count})</span>
				</div>`
			);
		});
	}

	function render_active_tab() {
		if (active_tab === "month") {
			render_month_chart();
		} else {
			render_reason_chart();
		}
	}

	function load_year(year) {
		frappe.call({
			method: "olscpl_hrms.events.employee_separation.get_exit_dashboard_data",
			args: { year: year },
			callback: function (r) {
				if (!r.message) {
					return;
				}
				active_data = r.message;
				active_year = year;
				render_active_tab();
			},
		});
	}

	$wrapper.on("click", "button[data-tab]", function () {
		active_tab = $(this).data("tab");
		$wrapper.find("button[data-tab]").attr("style", INACTIVE_STYLE);
		$(this).attr("style", ACTIVE_STYLE);
		render_active_tab();
	});

	$wrapper.on("change", "#exit-dashboard-year", function () {
		load_year(parseInt($(this).val(), 10));
	});

	load_year(current_year);
};
"""


def _ensure_exit_dashboard_client_script():
	name = "Employee Separation Exit Dashboard Charts"
	if frappe.db.exists("Client Script", name):
		frappe.db.set_value("Client Script", name, "script", EXIT_DASHBOARD_SCRIPT)
		return
	frappe.get_doc(
		{
			"doctype": "Client Script",
			"name": name,
			"dt": "Employee Separation",
			"view": "List",
			"script": EXIT_DASHBOARD_SCRIPT,
			"enabled": 1,
		}
	).insert(ignore_permissions=True)
