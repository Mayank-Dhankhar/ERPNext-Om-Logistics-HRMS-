# olscpl_hrms/patches/v1_1/setup_osbs_flexi_structure.py
#
# RapidShyp (OPEN SOURCE BUSINESS SOLUTIONS PVT LTD) Flexi Benefit Plan: the
# "OSBS Flexi Benefit Structure" Salary Structure. Separate from the gross-based
# "OSBS Base-Salary-Based Structure" (setup_rapidshyp_salary_structure.py) and
# the formula-free "OSBS-Manual Salary Structure", which stay as they are.
#
# The Salary Structure Assignment's Base is the MONTHLY gross. As on HR's payroll
# structure sheet (RapidShyp-Salary Structure.xlsx); the bucket is its "Flexi Pay"
# line (10% of gross), for gross >= 1,00,000 only:
#   Basic             = 50% of Base                       (to the rupee)
#   HRA               = 40% of Base                       (to the rupee)
#   each FBP benefit  = the employee's chosen ANNUAL amount / 12 (to the rupee)
#   Special Allowance = Base - Basic - HRA - the benefits (taxable balance)
# The chosen annual amounts sit in the fbp_* fields of the Assignment, written
# by an FBP Declaration (add_fbp_custom_fields.py). "(x or 0)" keeps a formula
# valid for an Assignment whose fields were never filled - all of the bucket
# then comes out as Special Allowance. Special Allowance is written out in full
# (not from the other rows' abbreviations) so it never depends on how those
# components were abbreviated; the FBP Declaration checks the chosen amounts
# fit, so it cannot go negative.
#
# The benefits are the components the Manual structure already pays (so slips
# read the same); only one that does not exist is created, with the tax flag on.
# Which of them are tax-exempt, and on what proof, is HR's / the CA's call - set
# it on the Salary Component.
#
# Deductions: the same rows, in the same order, as the other OSBS structure but
# with no formulas - PF, ESI, PT, TDS etc. are filled by the salary slip steps
# (events/salary_slip_steps.py treats this structure like the OSBS ones there).
#
# Idempotent; does nothing if the company doesn't exist; never touches an
# existing structure of that name (it may be in use).
import frappe

from olscpl_hrms.utils.fbp_slabs import (
	BALANCE_COMPONENT,
	BASIC_COMPONENT,
	BASIC_RATE,
	COMPONENT_FIELD_MAP,
	FBP_COMPANY,
	FBP_COMPONENT_ABBR,
	FLEXI_SALARY_STRUCTURE,
	HRA_COMPONENT,
	HRA_RATE,
	TOTAL_FIELD,
)

# same order as the other OSBS structure's deductions, minus every formula
DEDUCTIONS = [
	"Provident Fund",
	"ESIC",
	"Professional Tax",
	"LWF",
	"TDS",
	"VPF",
	"ADVANCE",
	"LOAN",
	"MOBILE_DED",
	"Other Deductions",
	"DRF",
	"Medical Insurance",
	"ACCOM",
]

BASIC_FORMULA = f"round(base * {BASIC_RATE})"
HRA_FORMULA = f"round(base * {HRA_RATE})"


def _benefit_formula(fieldname):
	return f"round(({fieldname} or 0) / 12)"


def _special_formula():
	benefits = " + ".join(_benefit_formula(f) for f in COMPONENT_FIELD_MAP.values())
	return f"base - {BASIC_FORMULA} - {HRA_FORMULA} - ({benefits})"


def _earnings():
	rows = [(BASIC_COMPONENT, BASIC_FORMULA), (HRA_COMPONENT, HRA_FORMULA)]
	for component, fieldname in COMPONENT_FIELD_MAP.items():
		rows.append((component, _benefit_formula(fieldname)))
	rows.append((BALANCE_COMPONENT, _special_formula()))
	return rows


def _ensure_component(name):
	if frappe.db.exists("Salary Component", name):
		return
	abbr = FBP_COMPONENT_ABBR[name]
	# abbreviations are unique across Salary Components - never fail a migrate
	# over a clash, just number it
	taken = abbr
	n = 1
	while frappe.db.exists("Salary Component", {"salary_component_abbr": taken}):
		n += 1
		taken = f"{abbr}{n}"

	values = {
		"doctype": "Salary Component",
		"salary_component": name,
		"salary_component_abbr": taken,
		"type": "Earning",
		"is_tax_applicable": 1,
		"depends_on_payment_days": 0,
		"exempted_from_income_tax": 0,
	}
	meta = frappe.get_meta("Salary Component")
	values = {k: v for k, v in values.items() if k == "doctype" or meta.has_field(k)}
	frappe.get_doc(values).insert(ignore_permissions=True)


def _row(component, formula=None):
	return {
		"salary_component": component,
		"abbr": frappe.db.get_value("Salary Component", component, "salary_component_abbr"),
		"amount_based_on_formula": 1 if formula else 0,
		"formula": formula,
		"amount": 0,
		"do_not_include_in_total": 0,
		# the salary slip steps prorate every earning for LWP themselves
		"depends_on_payment_days": 0,
	}


def execute():
	if not frappe.db.exists("Company", FBP_COMPANY):
		return
	if frappe.db.exists("Salary Structure", FLEXI_SALARY_STRUCTURE):
		return

	for component in COMPONENT_FIELD_MAP:
		_ensure_component(component)

	# Basic / HRA / Special Allowance are core to every structure; without them
	# there is nothing sensible to build
	for core in (BASIC_COMPONENT, HRA_COMPONENT, BALANCE_COMPONENT):
		if not frappe.db.exists("Salary Component", core):
			frappe.log_error(f"Salary Component {core} not found; {FLEXI_SALARY_STRUCTURE} not created", "FBP setup")
			return

	ss = frappe.get_doc(
		{
			"doctype": "Salary Structure",
			"name": FLEXI_SALARY_STRUCTURE,
			"__newname": FLEXI_SALARY_STRUCTURE,
			"company": FBP_COMPANY,
			"payroll_frequency": "Monthly",
			"currency": frappe.db.get_value("Company", FBP_COMPANY, "default_currency") or "INR",
			"is_active": "Yes",
			"earnings": [_row(c, f) for c, f in _earnings()],
			"deductions": [_row(c) for c in DEDUCTIONS if frappe.db.exists("Salary Component", c)],
		}
	)
	ss.insert(ignore_permissions=True)
	ss.submit()
