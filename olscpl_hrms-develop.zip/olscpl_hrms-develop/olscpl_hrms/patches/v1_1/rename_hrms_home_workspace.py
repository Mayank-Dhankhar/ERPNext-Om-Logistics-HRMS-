# olscpl_hrms/patches/v1_1/rename_hrms_home_workspace.py
#
# The home workspace was only re-titled "Atlas Home" - its name, and so its
# URL, stayed "Hrms Home" (/app/hrms-home), and Frappe's sidebar links by
# title, so /app/atlas-home was "not found". Rename the record itself.
# pre_model_sync: before workspace/atlas_home/atlas_home.json and the
# fixture (both now "Atlas Home") are synced, so they update this record
# instead of adding a second one.
import frappe

OLD, NEW = "Hrms Home", "Atlas Home"


def execute():
	if not frappe.db.exists("Workspace", OLD) or frappe.db.exists("Workspace", NEW):
		return
	frappe.rename_doc("Workspace", OLD, NEW, force=True)
	frappe.db.set_value("Workspace", NEW, {"label": NEW, "title": NEW}, update_modified=False)
