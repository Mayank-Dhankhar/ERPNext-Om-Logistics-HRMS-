# olscpl_hrms/patches/v1_1/add_company_branch_code_fields.py
#
# Adds the legacy ERP code straight onto the two core doctypes it belongs
# to - no separate master doctype.
#
# Company: matched by name against data/company_master.csv (trimmed from
# the legacy export - just company_code + company_name), normalized (case/
# punctuation/whitespace only - never fuzzy), plus a short hand-verified
# override list for the handful whose wording differs too much for that
# (typos, "Ltd"/"Limited", an abbreviated legal name) - every pair in that
# list was checked against the actual CSV row, not guessed.
#
# Branch: every existing Branch record is already named "<code> - <name>"
# (e.g. "102 - PARWANOO-H P") - that leading number is used directly as the
# branch code, for every record (100% coverage, no CSV lookup involved).
#
# This was previously matched against branch_master.csv by name instead
# (only ~57% of records had a unique name match - the rest were either
# ambiguous or simply weren't in the CSV), which for most records agreed
# with this same leading number anyway; where it didn't, that CSV name
# match was arguably the more "correct" per-branch code (the prefix is, in
# a few cases, actually a different/incompatible hub-level code) - but the
# simple, always-available, always-consistent source is this prefix, which
# is what's used now.
import csv
import os
import re

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data")

# Existing Company name -> legacy company code, for the handful confirmed
# by hand to be the same company under a different spelling/wording than
# normalized matching can bridge.
MANUAL_COMPANY_CODE_OVERRIDES = {
	"OM AIR FRIEGHT LTD": "400004",  # vs CSV's "OM AIR FREIGHT LTD."
	"OMX INFO. MANAGEMENT PVT LTD": "400005",  # vs CSV's "OMX INFO MANAGEMENT"
	"OM TRANS LOGISTICS LTD": "400006",  # vs CSV's "OMTRANS LOGISTICS LTD"
	"OM LOGISTICS NEPAL PVT LTD": "400008",  # vs CSV's "OM LOGISTICS PVT LTD. NEPAL"
	"OM TRAX PACKING SOLUTIONS PVT LTD": "400009",  # vs CSV's "OM TRAX PACKAGING SOLUTIONS LTD."
	"DAIL LOGISTICS PVT LTD": "400010",  # vs CSV's "DIAL LOGISTICS PVT LTD."
	"OM INSTITUTE OF LOGISTICS AND SUPPLY CHAIN PVT LTD": "400012",  # vs CSV's much longer full legal name
	"OM TRAX MANAGEMENT SERVICE LTD": "400017",  # vs CSV's "OM TRAX MANAGEMENT SERVICES LIMITED"
}


def execute():
	_add_custom_fields()
	_backfill_company_codes()
	_backfill_branch_codes()
	frappe.db.commit()


def _read_csv(filename):
	path = os.path.join(_DATA_DIR, filename)
	with open(path, newline="", encoding="utf-8") as f:
		return list(csv.DictReader(f))


def _add_custom_fields():
	create_custom_fields(
		{
			"Company": [
				{
					"fieldname": "custom_company_code",
					"fieldtype": "Data",
					"label": "Company Code",
					"insert_after": "company_name",
				}
			],
			"Branch": [
				{
					"fieldname": "custom_branch_code",
					"fieldtype": "Data",
					"label": "Branch Code",
					"insert_after": "branch",
				}
			],
		},
		ignore_validate=frappe.flags.in_patch,
	)


def _normalize(name):
	name = re.sub(r"[.,]", "", name or "")
	name = re.sub(r"\s+", " ", name)
	return name.strip().upper()


def _backfill_company_codes():
	code_by_name = {}
	for row in _read_csv("company_master.csv"):
		code_by_name.setdefault(_normalize(row["company_name"]), row["company_code"])

	for row in frappe.get_all("Company", fields=["name", "company_name", "custom_company_code"]):
		if row.custom_company_code:
			continue
		code = MANUAL_COMPANY_CODE_OVERRIDES.get(row.name) or code_by_name.get(_normalize(row.company_name))
		if code:
			frappe.db.set_value("Company", row.name, "custom_company_code", code, update_modified=False)


def _backfill_branch_codes():
	for row in frappe.get_all("Branch", pluck="name"):
		match = re.match(r"^(\d+)\s*-\s*", row)
		if match:
			frappe.db.set_value("Branch", row, "custom_branch_code", match.group(1), update_modified=False)
