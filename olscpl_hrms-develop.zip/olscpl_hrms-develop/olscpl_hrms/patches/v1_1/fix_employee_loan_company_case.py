# olscpl_hrms/patches/v1_1/fix_employee_loan_company_case.py
#
# Opening-balance Employee Loans were imported with the company as
# "OM Logistics Supply Chain Pvt. Ltd."; the Company is named "... PVT. LTD.".
# MariaDB compares case-insensitively, so the link passed - but saving a
# submitted loan (Salary Slip submit marks its EMI paid) normalises the link
# to the real name, and "Company" cannot change after submit, so the slip
# fails to submit. Set every loan's company to the Company's exact name.
import frappe


def execute():
	if not frappe.db.table_exists("Employee Loan"):
		return
	frappe.db.sql("""
		UPDATE `tabEmployee Loan` l JOIN `tabCompany` c ON c.name = l.company
		SET l.company = c.name
		WHERE BINARY l.company != BINARY c.name
	""")
