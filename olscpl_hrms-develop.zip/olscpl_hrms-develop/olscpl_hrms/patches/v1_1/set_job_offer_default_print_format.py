# olscpl_hrms/patches/v1_1/set_job_offer_default_print_format.py
#
# The "Letter of Intent" Print Format (fixtures/print_format.json) already
# exists for Job Offer and renders a proper candidate LOI + Salary
# Structure via get_letter_of_intent_print_html() - but nothing pointed
# Job Offer's Print/PDF at it, so it silently fell back to Frappe's
# generic "Standard" format (a plain field-by-field dump: every Data field
# boxed on its own, no real layout) whenever HR printed a Job Offer
# without manually picking "Letter of Intent" from the dropdown first -
# that generic dump is what the boxed NAME/DESIGNATION/DATE OF JOINING/
# LOCATION cells and misaligned Salary Structure table actually were.
#
# Job Offer is a standard (non-custom) hrms doctype, so this has to go
# through a Property Setter, not a direct DocType edit (that would need
# developer_mode) - same pattern already used in
# add_full_and_final_settlement_print_format.py for the same reason.
import frappe

PRINT_FORMAT_NAME = "Letter of Intent"


def execute():
	doc_type = "Job Offer"

	if not frappe.db.exists("Print Format", PRINT_FORMAT_NAME):
		# Fixture hasn't landed yet on this site (migrate order/first
		# install) - nothing to point at yet, patches.txt reruns this on
		# every migrate so it'll catch up once it does.
		return

	# A Property Setter overrides the DocType's meta, not the tabDocType
	# row itself - frappe.db.get_value("DocType", ...) would keep reading
	# the raw (untouched, still-None) column forever and never see this
	# take effect, making that check always fail and re-run the insert
	# below on every single migrate. get_meta() is what actually merges
	# Property Setter overrides in, and is also literally what Job
	# Offer's own Print view reads to pick the default - the same source
	# of truth this patch exists to change.
	if frappe.get_meta(doc_type).get("default_print_format") == PRINT_FORMAT_NAME:
		return

	property_setter_name = f"{doc_type}-main-default_print_format"
	if frappe.db.exists("Property Setter", property_setter_name):
		frappe.db.set_value("Property Setter", property_setter_name, "value", PRINT_FORMAT_NAME)
	else:
		from frappe.custom.doctype.property_setter.property_setter import make_property_setter

		make_property_setter(
			doc_type,
			fieldname=None,
			property="default_print_format",
			value=PRINT_FORMAT_NAME,
			property_type="Data",
			for_doctype=True,
		)

	frappe.clear_cache(doctype=doc_type)
	frappe.db.commit()
