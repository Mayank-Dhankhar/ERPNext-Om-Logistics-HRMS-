# olscpl_hrms/patches/v1_1/add_full_and_final_statement_automation_fields.py
#
# Adds the "Fetch Last Month Details" button that automates what used to be
# entirely manual entry on Full and Final Statement (see
# olscpl_hrms.overrides.full_and_final_statement.CustomFullandFinalStatement
# .fetch_last_month_details): Days Worked + the salary-breakup Dues fields
# that have a real Salary Component source, EPF/ESI/TDS Deductions,
# Loan/Advance (from the core Receivables table), and Excess Leave
# (Days + Amount, from the Leave Ledger). Fields with no clean system
# source (Edu. Allowance dues, LWF/P.F. Tax, Notice, Deduction from A/C,
# SPL1/DRF/CAB/FOOD/ACCM, Other) stay manual - the button never touches
# them.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields(get_custom_fields(), ignore_validate=frappe.flags.in_patch)


def get_custom_fields():
	return {
		"Full and Final Statement": [
			{
				"fieldname": "custom_dues_breakup_section",
				"fieldtype": "Section Break",
				"label": "Salary/Wages Payable for Last Month",
				"insert_after": "custom_rop_total",
				"collapsible": 1,
				"description": (
					"Click 'Fetch Last Month Details' to auto-fill Days Worked, the "
					"salary components below with a matching Salary Component, and "
					"EPF/ESI/TDS/Loan-Advance/Excess-Leave under Deductions. Fields "
					"with no automatic source (Edu. Allowance, LWF/P.F. Tax, Notice, "
					"Deduction from A/C, SPL1/DRF/CAB/FOOD/ACCM, Other) still need "
					"manual entry."
				),
			},
			{
				"fieldname": "custom_fetch_last_month_details",
				"fieldtype": "Button",
				"label": "Fetch Last Month Details",
				"insert_after": "custom_dues_breakup_section",
				"description": (
					"Uses the employee's actual submitted Salary Slip for the relieving "
					"month if one exists; otherwise computes a real (not submitted) "
					"payroll run for that month via HRMS's own engine - so days worked "
					"and prorated amounts are attendance/payroll-accurate, not a manual "
					"guess. Safe to click again to refresh; only overwrites the fields "
					"it knows how to fetch."
				),
			},
			{
				"fieldname": "custom_last_month_earnings",
				"fieldtype": "Table",
				"options": "FnF Last Month Earning",
				"label": "Last Month Earnings (as on Salary Slip)",
				"insert_after": "custom_dues_days_worked",
				"read_only": 1,
				"description": (
					"Every earning row from the relieving month's Salary Slip, copied "
					"exactly as computed there - not just the components the fixed "
					"Basic/HRA/etc. fields below know how to match. Read-only: refetch "
					"via the button above rather than editing here."
				),
			},
			{
				"fieldname": "custom_last_month_deductions",
				"fieldtype": "Table",
				"options": "FnF Last Month Deduction",
				"label": "Last Month Deductions (as on Salary Slip)",
				"insert_after": "custom_ded_other",
				"read_only": 1,
				"description": (
					"Every deduction row from the relieving month's Salary Slip, copied "
					"exactly as computed there - not just EPF/ESI/TDS. Read-only: "
					"refetch via the button above rather than editing here."
				),
			},
		],
	}
