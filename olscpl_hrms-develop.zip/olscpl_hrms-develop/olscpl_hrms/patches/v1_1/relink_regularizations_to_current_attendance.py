# olscpl_hrms/patches/v1_1/relink_regularizations_to_current_attendance.py
#
# Open Attendance Regularizations whose attendance_link points at a cancelled
# Attendance (the day was re-marked after the request was raised) can't be
# approved - "Cannot link cancelled document". Point each at that day's
# current Attendance. New re-marks are handled by
# events/attendance.relink_open_regularizations. Idempotent.
import frappe


def execute():
	frappe.db.sql("""
		UPDATE `tabAttendance Regularization` ar
		JOIN `tabAttendance` old ON old.name = ar.attendance_link AND old.docstatus = 2
		JOIN `tabAttendance` cur ON cur.employee = ar.employee AND cur.attendance_date = ar.for_date AND cur.docstatus = 1
		SET ar.attendance_link = cur.name
		WHERE ar.docstatus = 0
	""")
