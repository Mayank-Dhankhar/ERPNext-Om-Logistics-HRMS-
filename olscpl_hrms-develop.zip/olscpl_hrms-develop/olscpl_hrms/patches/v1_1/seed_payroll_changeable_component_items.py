import frappe


def execute():
	cached = frappe.cache().get_value("payroll_changeable_component_pre_migration_values")
	if not cached:
		return

	old = frappe.parse_json(cached)
	frappe.cache().delete_value("payroll_changeable_component_pre_migration_values")

	if not frappe.db.exists("Payroll Changeable Component", old.name):
		return

	parent = frappe.get_doc("Payroll Changeable Component", old.name)

	if parent.components:
		return

	today = frappe.utils.today()
	now = frappe.utils.now_datetime()

	for component_name, amount in [
		("PF Ceiling Amount", old.custom_pf_ceiling_amount),
		("Bonus Limit Amount", old.custom_bonus_limit_amount),
		("Bonus Ceiling Amount", old.custom_bonus_ceiling_amount),
	]:
		parent.append("components", {
			"component_name": component_name,
			"amount": amount or 0,
			"effective_date": today,
			"changed_by": "Administrator",
			"changed_on": now,
		})

	parent.save(ignore_permissions=True)