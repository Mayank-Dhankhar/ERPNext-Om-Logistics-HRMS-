# Employees still without a Reports To after assign_unmanaged_to_branch_hr,
# whose branch has no HR (or who have no branch), report to 14966 (Jagdish
# Chander, H.R.D. Manager) so every request has an approver. Self-reporting
# heads are untouched. Undo file - see utils/branch_hr_import.
from olscpl_hrms.utils.branch_hr_import import assign_uncovered_to


def execute():
	assign_uncovered_to("14966")
