# olscpl_hrms/patches/v1_1/add_salary_annexure_breakup_tables.py
#
# The Employee "Salary annexure" tab's breakup/allowances/deductions/other-
# benefits tables were built directly on production through the UI - five
# Custom DocTypes and ten Custom Fields on Employee, none of it ever
# committed to this app (the "Employee Salary Annexure" Client Script that
# reads them was separately added locally already, so this patch only
# recreates the DocTypes/fields it depends on).
import frappe

CHILD_DOCTYPES = {
	"LOI Salary Breakup": [
		{"fieldname": "particulars", "label": "Particulars", "fieldtype": "Data", "reqd": 1, "in_list_view": 1},
		{"fieldname": "per_month", "label": "Per Month", "fieldtype": "Currency", "in_list_view": 1},
		{"fieldname": "per_annum", "label": "Per Annum", "fieldtype": "Currency", "in_list_view": 1},
	],
	"LOI Allowance": [
		{"fieldname": "particulars", "label": "Particulars", "fieldtype": "Data", "reqd": 1, "in_list_view": 1},
		{"fieldname": "per_month", "label": "Per Month", "fieldtype": "Currency", "in_list_view": 1},
		{"fieldname": "per_annum", "label": "Per Annum", "fieldtype": "Currency", "in_list_view": 1},
	],
	"LOI Deduction": [
		{"fieldname": "particulars", "label": "Particulars", "fieldtype": "Data", "reqd": 1, "in_list_view": 1},
		{"fieldname": "per_month", "label": "Per Month", "fieldtype": "Currency", "in_list_view": 1},
		{"fieldname": "per_annum", "label": "Per Annum", "fieldtype": "Currency", "in_list_view": 1},
	],
	"LOI Other Benefit": [
		{"fieldname": "particulars", "label": "Particulars", "fieldtype": "Data", "reqd": 1, "in_list_view": 1},
		{"fieldname": "per_month", "label": "Per Month", "fieldtype": "Currency", "in_list_view": 1},
		{"fieldname": "per_annum", "label": "Per Annum", "fieldtype": "Currency", "in_list_view": 1},
	],
	"LOI Benefit": [
		{"fieldname": "particulars", "label": "Particulars", "fieldtype": "Data", "reqd": 1, "in_list_view": 1},
		{"fieldname": "amount", "label": "Amount", "fieldtype": "Currency", "in_list_view": 1},
	],
}

# fieldname -> (label, fieldtype, options, insert_after) - chain matches live exactly
EMPLOYEE_FIELDS = [
	("custom_section_break_oyvjx", "", "Section Break", None, "custom_base_amount"),
	("custom_salary_breakup", "Salary Breakup", "Table", "LOI Salary Breakup", "custom_section_break_oyvjx"),
	("custom_section_break_unauu", "", "Section Break", None, "custom_total_breakupannum"),
	("custom_allowances", "Allowances", "Table", "LOI Allowance", "custom_section_break_unauu"),
	("custom_section_break_1bnwp", "", "Section Break", None, "custom_gross_salaryannum"),
	("custom_deductions", "Deductions", "Table", "LOI Deduction", "custom_section_break_1bnwp"),
	("custom_section_break_qcnxb", "", "Section Break", None, "custom_total_deductannum"),
	("custom_other_benefits", "Other Benefits", "Table", "LOI Other Benefit", "custom_section_break_qcnxb"),
	("custom_section_break_iil0o", "", "Section Break", None, "custom_total_benefitannum"),
	("custom_benefits", "Benefits", "Table", "LOI Benefit", "custom_section_break_iil0o"),
]


def execute():
	for doctype, fields in CHILD_DOCTYPES.items():
		if frappe.db.exists("DocType", doctype):
			continue
		doc_fields = [dict(f, idx=i + 1) for i, f in enumerate(fields)]
		frappe.get_doc({
			"doctype": "DocType",
			"name": doctype,
			"module": "Payroll",
			"custom": 1,
			"istable": 1,
			"editable_grid": 1,
			"fields": doc_fields,
		}).insert(ignore_permissions=True)

	for fieldname, label, fieldtype, options, insert_after in EMPLOYEE_FIELDS:
		if frappe.db.exists("Custom Field", f"Employee-{fieldname}"):
			continue
		frappe.get_doc({
			"doctype": "Custom Field",
			"dt": "Employee",
			"fieldname": fieldname,
			"label": label,
			"fieldtype": fieldtype,
			"options": options,
			"insert_after": insert_after,
		}).insert(ignore_permissions=True)

	frappe.db.commit()
