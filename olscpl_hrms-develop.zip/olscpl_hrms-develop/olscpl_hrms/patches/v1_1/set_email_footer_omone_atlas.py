# olscpl_hrms/patches/v1_1/set_email_footer_omone_atlas.py
#
# Every outgoing email carried a "Sent via ERPNext" footer. It comes from
# erpnext's own `default_mail_footer` hook, and Frappe merges that hook across
# all apps (an app can add lines but cannot remove another app's), so the only
# supported way to drop it is System Settings > "Disable Standard Email
# Footer" - which is a site default (frappe.db.get_default), set below the
# same way System Settings.on_update does it.
#
# The replacement text goes in each Email Account's own Footer field
# (rendered by Frappe's email_footer template as the account footer). Only
# accounts with an empty Footer are touched, so a footer someone set on
# purpose is never overwritten. Registered in after_migrate too, so an
# Email Account created later is picked up on the next migrate.
import frappe

FOOTER = "Sent via OmOne Atlas"


def execute():
	if not frappe.db.get_single_value("System Settings", "disable_standard_email_footer"):
		frappe.db.set_single_value("System Settings", "disable_standard_email_footer", 1)
	frappe.db.set_default("disable_standard_email_footer", "1")

	for name in frappe.get_all("Email Account", filters={"footer": ["in", ["", None]]}, pluck="name"):
		frappe.db.set_value("Email Account", name, "footer", FOOTER, update_modified=False)

	frappe.db.commit()
	frappe.clear_cache()
