# olscpl_hrms/patches/v1_1/bulk_upload_cancel_same_date_ssa.py
#
# Base Salary Bulk Upload (Server Script "process_formula_bulk_upload"),
# "Cancel Existing SSA": it only cancelled the employee's assignments on the
# SAME salary structure as the upload. Moving someone from another structure
# (e.g. the old "OTPL-Base Salary-Based Structure") on the same From Date then
# failed - "Salary Structure Assignment for Employee already exists". Also
# cancel any submitted assignment of that employee on the upload's From Date.
# DB-only Server Script, edited in place. Idempotent.
import frappe

SCRIPT = "process_formula_bulk_upload"
OLD = """            existing_ssa = frappe.get_all(
                "Salary Structure Assignment",
                filters={
                    "employee": item.employee,
                    "salary_structure": item.salary_structure,
                    "docstatus": 1
                },
                pluck="name"
            )
"""
NEW = """            existing_ssa = frappe.get_all(
                "Salary Structure Assignment",
                filters={
                    "employee": item.employee,
                    "salary_structure": item.salary_structure,
                    "docstatus": 1
                },
                pluck="name"
            )
            # plus any other structure's assignment on the same From Date -
            # HRMS allows only one submitted assignment per employee per date
            for same_day in frappe.get_all(
                "Salary Structure Assignment",
                filters={
                    "employee": item.employee,
                    "from_date": item.from_date,
                    "docstatus": 1
                },
                pluck="name"
            ):
                if same_day not in existing_ssa:
                    existing_ssa.append(same_day)
"""


def execute():
	if not frappe.db.exists("Server Script", SCRIPT):
		return
	script = (frappe.db.get_value("Server Script", SCRIPT, "script") or "").replace("\r\n", "\n")
	if NEW in script or OLD not in script:
		return
	frappe.db.set_value("Server Script", SCRIPT, "script", script.replace(OLD, NEW))
