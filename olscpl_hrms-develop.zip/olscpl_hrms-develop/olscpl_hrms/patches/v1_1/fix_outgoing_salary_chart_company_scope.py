import frappe


def execute():
	"""The stock 'Outgoing Salary' Dashboard Chart scopes Salary Slip data to
	frappe.defaults.get_user_default("Company") via dynamic_filters_json. Most
	users don't have a default company that matches where most payroll data
	actually lives, so the chart silently renders empty/flat for them.

	Clear that auto-scoping so the chart shows all companies by default; a
	Company quick-filter (added alongside the Year/Month controls, see
	public/js/dashboard_chart_company_filter.js) lets users narrow it down
	the same way they already narrow by Year/Month.
	"""
	if not frappe.db.exists("Dashboard Chart", "Outgoing Salary"):
		return

	dynamic_filters_json = frappe.db.get_value(
		"Dashboard Chart", "Outgoing Salary", "dynamic_filters_json"
	)
	if dynamic_filters_json and "get_user_default" in dynamic_filters_json:
		frappe.db.set_value(
			"Dashboard Chart", "Outgoing Salary", "dynamic_filters_json", "[]"
		)

	frappe.db.commit()
