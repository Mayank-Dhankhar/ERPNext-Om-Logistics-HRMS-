# olscpl_hrms/patches/v1_1/setup_role_based_hr_access.py
#
# Codifies a full round of role-based access work that was originally done
# by hand against a live site (see the "Create Login with Rights" request):
# three narrow-scope roles (Payroll Access, Recruitment Access, Onboarding
# Access), each restricted to exactly the doctypes their job needs, plus
# the workspace/report visibility fixes needed to stop unrelated data from
# leaking through the sidebar and "Reports & Masters" links to people who
# don't have real permission on it.
#
# Deliberately does NOT create the 7 specific user logins that prompted
# this - that's genuine per-site data (real names/emails), not something a
# patch should silently do to every site. Only the reusable access-control
# scaffolding lives here.
#
# Workspace/Report saves are wrapped with developer_mode temporarily
# disabled - both doctypes export themselves back to their OWNING app's
# source files on save when developer_mode is on (see
# frappe/desk/doctype/workspace/workspace.py on_update()), which for stock
# hrms workspaces would mean writing into apps/hrms - never appropriate
# for a patch in this app.
import contextlib

import frappe
from frappe.permissions import add_permission, update_permission_property


@contextlib.contextmanager
def _no_fixture_export():
	original = frappe.conf.get("developer_mode")
	frappe.conf.developer_mode = 0
	try:
		yield
	finally:
		frappe.conf.developer_mode = original


def _ensure_role(role_name):
	if not frappe.db.exists("Role", role_name):
		frappe.get_doc({"doctype": "Role", "role_name": role_name, "desk_access": 1}).insert(
			ignore_permissions=True
		)


def _grant(doctype, role, write=0, create=0, submit=0, read=1):
	if not frappe.db.exists("DocType", doctype):
		return
	add_permission(doctype, role, 0)
	update_permission_property(doctype, role, 0, "read", read)
	update_permission_property(doctype, role, 0, "write", write)
	update_permission_property(doctype, role, 0, "create", create)
	if submit:
		update_permission_property(doctype, role, 0, "submit", 1)


def _set_workspace_roles(name, roles):
	if not frappe.db.exists("Workspace", name):
		return
	with _no_fixture_export():
		doc = frappe.get_doc("Workspace", name)
		doc.set("roles", [])
		for role in roles:
			doc.append("roles", {"role": role})
		doc.save(ignore_permissions=True)


def _set_report_roles(report_name, roles):
	"""Report.save() actively refuses to save a standard report at all
	unless developer_mode is on (unlike Workspace, which just skips its
	export step when it's off) - so disabling developer_mode the way
	_set_workspace_roles() does would throw here instead of helping.
	Insert the child rows directly instead, bypassing Report's controller
	(and its fixture export) entirely."""
	if not frappe.db.exists("Report", report_name):
		return
	existing_rows = frappe.get_all(
		"Has Role", filters={"parent": report_name, "parenttype": "Report"}, fields=["role"]
	)
	existing_roles = {r.role for r in existing_rows}
	next_idx = len(existing_rows)
	for role in roles:
		if role in existing_roles:
			continue
		next_idx += 1
		row = frappe.get_doc(
			{
				"doctype": "Has Role",
				"parent": report_name,
				"parenttype": "Report",
				"parentfield": "roles",
				"idx": next_idx,
				"role": role,
			}
		)
		row.db_insert()


def execute():
	# ---- 1. Roles ----
	_ensure_role("Payroll Access")
	_ensure_role("Recruitment Access")
	_ensure_role("Onboarding Access")

	# "Payroll Manager" is referenced by name in two places that predate
	# this patch - the tds-advisory-hr Page's own roles list, and a
	# hardcoded allowed_roles set inside
	# api/tds_advisory.py::get_employee_tds_advisory_for_hr() - but the
	# actual Role record was never created, so nobody could ever actually
	# hold it. It needs no doctype permissions beyond Employee read (the
	# one explicit frappe.has_permission check in that function); every
	# other lookup inside it uses frappe.get_all/frappe.db.get_value,
	# which don't apply the calling user's permissions the way
	# frappe.get_list does - so this role is deliberately this narrow and
	# still fully functional. ("Create Login with TDS Module Rights.")
	_ensure_role("Payroll Manager")
	_grant("Employee", "Payroll Manager")

	# ---- 2. Doctype permissions, scoped to each role's actual job ----
	# Payroll Access covers *every* doctype that actually lives in the
	# Payroll module, computed live rather than hand-listed - a static
	# list drifts (stock hrms already gates a dozen of these, tax
	# exemptions/gratuity/benefits/withholding/loans/statutory masters,
	# behind "HR Manager" specifically; the first fix here only covered
	# the doctypes used day-to-day and kept missing others, which is
	# exactly what led to "just give them HR Manager too" being tried -
	# and that also pulled in HR/Onboarding/Recruitment workspace access
	# that has nothing to do with payroll). Doing it by module means a
	# future hrms/olscpl_hrms payroll doctype is covered automatically the
	# next time this runs, with no list to remember to update.
	for dt in frappe.get_all("DocType", filters={"module": "Payroll", "istable": 0}, pluck="name"):
		is_single = frappe.db.get_value("DocType", dt, "issingle")
		is_submittable = frappe.db.get_value("DocType", dt, "is_submittable")
		_grant(dt, "Payroll Access", write=1, create=0 if is_single else 1, submit=is_submittable)

	# Cross-module extras that are genuinely payroll's job even though
	# they don't live in the Payroll module itself: Employee Advance (HR
	# module), and the two custom Loan doctypes that already have a real
	# home under the Payroll workspace's "Loans" card (see below) - without
	# this they'd show there but throw "not permitted" on click, the same
	# bug the HR Dashboard shortcuts had before that was fixed.
	_grant("Employee Advance", "Payroll Access", write=1, create=1, submit=True)
	_grant("Loan Prepayment Request", "Payroll Access", write=1, create=1)
	_grant("Loan Skip Request", "Payroll Access", write=1, create=1)
	_grant("Employee", "Payroll Access")  # read-only context

	for dt, submittable in [
		("Job Opening", False),
		("Job Applicant", False),
		("Job Offer", True),
		("Job Requisition", True),
		("Interview", False),
		("Interview Round", False),
		("Interview Type", False),
		("Interview Feedback", False),
		("Employee Referral", False),
		("Staffing Plan", True),
	]:
		_grant(dt, "Recruitment Access", write=1, create=1, submit=submittable)

	for dt, submittable in [
		("Employee Onboarding", True),
		("Employee Onboarding Template", False),
		("Background Verification", False),
		("Background Verification Check", False),
	]:
		_grant(dt, "Onboarding Access", write=1, create=1, submit=submittable)
	# Unlike the other two roles, Onboarding Access needs real write/create
	# on Employee, not just read - completing onboarding means creating the
	# Employee record from Employee Onboarding's own "Create > Employee"
	# button, which is the entire point of the role.
	_grant("Employee", "Onboarding Access", write=1, create=1)

	# Note: the baseline self-service "Employee" role (own profile,
	# attendance, leave application, etc.) is assigned per-user alongside
	# whichever of the three roles above they get - not something this
	# patch grants itself, since it's real per-login data, not scaffolding.

	# ---- 3. Payroll reports ----
	# Provident Fund Deductions / Professional Tax Deductions were the two
	# left with no role restriction at all (every sibling payroll report
	# already required HR User/HR Manager) - close that leak. Every report
	# in the Payroll module (this includes those two, plus Salary
	# Register, Bank Remittance, Income Tax Computation/Deductions, the
	# ECS/payment-mode reports, and any custom ones added later) also gets
	# Payroll Access, same by-module reasoning as the doctype grants above.
	_set_report_roles("Provident Fund Deductions", ["HR User", "HR Manager"])
	_set_report_roles("Professional Tax Deductions", ["HR User", "HR Manager"])
	for report in frappe.get_all("Report", filters={"module": "Payroll"}, pluck="name"):
		_set_report_roles(report, ["Payroll Access"])

	# ---- 4. Workspace visibility ----
	# Payroll/Salary Payout/Tax & Benefits: restrict to the roles that
	# actually belong there (previously wide open to any desk user).
	_set_workspace_roles("Payroll", ["HR User", "HR Manager", "Payroll Access"])
	_set_workspace_roles("Salary Payout", ["HR User", "HR Manager", "Payroll Access"])
	_set_workspace_roles("Tax & Benefits", ["HR User", "HR Manager", "Payroll Access"])

	# HR's own children (Employee Lifecycle/Performance/Shift & Attendance/
	# Expense Claims/Leaves) were also wide open; Recruitment gets its own
	# role too and is promoted to a top-level sidebar entry (see below) so
	# Recruitment-only users see just "Recruitment", no HR wrapper.
	_set_workspace_roles("HR", ["HR User", "HR Manager"])
	_set_workspace_roles("Employee Lifecycle", ["HR User", "HR Manager"])
	_set_workspace_roles("Performance", ["HR User", "HR Manager"])
	_set_workspace_roles("Shift & Attendance", ["HR User", "HR Manager"])
	_set_workspace_roles("Expense Claims", ["HR User", "HR Manager"])
	_set_workspace_roles("Leaves", ["HR User", "HR Manager"])
	_set_workspace_roles("Recruitment", ["HR User", "HR Manager", "Recruitment Access"])

	if frappe.db.exists("Workspace", "Recruitment"):
		with _no_fixture_export():
			frappe.db.set_value("Workspace", "Recruitment", "parent_page", "")

	# HR's own shortcut row carried 5 "Dashboard"-type shortcuts (HR
	# Dashboard, Recruitment Dashboard, Employee Lifecycle Dashboard,
	# Attendance Dashboard, Expense Claims Dashboard). Frappe only
	# auto-hides "DocType"-type shortcuts based on permission - Dashboard
	# ones render unconditionally and only fail once clicked. Drop them;
	# the two DocType-type ones (Leave Application, Employee) already
	# self-filter correctly and stay.
	if frappe.db.exists("Workspace", "HR"):
		with _no_fixture_export():
			doc = frappe.get_doc("Workspace", "HR")
			keep = [s for s in doc.shortcuts if s.type != "Dashboard"]
			doc.set("shortcuts", [])
			for s in keep:
				doc.append(
					"shortcuts",
					{"label": s.label, "type": s.type, "link_to": s.link_to, "doc_view": s.doc_view},
				)
			doc.save(ignore_permissions=True)

	# Loan Prepayment Request / Loan Skip Request are genuinely orphaned
	# custom doctypes (module OLSCPL HRMS, not linked from any workspace) -
	# Frappe auto-surfaces any such doctype under a "Custom Documents" card
	# on every workspace sharing that module, which is how they ended up
	# showing on the new Onboarding workspace despite having nothing to do
	# with onboarding. Give them a real home under Payroll (their actual
	# subject) instead of leaving them unclaimed.
	if frappe.db.exists("Workspace", "Payroll"):
		existing_links = {
			l.link_to for l in frappe.get_doc("Workspace", "Payroll").links if l.link_to
		}
		if "Loan Prepayment Request" not in existing_links:
			with _no_fixture_export():
				doc = frappe.get_doc("Workspace", "Payroll")
				doc.append("links", {"type": "Card Break", "label": "Loans", "link_count": 2})
				doc.append(
					"links",
					{
						"type": "Link",
						"label": "Loan Prepayment Request",
						"link_to": "Loan Prepayment Request",
						"link_type": "DocType",
					},
				)
				doc.append(
					"links",
					{
						"type": "Link",
						"label": "Loan Skip Request",
						"link_to": "Loan Skip Request",
						"link_type": "DocType",
					},
				)
				content = frappe.parse_json(doc.content)
				content.append({"type": "card", "data": {"card_name": "Loans", "col": 4}})
				doc.content = frappe.as_json(content)
				doc.save(ignore_permissions=True)

	# The Onboarding workspace originally lived on its own isolated custom
	# module ("Onboarding Portal") to stop the Loans leak above from also
	# showing on IT (Frappe's "Custom Documents"/"Custom Reports" cards
	# leak any custom doctype/report sharing a workspace's module - see
	# get_custom_reports_and_doctypes() in frappe/desk/desktop.py). That
	# backfired badly: the sidebar itself (Workspace.__init__, same file)
	# hard-requires the viewing user to already have real permission on
	# *some* doctype in the workspace's module - an empty module can never
	# satisfy that for anyone except a Workspace Manager, so the whole
	# workspace silently vanished from every real user's sidebar
	# (PermissionError, swallowed silently by the caller).
	#
	# The actual fix is two separate, correct tools instead of one
	# module trick trying to do both jobs: "HR" is the right module for
	# visibility (it's what Employee Onboarding itself belongs to, so
	# Onboarding Access - already granted real permission on Employee
	# Onboarding above - naturally unlocks the workspace); hide_custom=1
	# is the right switch for suppressing the auto Custom
	# Documents/Reports leak (it's the literal flag get_links() checks
	# before calling get_custom_reports_and_doctypes() at all) - and
	# unlike the module trick, it blocks ANY future custom doctype/report
	# landing on "HR", not just the Loan ones that prompted this.
	# sequence_id controls sidebar order and defaults to 0 for a newly
	# created workspace with none set - which put Onboarding above every
	# other top-level workspace, including Atlas Home itself. 3.5 sits it
	# right after Recruitment (3.0) and before HR (8.0), matching the
	# hire-to-onboard flow. The onboarding.json fixture carries this too,
	# but fixture sync only inserts a genuinely new workspace from JSON -
	# it doesn't overwrite an already-existing record's fields, so this is
	# the version that actually reaches a site where Onboarding already
	# exists (same reasoning as module/hide_custom right below).
	if frappe.db.exists("Workspace", "Onboarding"):
		doc = frappe.get_doc("Workspace", "Onboarding")
		if doc.module != "HR" or not doc.hide_custom or doc.sequence_id != 3.5:
			with _no_fixture_export():
				doc.module = "HR"
				doc.hide_custom = 1
				doc.sequence_id = 3.5
				doc.save(ignore_permissions=True)
	if frappe.db.exists("Module Def", "Onboarding Portal"):
		if not frappe.db.exists("Workspace", {"module": "Onboarding Portal"}) and not frappe.db.exists(
			"DocType", {"module": "Onboarding Portal"}
		):
			frappe.delete_doc("Module Def", "Onboarding Portal", force=True, ignore_permissions=True)

	frappe.db.commit()

	# get_allowed_modules() (which drives each user's sidebar workspace
	# list) is cached per-user for 6 hours - frappe.cache.get_value(
	# "user_allowed_modules", user=...). Since this function changes
	# workspace roles/module assignments, a user cached before it last ran
	# would keep seeing a stale sidebar (e.g. missing a workspace their
	# role now grants) until that cache expires on its own. Clear it every
	# time this runs so the change is visible on the user's very next
	# request, not up to 6 hours later.
	frappe.clear_cache()
