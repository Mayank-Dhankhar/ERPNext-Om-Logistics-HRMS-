# The earlier index_employee_reports_to patch added the index with a raw
# add_index, but Frappe's schema sync drops any index its doctype meta does
# not declare, so on prod the index was gone and the Org Chart timed out (504).
# A Property Setter (search_index=1) makes Employee.reports_to a declared
# index, so every migrate keeps it. Idempotent; also run from after_migrate.
import frappe


def execute():
	if not frappe.db.exists(
		"Property Setter",
		{"doc_type": "Employee", "field_name": "reports_to", "property": "search_index", "value": "1"},
	):
		frappe.make_property_setter(
			{
				"doctype": "Employee",
				"fieldname": "reports_to",
				"property": "search_index",
				"value": "1",
				"property_type": "Check",
			}
		)
		frappe.clear_cache(doctype="Employee")
	# create the column index now if it is missing
	if not frappe.db.sql("show index from `tabEmployee` where Column_name='reports_to'"):
		frappe.db.updatedb("Employee")
