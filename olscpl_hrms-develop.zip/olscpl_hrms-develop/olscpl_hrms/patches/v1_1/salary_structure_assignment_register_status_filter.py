# olscpl_hrms/patches/v1_1/salary_structure_assignment_register_status_filter.py
#
# "Salary Structure Assignment Register" is a DB-only Script Report (made in
# the desk, not in any app's code). Adds an Employee Status filter (Active /
# Inactive / Suspended / Left) and a Status column to it, editing the
# report's script in place. Idempotent; does nothing if the report is absent.
import frappe

REPORT = "Salary Structure Assignment Register"

EDITS = [
	(
		'branch      = filters.get("branch") or ""\n',
		'branch      = filters.get("branch") or ""\nstatus      = filters.get("status") or ""\n',
	),
	(
		'if branch:\n    cond += " AND e.branch = %(branch)s"\n    params["branch"] = branch\n',
		'if branch:\n    cond += " AND e.branch = %(branch)s"\n    params["branch"] = branch\n'
		'if status:\n    cond += " AND e.status = %(status)s"\n    params["status"] = status\n',
	),
	(
		"        e.company            AS company,\n",
		"        e.company            AS company,\n        e.status             AS status,\n",
	),
	(
		'        "company":           a.company,\n',
		'        "company":           a.company,\n        "status":            a.status,\n',
	),
	(
		'    {"label": "Company",                "fieldname": "company",           "fieldtype": "Data",     "width": 200},\n',
		'    {"label": "Company",                "fieldname": "company",           "fieldtype": "Data",     "width": 200},\n'
		'    {"label": "Status",                 "fieldname": "status",            "fieldtype": "Data",     "width": 100},\n',
	),
]


def execute():
	if not frappe.db.exists("Report", REPORT):
		return
	report = frappe.get_doc("Report", REPORT)
	# saved from Windows: CRLF line endings
	script = (report.report_script or "").replace("\r\n", "\n")
	if "%(status)s" not in script:
		for old, new in EDITS:
			if old not in script:
				frappe.log_error(f"{REPORT}: expected text not found, status filter not added", old)
				return
			script = script.replace(old, new, 1)
		report.report_script = script
	if not any(f.fieldname == "status" for f in report.filters):
		report.append("filters", {
			"fieldname": "status", "label": "Status", "fieldtype": "Select",
			"options": "\nActive\nInactive\nSuspended\nLeft",
		})
	report.flags.ignore_permissions = True
	report.save()
