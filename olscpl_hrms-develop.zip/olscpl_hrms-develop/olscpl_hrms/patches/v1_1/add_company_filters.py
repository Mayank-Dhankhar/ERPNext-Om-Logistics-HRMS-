# olscpl_hrms/patches/v1_1/add_company_filters.py
#
# Company in the list filter bar of Job Opening and Job Applicant. Job
# Applicant has no company of its own, so it gets a read-only Company taken
# from its Job Opening (fetch_from, kept current on every save; existing
# applicants filled in here).
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


def execute():
	make_property_setter("Job Opening", "company", "in_standard_filter", 1, "Check", validate_fields_for_doctype=False)
	create_custom_fields({"Job Applicant": [{
		"fieldname": "custom_company", "label": "Company", "fieldtype": "Link", "options": "Company",
		"fetch_from": "job_title.company", "fetch_if_empty": 1, "read_only": 1, "in_standard_filter": 1, "insert_after": "custom_job_opening_title",
	}]}, update=True)
	frappe.db.sql("""
		update `tabJob Applicant` ja join `tabJob Opening` jo on jo.name = ja.job_title
		set ja.custom_company = jo.company
		where ifnull(ja.custom_company, '') != ifnull(jo.company, '')
	""")
