# olscpl_hrms/patches/v1_1/seed_hr_masters.py
#
# HR-maintained masters used to be Frappe *fixtures*, and every `bench migrate`
# re-imported them over the live records, wiping HR's edits. They now live in
# olscpl_hrms/seed_data/ and are only INSERTED when missing (never updated).
from olscpl_hrms.seed_masters import seed_masters


def execute():
	seed_masters()
