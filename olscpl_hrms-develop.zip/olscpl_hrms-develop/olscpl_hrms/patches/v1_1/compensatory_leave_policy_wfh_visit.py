# "Compensatory Leave Policy" (Server Script, before_validate on
# Compensatory Leave Request) credits comp off from Attendance.working_hours.
# An approved Work From Home / Visit marks the day without any punches
# (events/work_from_home_request.py, events/visit.py), so working_hours is 0
# and the script threw "Worked less than 3 hours" for every WFH/Visit
# worked on a holiday. Visit was not even an eligible status.
#
# Credit those by the approved day instead: WFH and Full Day Visit = full
# day, First/Second Half Visit = half day. Punch-based days are unchanged.
# Same text is in fixtures/server_script.json for new sites.
import frappe

SCRIPT = "Compensatory Leave Policy"

REPLACEMENTS = [
	(
		'["working_hours", "status"],',
		'["working_hours", "status", "custom_visit_day_portion"],',
	),
	(
		'if attendance.status not in ["Present", "Half Day", "Work From Home", "On Duty"]:',
		'if attendance.status not in ["Present", "Half Day", "Work From Home", "On Duty", "Visit"]:',
	),
	(
		"    working_hours = attendance.working_hours or 0\n",
		"    working_hours = attendance.working_hours or 0\n"
		"\n"
		"    # Approved WFH / Visit carry no punches (working_hours 0) - credit by\n"
		"    # the approved day: WFH and Full Day Visit = full, half Visit = half.\n"
		'    if attendance.status == "Work From Home" or (\n'
		'        attendance.status == "Visit" and attendance.custom_visit_day_portion == "Full Day"\n'
		"    ):\n"
		"        working_hours = 6\n"
		'    elif attendance.status == "Visit":\n'
		"        working_hours = 3\n",
	),
]


def execute():
	if not frappe.db.exists("Server Script", SCRIPT):
		return
	script = frappe.db.get_value("Server Script", SCRIPT, "script")
	if "custom_visit_day_portion" in script:
		return
	for old, new in REPLACEMENTS:
		if old not in script:
			frappe.log_error(f"Snippet not found: {old}", f"Patch {__name__} skipped")
			return
		script = script.replace(old, new, 1)
	frappe.db.set_value("Server Script", SCRIPT, "script", script)
	frappe.clear_cache()
