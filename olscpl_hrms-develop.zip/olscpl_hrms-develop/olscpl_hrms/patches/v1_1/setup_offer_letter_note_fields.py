# olscpl_hrms/patches/v1_1/setup_offer_letter_note_fields.py
#
# Job Offer > Salary Annexure > "Offer Letter Notes": one tick per standard
# note under the Letter of Intent's salary structure, so HR picks which ones
# that candidate's letter shows (api/letter_of_intent.py, OFFER_NOTES). All
# ticked by default - existing offers keep printing every note, as before.
# RapidShyp's Letter Of Offer has its own Benefits lines
# (api/rapidshyp.py) - those tick-boxes show on RapidShyp offers instead.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from olscpl_hrms.api import rapidshyp
from olscpl_hrms.api.letter_of_intent import OFFER_NOTES

RAPIDSHYP = f"eval:doc.company=='{rapidshyp.COMPANY}'"
OTHERS = f"eval:doc.company!='{rapidshyp.COMPANY}'"


def execute():
	fields = [{
		"fieldname": "custom_offer_notes_section", "label": "Offer Letter Notes", "fieldtype": "Section Break",
		"insert_after": "custom_net_salaryannum",
		"description": "Ticked notes are printed under the salary structure in the offer letter",
	}]
	insert_after = "custom_offer_notes_section"
	for lines, shown in ((OFFER_NOTES, OTHERS), (rapidshyp.BENEFITS, RAPIDSHYP)):
		for fieldname, text in lines:
			fields.append({"fieldname": fieldname, "label": text, "fieldtype": "Check", "default": "1",
				# the letter is generated after the offer is submitted
				"allow_on_submit": 1, "depends_on": shown, "insert_after": insert_after})
			insert_after = fieldname
	create_custom_fields({"Job Offer": fields}, update=True)
