import frappe


def execute():
	current_options = frappe.get_meta("Employee Attendance Tool").get_field("status").options or ""
	existing = [opt for opt in current_options.split("\n") if opt]

	if "Week Off" not in existing:
		new_options = current_options.rstrip("\n") + "\nWeek Off"
		frappe.make_property_setter({
			"doctype": "Employee Attendance Tool",
			"fieldname": "status",
			"property": "options",
			"value": new_options,
			"property_type": "Text",
		})

	frappe.db.commit()


