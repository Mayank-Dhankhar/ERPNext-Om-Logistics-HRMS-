"""
OLSCPL-HRMS-TDS-001 : Patch -- add TDS Advisory (HR) shortcut to Payroll workspace

Adds a "TDS Advisory (HR)" shortcut linking to the tds-advisory-hr Page on
the standard Payroll workspace. Fixtures already export the Workspace
record itself, but this patch exists as a belt-and-suspenders safeguard --
if a future `bench update` reinstalls/resets the standard HRMS Payroll
workspace before fixtures sync, this patch re-applies the shortcut
regardless of ordering.

Idempotent: checks both the shortcuts child table AND the content JSON
layout block before adding either, so it's safe to re-run on every
migrate (same convention as hide_non_hr_workspaces and
create_payroll_periods in this same patches folder).
"""

import frappe
import json


def execute():
    if not frappe.db.exists("Workspace", "Payroll"):
        print("Payroll workspace not found -- skipping TDS Advisory shortcut patch.")
        return

    workspace = frappe.get_doc("Workspace", "Payroll")

    # -- Step 1: add the shortcut child table row if not already present
    already_has_shortcut = any(s.label == "TDS Advisory (HR)" for s in workspace.shortcuts)
    if not already_has_shortcut:
        workspace.append("shortcuts", {
            "type": "Page",
            "link_to": "tds-advisory-hr",
            "label": "TDS Advisory (HR)",
            "color": "Blue",
        })
        print("Added 'TDS Advisory (HR)' shortcut row to Payroll workspace.")
    else:
        print("'TDS Advisory (HR)' shortcut row already exists -- skipping.")

    # -- Step 2: add the matching content JSON layout block if not already present
    content = json.loads(workspace.content or "[]")
    already_has_block = any(
        block.get("type") == "shortcut" and block.get("data", {}).get("shortcut_name") == "TDS Advisory (HR)"
        for block in content
    )
    if not already_has_block:
        insert_at = None
        for i, block in enumerate(content):
            if block.get("type") == "shortcut":
                insert_at = i + 1
        new_block = {"type": "shortcut", "data": {"shortcut_name": "TDS Advisory (HR)", "col": 3}}
        if insert_at is not None:
            content.insert(insert_at, new_block)
        else:
            content.append(new_block)
        workspace.content = json.dumps(content)
        print("Added 'TDS Advisory (HR)' block to Payroll workspace content layout.")
    else:
        print("'TDS Advisory (HR)' content block already exists -- skipping.")

    if not already_has_shortcut or not already_has_block:
        workspace.save()
        frappe.db.commit()