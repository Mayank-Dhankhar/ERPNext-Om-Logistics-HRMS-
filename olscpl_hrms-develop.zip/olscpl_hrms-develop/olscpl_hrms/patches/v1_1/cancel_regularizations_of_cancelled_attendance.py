# Open Attendance Regularizations whose Attendance was already cancelled could
# not be saved ("Cannot link cancelled document") and blocked deleting that
# Attendance. Cancel them, as cancelling an Attendance now does
# (events/attendance.cancel_linked_regularizations).
import frappe

from olscpl_hrms.events.attendance import cancel_linked_regularizations


def execute():
	for name in frappe.db.sql_list(
		"""SELECT DISTINCT a.name FROM `tabAttendance Regularization` r
		JOIN `tabAttendance` a ON a.name = r.attendance_link
		WHERE r.docstatus = 0 AND a.docstatus = 2"""
	):
		cancel_linked_regularizations(frappe._dict(name=name))
