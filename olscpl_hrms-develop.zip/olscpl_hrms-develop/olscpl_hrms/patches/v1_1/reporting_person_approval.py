# olscpl_hrms/patches/v1_1/reporting_person_approval.py
#
# One approval rule for Leave, Comp Off, Visit, Work From Home and Attendance
# Regularization: only the chosen Reporting Person, a branch HR or a System Manager approves
# (workflow conditions in fixtures/workflow.json, helpers in
# utils/reporting_person.py). This patch does the database-side setup that
# fixtures can't carry safely:
#   1. System Manager gets read/write/submit on all five (the override needs
#      Submit - approving submits the document). Only that role/permlevel 0
#      row is touched, so each site's other permission tweaks survive.
#   2. Disables the two DB-only permission Server Scripts now replaced by
#      code in permissions/queries.py, plus two old-rule leftovers (below).
#   3. Pending requests with no Reporting Person get the employee's
#      reports_to manager (nothing in flight is orphaned) and are shared
#      with whoever is chosen.
# Idempotent.
import frappe
from frappe.permissions import add_permission, update_permission_property

from olscpl_hrms.utils.reporting_person import REPORTING_FIELD, default_reporting_value, share_with_reporting_person

# Only requests actually waiting for approval - old drafts/rejected ones are left alone.
PENDING = {
	"Leave Application": {"docstatus": 0, "status": "Open"},
	"Compensatory Leave Request": {"docstatus": 0, "workflow_state": "Pending"},
	"Visit": {"docstatus": 0, "workflow_state": "Pending"},
	"Work From Home Request": {"docstatus": 0, "workflow_state": "Pending"},
	"Attendance Regularization": {"docstatus": 0, "workflow_state": "Pending"},
}


def execute():
	# Attendance Regularization.reporting_person comes from fixtures/doctype.json,
	# which migrate syncs only after patches run - sync it now if missing.
	if not frappe.db.has_column("Attendance Regularization", "reporting_person"):
		from frappe.utils.fixtures import sync_fixtures

		sync_fixtures("olscpl_hrms")

	for doctype in REPORTING_FIELD:
		if not frappe.db.exists("Custom DocPerm", {"parent": doctype, "role": "System Manager", "permlevel": 0}):
			add_permission(doctype, "System Manager", 0)
		for prop in ("read", "write", "submit"):
			update_permission_property(doctype, "System Manager", 0, prop, 1)

	for script in ("Permission Query WFH", "Permission Query For Attendance Regularization"):
		if frappe.db.exists("Server Script", script):
			frappe.db.set_value("Server Script", script, "disabled", 1)
	# Old-rule leftovers: an alert to EVERY "Manager" role user on each pending
	# regularization (the chosen person already gets it as an assignment), and
	# a desk script filling WFH's unused `approver` from Employee.leave_approver.
	if frappe.db.exists("Notification", "Attendance Regularization for Approval or Rejection"):
		frappe.db.set_value("Notification", "Attendance Regularization for Approval or Rejection", "enabled", 0)
	if frappe.db.exists("Client Script", "WFH Approver Auto Fetch"):
		frappe.db.set_value("Client Script", "WFH Approver Auto Fetch", "enabled", 0)

	for doctype, filters in PENDING.items():
		fieldname, _ = REPORTING_FIELD[doctype]
		for name, employee, current in frappe.get_all(doctype, filters=filters, fields=["name", "employee", fieldname], as_list=True):
			if not current:
				current = default_reporting_value(doctype, employee)
				if not current:
					continue
				frappe.db.set_value(doctype, name, fieldname, current, update_modified=False)
			share_with_reporting_person(frappe.get_doc(doctype, name))

	frappe.clear_cache()
	frappe.db.commit()
