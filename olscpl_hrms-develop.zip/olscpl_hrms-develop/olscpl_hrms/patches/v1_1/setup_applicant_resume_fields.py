# olscpl_hrms/patches/v1_1/setup_applicant_resume_fields.py
#
# Show the resume the candidate actually uploaded (Job Applicant.resume_attachment)
# on every recruitment document that links to the applicant - each Interview
# round, its Interview Feedback, the Job Offer, Appointment Letter and Employee
# Onboarding - instead of Interview's stock free-text "Resume Link", which is
# almost always empty because applicants upload a file rather than paste a URL.
#
# Read-only Attach fields with fetch_from, so they follow the applicant on new
# documents; existing documents are backfilled below. Idempotent - registered
# in after_migrate (not patches.txt) because the backfill must run after the
# fields exist, and re-running it also fills documents created before deploy.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter

FIELDNAME = "custom_applicant_resume"
DOCTYPES = {
	"Interview": "resume_link",
	"Interview Feedback": "job_applicant",
	"Job Offer": "job_applicant",
	"Appointment Letter": "job_applicant",
	"Employee Onboarding": "job_applicant",
}


def execute():
	create_custom_fields(
		{
			dt: [
				{
					"fieldname": FIELDNAME,
					"label": "Applicant Resume",
					"fieldtype": "Attach",
					"insert_after": insert_after,
					"fetch_from": "job_applicant.resume_attachment",
					"read_only": 1,
					"no_copy": 1,
					"depends_on": f"eval:doc.{FIELDNAME}",
				}
			]
			for dt, insert_after in DOCTYPES.items()
		},
		update=True,
	)

	# Stock "Resume Link" stays only for the rare applicant who gave a link
	# and no file - otherwise it's an always-empty box next to the real resume.
	make_property_setter(
		"Interview",
		"resume_link",
		"depends_on",
		f"eval:doc.resume_link && !doc.{FIELDNAME}",
		"Data",
		validate_fields_for_doctype=False,
	)
	frappe.db.set_value(
		"Property Setter", "Interview-resume_link-depends_on", "is_system_generated", 0
	)

	for dt in DOCTYPES:
		frappe.db.sql(
			f"""
			UPDATE `tab{dt}` t
			JOIN `tabJob Applicant` ja ON ja.name = t.job_applicant
			SET t.`{FIELDNAME}` = ja.resume_attachment
			WHERE IFNULL(ja.resume_attachment, '') != ''
				AND IFNULL(t.`{FIELDNAME}`, '') = ''
			"""
		)
	frappe.db.commit()
