# olscpl_hrms/patches/v1_1/add_compensatory_leave_bulk_upload_field.py
#
# "Skip Attendance Validation" checkbox on Compensatory Leave Request -
# lets a System Manager bulk-import old/historical compensatory leave
# records without HRMS core's validate_attendance() rejecting every one
# that has no matching Attendance record for those dates (the whole point
# of a bulk historical import - that data usually predates Attendance
# being tracked in this system at all, or simply wasn't kept). permlevel 1
# with only System Manager granted read/write at that level - every other
# role (HR User/HR Manager/Employee applying for their own comp-off) never
# even sees the field, let alone can tick it. See overrides/
# compensatory_leave_request.py for where this actually skips the check.
import frappe
from frappe.permissions import add_permission, update_permission_property


def execute():
	docname = "Compensatory Leave Request-custom_skip_attendance_validation"
	if not frappe.db.exists("Custom Field", docname):
		frappe.get_doc({
			"doctype": "Custom Field",
			"dt": "Compensatory Leave Request",
			"fieldname": "custom_skip_attendance_validation",
			"fieldtype": "Check",
			"label": "Skip Attendance Validation (bulk upload)",
			"insert_after": "reason",
			"permlevel": 1,
			"description": (
				"For bulk-uploading old compensatory leave records with no matching "
				"Attendance on file. System Manager only."
			),
		}).insert(ignore_permissions=True)

	add_permission("Compensatory Leave Request", "System Manager", 1)
	update_permission_property("Compensatory Leave Request", "System Manager", 1, "read", 1)
	update_permission_property("Compensatory Leave Request", "System Manager", 1, "write", 1)

	frappe.db.commit()
