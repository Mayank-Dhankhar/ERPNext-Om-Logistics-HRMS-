# olscpl_hrms/patches/v1_1/add_visit_half_day_support.py
#
# Lets a Visit cover Full Day / First Half / Second Half, matching how
# Attendance itself already supports "Half Day". Attendance.status stays
# "Visit" either way (not "Half Day") - a companion field
# custom_visit_day_portion carries which portion, since status alone
# can't say both "this is a Visit" and "it's only half a day" at once.
# events/salary_slip_steps.py's half-day payroll counting (which
# consumes leave balance / reduces absent_days for every Half Day
# Attendance record) is extended to also count a First/Second Half
# Visit the same way - see that file's own comments for where.
import frappe


def execute():
	# Visit is a Custom DocType shipped via fixtures/doctype.json, synced only
	# in post_schema_updates() - AFTER all patches (including this one, which
	# runs in [post_model_sync]) have already run. On a site where Visit has
	# never existed before, frappe.get_doc("DocType", "Visit") below would
	# raise DoesNotExistError. Harmless to skip in that case: the fixture
	# already bakes in day_portion for a fresh install, so there is nothing
	# for this block to add - it only matters on a site (like local dev) that
	# already had Visit installed before day_portion was added to it.
	if not frappe.db.exists("DocType", "Visit"):
		return

	doc = frappe.get_doc("DocType", "Visit")
	if not any(f.fieldname == "day_portion" for f in doc.fields):
		insert_after_idx = next(i for i, f in enumerate(doc.fields) if f.fieldname == "time")
		field = doc.append("fields", {
			"fieldname": "day_portion",
			"fieldtype": "Select",
			"label": "Day Portion",
			"options": "Full Day\nFirst Half\nSecond Half",
			"default": "Full Day",
			"reqd": 1,
		})
		doc.fields.remove(field)
		doc.fields.insert(insert_after_idx + 1, field)
		for i, f in enumerate(doc.fields, 1):
			f.idx = i
		doc.save(ignore_permissions=True)

	if not frappe.db.exists("Custom Field", "Attendance-custom_visit_day_portion"):
		frappe.get_doc({
			"doctype": "Custom Field",
			"dt": "Attendance",
			"fieldname": "custom_visit_day_portion",
			"fieldtype": "Select",
			"options": "\nFull Day\nFirst Half\nSecond Half",
			"label": "Visit Day Portion",
			"insert_after": "status",
			"depends_on": "eval:doc.status=='Visit'",
			"read_only": 1,
			"no_copy": 1,
			# Attendance is submittable, and both directions of the
			# punch/Visit half-day merge (events/visit.py's
			# _mark_attendance() and events/attendance_steps.py's
			# reconcile_half_day_visit_with_punches()) need to update
			# this field on an already-submitted Attendance record -
			# without this, Frappe's own UpdateAfterSubmitError blocks
			# every such merge via the normal doc.save() path.
			"allow_on_submit": 1,
		}).insert(ignore_permissions=True)

	frappe.db.commit()
