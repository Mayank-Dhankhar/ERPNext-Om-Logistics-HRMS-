# olscpl_hrms/patches/v1_1/add_interview_external_interviewers.py
#
# Interview > "External Interviewers": people outside the company on the
# panel. Each gets a website-only user (so the standard Interview Feedback
# rules apply) and an email with a no-login feedback link
# (events/interview.py, www/interview-feedback-form).
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields({"Interview": [
		{"fieldname": "custom_external_interviewers", "fieldtype": "Table", "label": "External Interviewers",
			"options": "Interview External Interviewer", "insert_after": "interview_details",
			"description": "Interviewers from outside the company. On save each one is emailed the interview details "
				"and a private link to submit their feedback - no login needed."},
	]}, update=True)
