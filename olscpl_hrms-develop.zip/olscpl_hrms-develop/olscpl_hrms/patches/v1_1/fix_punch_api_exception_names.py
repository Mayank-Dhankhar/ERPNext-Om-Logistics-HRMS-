# olscpl_hrms/patches/v1_1/fix_punch_api_exception_names.py
#
# "API - Punch In" / "API - Punch Out" are DB-only Server Scripts (mobile
# punch). Two fixes, applied in place; idempotent; skips a missing script:
#
# 1. They caught `frappe.exceptions.DuplicateEntryError`, but inside a Server
#    Script there is no frappe.exceptions - the exception classes sit on frappe
#    itself (frappe.DuplicateEntryError, see frappe.utils.safe_exec). So when
#    the check-in insert failed, the except line raised "catching classes that
#    do not inherit from BaseException is not allowed" and hid the real error.
# 2. They only checked that the employee exists. An Inactive / Left employee
#    could still punch from the app; HRMS then refused the check-in
#    ("Transactions cannot be created for an Inactive Employee"), which (1)
#    turned into the confusing error. Now such a punch gets a clear reply.
import frappe

SCRIPTS = ("API - Punch In", "API - Punch Out")

ANCHOR = '        emp = frappe.get_doc("Employee", employee)\n'
STATUS_CHECK = (
	ANCHOR
	+ "\n"
	+ "        # olscpl_hrms: only Active employees can punch\n"
	+ '        if emp.status != "Active":\n'
	+ '            frappe.response["message"] = {\n'
	+ '                "success": False,\n'
	+ '                "message": f"Your employee record is {emp.status} - punching is not allowed. Please contact HR."\n'
	+ "            }\n"
	+ "            return\n"
)


def execute():
	for name in SCRIPTS:
		if not frappe.db.exists("Server Script", name):
			continue
		script = (frappe.db.get_value("Server Script", name, "script") or "").replace("\r\n", "\n")
		new = script.replace("frappe.exceptions.", "frappe.")
		if "only Active employees can punch" not in new:
			if ANCHOR in new:
				new = new.replace(ANCHOR, STATUS_CHECK, 1)
			else:
				frappe.log_error(f"{name}: employee lookup line not found, status check not added", ANCHOR)
		if new == script:
			continue
		doc = frappe.get_doc("Server Script", name)
		doc.script = new
		doc.flags.ignore_permissions = True
		doc.save()
