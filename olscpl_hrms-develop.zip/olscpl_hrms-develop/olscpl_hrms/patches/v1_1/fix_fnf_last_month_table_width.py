# olscpl_hrms/patches/v1_1/fix_fnf_last_month_table_width.py
#
# add_full_and_final_statement_automation_fields.py inserted
# custom_last_month_earnings/custom_last_month_deductions (both Table
# fields) into the middle of an existing multi-column section - each landed
# in whatever ~50%-width column its insert_after anchor happened to be in,
# same as every Currency field around it. A grid only has room for a
# checkbox + No. + Component + a right-aligned Currency column; squeezed
# into half a section it doesn't have space for all of that, so the row
# checkboxes visually overlap the Amount column.
#
# Fix: give each Table its own single-column (so: full width) section by
# sandwiching it between two label-less Section Breaks, then re-point both
# the Table and the field that used to render right after it (it shared the
# Table's own insert_after anchor, which is how it ended up right after the
# Table rather than immediately after its own anchor) onto those new
# breaks, so everything else's layout is unchanged.
#
# Also fixes a second, unrelated instance of the same underlying mistake:
# custom_fetch_last_month_details (the "Fetch Last Month Details" button)
# and custom_dues_days_worked both have insert_after ==
# "custom_dues_breakup_section" - two fields can't both render "right after"
# the same anchor, and Frappe's field-order resolution has no way to place
# the one that loses that tie, so the button silently falls all the way to
# the end of the doctype's field list (index 122 of 123, verified via
# `frappe.get_meta("Full and Final Statement").fields`) instead of showing
# next to the section it belongs to. Give Days Worked an unambiguous anchor
# right after the button instead.
#
# Third, a smaller defensive fix found while verifying the above in a
# browser: none of this doctype's 6 collapsible Section Breaks set a
# `css_class`. Frappe's Section constructor (frappe/public/js/frappe/form/
# section.js) remembers a user's last-toggled open/closed state in
# localStorage keyed by `df.css_class + "-closed"` - with no css_class that
# key is literally the string "undefined-closed", shared by every
# collapsible section anywhere in the app that also has no css_class, so
# toggling any one of them can stomp on another's remembered state. (Note:
# this isn't why "Salary/Wages Payable for Last Month" renders collapsed on
# a fresh load - that's frappe/public/js/frappe/form/layout.js's
# refresh_section_collapse(), which collapses every collapsible section by
# default on every refresh regardless of localStorage, unless it has an
# empty mandatory field inside it. Click the section heading to expand it -
# same as before this patch, not something this fixes.) Giving each section
# its own css_class still closes off the shared-key collision as a latent
# bug worth fixing on its own.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter

DOCTYPE = "Full and Final Statement"

COLLAPSIBLE_SECTION_CSS_CLASSES = {
	"custom_legacy_details_section": "fnf-legacy-details-section",
	"custom_rate_of_pay_section": "fnf-rate-of-pay-section",
	"custom_dues_breakup_section": "fnf-dues-breakup-section",
	"custom_deductions_section": "fnf-deductions-section",
	"custom_other_dues_section": "fnf-other-dues-section",
	"custom_sign_off_section": "fnf-sign-off-section",
}


def execute():
	create_custom_fields(get_custom_fields(), ignore_validate=frappe.flags.in_patch)

	_reposition("custom_dues_days_worked", "custom_fetch_last_month_details")
	_reposition("custom_last_month_earnings", "custom_dues_earnings_section_start")
	_reposition("custom_dues_basic", "custom_dues_earnings_section_end")
	_reposition("custom_last_month_deductions", "custom_dues_deductions_section_start")
	_reposition("custom_ded_total", "custom_dues_deductions_section_end")

	for fieldname, css_class in COLLAPSIBLE_SECTION_CSS_CLASSES.items():
		# css_class isn't one of Custom Field's own columns (only plain
		# DocFields on a doctype's own .json get it directly) - a Property
		# Setter is the sanctioned way to attach a property Custom Field
		# itself doesn't expose, same as make_property_setter is already
		# used elsewhere in this app (e.g. set_job_offer_default_print_format).
		ps_name = f"{DOCTYPE}-{fieldname}-css_class"
		if frappe.db.get_value("Property Setter", ps_name, "value") == css_class:
			continue
		if frappe.db.exists("Property Setter", ps_name):
			frappe.db.set_value("Property Setter", ps_name, "value", css_class)
		else:
			make_property_setter(DOCTYPE, fieldname, "css_class", css_class, "Data")

	frappe.clear_cache(doctype=DOCTYPE)
	frappe.db.commit()


def _reposition(fieldname, insert_after):
	"""Custom Field ordering is just the insert_after pointer stored on the
	field itself - update it directly rather than through a Property Setter
	(which is for standard-doctype field properties, not this)."""
	docname = f"{DOCTYPE}-{fieldname}"
	if frappe.db.get_value("Custom Field", docname, "insert_after") == insert_after:
		return
	frappe.db.set_value("Custom Field", docname, "insert_after", insert_after)


def get_custom_fields():
	return {
		DOCTYPE: [
			{
				"fieldname": "custom_dues_earnings_section_start",
				"fieldtype": "Section Break",
				"insert_after": "custom_dues_days_worked",
			},
			{
				"fieldname": "custom_dues_earnings_section_end",
				"fieldtype": "Section Break",
				"insert_after": "custom_last_month_earnings",
			},
			{
				"fieldname": "custom_dues_deductions_section_start",
				"fieldtype": "Section Break",
				"insert_after": "custom_ded_other",
			},
			{
				"fieldname": "custom_dues_deductions_section_end",
				"fieldtype": "Section Break",
				"insert_after": "custom_last_month_deductions",
			},
		],
	}
