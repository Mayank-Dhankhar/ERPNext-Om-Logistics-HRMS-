# olscpl_hrms/patches/v1_1/add_careers_page_shortcuts.py
#
# Adds a "Careers Page" (/jobs) URL shortcut to the Atlas Home and Complete
# Flow workspaces. The workspace JSON fixtures under
# olscpl_hrms/olscpl_hrms/workspace/ carry this too, but bench migrate's
# workspace sync only inserts missing workspaces - it does not overwrite an
# already-existing record's content/shortcuts from its JSON file, so an
# edit there alone never reaches a site that already has these workspaces.
# Writing it here (like setup_role_based_hr_access.py) is what actually
# applies it. Registered under both patches.txt and hooks.py's
# after_migrate so it also survives the post-patch "Updating Dashboard for
# X" step the way setup_role_based_hr_access.py's Payroll fix needed to.
import contextlib

import frappe


@contextlib.contextmanager
def _no_fixture_export():
	original = frappe.conf.get("developer_mode")
	frappe.conf.developer_mode = 0
	try:
		yield
	finally:
		frappe.conf.developer_mode = original


def _shortcut_row_insert_position(content):
	"""Insert right after the last shortcut in the same "Explore" row,
	not at the very end of the whole page. A live workspace's content
	isn't just [header, shortcuts...] - it's
	[header, shortcuts, spacer, header, report cards...], so a plain
	content.append() lands the new block after every Reports & Masters
	card instead of alongside the other shortcuts (confirmed on
	atlas.omone.in - Careers Page showed up dead last on the page)."""
	last_shortcut_idx = None
	for i, block in enumerate(content):
		if block.get("type") == "shortcut":
			last_shortcut_idx = i
	return len(content) if last_shortcut_idx is None else last_shortcut_idx + 1


def _ensure_careers_shortcut(workspace_name, content_id, col=3):
	if not frappe.db.exists("Workspace", workspace_name):
		return
	doc = frappe.get_doc("Workspace", workspace_name)
	has_shortcut_row = any(s.label == "Careers Page" for s in doc.shortcuts)
	content = frappe.parse_json(doc.content)
	careers_idx = next(
		(i for i, b in enumerate(content) if b.get("data", {}).get("shortcut_name") == "Careers Page"), None
	)
	correct_idx = _shortcut_row_insert_position(
		[b for i, b in enumerate(content) if i != careers_idx]
	)

	if has_shortcut_row and careers_idx == correct_idx:
		return  # already present and already in the right spot

	dirty = False
	with _no_fixture_export():
		if not has_shortcut_row:
			doc.append(
				"shortcuts",
				{"label": "Careers Page", "type": "URL", "url": "/jobs", "color": "Grey", "doc_view": ""},
			)
			dirty = True
		if careers_idx is None:
			content.insert(correct_idx, {"id": content_id, "type": "shortcut", "data": {"shortcut_name": "Careers Page", "col": col}})
			dirty = True
		elif careers_idx != correct_idx:
			# already present, but appended in the wrong spot by an older
			# version of this patch (blind content.append()) - move it,
			# don't just leave it stranded after Reports & Masters.
			block = content.pop(careers_idx)
			content.insert(correct_idx, block)
			dirty = True
		if dirty:
			doc.content = frappe.as_json(content)
			doc.save(ignore_permissions=True)


def execute():
	_ensure_careers_shortcut("Atlas Home", "hhShortcutCareers")
	_ensure_careers_shortcut("Complete Flow", "cfShortcut1")
	frappe.db.commit()
