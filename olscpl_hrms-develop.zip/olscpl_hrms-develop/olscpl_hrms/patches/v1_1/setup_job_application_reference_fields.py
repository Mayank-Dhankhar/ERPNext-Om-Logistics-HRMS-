# olscpl_hrms/patches/v1_1/setup_job_application_reference_fields.py
#
# Public "Job Application" web form (/job_application):
# - Department: read-only, taken from the Job Opening being applied to (the
#   opening already has one - applicants don't choose it). Stored on Job
#   Applicant via fetch_from, so it's right however the application arrives
#   (this form, the careers API, desk); the form also shows it on load.
# - Pinned "General Application" opening (Job Opening.custom_is_general):
#   for people who walk in / come through a reference with no opening
#   posted. Always first on /jobs. On its form the applicant picks the
#   Department (or "Other" + its name) and any open job (or "Other" + the
#   position they want); the application stays on the general opening
#   (checked in events/job_applicant.set_department_and_position).
# - "Came through a reference?" - ticking it asks for the referring
#   employee's number (typed, not a dropdown), name and contact number.
#
# Stored as custom fields on Job Applicant (so HR sees them on the applicant
# too). The web form is HRMS's standard one, so its rows are written straight
# to the database, like make_resume_attachment_public.py and for the same
# reasons (no export into apps/hrms, no developer-mode refusal). Idempotent;
# also in after_migrate, so it comes back if HRMS ever resets the form.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter

WEB_FORM = "job-application"
REF = "eval:doc.custom_has_reference"

OTHER = "eval:doc.custom_position_applied=='Other'"
OTHER_DEPT = "eval:doc.custom_preferred_department=='Other'"

# web_*: how the web form shows it, when different from the stored field.
# Department/position options are filled in by DEPARTMENT_SCRIPT.
FIELDS = [
	# general opening's company pick (it is shared by every company); copied
	# into custom_company by the validate hook. Normal openings: hidden.
	{"fieldname": "custom_preferred_company", "label": "Company", "fieldtype": "Link", "options": "Company",
		"hidden": 1, "web_fieldtype": "Select", "web_hidden": 1},
	# fetch_if_empty: keeps what's chosen on the general opening (it has no
	# department); a normal opening's own one is forced in the validate hook
	{"fieldname": "custom_department", "label": "Department", "fieldtype": "Link", "options": "Department",
		"fetch_from": "job_title.department", "fetch_if_empty": 1, "read_only": 1, "web_fieldtype": "Select"},
	# general opening's pick (a department, or "Other" + a typed name); a
	# real one is copied into custom_department by the validate hook
	{"fieldname": "custom_preferred_department", "label": "Department", "fieldtype": "Data",
		"hidden": 1, "web_fieldtype": "Select", "web_hidden": 1},
	{"fieldname": "custom_other_department", "label": "Department Name", "fieldtype": "Data",
		"depends_on": OTHER_DEPT, "mandatory_depends_on": OTHER_DEPT},
	{"fieldname": "custom_position_applied", "label": "Position Applying For", "fieldtype": "Data",
		"read_only": 1, "web_fieldtype": "Select", "web_read_only": 0, "web_hidden": 1},
	{"fieldname": "custom_other_position", "label": "Position Name", "fieldtype": "Data",
		"depends_on": OTHER, "mandatory_depends_on": OTHER},
	{"fieldname": "custom_has_reference", "label": "Came through a reference?", "fieldtype": "Check"},
	{"fieldname": "custom_referrer_employee_number", "label": "Referrer Employee Code", "fieldtype": "Data",
		"depends_on": REF, "mandatory_depends_on": REF},
	{"fieldname": "custom_referrer_name", "label": "Referrer Name", "fieldtype": "Data",
		"depends_on": REF, "mandatory_depends_on": REF},
	{"fieldname": "custom_referrer_contact", "label": "Referrer Contact No", "fieldtype": "Data", "options": "Phone",
		"depends_on": REF, "mandatory_depends_on": REF},
	# how the application arrived: the QR code / a shared Copy Job Link (?via=qr /
	# ?via=link on the job page, picked up by the form script) or straight off the
	# careers site; "Added by HR" when made in the desk. QR / Link -> source Walk In
	# (events/job_applicant.set_channel_and_source).
	{"fieldname": "custom_application_channel", "label": "Application Channel", "fieldtype": "Select",
		"options": "\nWebsite\nQR Code\nLink\nAdded by HR", "read_only": 1, "in_standard_filter": 1,
		"web_hidden": 1, "web_read_only": 0},
]

GENERAL_TITLE = "General Application"
GENERAL_DESIGNATION = "General Application"
GENERAL_DESCRIPTION = (
	"<p>Didn't find your role listed, or came to us through a reference? Apply here - "
	"choose the company and your department, then the open position you want, or <b>Other</b> to tell us "
	"the role you're looking for.</p>"
)

SCRIPT_MARKER = "olscpl_hrms: job opening department v8"
DEPARTMENT_SCRIPT = f"""
// {SCRIPT_MARKER}
// A normal opening: show its own department, read-only (Job Applicant also
// takes it from the opening on save). The pinned general opening: pick the
// department (or "Other" + its name) and any open job (or "Other" + the
// position wanted).
(() => {{
	const wf = frappe.web_form;
	let tries = 0;
	let loading = false;
	let openings = [];
	const select = (fieldname, values) => wf.set_df_property(fieldname, "options", [""].concat(values));
	const fillPositions = () => {{
		select("custom_position_applied", [...new Set(openings.map((o) => o.title))].concat(["Other"]));
	}};
	// general opening: the chosen company's departments and open jobs
	const loadCompany = () => {{
		const company = wf.get_value("custom_preferred_company");
		openings = [];
		select("custom_preferred_department", ["Other"]);
		fillPositions();
		wf.set_value("custom_preferred_department", "");
		wf.set_value("custom_position_applied", "");
		if (!company) return;
		frappe.call({{
			method: "olscpl_hrms.api.job_application.get_form_options",
			args: {{ job_opening: wf.get_value("job_title"), company }},
			callback: (r) => {{
				const o = r.message || {{}};
				openings = o.openings || [];
				select("custom_preferred_department", (o.departments || []).concat(["Other"]));
				fillPositions();
			}},
		}});
	}};
	const fill = () => {{
		if (loading || wf.get_value("custom_department") || wf.get_value("custom_preferred_department")) return;
		const opening = wf.get_value("job_title");
		// the opening is filled in from the link a moment after this runs
		if (!opening) return tries++ < 20 && setTimeout(fill, 250);
		loading = true;
		frappe.call({{
			method: "olscpl_hrms.api.job_application.get_form_options",
			args: {{ job_opening: opening }},
			callback: (r) => {{
				const o = r.message || {{}};
				if (!o.is_general) {{
					if (!o.department) return;
					select("custom_department", [o.department]);
					return wf.set_value("custom_department", o.department);
				}}
				select("custom_preferred_company", o.companies || []);
				wf.set_df_property("custom_preferred_company", "hidden", 0);
				wf.set_df_property("custom_preferred_company", "reqd", 1);
				wf.fields_dict.custom_preferred_company.$input.on("change", loadCompany);
				wf.set_df_property("custom_department", "hidden", 1);
				wf.set_df_property("custom_preferred_department", "hidden", 0);
				wf.set_df_property("custom_preferred_department", "reqd", 1);
				wf.set_df_property("custom_position_applied", "hidden", 0);
				wf.set_df_property("custom_position_applied", "reqd", 1);
				loadCompany();
			}},
		}});
	}};
	// Application Channel: ?via=qr / ?via=link on this page, or on the job page it came
	// from (same-site referrer keeps the query) - else straight off the careers site
	const via = (new URLSearchParams(location.search).get("via")
		|| new URLSearchParams((document.referrer.split("?")[1] || "").split("#")[0]).get("via") || "").toLowerCase();
	const setChannel = () => wf.set_value("custom_application_channel", {{ qr: "QR Code", link: "Link" }}[via] || "Website");
	setChannel();
	wf.events.on("after_load", setChannel);
	// may run before the form has filled in job_title, or after its after_load
	fill();
	wf.events.on("after_load", fill);
}})();
"""


WALK_IN = "Walk In"


def execute():
	if not frappe.db.exists("Job Applicant Source", WALK_IN):
		frappe.get_doc({"doctype": "Job Applicant Source", "source_name": WALK_IN}).insert(ignore_permissions=True)
	create_custom_fields({"Job Opening": [{
		"fieldname": "custom_is_general", "label": "Pinned General Application", "fieldtype": "Check",
		"insert_after": "publish",
		# set only on the one opening ensure_general_opening() makes - not a choice for other jobs
		"hidden": 1, "read_only": 1,
		"description": "Always first on /jobs; applicants pick the department and position themselves "
			"(walk-ins / references with no opening posted)",
	}]}, update=True)
	ensure_general_opening()
	# the careers page / API never show how many applied - no option to
	make_property_setter("Job Opening", "publish_applications_received", "hidden", 1, "Check",
		validate_fields_for_doctype=False)

	# desk only: the opening's title under its id
	create_custom_fields({"Job Applicant": [{
		"fieldname": "custom_job_opening_title", "label": "Job Title", "fieldtype": "Data",
		"fetch_from": "job_title.job_title", "read_only": 1, "insert_after": "job_title",
	}]}, update=True)
	frappe.db.sql("""
		update `tabJob Applicant` ja join `tabJob Opening` jo on jo.name = ja.job_title
		set ja.custom_job_opening_title = jo.job_title
		where ifnull(ja.custom_job_opening_title, '') != jo.job_title
	""")

	# Job Applicant: right after Designation, in this order
	insert_after = "designation"
	custom = []
	for f in FIELDS:
		custom.append({k: v for k, v in f.items() if not k.startswith("web_")} | {"insert_after": insert_after})
		insert_after = f["fieldname"]
	create_custom_fields({"Job Applicant": custom}, update=True)

	if frappe.db.exists("Custom Field", "Job Applicant-custom_company"):
		frappe.db.set_value("Custom Field", "Job Applicant-custom_company", "fetch_if_empty", 1, update_modified=False)

	if not frappe.db.exists("Web Form", WEB_FORM):
		return
	rows = frappe.get_all(
		"Web Form Field",
		{"parent": WEB_FORM, "parenttype": "Web Form"},
		["name", "fieldname"],
		order_by="idx",
	)
	have = {r.fieldname: r for r in rows}
	ours = []
	for f in FIELDS:
		props = {
			"label": f["label"],
			"fieldtype": f.get("web_fieldtype") or f["fieldtype"],
			"options": None if f.get("web_fieldtype") else f.get("options"),
			"read_only": f.get("web_read_only", f.get("read_only", 0)),
			"hidden": f.get("web_hidden", 0),
			"depends_on": f.get("depends_on"),
			"mandatory_depends_on": f.get("mandatory_depends_on"),
		}
		if f["fieldname"] in have:
			frappe.db.set_value("Web Form Field", have[f["fieldname"]].name, props, update_modified=False)
			ours.append(have[f["fieldname"]])
			continue
		row = frappe.get_doc({
			"doctype": "Web Form Field",
			"parent": WEB_FORM,
			"parenttype": "Web Form",
			"parentfield": "web_form_fields",
			"fieldname": f["fieldname"],
			**props,
		})
		row.db_insert()
		ours.append(frappe._dict(name=row.name, fieldname=f["fieldname"]))

	# ours, in FIELDS order, right after "Country of Residence"
	mine = {f["fieldname"] for f in FIELDS}
	order = [r for r in rows if r.fieldname not in mine]
	pos = next((i + 1 for i, r in enumerate(order) if r.fieldname == "country"), len(order))
	order[pos:pos] = ours
	for idx, r in enumerate(order, start=1):
		frappe.db.set_value("Web Form Field", r.name, "idx", idx, update_modified=False)

	script = frappe.db.get_value("Web Form", WEB_FORM, "client_script") or ""
	if SCRIPT_MARKER not in script:
		# drop an older copy of our block (always appended last)
		old = script.find("// olscpl_hrms: job opening department")
		if old != -1:
			script = script[:old]
		frappe.db.set_value(
			"Web Form", WEB_FORM, "client_script", script.rstrip() + "\n" + DEPARTMENT_SCRIPT, update_modified=False
		)

	frappe.db.commit()
	frappe.clear_cache(doctype="Web Form")
	frappe.cache().delete_value(f"web_form:{WEB_FORM}")


def ensure_general_opening():
	if frappe.db.exists("Job Opening", {"custom_is_general": 1}):
		return
	company = frappe.defaults.get_global_default("company") or frappe.db.get_value("Company", {}, "name")
	if not company:
		return
	# Job Opening needs one (staffing-plan check); it isn't for one role
	if not frappe.db.exists("Designation", GENERAL_DESIGNATION):
		frappe.get_doc({"doctype": "Designation", "designation_name": GENERAL_DESIGNATION}).insert(ignore_permissions=True)
	jo = frappe.get_doc({
		"doctype": "Job Opening",
		"job_title": GENERAL_TITLE,
		"designation": GENERAL_DESIGNATION,
		"company": company,
		"status": "Open",
		"publish": 1,
		"custom_is_general": 1,
		"description": GENERAL_DESCRIPTION,
	})
	jo.insert(ignore_permissions=True)
