# The custom "Designation KRA" / "Designation KRA Item" doctypes were the
# wrong design for this - a bespoke mechanism duplicating hrms core's own
# Appraisal Template, which seed_kra_points.py now seeds directly. Must run
# after seed_kra_points.py (patches.txt order), since that's what carries
# the same point data over to Appraisal Template before this deletes the
# old doctypes and their data for good.
#
# Raw SQL, not frappe.delete_doc(): this app's own designation_kra/
# designation_kra_item source folders are gone by the time this patch
# ships (same commit), so frappe.get_doc("Designation KRA", ...) can no
# longer import their controller module to instantiate one - the normal
# delete path needs that import and fails with "No module named...".
# Working at the table/meta level directly sidesteps it.
import frappe


def execute():
	for doctype in ("Designation KRA Item", "Designation KRA"):
		if not frappe.db.exists("DocType", doctype):
			continue
		table = f"tab{doctype}"
		frappe.db.sql_ddl(f"DROP TABLE IF EXISTS `{table}`")
		frappe.db.sql("DELETE FROM `tabDocField` WHERE parent=%s", doctype)
		frappe.db.sql("DELETE FROM `tabDocPerm` WHERE parent=%s", doctype)
		frappe.db.sql("DELETE FROM `tabProperty Setter` WHERE doc_type=%s", doctype)
		frappe.db.sql("DELETE FROM `tabDocType` WHERE name=%s", doctype)

	frappe.clear_cache()
	frappe.db.commit()
