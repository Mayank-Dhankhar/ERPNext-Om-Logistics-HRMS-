# olscpl_hrms/patches/v1_1/add_job_applicant_onboarding_link_button.py
#
# New requirement: HR wants to send the same onboarding-documents link/
# email straight from Job Applicant, without creating a Job Offer first -
# everything else (message, portal link, static Guarantee/Medical forms)
# stays identical to the existing "Send Onboarding Link" button on Job
# Offer, it just can't attach a Letter of Intent (that PDF only renders
# from a Job Offer's own salary-structure fields - see
# employee_onboarding._first_send_attachments, which now skips it
# whenever job_offer isn't set).
#
# Employee Onboarding.job_offer is reqd=1 in core hrms - get_or_create_
# for_applicant() can't insert without a Property Setter relaxing that,
# same mechanism set_job_offer_default_print_format.py uses for the same
# reason (Job Offer/Employee Onboarding are standard hrms doctypes, not
# ours, so this can't go through developer_mode's direct DocType edit).
import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter

SCRIPT_NAME = "Job Applicant Onboarding Link Button"

SCRIPT = r"""frappe.ui.form.on("Job Applicant", {
	refresh: function (frm) {
		if (frm.doc.__islocal || frm.doc.status === "Rejected") {
			return;
		}

		frm.add_custom_button(__("Send Onboarding Link"), function () {
			frappe.confirm(
				__("Send an onboarding-document link to {0}? No Job Offer has been created - this won't include an offer letter, just the onboarding link and the standard joining forms.", [frm.doc.email_id]),
				function () {
					// Every onboarding form prints the sender's own
					// signature as "Employer/Authorised Signatory" -
					// make sure one exists (or gets drawn right now)
					// before anything actually goes out. See
					// public/js/signature_gate.js.
					ensureSenderSignature(function () {
						// Standard ATLAS loader across both steps (see
						// public/js/om_loader.js) instead of Frappe's blank
						// freeze, which also flickered between the two calls.
						om_loader.show(__("Preparing onboarding for {0}…", [frm.doc.applicant_name || frm.doc.email_id]));
						frappe.call({
							method: "olscpl_hrms.events.employee_onboarding.get_or_create_for_applicant",
							args: { job_applicant: frm.doc.name },
							always: function (r) {
								if (!r || !r.message) om_loader.hide();
							},
							callback: function (r) {
								if (!r.message) {
									return;
								}
								om_loader.show(__("Sending the onboarding link to {0}…", [frm.doc.email_id]));
								frappe.call({
									method: "olscpl_hrms.events.employee_onboarding.generate_portal_link",
									args: { employee_onboarding: r.message },
									always: function () {
										om_loader.hide();
									},
									callback: function (r2) {
										if (r2.message) {
											var msg = r2.message.email_sent
												? __("Onboarding link sent to {0}. Valid until {1}.", [
														frm.doc.email_id,
														r2.message.expires_on,
												  ])
												: __(
														"Could not email this candidate (no outgoing email configured) - copy the link below and share it manually. Valid until {0}.<br><br><code>{1}</code>",
														[r2.message.expires_on, r2.message.portal_url]
												  );
											frappe.msgprint({
												title: r2.message.email_sent ? __("Link Sent") : __("Link Generated"),
												message: msg,
												indicator: r2.message.email_sent ? "green" : "orange",
											});
											frm.reload_doc();
										}
									},
								});
							},
						});
					});
				}
			);
		});

		frappe.db.get_list("Employee Onboarding", {
			filters: { job_applicant: frm.doc.name },
			fields: ["name"],
			limit: 1,
		}).then((rows) => {
			if (rows && rows.length) {
				frm.add_custom_button(__("View Employee Onboarding"), function () {
					frappe.set_route("Form", "Employee Onboarding", rows[0].name);
				});
			} else {
				frm.add_custom_button(__("New Employee Onboarding"), function () {
					frappe.new_doc("Employee Onboarding", {
						job_applicant: frm.doc.name,
						employee_name: frm.doc.applicant_name,
						company: frm.doc.custom_company,
					});
				});
			}
		});
	},
});
"""


def execute():
	if frappe.get_meta("Employee Onboarding").get_field("job_offer").reqd:
		make_property_setter("Employee Onboarding", "job_offer", "reqd", 0, "Check")

	if frappe.db.exists("Client Script", SCRIPT_NAME):
		frappe.db.set_value("Client Script", SCRIPT_NAME, "script", SCRIPT)
	else:
		frappe.get_doc({
			"doctype": "Client Script",
			"name": SCRIPT_NAME,
			"dt": "Job Applicant",
			"view": "Form",
			"enabled": 1,
			"script": SCRIPT,
		}).insert(ignore_permissions=True)

	frappe.db.commit()
