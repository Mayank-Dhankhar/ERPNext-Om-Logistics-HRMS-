# Loads HR's branch -> HR mapping (data/regional_hr.csv) into
# Branch.custom_branch_hrs. Runs after setup_org_chart created the table.
from olscpl_hrms.utils.branch_hr_import import run


def execute():
	run()
