"""
olscpl_hrms/patches/v1_1/add_iam_synced_field.py

Adds a hidden `custom_iam_synced` Check field on Employee, used by
olscpl_hrms.events.iam_sync to track whether the CREATION event for an
employee has already been published to User IAM (deferred until user_id
is set — see the note at the top of events/iam_sync.py for why).

Register in olscpl_hrms/patches.txt (post_model_sync section), placed
BEFORE backfill_iam_creation_events.py if/when that gets added there,
since the backfill patch depends on this field existing:
    olscpl_hrms.patches.v1_1.add_iam_synced_field
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields(
		{
			"Employee": [
				{
					"fieldname": "custom_iam_synced",
					"label": "IAM Synced",
					"fieldtype": "Check",
					"default": "0",
					"hidden": 1,
					"read_only": 1,
					"no_copy": 1,
					"insert_after": "user_id",
					"description": (
						"Internal — set once a CREATION event for this employee has been "
						"published to User IAM. Do not edit manually."
					),
				}
			]
		},
		ignore_validate=True,
	)
