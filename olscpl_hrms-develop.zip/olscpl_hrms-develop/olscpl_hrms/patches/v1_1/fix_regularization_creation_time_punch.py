# Regularizations got the request's creation time in the punch their type
# does not ask for (insert() fills an unset Time field with now, and
# auto_fill_missing_punch kept it - fixed there):
#   Less Working Hours / Missing Punch OUT -> Requested Punch IN
#   Missing Punch IN                        -> Requested Punch OUT
# On approval that time was written to the Attendance as a punch, so the day
# was recalculated wrongly (e.g. 09:26 -> 10:41 punch in, still Half Day).
#
# For every request hit by it: put back the day's real punch (first valid IN /
# last valid OUT, or empty) and, if Approved and the Attendance still holds the
# wrong time, recalculate the Attendance.
import frappe
from frappe.utils import get_datetime, get_time

from olscpl_hrms.events.attendance_regularization_steps import update_attendance_after_approval

# type -> (request field, attendance field, punch log_type, SQL aggregate)
AFFECTED = {
	"Less Working Hours": ("requested_punch_in_time", "custom_check_in_time", "IN", "MIN"),
	"Missing Punch OUT": ("requested_punch_in_time", "custom_check_in_time", "IN", "MIN"),
	"Missing Punch IN": ("requested_punch_out_time", "custom_check_out_time", "OUT", "MAX"),
}


def _seconds(t):
	return t.hour * 3600 + t.minute * 60 + t.second + t.microsecond / 1e6


def execute():
	rows = frappe.get_all(
		"Attendance Regularization",
		filters={"regularization_type": ("in", list(AFFECTED)), "docstatus": ("<", 2)},
		fields=["name", "employee", "for_date", "regularization_type", "requested_punch_in_time",
			"requested_punch_out_time", "creation", "attendance_link", "workflow_state"],
	)
	for r in rows:
		field, att_field, log_type, agg = AFFECTED[r.regularization_type]
		if not r.get(field):
			continue
		wrong = get_time(r.get(field))
		if abs(_seconds(wrong) - _seconds(get_datetime(r.creation))) > 5:
			continue  # not from the bug

		real = frappe.db.sql(
			f"""SELECT {agg}(time) FROM `tabEmployee Checkin`
			WHERE employee = %s AND log_type = %s AND custom_custom_geo_validation = 'Valid'
			AND time >= %s AND time < DATE_ADD(%s, INTERVAL 1 DAY)""",
			(r.employee, log_type, r.for_date, r.for_date),
		)[0][0]

		doc = frappe.get_doc("Attendance Regularization", r.name)
		doc.db_set(field, real.time() if real else None, update_modified=False)

		if r.workflow_state != "Approved" or not r.attendance_link:
			continue

		# Inactive (left) employees fail Attendance.validate -> skip the recalculation.
		if frappe.db.get_value("Employee", r.employee, "status") != "Active":
			frappe.log_error(f"Skipped recalculation, inactive employee {r.employee}: {r.name}", "Regularization patch")
			continue

		att_value = frappe.db.get_value("Attendance", r.attendance_link, att_field)
		if att_value and abs(_seconds(get_datetime(att_value)) - _seconds(wrong)) < 1:
			# drop the wrong punch; update_attendance_after_approval only
			# writes the times the request has, then recalculates the day
			try:
				frappe.db.set_value("Attendance", r.attendance_link, att_field, None, update_modified=False)
				update_attendance_after_approval(doc)
			except Exception:
				frappe.log_error(frappe.get_traceback(), f"Regularization patch failed for {r.name}")
