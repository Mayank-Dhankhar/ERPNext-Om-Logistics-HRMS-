# olscpl_hrms/patches/v1_1/add_job_offer_additional_terms.py
#
# Job Offer > "Additional Terms & Commitments": anything agreed with the
# candidate beyond the standard letter, including what was promised
# verbally. Asked for in the "Submit Offer" dialog (public/js/job_offer.js)
# and printed as the last page of the offer letter
# (api/letter_of_intent._additional_terms_page); left blank, no page.
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields({"Job Offer": [
		{"fieldname": "custom_additional_terms_section", "fieldtype": "Section Break", "label": "Additional Terms & Commitments",
			"insert_after": "custom_rs_benefit_gtl"},
		{"fieldname": "custom_additional_terms", "fieldtype": "Small Text", "label": "Additional Terms & Commitments",
			"insert_after": "custom_additional_terms_section",
			"description": "Anything agreed with the candidate that isn't in the standard letter, including verbal promises - "
				"e.g. joining bonus, relocation or travel support, laptop, notice-period buyout, planned leave. "
				"One point per line. Printed on the last page of the offer letter; leave blank if none."},
	]}, update=True)
