# olscpl_hrms/patches/v1_1/add_salary_comparison_report.py
#
# Registers "Salary Comparison Report" (Script Report on Salary Slip,
# from Mayank) as a standard report of this app and reloads it from the
# app's own report/salary_comparison_report/ files, so the report exists
# and stays in sync on every site this app is installed on.
import frappe


def execute():
    report_name = "Salary Comparison Report"

    if not frappe.db.exists("Report", report_name):
        frappe.get_doc({
            "doctype": "Report",
            "report_name": report_name,
            "ref_doctype": "Salary Slip",
            "report_type": "Script Report",
            "module": "OLSCPL HRMS",
            "is_standard": "Yes",
            "prepared_report": 0,
            "disabled": 0
        }).insert(ignore_permissions=True)
    else:
        frappe.db.set_value(
            "Report",
            report_name,
            {
                "ref_doctype": "Salary Slip",
                "report_type": "Script Report",
                "module": "OLSCPL HRMS",
                "is_standard": "Yes",
                "prepared_report": 0,
                "disabled": 0
            }
        )

    # Reload the standard report from app files
    frappe.reload_doc(
        "olscpl_hrms",
        "report",
        "salary_comparison_report"
    )

    frappe.db.commit()
