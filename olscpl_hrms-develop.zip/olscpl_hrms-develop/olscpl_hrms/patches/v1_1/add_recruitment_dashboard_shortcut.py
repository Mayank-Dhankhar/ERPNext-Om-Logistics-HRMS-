# olscpl_hrms/patches/v1_1/add_recruitment_dashboard_shortcut.py
#
# "Recruitment Dashboard" shortcut on the Recruitment workspace: opens the
# Recruitment & Onboarding control centre (ess_dashboard, /recruitment-dashboard).
# Same approach as add_resume_parser_shortcut.py.
import frappe

from olscpl_hrms.patches.v1_1.add_careers_page_shortcuts import _no_fixture_export, _shortcut_row_insert_position

LABEL = "Recruitment Dashboard"


def execute():
	if not frappe.db.exists("Workspace", "Recruitment"):
		return
	doc = frappe.get_doc("Workspace", "Recruitment")
	if any(s.label == LABEL for s in doc.shortcuts):
		return
	content = frappe.parse_json(doc.content)
	with _no_fixture_export():
		doc.append("shortcuts", {"label": LABEL, "type": "URL", "url": "/recruitment-dashboard", "color": "Blue", "doc_view": ""})
		content.insert(_shortcut_row_insert_position(content), {"id": "rcShortcutRecruitDash", "type": "shortcut", "data": {"shortcut_name": LABEL, "col": 3}})
		doc.content = frappe.as_json(content)
		doc.save(ignore_permissions=True)
	frappe.db.commit()
