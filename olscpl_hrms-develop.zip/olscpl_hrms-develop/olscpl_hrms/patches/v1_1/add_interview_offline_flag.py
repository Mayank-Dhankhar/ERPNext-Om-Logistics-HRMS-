# olscpl_hrms/patches/v1_1/add_interview_offline_flag.py
#
# Interview "Offline Interview (no emails)": for interviews already held
# offline that HR only records afterwards - events/interview.py then sends
# no scheduling mail to the candidate or interviewers and no feedback link to
# external interviewers. Idempotent.
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields({"Interview": [{
		"fieldname": "custom_offline_interview", "label": "Offline Interview (no emails)", "fieldtype": "Check",
		"insert_after": "status", "set_only_once": 1,
		"description": "Tick when the interview already happened offline and you are only recording it - "
			"no email goes to the candidate or interviewers. Set before the first save.",
	}]}, update=True)
