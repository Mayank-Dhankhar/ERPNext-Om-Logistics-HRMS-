# Social Post images pasted in the desk editor were uploaded as private files,
# so every other employee's feed got a 403 for them. Make them public and point
# the post at the new URL. (social_post.json now has make_attachments_public,
# so new uploads are public from the start.)
import frappe

FIELDS = ("content", "images", "attachments")


def execute():
	for f in frappe.get_all(
		"File", {"attached_to_doctype": "Social Post", "is_private": 1}, ["name", "file_url", "attached_to_name"]
	):
		old = frappe.get_doc("File", f.name)
		try:
			content = old.get_content()
		except Exception:
			continue  # file missing on disk - nothing to publish
		# A public copy, not is_private=0 + save: that refuses to move onto an
		# existing public file of the same name; insert() picks a free name.
		public = frappe.get_doc({
			"doctype": "File",
			"file_name": old.file_name,
			"content": content,
			"is_private": 0,
			"attached_to_doctype": "Social Post",
			"attached_to_name": f.attached_to_name,
		}).insert(ignore_permissions=True)
		post = frappe.db.get_value("Social Post", f.attached_to_name, FIELDS, as_dict=True) or {}
		for field in FIELDS:
			value = post.get(field)
			if value and f.file_url in value:
				# links also carry "?fid=<file name>"
				new = value.replace(f"{f.file_url}?fid={f.name}", public.file_url).replace(f.file_url, public.file_url)
				frappe.db.set_value("Social Post", f.attached_to_name, field, new, update_modified=False)
		frappe.delete_doc("File", f.name, ignore_permissions=True)
