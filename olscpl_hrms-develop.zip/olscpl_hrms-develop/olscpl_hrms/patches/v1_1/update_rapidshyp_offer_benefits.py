# olscpl_hrms/patches/v1_1/update_rapidshyp_offer_benefits.py
#
# RapidShyp's Benefits tick-boxes on Job Offer now carry the wording of HR's
# RapidShyp salary sheet (api/rapidshyp.py BENEFITS); the Gratuity line is
# gone - the sheet's "* PF, ESI, LWF, PT, Gratuity ..." note, always printed,
# covers it.
import frappe

from olscpl_hrms.patches.v1_1 import setup_offer_letter_note_fields


def execute():
	setup_offer_letter_note_fields.execute()  # relabels the tick-boxes
	if frappe.db.exists("Custom Field", "Job Offer-custom_rs_benefit_gratuity"):
		frappe.delete_doc("Custom Field", "Job Offer-custom_rs_benefit_gratuity", ignore_permissions=True)
