# olscpl_hrms/patches/v1_1/update_compensatory_leave_policy_script.py
#
# "Compensatory Leave Policy" (Server Script, before_validate on
# Compensatory Leave Request) does its own independent attendance check -
# separate from, and stricter than, HRMS core's own validate_attendance()
# (which overrides/compensatory_leave_request.py already made skippable) -
# requiring a submitted Attendance record for the worked date before it'll
# even compute the half/full-day split or apply the monthly cap. A
# historical bulk import usually has no Attendance record at all for
# those old dates, so this rejected every single row regardless of the
# override above.
#
# Wraps the script's entire body in the same
# custom_skip_attendance_validation check (System Manager only, see
# add_compensatory_leave_bulk_upload_field.py) - a Server Script is
# per-site data, not a file this app ships, so this patch is what
# actually applies the fix (a fixture entry for it deploys the *current*
# content to a brand-new site, but never overwrites this script on a site
# where it already exists with different content the way this patch does).
import frappe

NEW_SCRIPT = '''# Script Type - DocType Event
# Reference Document Type - Compensatory Leave Request
# DocType Event - Before Validate

if not doc.get("custom_skip_attendance_validation"):
    employee = doc.employee
    work_date = frappe.utils.getdate(doc.work_from_date)
    leave_type = doc.leave_type

    # 1. Fetch submitted Attendance
    attendance = frappe.db.get_value(
        "Attendance",
        {
            "employee": employee,
            "attendance_date": work_date,
            "docstatus": 1
        },
        ["working_hours", "status"],
        as_dict=True
    )

    if not attendance:
        frappe.throw("Attendance must be marked and submitted for the worked date.")

    # 2. Allowed attendance statuses
    if attendance.status not in ["Present", "Half Day", "Work From Home", "On Duty"]:
        frappe.throw("Attendance status is not eligible for Compensatory Leave.")

    # 3. AUTHORITATIVE HOURS-BASED COMP-OFF POLICY
    working_hours = attendance.working_hours or 0

    if working_hours >= 6:
        # FULL DAY COMP-OFF
        doc.half_day = 0
        doc.half_day_date = None
        doc.total_leave_days = 1

    elif working_hours >= 3:
        # HALF DAY COMP-OFF
        doc.half_day = 1
        doc.half_day_date = work_date   # REQUIRED FIELD
        doc.total_leave_days = 0.5

    else:
        frappe.throw("Worked less than 3 hours. Compensatory Leave is not allowed.")

    # 4. Monthly limit (Max 5 days)
    month_start = work_date.replace(day=1)
    month_end = frappe.utils.get_last_day(work_date)

    used_comp_off = frappe.db.sql("""
        SELECT SUM(
            CASE WHEN half_day = 1 THEN 0.5 ELSE 1 END
        )
        FROM `tabCompensatory Leave Request`
        WHERE employee = %s
          AND leave_type = %s
          AND work_from_date BETWEEN %s AND %s
          AND docstatus = 1
    """, (employee, leave_type, month_start, month_end))[0][0] or 0

    requested = doc.total_leave_days or 0

    # Fetch monthly limit from Leave Type custom field
    monthly_limit = frappe.db.get_value(
        "Leave Type",
        leave_type,
        "custom_maximum_leave_allocated_per_month"
    ) or 0

    # Apply limit only if defined (>0)
    if monthly_limit and (used_comp_off + requested > monthly_limit):
        frappe.throw(
            f"Maximum {monthly_limit} Compensatory Leaves are allowed per month for {leave_type}."
        )
# else: custom_skip_attendance_validation is set (System Manager only,
# see olscpl_hrms.patches.v1_1.add_compensatory_leave_bulk_upload_field) -
# this whole check depends on an Attendance record that a bulk-imported
# historical Compensatory Leave Request usually won't have, so it's
# skipped entirely rather than throwing on every single row.
'''


def execute():
	doc = frappe.get_doc("Server Script", "Compensatory Leave Policy")
	if doc.script.strip() == NEW_SCRIPT.strip():
		return
	doc.script = NEW_SCRIPT
	doc.save(ignore_permissions=True)
	frappe.db.commit()
