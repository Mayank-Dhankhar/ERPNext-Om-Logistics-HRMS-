# olscpl_hrms/patches/v1_1/setup_org_chart.py
#
# Org Chart page (/app/org-chart) stores each branch's HR people on the
# Branch itself: Branch.custom_branch_hrs, a Table MultiSelect of the
# "Branch HR" child doctype. Idempotent.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_field


def execute():
	frappe.reload_doc("olscpl_hrms", "doctype", "branch_hr")
	create_custom_field(
		"Branch",
		{
			"fieldname": "custom_branch_hrs",
			"label": "Branch HR",
			"fieldtype": "Table MultiSelect",
			"options": "Branch HR",
			"insert_after": "custom_branch_code",
			"description": "HR people responsible for this branch (set from the Org Chart page).",
		},
	)
	frappe.reload_doc("olscpl_hrms", "page", "org_chart")
	frappe.clear_cache(doctype="Branch")
