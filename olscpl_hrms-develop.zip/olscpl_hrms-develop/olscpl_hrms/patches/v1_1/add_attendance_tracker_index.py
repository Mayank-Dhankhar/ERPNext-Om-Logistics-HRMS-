# Composite index for the Monthly Attendance Tracker lookup by
# (employee, month, year). Attendance processing looks the tracker up about
# three times per Attendance record (attendance_steps, attendance_tracker_update
# on_update, monthly_attendance_tracker before_validate duplicate check), and
# the table had no index on these columns, so every lookup scanned the table.
#
# Frappe's schema sync drops indexes its doctype meta does not declare, and a
# composite index cannot be declared in the doctype, so this is idempotent and
# also runs from after_migrate to re-create the index after every migrate.
import frappe

INDEX_NAME = "idx_emp_month_year"


def execute():
	if not frappe.db.table_exists("Monthly Attendance Tracker"):
		return

	if frappe.db.sql(
		"show index from `tabMonthly Attendance Tracker` where Key_name = %s", INDEX_NAME
	):
		return

	frappe.db.add_index("Monthly Attendance Tracker", ["employee", "month", "year"], INDEX_NAME)
