# Tracks whether/when/by-whom an Appointment Letter has already been sent
# for this employee (see olscpl_hrms/api/appointment_letter.py and public/
# js/employee.js) - so re-opening the preview shows "already sent" instead
# of looking like it's never gone out, and the dialog's button reads "Send
# Again" rather than "Send Mail" once one has. Hidden - this is read-only
# bookkeeping state for that dialog, not something meant to be seen/edited
# as a regular form field.
import frappe


def execute():
	fields = [
		{
			"doctype": "Custom Field",
			"dt": "Employee",
			"fieldname": "custom_appointment_letter_sent_on",
			"fieldtype": "Datetime",
			"label": "Appointment Letter Sent On",
			"insert_after": "date_of_joining",
			"read_only": 1,
			"hidden": 1,
		},
		{
			"doctype": "Custom Field",
			"dt": "Employee",
			"fieldname": "custom_appointment_letter_sent_by",
			"fieldtype": "Link",
			"options": "User",
			"label": "Appointment Letter Sent By",
			"insert_after": "custom_appointment_letter_sent_on",
			"read_only": 1,
			"hidden": 1,
		},
	]
	for f in fields:
		docname = f"{f['dt']}-{f['fieldname']}"
		if frappe.db.exists("Custom Field", docname):
			continue
		frappe.get_doc(f).insert(ignore_permissions=True)

	frappe.db.commit()
