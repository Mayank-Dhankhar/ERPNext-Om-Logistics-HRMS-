# olscpl_hrms/patches/v1_1/add_full_and_final_settlement_print_format.py
#
# Recreates the company's legacy "Statement of Full & Final Settlement"
# Word-doc template as a proper Frappe Print Format on top of HRMS core's
# Full and Final Statement doctype, using the fields added by
# add_full_and_final_statement_fields.py. The doctype's own "letter_head"
# field (also added by that patch, auto-filled per-company by
# CustomFullandFinalStatement.set_default_letter_head()) is all that's
# needed for frappe's print view to pick up the right company's letterhead
# (see patches.v1_1.setup_company_letterheads) - no bespoke header/footer
# handling here, unlike appointment_letter.py which builds its PDF outside
# the print-format pipeline entirely.
import frappe

PRINT_FORMAT_NAME = "Full and Final Settlement (Legacy)"

HTML = r"""
<style>
	/* Print Format's own margin_top/bottom/left/right DocType fields (also
	   set in execute() below) are NOT actually consulted anywhere in
	   core's wkhtmltopdf pipeline for a Jinja print format - frappe.utils
	   .print_format.download_pdf -> frappe.get_print(as_pdf=True) never
	   builds pdf_options from them, and wkhtmltopdf itself ignores @page
	   margin CSS. The one mechanism that IS wired
	   (frappe.utils.pdf.get_print_format_styles/read_options_from_html)
	   scans the rendered HTML for a ".print-format { margin-top: ... }"
	   rule (longhand properties, not the "margin" shorthand - cssutils
	   doesn't expand shorthand into these names) and feeds those values to
	   wkhtmltopdf as --margin-*. Values below (1.6/6.35/12.7/12.7mm) are
	   the actual PDF geometry measured off the source document. */
	.print-format { margin-top: 1.6mm; margin-bottom: 6.35mm; margin-left: 12.7mm; margin-right: 12.7mm; }
	/* Source PDF's embedded text is Courier/Courier-Bold throughout
	   (confirmed from the PDF's own font metadata) - 10pt body copy in
	   the source, but this doctype's data has more sections than the
	   source template accounted for (separate Rate of Pay + last-month
	   Dues breakup + Deductions + Other Dues, where the source condenses
	   some of that), so 10pt across the board overflowed the page badly:
	   columns collided, 3 pages instead of 1. Backed down to 7.5pt body -
	   still real Courier, at a size dense text at 10pt would need for
	   this much content, not the ~7px shrink tried even earlier (which
	   read as "too much space between fonts" - px and pt aren't
	   equivalent, and that attempt was cramped without being genuinely
	   smaller in a way that stayed readable). Title/headings stay at the
	   source's actual 12pt since those aren't the cramped part. */
	.fnf-legacy { font-family: "Courier New", Courier, monospace; font-size: 7.5pt; color: #000; border: 1pt solid #000; padding: 2pt; }
	.fnf-legacy table { width: 100%; border-collapse: collapse; table-layout: fixed; }
	.fnf-legacy td, .fnf-legacy th { padding: 0.5pt 1.5pt; vertical-align: top; overflow-wrap: break-word; line-height: 1; }
	.fnf-legacy .company-name { text-align: center; font-weight: bold; font-size: 12pt; line-height: 1.4; text-transform: uppercase; }
	.fnf-legacy .title { text-align: center; font-weight: bold; font-size: 12pt; line-height: 1.4; text-transform: uppercase; margin-bottom: 2pt; }
	.fnf-legacy .grid { border: 1pt solid #000; }
	.fnf-legacy .grid td, .fnf-legacy .grid th { border: 1pt solid #000; text-align: center; }
	.fnf-legacy .grid th { font-weight: normal; font-size: 7pt; }
	.fnf-legacy .grid td { font-weight: bold; }
	.fnf-legacy .label { font-weight: normal; white-space: nowrap; }
	/* Boxed value, like the source's bracketed totals ("TOTAL Rs. [ 0 ]") */
	.fnf-legacy .box { border: 1pt solid #000; display: inline-block; padding: 0 10pt; min-width: 40pt; text-align: right; font-weight: bold; }
	/* Every cell in the two DUES/DEDUCTION tables is bordered, matching
	   the reference form's full grid (not just alternating row dividers).
	   47.5% / 45% with a real gap between (not a 50/50 split) - matches
	   the source's ~90.5mm / 14.3mm gap / ~85.7mm column geometry. */
	.fnf-legacy .two-col { width: 100%; }
	.fnf-legacy .two-col > tbody > tr > td.dues-col { width: 47.5%; vertical-align: top; padding: 0 7.5% 0 0; }
	.fnf-legacy .two-col > tbody > tr > td.ded-col { width: 45%; vertical-align: top; padding: 0; }
	/* The DUES/DEDUCTION pair only spans 65% of the content width here
	   (the other 35% is the signature column to their right), unlike the
	   source PDF where they span the full page width - so an absolute mm
	   desc-column width copied from the source's own geometry overshot
	   this narrower container and pushed the table into the signature
	   column. A relative split within each detail table's own width
	   avoids that. wkhtmltopdf's WebKit also doesn't reliably wrap an
	   unbroken "/"-joined label ("SPL1/DRF/CAB/FOOD/ACCM" has no spaces)
	   - handled with an explicit <wbr> in that one string. */
	.fnf-legacy .two-col table { margin: 0; border: 1pt solid #000; table-layout: fixed; }
	.fnf-legacy .two-col table td { border: 1pt solid #000; }
	.fnf-legacy .two-col table td:first-child { width: 73%; }
	.fnf-legacy .two-col table td:last-child { width: 27%; text-align: right; font-weight: bold; }
	/* "DUES"/"AMOUNT" and "DEDUCTION"/"AMOUNT" are two separate bordered
	   header boxes side by side in the source, spanning the same two
	   columns as the detail rows below them - not a single floating
	   label (that was a real content gap against the source, not just a
	   styling one: the source always shows both header cells). */
	.fnf-legacy .head-table td { border: 1pt solid #000; font-weight: bold; text-align: left; }
	/* Independent of the detail rows' amount column below (a separate
	   table, just visually stacked) - "AMOUNT" needs more room than any
	   actual number ever will, so it gets its own wider share here. */
	.fnf-legacy .head-table td:last-child { width: 34% !important; text-align: center; }
	.fnf-legacy .total-row td { font-weight: bold; }
	.fnf-legacy .no-border td { border: none !important; }
	.fnf-legacy .declaration { margin-top: 3pt; }
	.fnf-legacy .sign-row td { padding-top: 4pt; text-align: center; font-weight: bold; border-top: 1pt solid #000; }
	/* 99pt x 54pt in the source, i.e. ~35mm x 19mm */
	.fnf-legacy .sign-box { width: 35mm; height: 19mm; border: 1pt solid #000; margin-left: auto; }
	.fnf-legacy .sign-box-caption { text-align: center; font-size: 9pt; font-weight: bold; margin-top: 2pt; }
</style>

<div class="fnf-legacy">
	<div class="company-name">{{ doc.company }}</div>
	<div class="title">Statement of Full &amp; Final Settlement</div>

	<table class="no-border">
		<tr>
			<td class="label" style="width:12%;">SR NO.</td>
			<td style="width:38%;"><b>{{ doc.custom_sr_no or "" }}</b></td>
			<td class="label" style="width:18%;">EMP CODE:-</td>
			<td style="width:32%;"><b>{{ doc.custom_emp_code or "" }}</b></td>
		</tr>
		<tr>
			<td class="label">Name:-</td>
			<td><b>{{ doc.employee_name }}</b></td>
			<td class="label">S/o,D/o,W/o Sh:-</td>
			<td><b>{{ doc.custom_father_name or "" }}</b></td>
		</tr>
		<tr>
			<td class="label">Designation:-</td>
			<td><b>{{ doc.designation or "" }}</b></td>
			<td class="label">Department:-</td>
			<td><b>{{ doc.department or "" }}</b></td>
		</tr>
	</table>

	<div style="margin-top:2pt;">Rate of Pay:-</div>
	<table class="grid">
		<tr>
			<th style="width:6.67%;">BASIC</th><th style="width:5.83%;">HRA</th><th style="width:7.50%;">CONV.</th>
			<th style="width:9.17%;">UNI.ALW.</th><th style="width:12.50%;">EDU. ALLOW.</th><th style="width:9.17%;">MOBILE</th>
			<th style="width:9.17%;">LAPTOP</th><th style="width:11.67%;">TEA ALLOW.</th><th style="width:7.50%;">CCA</th>
			<th style="width:10.00%;">ARREARS</th><th style="width:10.83%;">OTHER</th>
		</tr>
		<tr>
			<td>{{ "%.0f"|format(doc.custom_rop_basic or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_hra or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_conv or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_uniform or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_edu_allow or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_mobile or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_laptop or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_tea_allow or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_cca or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_arrears or 0) }}</td>
			<td>{{ "%.0f"|format(doc.custom_rop_other or 0) }}</td>
		</tr>
	</table>

	<table class="no-border" style="margin-top:2px;">
		<tr>
			<td class="label" style="width:8%; white-space:nowrap;">Salary:-</td>
			<td style="width:8%; white-space:nowrap;">{{ "%.0f"|format(doc.custom_rop_total or 0) }}</td>
			<td class="label" style="width:7%; white-space:nowrap;">DOJ:-</td>
			<td style="width:12%; white-space:nowrap;">{{ frappe.utils.format_date(doc.date_of_joining, "dd-MMM-yy") if doc.date_of_joining else "" }}</td>
			<td class="label" style="width:9%; white-space:nowrap;">DOJ OLL:-</td>
			<td style="width:12%; white-space:nowrap;">{{ frappe.utils.format_date(doc.custom_doj_oll, "dd-MMM-yy") if doc.custom_doj_oll else "" }}</td>
			<td class="label" style="width:12%; white-space:nowrap;">Date of Leaving:-</td>
			<td style="white-space:nowrap;">{{ frappe.utils.format_date(doc.relieving_date, "dd-MMM-yy") if doc.relieving_date else "" }}</td>
		</tr>
		<tr>
			<td class="label">Station:-</td>
			<td colspan="3">{{ doc.custom_station or "" }}</td>
			<td class="label" colspan="2">Reason for Leaving:-</td>
			<td colspan="2">{{ frappe.db.get_value("Employee", doc.employee, "reason_for_leaving") or "" }}</td>
		</tr>
	</table>

	<table class="no-border" style="margin-top:2pt;">
		<tr>
			<td valign="top" style="width:65%;">
				<table class="two-col">
					<tr>
						<td class="dues-col">
							<table class="head-table"><tr><td>DUES</td><td>AMOUNT</td></tr></table>
							<table>
								<tr><td colspan="2">Salary/Wages for the M/o {{ frappe.utils.format_date(doc.relieving_date, "MMM-yyyy") if doc.relieving_date else "" }} ({{ doc.custom_dues_days_worked or "0 Days" }})</td></tr>
								<tr><td>BASIC</td><td>{{ "%.0f"|format(doc.custom_dues_basic or 0) }}</td></tr>
								<tr><td>HRA</td><td>{{ "%.0f"|format(doc.custom_dues_hra or 0) }}</td></tr>
								<tr><td>CONV.</td><td>{{ "%.0f"|format(doc.custom_dues_conv or 0) }}</td></tr>
								<tr><td>UNI.ALW.</td><td>{{ "%.0f"|format(doc.custom_dues_uniform or 0) }}</td></tr>
								<tr><td>EDU.ALLOW.</td><td>{{ "%.0f"|format(doc.custom_dues_edu_allow or 0) }}</td></tr>
								<tr><td>MOBILE</td><td>{{ "%.0f"|format(doc.custom_dues_mobile or 0) }}</td></tr>
								<tr><td>INCENTIVE</td><td>{{ "%.0f"|format(doc.custom_dues_incentive or 0) }}</td></tr>
								<tr><td>ADVANCE BONUS</td><td>{{ "%.0f"|format(doc.custom_dues_advance_bonus or 0) }}</td></tr>
								<tr><td>CCA/MESS/WASHING</td><td>{{ "%.0f"|format(doc.custom_dues_cca_mess_washing or 0) }}</td></tr>
								<tr><td>ARREAR/OTHER</td><td>{{ "%.0f"|format(doc.custom_dues_arrear_other or 0) }}</td></tr>
								<tr class="total-row"><td>TOTAL Rs.</td><td>{{ "%.0f"|format(doc.custom_dues_total or 0) }}</td></tr>
							</table>
							<table style="margin-top:2px; table-layout:auto;">
								<tr><td style="white-space:nowrap;">Encashment Last Yr</td><td style="white-space:nowrap;">{{ doc.custom_encashment_last_yr_leave or "" }} Leave</td><td style="width:26%;">{{ "%.0f"|format(doc.custom_encashment_last_yr_amount or 0) }}</td></tr>
								<tr><td style="white-space:nowrap;">Encashment Current Yr</td><td style="white-space:nowrap;">{{ doc.custom_encashment_current_yr_leave or "0.0" }} Leave</td><td>{{ "%.0f"|format(doc.custom_encashment_current_yr_amount or 0) }}</td></tr>
								<tr><td colspan="2">Bonus/EX-Gratia Last Year</td><td>{{ "%.0f"|format(doc.custom_bonus_exgratia_last_yr or 0) }}</td></tr>
								<tr><td colspan="2">Bonus/EX-Gratia Current Year</td><td>{{ "%.0f"|format(doc.custom_bonus_exgratia_current_yr or 0) }}</td></tr>
								<tr><td style="white-space:nowrap;">Gratuity</td><td style="white-space:nowrap;">{{ doc.custom_gratuity_years or 0 }} Yrs</td><td>{{ "%.0f"|format(doc.custom_gratuity_amount or 0) }}</td></tr>
								<tr><td style="white-space:nowrap;">Notice Pay</td><td style="white-space:nowrap;">{{ doc.custom_notice_pay_days or 0 }} Days</td><td>{{ "%.0f"|format(doc.custom_notice_pay_amount or 0) }}</td></tr>
								<tr><td colspan="2">Service Compensation</td><td>{{ "%.0f"|format(doc.custom_service_compensation or 0) }}</td></tr>
								<tr><td colspan="2">MISC</td><td>{{ "%.0f"|format(doc.custom_misc or 0) }}</td></tr>
								<tr class="total-row"><td colspan="2">TOTAL</td><td>{{ "%.0f"|format(doc.custom_other_dues_total or 0) }}</td></tr>
							</table>
						</td>
						<td class="ded-col">
							<table class="head-table"><tr><td>DEDUCTION</td><td>AMOUNT</td></tr></table>
							<table>
								<tr><td>E.P.F</td><td>{{ "%.0f"|format(doc.custom_ded_epf or 0) }}</td></tr>
								<tr><td>E.S.I</td><td>{{ "%.0f"|format(doc.custom_ded_esi or 0) }}</td></tr>
								<tr><td>T.D.S</td><td>{{ "%.0f"|format(doc.custom_ded_tds or 0) }}</td></tr>
								<tr><td>LWF/P.F.TAX</td><td>{{ "%.0f"|format(doc.custom_ded_lwf_pf_tax or 0) }}</td></tr>
								<tr><td>LOAN/ADVANCE</td><td>{{ "%.0f"|format(doc.custom_ded_loan_advance or 0) }}</td></tr>
								<tr><td>NOTICE</td><td>{{ "%.0f"|format(doc.custom_ded_notice or 0) }}</td></tr>
								<tr><td>EXCESS LEAVES - {{ doc.custom_ded_excess_leave_days or "" }}</td><td>{{ "%.0f"|format(doc.custom_ded_excess_leave_amount or 0) }}</td></tr>
								<tr><td>DEDUCTION FROM A/C</td><td>{{ "%.0f"|format(doc.custom_ded_deduction_from_ac or 0) }}</td></tr>
								<tr><td>SPL1/DRF/CAB<wbr>/FOOD/ACCM</td><td>{{ "%.0f"|format(doc.custom_ded_spl1_drf_cab_food_accm or 0) }}</td></tr>
								<tr><td>OTHER</td><td>{{ "%.0f"|format(doc.custom_ded_other or 0) }}</td></tr>
								<tr class="total-row"><td>TOTAL Rs.</td><td>{{ "%.0f"|format(doc.custom_ded_total or 0) }}</td></tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
			<td valign="top" style="width:35%; padding-left: 8pt; padding-top: 0;">
				<div class="sign-box"></div>
				<div class="sign-box-caption">Emp.Sign.Thumb Impression</div>
			</td>
		</tr>
	</table>

	<table class="no-border" style="margin-top:2pt;">
		<tr>
			<td class="label" style="width:16%;">GRAND TOTAL</td>
			<td style="width:20%;"><span class="box">{{ "%.0f"|format(doc.custom_grand_total or 0) }}</span></td>
			<td class="label" style="width:28%;">Amount payable/recoverable Rs.</td>
			<td><span class="box">{{ "%.0f"|format(doc.custom_amount_payable_recoverable or 0) }}</span></td>
		</tr>
	</table>
	<div style="margin-top:2pt;">In Words: <b>{{ doc.custom_amount_in_words or "" }}</b></div>
	<div style="margin-top:2pt;">Remarks: <b>{{ doc.custom_settlement_remarks or "" }}</b></div>

	<table class="sign-row" style="margin-top:4pt;">
		<tr>
			<td>Prepared By</td>
			<td>Verified By</td>
			<td>Accounts Checked By</td>
			<td>Accounts H.O.D</td>
		</tr>
	</table>

	<div class="declaration">
		<div style="font-weight:bold; text-align:center; text-decoration:underline; margin-bottom:2pt;">DECLARATION</div>
		<div style="font-weight:bold;">
			I ______________{{ doc.employee_name }}______________S/o,D/o,W/o,Sh.______________{{ doc.custom_father_name or "" }}______________
		</div>
		<div style="font-size:8pt; font-weight:normal; margin-top:2pt;">
			Declare that I have received from the Company being the amount due to me in Full &amp; Final Settlement of my dues
			against earned wages, leave encashment, Notice Period, Service Compensation, Bonus, Gratuity etc. and have signed
			in token thereof. I will not claim reinstatement/later on as, I have resigned my job of my own accord. Nothing
			more is due to me from any account of the company.
		</div>
		<table class="no-border" style="margin-top:4pt; font-weight:bold; font-size:9pt;">
			<tr>
				<td style="width:50%;">Date:</td>
				<td style="text-align:right;">Emp.Signature &amp; Thumb Impression</td>
			</tr>
		</table>
	</div>
</div>
"""


def execute():
	doc_type = "Full and Final Statement"
	if not frappe.db.exists("DocType", doc_type):
		return

	if frappe.db.exists("Print Format", PRINT_FORMAT_NAME):
		pf = frappe.get_doc("Print Format", PRINT_FORMAT_NAME)
	else:
		pf = frappe.new_doc("Print Format")
		pf.name = PRINT_FORMAT_NAME
		pf.doc_type = doc_type
		pf.module = "OLSCPL HRMS"

	pf.print_format_type = "Jinja"
	pf.standard = "No"
	pf.disabled = 0
	pf.html = HTML
	pf.custom_format = 1
	# These DocType fields are cosmetic only - the print/PDF pipeline for a
	# Jinja print format never reads them (confirmed: frappe.utils
	# .print_format.download_pdf -> frappe.get_print(as_pdf=True) builds no
	# pdf_options from them). Set anyway so the Print Format Builder UI and
	# any future core version that does wire them shows the right values;
	# the ".print-format { margin-top: ... }" rule in HTML's own <style>
	# above is what actually controls the rendered PDF's margins.
	pf.margin_top = 6
	pf.margin_bottom = 6
	pf.margin_left = 8
	pf.margin_right = 8
	pf.save(ignore_permissions=True)

	# Make this the default print format so it's what actually renders on
	# Print/PDF without the user having to pick it from the dropdown -
	# otherwise it silently falls back to the generic "Standard" format
	# (a plain field dump, nothing like the legacy layout this builds).
	# Full and Final Statement is a standard (non-custom) doctype, so this
	# has to go through a Property Setter, not a direct DocType edit
	# (that would need developer_mode).
	from frappe.custom.doctype.property_setter.property_setter import make_property_setter

	make_property_setter(
		doc_type,
		fieldname=None,
		property="default_print_format",
		value=PRINT_FORMAT_NAME,
		property_type="Data",
		for_doctype=True,
	)

	frappe.db.commit()
