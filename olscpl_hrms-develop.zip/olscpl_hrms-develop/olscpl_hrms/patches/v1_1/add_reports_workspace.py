# olscpl_hrms/patches/v1_1/add_reports_workspace.py
#
# A dedicated "Reports" entry in the sidebar, right below "Dashboards" (same
# sequence_id pattern: Dashboards sits at 0.7, Recruitment at 3.0, so 1.0
# lands cleanly between them) - module "OLSCPL HRMS" so it's not entangled
# with hrms core's own Workspace sync the way "Atlas Home" is (module
# "Payroll", owned by hrms - saving it writes back into hrms's own source
# tree and a later `bench migrate` can silently reset links added there).
# Owning this workspace outright avoids that.
import frappe


def execute():
	workspace_name = "Reports"
	report_name = "Reporting Person Report"

	if not frappe.db.exists("Workspace", workspace_name):
		frappe.get_doc({
			"doctype": "Workspace",
			"name": workspace_name,
			"title": workspace_name,
			"label": workspace_name,
			"module": "OLSCPL HRMS",
			"icon": "file",
			"public": 1,
			"is_hidden": 0,
			"sequence_id": 1.0,
			"content": frappe.as_json([
				{"type": "header", "data": {"col": 12, "text": '<span class="h4"><b>Reports</b></span>'}},
				{"type": "spacer", "data": {"col": 12}},
				{"type": "shortcut", "data": {"col": 6, "shortcut_name": report_name}},
			]),
			"shortcuts": [{
				"label": report_name,
				"type": "Report",
				"link_to": report_name,
			}],
			"roles": [{"role": "System Manager"}, {"role": "HR Manager"}, {"role": "HR User"}],
		}).insert(ignore_permissions=True)
	else:
		workspace = frappe.get_doc("Workspace", workspace_name)
		if not any(s.label == report_name for s in workspace.shortcuts):
			workspace.append("shortcuts", {"label": report_name, "type": "Report", "link_to": report_name})
			blocks = frappe.parse_json(workspace.content)
			blocks.append({"type": "shortcut", "data": {"col": 6, "shortcut_name": report_name}})
			workspace.content = frappe.as_json(blocks)
			workspace.save(ignore_permissions=True)

	frappe.db.commit()
