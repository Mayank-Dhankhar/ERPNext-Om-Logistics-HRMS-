# olscpl_hrms/patches/v1_1/setup_email_branding.py
#
# Email Branding records for today's two designs (Default = OM One ATLAS,
# RapidShyp), so they can be edited from the UI, and the Notification fields
# that let any UI-made notification use them (overrides/notification.py).
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from olscpl_hrms.utils.email_layout import DEFAULT_BRANDING, RAPIDSHYP_BRANDING


def execute():
	frappe.reload_doc("olscpl_hrms", "doctype", "email_branding")
	from olscpl_hrms.api.rapidshyp import COMPANY

	for values, extra in ((DEFAULT_BRANDING, {"is_default": 1}), (RAPIDSHYP_BRANDING, {"company": COMPANY})):
		if frappe.db.exists("Email Branding", values.brand_name):
			continue
		if extra.get("company") and not frappe.db.exists("Company", extra["company"]):
			continue
		frappe.get_doc({"doctype": "Email Branding", **values, **extra, "enabled": 1}).insert(ignore_permissions=True)

	create_custom_fields({"Notification": [
		{"fieldname": "custom_company_template_section", "fieldtype": "Section Break", "label": "Company Email Template",
			"insert_after": "message_examples", "collapsible": 0},
		{"fieldname": "custom_use_company_template", "fieldtype": "Check", "label": "Use company email template",
			"insert_after": "custom_company_template_section",
			"description": "Send this email inside a company's Email Branding (header, colours, footer)."},
		{"fieldname": "custom_template_company", "fieldtype": "Link", "options": "Company", "label": "Company",
			"insert_after": "custom_use_company_template", "depends_on": "custom_use_company_template",
			"description": "Whose branding to use. Blank: the document's own Company (else the Default branding)."},
		{"fieldname": "custom_template_label", "fieldtype": "Data", "label": "Template Label",
			"insert_after": "custom_template_company", "depends_on": "custom_use_company_template",
			"description": "The badge at the top, e.g. Leave Approved. Blank: the subject."},
		{"fieldname": "custom_template_signoff", "fieldtype": "Check", "label": "Add team sign-off",
			"insert_after": "custom_template_label", "depends_on": "custom_use_company_template",
			"description": "Ends the mail with the branding's \"Thank you, <team>\" block."},
	]}, update=True)
