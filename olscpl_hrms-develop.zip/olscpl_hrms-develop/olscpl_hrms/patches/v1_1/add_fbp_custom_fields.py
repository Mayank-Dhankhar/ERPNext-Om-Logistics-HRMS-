# olscpl_hrms/patches/v1_1/add_fbp_custom_fields.py
#
# Flexi Benefit Plan (RapidShyp / OSBS) - the fields it needs on core doctypes:
#
#   Salary Structure Assignment: the employee's chosen ANNUAL amount per FBP
#     component + their total. Written when an FBP Declaration is submitted
#     (doctype/fbp_declaration); read by the formulas of "OSBS Flexi Benefit
#     Structure" (setup_osbs_flexi_structure.py) - Frappe HR exposes every
#     Salary Structure Assignment field to a Salary Structure formula.
#   Company: "Enable Flexi Benefit Plan". FBP Declaration is refused for a
#     company that doesn't have it ticked; left unticked here - HR ticks it for
#     OPEN SOURCE BUSINESS SOLUTIONS PVT LTD after UAT.
#
# Idempotent (create_custom_fields with update=True).
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from olscpl_hrms.utils.fbp_slabs import COMPONENT_FIELD_MAP, TOTAL_FIELD

LABELS = {
	"fbp_uniform": "FBP Uniform (Annual)",
	"fbp_food_coupon": "FBP Food Coupon (Annual)",
	"fbp_internet": "FBP Internet (Annual)",
	"fbp_children_edu": "FBP Children Education (Annual)",
	"fbp_books": "FBP Books and Periodicals (Annual)",
	"fbp_conveyance": "FBP Conveyance (Annual)",
	"fbp_helper": "FBP Helper (Annual)",
	"fbp_driver": "FBP Driver (Annual)",
	"fbp_scholarship": "FBP Scholarship (Annual)",
	TOTAL_FIELD: "FBP Opted Total (Annual)",
}


def execute():
	ssa_fields = [
		{
			"fieldname": "fbp_section",
			"label": "Flexi Benefit Plan (set by FBP Declaration)",
			"fieldtype": "Section Break",
			"insert_after": "base",
			"collapsible": 1,
		}
	]
	previous = "fbp_section"
	for fieldname in list(COMPONENT_FIELD_MAP.values()) + [TOTAL_FIELD]:
		ssa_fields.append(
			{
				"fieldname": fieldname,
				"label": LABELS[fieldname],
				"fieldtype": "Currency",
				"default": "0",
				"read_only": 1,
				"allow_on_submit": 1,
				"no_copy": 1,
				"insert_after": previous,
			}
		)
		previous = fieldname

	create_custom_fields(
		{
			"Salary Structure Assignment": ssa_fields,
			"Company": [
				{
					"fieldname": "enable_fbp",
					"label": "Enable Flexi Benefit Plan",
					"fieldtype": "Check",
					"default": "0",
					"insert_after": "company_name",
				}
			],
		},
		update=True,
	)
