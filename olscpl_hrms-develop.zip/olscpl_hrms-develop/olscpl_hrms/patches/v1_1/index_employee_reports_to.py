# Employee.reports_to has no index, so the Org Chart's "who manages whom"
# lookups scanned all ~10k employees per row and took minutes.
import frappe


def execute():
	frappe.db.add_index("Employee", ["reports_to"])
