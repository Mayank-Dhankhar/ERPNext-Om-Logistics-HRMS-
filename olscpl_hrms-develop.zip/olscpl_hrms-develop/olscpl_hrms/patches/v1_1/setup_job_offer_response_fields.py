# olscpl_hrms/patches/v1_1/setup_job_offer_response_fields.py
#
# Fields behind the candidate's Accept/Decline buttons in the offer letter
# email (olscpl_hrms.events.job_offer). The key is a per-offer secret in the
# emailed link - the response page needs no login. Idempotent, run from
# after_migrate.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	common = {"read_only": 1, "no_copy": 1, "allow_on_submit": 1, "print_hide": 1}
	create_custom_fields(
		{
			"Job Offer": [
				{
					"fieldname": "custom_offer_response_key",
					"label": "Offer Response Key",
					"fieldtype": "Data",
					"hidden": 1,
					"insert_after": "status",
					**common,
				},
				{
					"fieldname": "custom_offer_responded_on",
					"label": "Candidate Responded On",
					"fieldtype": "Datetime",
					"insert_after": "custom_offer_response_key",
					"depends_on": "eval:doc.custom_offer_responded_on",
					**common,
				},
				{
					"fieldname": "custom_offer_decline_reason",
					"label": "Candidate's Reason for Declining",
					"fieldtype": "Small Text",
					"insert_after": "custom_offer_responded_on",
					"depends_on": "eval:doc.custom_offer_decline_reason",
					**common,
				},
			]
		},
		update=True,
	)
	frappe.db.commit()
