import frappe


def execute():
	if not frappe.db.exists("Custom Field", "Shift Assignment-weekly_off_day"):
		frappe.get_doc({
			"doctype": "Custom Field",
			"dt": "Shift Assignment",
			"fieldname": "weekly_off_day",
			"fieldtype": "Select",
			"options": "\nMonday\nTuesday\nWednesday\nThursday\nFriday\nSaturday\nSunday",
			"label": "Weekly Off Day",
			"insert_after": "end_date",
			"reqd": 1,
		}).insert(ignore_permissions=True)

	frappe.db.commit()
	