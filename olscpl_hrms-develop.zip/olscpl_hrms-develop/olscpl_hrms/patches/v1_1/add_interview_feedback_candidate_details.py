# olscpl_hrms/patches/v1_1/add_interview_feedback_candidate_details.py
#
# Interview Feedback > "Candidate Details" (below Feedback): what the HR /
# personal round asks - locations, experience and package, family, referral.
# events/interview_feedback.py starts a new feedback with what the
# candidate's previous feedback held, and writes the details as points into
# the Interview's Interview Summary. Editable after submit - the notes are
# often typed up after the round is submitted.
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter

MARRIED = "eval:doc.custom_married"


def _f(fieldname, label, fieldtype="Data", **extra):
	return {"fieldname": fieldname, "label": label, "fieldtype": fieldtype, "allow_on_submit": 1, **extra}


FIELDS = [
	_f("custom_candidate_details_section", "Candidate Details", "Section Break",
		description="HR / personal round - carried to the candidate's next feedback and shown in the Interview Summary"),
	_f("custom_current_job_location", "Current Job Location"),
	_f("custom_native_place", "Native Place"),
	_f("custom_candidate_details_col", None, "Column Break"),
	_f("custom_current_residing_location", "Current Residing Location"),
	_f("custom_preferred_location", "Preferred Location"),

	_f("custom_package_section", "Experience & Package", "Section Break"),
	_f("custom_total_experience", "Total Experience", description="e.g. 5 years 4 months"),
	_f("custom_current_package", "Current Package", description="e.g. 6.5 LPA"),
	_f("custom_current_fixed", "Fixed"),
	_f("custom_current_variable", "Variable"),
	_f("custom_package_col", None, "Column Break"),
	_f("custom_expected_package", "Expected Package"),
	_f("custom_notice_period", "Notice Period"),
	_f("custom_reason_for_change", "Reason for Change", "Small Text"),

	_f("custom_family_section", "Family Background", "Section Break"),
	_f("custom_father", "Father"),
	_f("custom_mother", "Mother"),
	_f("custom_brother", "Brother(s)"),
	_f("custom_sister", "Sister(s)"),
	_f("custom_family_col", None, "Column Break"),
	_f("custom_married", "Married", "Check"),
	_f("custom_spouse", "Spouse", depends_on=MARRIED),
	_f("custom_son", "Son(s)", depends_on=MARRIED),
	_f("custom_daughter", "Daughter(s)", depends_on=MARRIED),

	# filled from the Job Applicant's reference, when the application had one
	_f("custom_referred_by_section", "Referred By", "Section Break"),
	_f("custom_referred_by_name", "Name", fetch_from="job_applicant.custom_referrer_name", fetch_if_empty=1),
	_f("custom_referred_by_company", "Company"),
	_f("custom_referred_by_col", None, "Column Break"),
	_f("custom_referred_by_emp_code", "Emp Code", fetch_from="job_applicant.custom_referrer_employee_number", fetch_if_empty=1),
	_f("custom_referred_by_mobile", "Mob. No.", fetch_from="job_applicant.custom_referrer_contact", fetch_if_empty=1),
]

# carried to the next feedback and into the summary (layout fields left out)
CARRIED = [f["fieldname"] for f in FIELDS if f["fieldtype"] not in ("Section Break", "Column Break")]
# summary point labels where the field label alone is unclear
SUMMARY_LABELS = {
	"custom_current_fixed": "Current Fixed", "custom_current_variable": "Current Variable",
	"custom_referred_by_name": "Referred By", "custom_referred_by_company": "Referrer Company",
	"custom_referred_by_emp_code": "Referrer Emp Code", "custom_referred_by_mobile": "Referrer Mob. No.",
}


def execute():
	fields, insert_after = [], "feedback"
	for f in FIELDS:
		fields.append({**f, "insert_after": insert_after})
		insert_after = f["fieldname"]
	create_custom_fields({"Interview Feedback": fields}, update=True)
	# Result offers the Interview's own decisions (Pending is interview-only:
	# no feedback yet) - events/interview_feedback.sync_interview_status
	make_property_setter("Interview Feedback", "result", "options", "\nCleared\nUnder Review\nRejected", "Text",
		validate_fields_for_doctype=False)
