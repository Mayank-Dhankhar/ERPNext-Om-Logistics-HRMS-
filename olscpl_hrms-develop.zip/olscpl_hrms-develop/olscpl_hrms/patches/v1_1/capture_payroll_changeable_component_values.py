import frappe


def execute():
	if not frappe.db.table_exists("Payroll Changeable Component"):
		return

	columns = frappe.db.get_table_columns("Payroll Changeable Component")
	if "custom_pf_ceiling_amount" not in columns:
		return

	row = frappe.db.get_value(
		"Payroll Changeable Component", None,
		["name", "custom_pf_ceiling_amount", "custom_bonus_limit_amount", "custom_bonus_ceiling_amount"],
		as_dict=True,
	)
	if not row:
		return

	frappe.cache().set_value(
		"payroll_changeable_component_pre_migration_values",
		frappe.as_json(row),
	)