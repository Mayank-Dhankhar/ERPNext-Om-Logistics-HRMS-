"""
Patch: olscpl_hrms/patches/v1_1/setup_performance_masters.py
Frappe HR / ERPNext v15.9

Creates (idempotent, safe to re-run):
  1. Custom Fields for KPI details on KRA and Goal
  2. Employee Feedback Criteria (competencies)
  3. KRAs for "Software Developer"
  4. Appraisal Template "Software Developer" (KRA weightage = 100, criteria weightage = 100)

Register in patches.txt:
  olscpl_hrms.patches.v1_1.setup_performance_masters
"""
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

# (KRA title, weightage, KPI text)
KRAS = [
	("Development and Delivery", 30,
	 "KPI: Sprint commitment met >= 90%; on-time delivery of assigned tasks >= 90%; "
	 "no more than 1 missed release deadline per quarter."),
	("Code Quality", 20,
	 "KPI: Code review first-pass rate >= 80%; unit-test coverage >= 70% on new code; "
	 "defects found in UAT <= 2 per release."),
	("Production Support and Bug Resolution", 15,
	 "KPI: P1 issues resolved within SLA 100%; P2 within SLA >= 90%; "
	 "repeat/reopened bugs <= 5%."),
	("Performance and Optimization", 10,
	 "KPI: Slow queries/APIs identified and fixed (target: at least 3 per half-year); "
	 "page/API response-time improvement as agreed with lead."),
	("Documentation and Knowledge Sharing", 10,
	 "KPI: Technical docs updated for every release; "
	 "at least 1 knowledge-sharing session per quarter."),
	("Learning and Upskilling", 10,
	 "KPI: Complete at least 2 agreed trainings/certifications per year; "
	 "apply 1 new skill/tool in a project."),
	("Collaboration and Ownership", 5,
	 "KPI: Positive peer/stakeholder feedback; participation in stand-ups, "
	 "reviews and retrospectives."),
]

# (Criteria, weightage)  -> competencies rated by manager/peers
CRITERIA = [
	("Problem Solving", 30),
	("Communication", 25),
	("Teamwork", 25),
	("Ownership and Accountability", 20),
]

TEMPLATE_NAME = "Software Developer"


def execute():
	create_kpi_custom_fields()
	create_feedback_criteria()
	create_kras()
	create_template()
	frappe.db.commit()


def create_kpi_custom_fields():
	# NEVER edit the standard DocType directly - extend with Custom Fields only
	create_custom_fields(
		{
			"KRA": [
				{
					"fieldname": "kpi_details",
					"label": "KPI Details",
					"fieldtype": "Small Text",
					"insert_after": "title",
					"description": "How this KRA is measured (KPIs and targets)",
				}
			],
			"Goal": [
				{
					"fieldname": "kpi_section",
					"label": "KPI",
					"fieldtype": "Section Break",
					"insert_after": "kra",
				},
				{
					"fieldname": "kpi_target",
					"label": "KPI Target",
					"fieldtype": "Data",
					"insert_after": "kpi_section",
				},
				{
					"fieldname": "kpi_actual",
					"label": "KPI Actual",
					"fieldtype": "Data",
					"insert_after": "kpi_target",
				},
			],
		},
		update=True,
	)


def create_feedback_criteria():
	for name, _ in CRITERIA:
		if not frappe.db.exists("Employee Feedback Criteria", name):
			frappe.get_doc(
				{"doctype": "Employee Feedback Criteria", "criteria": name}
			).insert(ignore_permissions=True)


def create_kras():
	for title, _, kpi in KRAS:
		if frappe.db.exists("KRA", title):
			frappe.db.set_value("KRA", title, "kpi_details", kpi)
		else:
			frappe.get_doc(
				{"doctype": "KRA", "title": title, "kpi_details": kpi}
			).insert(ignore_permissions=True)


def create_template():
	if frappe.db.exists("Appraisal Template", TEMPLATE_NAME):
		return
	frappe.get_doc(
		{
			"doctype": "Appraisal Template",
			"template_title": TEMPLATE_NAME,
			"description": "Annual appraisal template for Software Developers",
			"goals": [
				{"key_result_area": t, "per_weightage": w} for t, w, _ in KRAS
			],
			"rating_criteria": [
				{"criteria": c, "per_weightage": w} for c, w in CRITERIA
			],
		}
	).insert(ignore_permissions=True)
