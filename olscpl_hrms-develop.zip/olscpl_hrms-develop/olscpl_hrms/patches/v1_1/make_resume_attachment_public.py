# olscpl_hrms/patches/v1_1/make_resume_attachment_public.py
#
# The stock "Job Application" web form (hrms/hr/web_form/job_application)
# shows a "Private" checkbox in the upload dialog for the Resume Attachment
# field. Applicants have no reason to mark their resume private, and a
# private file can't be opened without a login - which breaks the resume
# link/preview for recruiters using a shared/portal view.
#
# There's no web-form-field property for this, so it's done by appending a
# small monkey-patch to the web form's Client Script (same mechanism the
# form already uses for the resume_link validation) that forces
# make_attachments_public on the Resume Attachment control and hides its
# private toggle.
#
# Written with frappe.db.set_value() rather than doc.save(), deliberately:
# Web Form.on_update() always re-exports a standard web form's module JSON
# when developer_mode is on (confirmed on atlas.omone.in - it rewrote
# apps/hrms/hrms/hr/web_form/job_application/job_application.json), and
# Web Form.validate() refuses to save a standard web form at all when
# developer_mode is off ("You need to be in developer mode to edit a
# Standard Web Form") - so unlike this app's other patches there's no
# _no_fixture_export() way to call doc.save() safely here. A direct SQL
# update bypasses both the controller's file export and that validation,
# keeping the change out of apps/hrms. Registered under both patches.txt
# and hooks.py's after_migrate like this app's other web form patches, so
# it reapplies if the Client Script is ever reset from the fixture in
# apps/hrms.
import frappe

MARKER = "olscpl_hrms: force public resume upload"

PUBLIC_RESUME_UPLOAD_SCRIPT = f"""
// {MARKER}
// Resume attachments should always be uploaded as public files so they can
// be viewed/downloaded from the Job Applicant record without login issues.
// Hides the "Private" checkbox in the upload dialog and forces the upload
// to be public, without touching core Frappe/HRMS files.
(function () {{
\tlet original_set_upload_options = frappe.ui.form.ControlAttach.prototype.set_upload_options;
\tfrappe.ui.form.ControlAttach.prototype.set_upload_options = function () {{
\t\toriginal_set_upload_options.call(this);
\t\tif (this.df.fieldname === 'resume_attachment') {{
\t\t\tthis.upload_options.make_attachments_public = 1;
\t\t\tthis.upload_options.allow_toggle_private = 0;
\t\t}}
\t}};
}})();
"""


def execute():
	if not frappe.db.exists("Web Form", "job-application"):
		return

	current_script = frappe.db.get_value("Web Form", "job-application", "client_script") or ""
	if MARKER in current_script:
		return

	new_script = current_script.rstrip() + "\n" + PUBLIC_RESUME_UPLOAD_SCRIPT
	frappe.db.set_value(
		"Web Form", "job-application", "client_script", new_script, update_modified=False
	)
	frappe.db.commit()
	frappe.clear_cache(doctype="Web Form")
	frappe.cache().delete_value("web_form:job-application")
