# olscpl_hrms/patches/v1_1/setup_rapidshyp_salary_structure.py
#
# RapidShyp (OPEN SOURCE BUSINESS SOLUTIONS PVT LTD) Salary Structure. Picked
# as a Job Offer's LOI Salary Structure it switches that offer to RapidShyp's
# own salary sheet (api/rapidshyp.py - the Job Offer side is filled from
# there, not from these rows).
#
# The structure itself carries the same earnings and deductions, in the same
# order and with the same settings, as the other companies' structures (OLSCPL
# Base-Salary-Based Structure) - less Advance Bonus, Meal Voucher and
# Ex-Gratia, which RapidShyp doesn't pay; the rows HR's "Salary Structure.xlsx" (sheet
# RapidShyp) defines get its formulas, with the monthly Gross Salary as base:
#   Basic  = 21100 if Gross x 50% < 21100 else Gross x 50%
#   HRA    = Gross x 40%, or (Gross - Basic) up to 40% while Basic is 21100
#   Conv.  = Gross x 10%, or what's left of Gross while Basic is 21100
#   PF     = 12% of Basic, 3000 once Basic is 25000+ (the sheet's "Ceiling")
#   ESI    = employer 0.75% / employee 3.25% of Gross while Gross <= 21000
#   Gratuity = Basic / 26 x 15 / 12, LWF = 35
# The rest are listed without a formula, as several already are on the other
# structures. Medical Insurance stays formula-less: on the sheet insurance is
# an employer contribution, not a deduction from pay.
import frappe

NAME = "OSBS Base-Salary-Based Structure"
COMPANY = "OPEN SOURCE BUSINESS SOLUTIONS PVT LTD"

PF = "3000 if BASIC >= 25000 else BASIC * 0.12"

# (component, formula or fixed amount, do_not_include_in_total, depends_on_payment_days)
EARNINGS = [
	("Basic", "21100 if base * 0.5 < 21100 else base * 0.5", 0, 0),
	("House Rent Allowance", "base * 0.4 if base * 0.5 > 21100 else min(base - BASIC, base * 0.4)", 0, 0),
	("Conveyance", "base - BASIC - HRA if base * 0.5 <= 21100 else base * 0.1", 0, 0),
	("Child Education Allowance", None, 0, 0),
	("Uniform Allowance", None, 0, 0),
	("CCA", None, 0, 0),
	("Special Allowance", None, 0, 0),
	("Education Scholarship", None, 0, 0),
	("Performance Bonus", None, 0, 0),
	("Incentive", None, 0, 0),
	("Mobile Allowance", None, 0, 0),
	("Washing Allowance", None, 0, 0),
	("Other Allowance", None, 0, 0),
	("Employer PF", PF, 1, 0),
	("Employer ESI", "gross_pay * 0.0075 if gross_pay <= 21000 else 0", 1, 0),
	("Leave Encashment", None, 0, 0),
	("Gratuity", "BASIC / 26 * 15 / 12", 0, 0),
]
DEDUCTIONS = [
	("Provident Fund", PF, 0, 0),
	("ESIC", "gross_pay * 0.0325 if gross_pay <= 21000 else 0", 0, 0),
	("Professional Tax", None, 0, 0),
	("LWF", 35, 0, 0),
	("TDS", None, 0, 0),
	("VPF", None, 0, 0),
	("ADVANCE", None, 0, 0),
	("LOAN", None, 0, 0),
	("MOBILE_DED", None, 0, 0),
	("Other Deductions", None, 0, 1),
	("DRF", None, 0, 0),
	("Medical Insurance", None, 0, 0),
	("ACCOM", None, 0, 1),
]


def _row(component, value, do_not_include_in_total, depends_on_payment_days):
	is_formula = isinstance(value, str)
	return {
		"salary_component": component,
		"abbr": frappe.db.get_value("Salary Component", component, "salary_component_abbr"),
		"amount_based_on_formula": 1 if is_formula else 0,
		"formula": value if is_formula else None,
		"amount": 0 if is_formula else (value or 0),
		"do_not_include_in_total": do_not_include_in_total,
		"depends_on_payment_days": depends_on_payment_days,
	}


def execute():
	if not frappe.db.exists("Company", COMPANY):
		return
	rows = {
		"earnings": [_row(*r) for r in EARNINGS if frappe.db.exists("Salary Component", r[0])],
		"deductions": [_row(*r) for r in DEDUCTIONS if frappe.db.exists("Salary Component", r[0])],
	}
	if frappe.db.exists("Salary Structure", NAME):
		# already submitted (an earlier, shorter version of this patch) - its
		# rows are rewritten in place, as a submitted structure can't be edited
		frappe.db.delete("Salary Detail", {"parenttype": "Salary Structure", "parent": NAME})
		for parentfield, items in rows.items():
			for idx, item in enumerate(items, start=1):
				frappe.get_doc({
					"doctype": "Salary Detail", "parenttype": "Salary Structure", "parent": NAME,
					"parentfield": parentfield, "idx": idx, **item,
				}).db_insert()
		return
	ss = frappe.get_doc({
		"doctype": "Salary Structure",
		"name": NAME,
		"__newname": NAME,
		"company": COMPANY,
		"payroll_frequency": "Monthly",
		"currency": frappe.db.get_value("Company", COMPANY, "default_currency") or "INR",
		"is_active": "Yes",
		**rows,
	})
	ss.insert(ignore_permissions=True)
	ss.submit()
