# olscpl_hrms/patches/v1_1/add_company_statutory_registrations.py
#
# Company > Details > "Statutory Registrations" (before Address & Contact): the
# employer's PF / ESI / PAN / TAN, and a state-wise table for what is
# registered state by state - PT, LWF and the ESI sub-code
# (Company State Registration child table).
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields({"Company": [
		{"fieldname": "custom_statutory_section", "fieldtype": "Section Break", "label": "Statutory Registrations",
			"insert_after": "parent_company"},
		{"fieldname": "custom_pf_registration_no", "fieldtype": "Data", "label": "PF Registration No.",
			"insert_after": "custom_statutory_section", "description": "EPFO establishment code, e.g. DLCPM0012345000"},
		{"fieldname": "custom_esi_registration_no", "fieldtype": "Data", "label": "ESI Registration No.",
			"insert_after": "custom_pf_registration_no", "description": "17-digit ESIC employer code"},
		{"fieldname": "custom_statutory_column", "fieldtype": "Column Break", "insert_after": "custom_esi_registration_no"},
		{"fieldname": "custom_pan", "fieldtype": "Data", "label": "PAN", "insert_after": "custom_statutory_column"},
		{"fieldname": "custom_tan", "fieldtype": "Data", "label": "TAN", "insert_after": "custom_pan"},
		{"fieldname": "custom_state_registrations_section", "fieldtype": "Section Break", "insert_after": "custom_tan"},
		{"fieldname": "custom_state_registrations", "fieldtype": "Table", "label": "State-wise Registrations (PT / LWF / ESI)",
			"options": "Company State Registration", "insert_after": "custom_state_registrations_section"},
	]}, update=True)
