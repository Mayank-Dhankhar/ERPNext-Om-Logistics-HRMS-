# Employees with no Reports To whose branch has exactly one HR (Branch HR,
# loaded by load_regional_hr_mapping) now report to that HR. Multi-HR
# branches are left for HR to decide. Writes an undo file - see
# utils/branch_hr_import.undo_branch_hr_assignment.
from olscpl_hrms.utils.branch_hr_import import assign_unmanaged_to_branch_hr


def execute():
	assign_unmanaged_to_branch_hr()
