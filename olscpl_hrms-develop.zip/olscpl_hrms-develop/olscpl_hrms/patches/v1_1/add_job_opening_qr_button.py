# Adds "Copy Job Link" and "Download QR Code" buttons to the stock Job Opening desk form, so
# HR can grab the same QR code shown on the public /jobs listing (see
# olscpl_hrms.api.careers.download_qr_code) right from the form they use to
# publish the job, and put it on a poster / WhatsApp / social post etc.
#
# Registered in hooks.py's after_migrate (not just patches.txt) so it's
# safe to re-run and stays created if the Client Script is ever deleted -
# same pattern already used for the other Client Scripts this app adds.
import frappe

QR_BUTTON_SCRIPT = r"""frappe.ui.form.on("Job Opening", {
	refresh: function (frm) {
		if (frm.is_new() || !frm.doc.route) {
			return;
		}

		// Added first so it sits to the left of "Download QR Code". Built from
		// the browser's own origin (not the site's host_name setting) so the
		// copied link always matches the domain HR is actually using.
		frm.add_custom_button(__("Copy Job Link"), function () {
			// ?via=link marks applications from this link (Job Applicant > Application Channel)
			frappe.utils.copy_to_clipboard(window.location.origin + "/" + frm.doc.route + "?via=link");
		});

		frm.add_custom_button(__("Download QR Code"), function () {
			window.open(
				"/api/method/olscpl_hrms.api.careers.download_qr_code?job_opening=" +
					encodeURIComponent(frm.doc.name),
				"_blank",
			);
		});
	},
});
"""


def execute():
	_ensure_qr_button_client_script()
	frappe.db.commit()


def _ensure_qr_button_client_script():
	name = "Job Opening QR Code Button"
	if frappe.db.exists("Client Script", name):
		frappe.db.set_value("Client Script", name, "script", QR_BUTTON_SCRIPT)
		return
	frappe.get_doc(
		{
			"doctype": "Client Script",
			"name": name,
			"dt": "Job Opening",
			"view": "Form",
			"script": QR_BUTTON_SCRIPT,
			"enabled": 1,
		}
	).insert(ignore_permissions=True)
