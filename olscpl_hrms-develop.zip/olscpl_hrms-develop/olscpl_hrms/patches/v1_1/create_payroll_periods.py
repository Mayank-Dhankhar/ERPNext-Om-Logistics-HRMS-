import frappe
from frappe.utils import getdate


def execute():
	"""
	Ensures every company has Payroll Period records covering a wide range
	of fiscal years (April-March), so Salary Slip/TDS calculations never
	fail with 'not in any active Fiscal Year' - a gap we hit twice during
	testing (State Wage Master migration, Loan module EMI testing).

	Generates FY 2024-25 through FY 2029-30 (6 years) for every company,
	giving generous headroom before and after go-live. Safe to re-run -
	skips any period that already exists for a given company/date range.
	"""
	companies = frappe.get_all("Company", pluck="name")

	fiscal_years = []
	for start_year in range(2024, 2030):
		fiscal_years.append({
			"name_suffix": f"FY {start_year}-{str(start_year + 1)[-2:]}",
			"start_date": f"{start_year}-04-01",
			"end_date": f"{start_year + 1}-03-31",
		})

	created = 0
	skipped = 0

	for company in companies:
		for fy in fiscal_years:
			already_exists = frappe.db.exists("Payroll Period", {
				"company": company,
				"start_date": fy["start_date"],
				"end_date": fy["end_date"]
			})

			if already_exists:
				skipped = skipped + 1
				continue

			period_name = fy["name_suffix"] + " - " + company

			doc = frappe.get_doc({
				"doctype": "Payroll Period",
				"name": period_name,
				"start_date": fy["start_date"],
				"end_date": fy["end_date"],
				"company": company
			})
			doc.insert(ignore_permissions=True)
			created = created + 1

	frappe.db.commit()

	frappe.logger().info(
		f"create_payroll_periods patch: created {created} Payroll Periods, skipped {skipped} existing."
	)
	