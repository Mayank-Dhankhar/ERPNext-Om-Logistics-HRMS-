# olscpl_hrms/patches/v1_1/add_weekly_off_fields_to_employee.py
import frappe

def execute():
	if not frappe.db.exists("Custom Field", "Employee-weekly_off_type"):
		frappe.get_doc({
			"doctype": "Custom Field",
			"dt": "Employee",
			"fieldname": "weekly_off_type",
			"fieldtype": "Select",
			"options": "\nBranch Rotational\nFixed Weekly Off",
			"label": "Weekly Off Type",
			"insert_after": "holiday_list",
			"default": "Branch Rotational",
		}).insert(ignore_permissions=True)

	if not frappe.db.exists("Custom Field", "Employee-fixed_off_day"):
		frappe.get_doc({
			"doctype": "Custom Field",
			"dt": "Employee",
			"fieldname": "fixed_off_day",
			"fieldtype": "Select",
			"options": "\nMonday\nTuesday\nWednesday\nThursday\nFriday\nSaturday\nSunday",
			"label": "Fixed Off Day",
			"insert_after": "weekly_off_type",
			"depends_on": "eval:doc.weekly_off_type=='Fixed Weekly Off'",
		}).insert(ignore_permissions=True)

	frappe.db.commit()