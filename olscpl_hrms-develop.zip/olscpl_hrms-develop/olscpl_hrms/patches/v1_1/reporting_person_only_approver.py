# olscpl_hrms/patches/v1_1/reporting_person_only_approver.py
#
# Approval rule change for Leave, Comp Off, Visit, Work From Home and
# Attendance Regularization: only the employee's Reporting Person approves -
# Reports To, else FALLBACK_APPROVER (utils/reporting_person.py) - no longer a
# person the employee picks, and no longer the branch HRs. For requests still
# waiting: set that approver, drop the other approval shares (branch HRs /
# an earlier pick), share with the approver. The workflow conditions come
# from fixtures/workflow.json. Idempotent.
import frappe

from olscpl_hrms.patches.v1_1.reporting_person_approval import PENDING
from olscpl_hrms.utils.reporting_person import (
	REPORTING_FIELD,
	chosen_user,
	default_reporting_value,
	share_with_reporting_person,
)


def execute():
	for doctype, filters in PENDING.items():
		fieldname, _ = REPORTING_FIELD[doctype]
		for name, employee, current in frappe.get_all(doctype, filters=filters, fields=["name", "employee", fieldname], as_list=True):
			approver = default_reporting_value(doctype, employee)
			if approver != current:
				frappe.db.set_value(doctype, name, fieldname, approver, update_modified=False)
			doc = frappe.get_doc(doctype, name)
			frappe.db.delete("DocShare", {
				"share_doctype": doctype, "share_name": name, "submit": 1, "user": ["!=", chosen_user(doc) or ""]})
			share_with_reporting_person(doc)
	frappe.db.commit()
