# olscpl_hrms/patches/v1_1/add_reporting_person_report.py
#
# "Reporting Person Report" is a standard Script Report, controlled by
# olscpl_hrms/olscpl_hrms/report/reporting_person_report/*.py/.js - Frappe
# loads that controller by report_type + module + name at run time no
# matter how the Report *document* itself got created. This patch creates/
# fixes that document directly rather than leaning on `bench migrate`'s
# own module sync, because this report used to be a Report Builder report
# (same name, different report_type/is_standard, inserted by an earlier
# version of this same patch) and sync_all runs before post_model_sync
# patches do - so by the time this patch can act, any stale Report Builder
# record is already sitting on the name sync_all would otherwise use.
#
# Also points the "Atlas Home" workspace's existing link at the query-
# report route (is_query_report), since a Script Report has no Report
# Builder view to open.
import frappe


def execute():
	report_name = "Reporting Person Report"

	existing = frappe.db.get_value("Report", report_name, ["is_standard", "report_type"], as_dict=True)
	if existing and (existing.is_standard != "Yes" or existing.report_type != "Script Report"):
		frappe.delete_doc("Report", report_name, force=True, ignore_permissions=True)
		existing = None

	if not existing:
		frappe.get_doc({
			"doctype": "Report",
			"report_name": report_name,
			"ref_doctype": "Employee",
			"report_type": "Script Report",
			"module": "OLSCPL HRMS",
			"is_standard": "Yes",
			"roles": [{"role": "System Manager"}, {"role": "HR Manager"}, {"role": "HR User"}],
		}).insert(ignore_permissions=True)

	workspace = frappe.get_doc("Workspace", "Atlas Home")
	link = next((l for l in workspace.links if l.label == report_name), None)
	if not link:
		reports_break_idx = next(
			(i for i, l in enumerate(workspace.links) if l.type == "Card Break" and l.label == "Reports"), None
		)
		if reports_break_idx is not None:
			link = workspace.append("links", {
				"type": "Link",
				"link_type": "Report",
				"link_to": report_name,
				"label": report_name,
				"is_query_report": 1,
				"parentfield": "links",
			})
			workspace.links.remove(link)
			workspace.links.insert(reports_break_idx + 1, link)
			for i, l in enumerate(workspace.links):
				l.idx = i + 1
			workspace.save(ignore_permissions=True)
	elif not link.is_query_report:
		link.is_query_report = 1
		workspace.save(ignore_permissions=True)

	frappe.db.commit()
