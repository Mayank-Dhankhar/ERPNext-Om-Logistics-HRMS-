# olscpl_hrms/patches/v1_1/add_full_and_final_statement_fields.py
#
# Adds the fields needed to reproduce the company's legacy "Statement of
# Full & Final Settlement" print layout (see olscpl_hrms print format
# full_and_final_settlement_legacy) on top of HRMS core's generic
# Full and Final Statement doctype - which only tracks payables/receivables
# tables, not the fixed salary-breakup/deduction columns the legacy format
# uses. Also adds one Employee field (DOJ in the OM Logistics Ltd group,
# distinct from DOJ in the current company) that the legacy format shows
# but Employee has no equivalent field for.
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields(get_custom_fields(), ignore_validate=frappe.flags.in_patch)


def get_custom_fields():
	return {
		"Employee": [
			{
				"fieldname": "custom_doj_oll",
				"fieldtype": "Date",
				"label": "DOJ (OM Logistics Group)",
				"insert_after": "custom_date_of_appointment",
				"description": "Original date of joining the OM Logistics group, if different from Date of Joining in the current company (e.g. on inter-company transfer).",
			},
		],
		"Full and Final Statement": [
			# Unlike Salary Slip (which extends AccountsController and gets
			# a "letter_head" field + auto-fill from Company.default_letter_head
			# for free - see accounts_controller.set_default_letter_head),
			# HRMS's FullandFinalStatement only extends plain Document, so
			# it has no letter_head field at all and the print view falls
			# back to whichever Letter Head has is_default=1 - wrong for
			# every company except that one. Field name must be exactly
			# "letter_head" for frappe.www.printview.get_letter_head() to
			# pick it up; CustomFullandFinalStatement.validate() fills it
			# in from the company the same way AccountsController does.
			{
				"fieldname": "letter_head",
				"fieldtype": "Link",
				"label": "Letter Head",
				"options": "Letter Head",
				"insert_after": "total_receivable_amount",
				"allow_on_submit": 1,
				"print_hide": 1,
			},
			# --- Legacy identity fields ---
			{
				"fieldname": "custom_legacy_details_section",
				"fieldtype": "Section Break",
				"label": "Legacy Settlement Details",
				"insert_after": "letter_head",
				"collapsible": 1,
			},
			{
				"fieldname": "custom_sr_no",
				"fieldtype": "Data",
				"label": "Sr. No.",
				"insert_after": "custom_legacy_details_section",
			},
			{
				"fieldname": "custom_emp_code",
				"fieldtype": "Data",
				"label": "Emp Code",
				"fetch_from": "employee.employee_number",
				"insert_after": "custom_sr_no",
				"read_only": 1,
			},
			{
				"fieldname": "custom_column_break_legacy1",
				"fieldtype": "Column Break",
				"insert_after": "custom_emp_code",
			},
			{
				"fieldname": "custom_father_name",
				"fieldtype": "Data",
				"label": "S/o, D/o, W/o",
				"fetch_from": "employee.custom_father_name",
				"insert_after": "custom_column_break_legacy1",
				"read_only": 1,
			},
			{
				"fieldname": "custom_relation_prefix",
				"fieldtype": "Select",
				"label": "Relation",
				"options": "S/o\nD/o\nW/o",
				"insert_after": "custom_father_name",
				"description": "Auto-set from the employee's gender; change manually if incorrect (e.g. married woman using W/o).",
			},
			{
				"fieldname": "custom_station",
				"fieldtype": "Data",
				"label": "Station",
				"fetch_from": "employee.branch",
				"insert_after": "custom_relation_prefix",
				"read_only": 1,
			},
			{
				"fieldname": "custom_section_break_legacy2",
				"fieldtype": "Section Break",
				"insert_after": "custom_station",
			},
			{
				"fieldname": "custom_doj_oll",
				"fieldtype": "Date",
				"label": "DOJ (OLL)",
				"fetch_from": "employee.custom_doj_oll",
				"insert_after": "custom_section_break_legacy2",
				"read_only": 1,
			},
			{
				"fieldname": "custom_column_break_legacy2",
				"fieldtype": "Column Break",
				"insert_after": "custom_doj_oll",
			},
			{
				"fieldname": "custom_emp_ph_no",
				"fieldtype": "Data",
				"label": "Emp Ph. No.",
				"fetch_from": "employee.cell_number",
				"insert_after": "custom_column_break_legacy2",
				"read_only": 1,
			},
			# --- Rate of Pay (fixed monthly rate, per salary structure) ---
			{
				"fieldname": "custom_rate_of_pay_section",
				"fieldtype": "Section Break",
				"label": "Rate of Pay",
				"insert_after": "custom_emp_ph_no",
				"collapsible": 1,
			},
			{
				"fieldname": "custom_fetch_salary_breakup",
				"fieldtype": "Button",
				"label": "Fetch Salary Breakup",
				"insert_after": "custom_rate_of_pay_section",
			},
			{
				"fieldname": "custom_rop_basic",
				"fieldtype": "Currency",
				"label": "Basic",
				"insert_after": "custom_fetch_salary_breakup",
			},
			{
				"fieldname": "custom_rop_hra",
				"fieldtype": "Currency",
				"label": "HRA",
				"insert_after": "custom_rop_basic",
			},
			{
				"fieldname": "custom_rop_conv",
				"fieldtype": "Currency",
				"label": "Conv.",
				"insert_after": "custom_rop_hra",
			},
			{
				"fieldname": "custom_rop_uniform",
				"fieldtype": "Currency",
				"label": "Uni. Alw.",
				"insert_after": "custom_rop_conv",
			},
			{
				"fieldname": "custom_column_break_rop1",
				"fieldtype": "Column Break",
				"insert_after": "custom_rop_uniform",
			},
			{
				"fieldname": "custom_rop_edu_allow",
				"fieldtype": "Currency",
				"label": "Edu. Allow.",
				"insert_after": "custom_column_break_rop1",
			},
			{
				"fieldname": "custom_rop_mobile",
				"fieldtype": "Currency",
				"label": "Mobile",
				"insert_after": "custom_rop_edu_allow",
			},
			{
				"fieldname": "custom_rop_laptop",
				"fieldtype": "Currency",
				"label": "Laptop",
				"insert_after": "custom_rop_mobile",
			},
			{
				"fieldname": "custom_rop_tea_allow",
				"fieldtype": "Currency",
				"label": "Tea Allow.",
				"insert_after": "custom_rop_laptop",
			},
			{
				"fieldname": "custom_column_break_rop2",
				"fieldtype": "Column Break",
				"insert_after": "custom_rop_tea_allow",
			},
			{
				"fieldname": "custom_rop_cca",
				"fieldtype": "Currency",
				"label": "CCA",
				"insert_after": "custom_column_break_rop2",
			},
			{
				"fieldname": "custom_rop_arrears",
				"fieldtype": "Currency",
				"label": "Arrears",
				"insert_after": "custom_rop_cca",
			},
			{
				"fieldname": "custom_rop_other",
				"fieldtype": "Currency",
				"label": "Other",
				"insert_after": "custom_rop_arrears",
			},
			{
				"fieldname": "custom_rop_total",
				"fieldtype": "Currency",
				"label": "Salary (Total)",
				"insert_after": "custom_rop_other",
				"read_only": 1,
			},
			# --- Salary/Wages payable for the last month worked ---
			{
				"fieldname": "custom_dues_breakup_section",
				"fieldtype": "Section Break",
				"label": "Salary/Wages Payable for Last Month",
				"insert_after": "custom_rop_total",
				"collapsible": 1,
				"description": "Pro-rated amount actually due for the days worked in the last month - enter manually.",
			},
			{
				"fieldname": "custom_dues_days_worked",
				"fieldtype": "Data",
				"label": "Days Worked",
				"insert_after": "custom_dues_breakup_section",
			},
			{
				"fieldname": "custom_dues_basic",
				"fieldtype": "Currency",
				"label": "Basic",
				"insert_after": "custom_dues_days_worked",
			},
			{
				"fieldname": "custom_dues_hra",
				"fieldtype": "Currency",
				"label": "HRA",
				"insert_after": "custom_dues_basic",
			},
			{
				"fieldname": "custom_column_break_dues1",
				"fieldtype": "Column Break",
				"insert_after": "custom_dues_hra",
			},
			{
				"fieldname": "custom_dues_conv",
				"fieldtype": "Currency",
				"label": "Conv.",
				"insert_after": "custom_column_break_dues1",
			},
			{
				"fieldname": "custom_dues_uniform",
				"fieldtype": "Currency",
				"label": "Uni. Alw.",
				"insert_after": "custom_dues_conv",
			},
			{
				"fieldname": "custom_dues_edu_allow",
				"fieldtype": "Currency",
				"label": "Edu. Allow.",
				"insert_after": "custom_dues_uniform",
			},
			{
				"fieldname": "custom_column_break_dues2",
				"fieldtype": "Column Break",
				"insert_after": "custom_dues_edu_allow",
			},
			{
				"fieldname": "custom_dues_mobile",
				"fieldtype": "Currency",
				"label": "Mobile",
				"insert_after": "custom_column_break_dues2",
			},
			{
				"fieldname": "custom_dues_incentive",
				"fieldtype": "Currency",
				"label": "Incentive",
				"insert_after": "custom_dues_mobile",
			},
			{
				"fieldname": "custom_dues_advance_bonus",
				"fieldtype": "Currency",
				"label": "Advance Bonus",
				"insert_after": "custom_dues_incentive",
			},
			{
				"fieldname": "custom_column_break_dues3",
				"fieldtype": "Column Break",
				"insert_after": "custom_dues_advance_bonus",
			},
			{
				"fieldname": "custom_dues_cca_mess_washing",
				"fieldtype": "Currency",
				"label": "CCA/Mess/Washing",
				"insert_after": "custom_column_break_dues3",
			},
			{
				"fieldname": "custom_dues_arrear_other",
				"fieldtype": "Currency",
				"label": "Arrear/Other",
				"insert_after": "custom_dues_cca_mess_washing",
			},
			{
				"fieldname": "custom_dues_total",
				"fieldtype": "Currency",
				"label": "Dues (Total)",
				"insert_after": "custom_dues_arrear_other",
				"read_only": 1,
			},
			# --- Deductions ---
			{
				"fieldname": "custom_deductions_section",
				"fieldtype": "Section Break",
				"label": "Deductions",
				"insert_after": "custom_dues_total",
				"collapsible": 1,
			},
			{
				"fieldname": "custom_ded_epf",
				"fieldtype": "Currency",
				"label": "E.P.F",
				"insert_after": "custom_deductions_section",
			},
			{
				"fieldname": "custom_ded_esi",
				"fieldtype": "Currency",
				"label": "E.S.I",
				"insert_after": "custom_ded_epf",
			},
			{
				"fieldname": "custom_ded_tds",
				"fieldtype": "Currency",
				"label": "T.D.S",
				"insert_after": "custom_ded_esi",
			},
			{
				"fieldname": "custom_column_break_ded1",
				"fieldtype": "Column Break",
				"insert_after": "custom_ded_tds",
			},
			{
				"fieldname": "custom_ded_lwf_pf_tax",
				"fieldtype": "Currency",
				"label": "LWF/P.F. Tax",
				"insert_after": "custom_column_break_ded1",
			},
			{
				"fieldname": "custom_ded_loan_advance",
				"fieldtype": "Currency",
				"label": "Loan/Advance",
				"insert_after": "custom_ded_lwf_pf_tax",
			},
			{
				"fieldname": "custom_ded_notice",
				"fieldtype": "Currency",
				"label": "Notice",
				"insert_after": "custom_ded_loan_advance",
			},
			{
				"fieldname": "custom_column_break_ded2",
				"fieldtype": "Column Break",
				"insert_after": "custom_ded_notice",
			},
			{
				"fieldname": "custom_ded_excess_leave_days",
				"fieldtype": "Float",
				"label": "Excess Leaves (Days)",
				"insert_after": "custom_column_break_ded2",
			},
			{
				"fieldname": "custom_ded_excess_leave_amount",
				"fieldtype": "Currency",
				"label": "Excess Leaves (Amount)",
				"insert_after": "custom_ded_excess_leave_days",
			},
			{
				"fieldname": "custom_ded_deduction_from_ac",
				"fieldtype": "Currency",
				"label": "Deduction from A/C",
				"insert_after": "custom_ded_excess_leave_amount",
			},
			{
				"fieldname": "custom_column_break_ded3",
				"fieldtype": "Column Break",
				"insert_after": "custom_ded_deduction_from_ac",
			},
			{
				"fieldname": "custom_ded_spl1_drf_cab_food_accm",
				"fieldtype": "Currency",
				"label": "SPL1/DRF/CAB/FOOD/ACCM",
				"insert_after": "custom_column_break_ded3",
			},
			{
				"fieldname": "custom_ded_other",
				"fieldtype": "Currency",
				"label": "Other",
				"insert_after": "custom_ded_spl1_drf_cab_food_accm",
			},
			{
				"fieldname": "custom_ded_total",
				"fieldtype": "Currency",
				"label": "Deductions (Total)",
				"insert_after": "custom_ded_other",
				"read_only": 1,
			},
			# --- Other dues: encashment, bonus, gratuity, notice pay etc. ---
			{
				"fieldname": "custom_other_dues_section",
				"fieldtype": "Section Break",
				"label": "Other Dues",
				"insert_after": "custom_ded_total",
				"collapsible": 1,
			},
			{
				"fieldname": "custom_encashment_last_yr_leave",
				"fieldtype": "Float",
				"label": "Encashment Last Yr (Leave Days)",
				"insert_after": "custom_other_dues_section",
			},
			{
				"fieldname": "custom_encashment_last_yr_amount",
				"fieldtype": "Currency",
				"label": "Encashment Last Yr (Amount)",
				"insert_after": "custom_encashment_last_yr_leave",
			},
			{
				"fieldname": "custom_encashment_current_yr_leave",
				"fieldtype": "Float",
				"label": "Encashment Current Yr (Leave Days)",
				"insert_after": "custom_encashment_last_yr_amount",
			},
			{
				"fieldname": "custom_column_break_other1",
				"fieldtype": "Column Break",
				"insert_after": "custom_encashment_current_yr_leave",
			},
			{
				"fieldname": "custom_encashment_current_yr_amount",
				"fieldtype": "Currency",
				"label": "Encashment Current Yr (Amount)",
				"insert_after": "custom_column_break_other1",
				"description": "Auto-filled from the Leave Encashment payable row, if present. Editable.",
			},
			{
				"fieldname": "custom_bonus_exgratia_last_yr",
				"fieldtype": "Currency",
				"label": "Bonus/Ex-Gratia Last Year",
				"insert_after": "custom_encashment_current_yr_amount",
			},
			{
				"fieldname": "custom_bonus_exgratia_current_yr",
				"fieldtype": "Currency",
				"label": "Bonus/Ex-Gratia Current Year",
				"insert_after": "custom_bonus_exgratia_last_yr",
				"description": "Auto-filled from the Bonus payable row, if present. Editable.",
			},
			{
				"fieldname": "custom_column_break_other2",
				"fieldtype": "Column Break",
				"insert_after": "custom_bonus_exgratia_current_yr",
			},
			{
				"fieldname": "custom_gratuity_years",
				"fieldtype": "Float",
				"label": "Gratuity (Years of Service)",
				"insert_after": "custom_column_break_other2",
			},
			{
				"fieldname": "custom_gratuity_amount",
				"fieldtype": "Currency",
				"label": "Gratuity (Amount)",
				"insert_after": "custom_gratuity_years",
				"description": "Auto-filled from the Gratuity payable row, if present. Editable.",
			},
			{
				"fieldname": "custom_notice_pay_days",
				"fieldtype": "Int",
				"label": "Notice Pay (Days)",
				"insert_after": "custom_gratuity_amount",
			},
			{
				"fieldname": "custom_column_break_other3",
				"fieldtype": "Column Break",
				"insert_after": "custom_notice_pay_days",
			},
			{
				"fieldname": "custom_notice_pay_amount",
				"fieldtype": "Currency",
				"label": "Notice Pay (Amount)",
				"insert_after": "custom_column_break_other3",
			},
			{
				"fieldname": "custom_service_compensation",
				"fieldtype": "Currency",
				"label": "Service Compensation",
				"insert_after": "custom_notice_pay_amount",
			},
			{
				"fieldname": "custom_misc",
				"fieldtype": "Currency",
				"label": "Misc",
				"insert_after": "custom_service_compensation",
			},
			{
				"fieldname": "custom_other_dues_total",
				"fieldtype": "Currency",
				"label": "Other Dues (Total)",
				"insert_after": "custom_misc",
				"read_only": 1,
			},
			# --- Settlement totals ---
			{
				"fieldname": "custom_legacy_totals_section",
				"fieldtype": "Section Break",
				"label": "Settlement Totals",
				"insert_after": "custom_other_dues_total",
			},
			{
				"fieldname": "custom_total_dues",
				"fieldtype": "Currency",
				"label": "Total Dues",
				"insert_after": "custom_legacy_totals_section",
				"read_only": 1,
			},
			{
				"fieldname": "custom_total_deductions",
				"fieldtype": "Currency",
				"label": "Total Deductions",
				"insert_after": "custom_total_dues",
				"read_only": 1,
			},
			{
				"fieldname": "custom_column_break_totals",
				"fieldtype": "Column Break",
				"insert_after": "custom_total_deductions",
			},
			{
				"fieldname": "custom_grand_total",
				"fieldtype": "Currency",
				"label": "Grand Total",
				"insert_after": "custom_column_break_totals",
				"read_only": 1,
			},
			{
				"fieldname": "custom_amount_payable_recoverable",
				"fieldtype": "Currency",
				"label": "Amount Payable/Recoverable",
				"insert_after": "custom_grand_total",
				"read_only": 1,
			},
			{
				"fieldname": "custom_amount_in_words",
				"fieldtype": "Data",
				"label": "Amount in Words",
				"insert_after": "custom_amount_payable_recoverable",
				"read_only": 1,
			},
			{
				"fieldname": "custom_settlement_remarks",
				"fieldtype": "Small Text",
				"label": "Remarks",
				"insert_after": "custom_amount_in_words",
			},
			# --- Sign-off ---
			{
				"fieldname": "custom_sign_off_section",
				"fieldtype": "Section Break",
				"label": "Sign Off",
				"insert_after": "custom_settlement_remarks",
				"collapsible": 1,
			},
			{
				"fieldname": "custom_prepared_by",
				"fieldtype": "Link",
				"label": "Prepared By",
				"options": "User",
				"insert_after": "custom_sign_off_section",
			},
			{
				"fieldname": "custom_verified_by",
				"fieldtype": "Link",
				"label": "Verified By",
				"options": "User",
				"insert_after": "custom_prepared_by",
			},
			{
				"fieldname": "custom_column_break_signoff",
				"fieldtype": "Column Break",
				"insert_after": "custom_verified_by",
			},
			{
				"fieldname": "custom_accounts_checked_by",
				"fieldtype": "Link",
				"label": "Accounts Checked By",
				"options": "User",
				"insert_after": "custom_column_break_signoff",
			},
			{
				"fieldname": "custom_accounts_hod",
				"fieldtype": "Link",
				"label": "Accounts H.O.D",
				"options": "User",
				"insert_after": "custom_accounts_checked_by",
			},
		],
	}
