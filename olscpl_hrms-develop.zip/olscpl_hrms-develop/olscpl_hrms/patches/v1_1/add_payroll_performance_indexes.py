# olscpl_hrms/patches/v1_1/add_payroll_performance_indexes.py
#
# Indexes for salary slip creation (api/payroll_entry.py):
# - Employee Checkin.attendance: approving the auto leave conversion updates
#   attendance, and HRMS then runs "... WHERE attendance=X FOR UPDATE" on
#   checkins. Unindexed, that scans and locks every checkin row (~430k), so
#   parallel slip processes blocked each other into "Lock wait timeout".
# - Monthly Attendance Tracker (employee, month, year): read once per slip.
# - Attendance (employee, attendance_date): per-employee day lookups.
# - Attendance.leave_application: cancelling any Leave Application checks for
#   attendance linked to it - unindexed, ~0.8s per leave (a Payroll Entry
#   cancel undoes thousands of auto leaves).
# Idempotent - add_index skips an index that already exists.
import frappe

INDEXES = [
	("Employee Checkin", ["attendance"], "attendance_index"),
	("Monthly Attendance Tracker", ["employee", "month", "year"], "employee_month_year_index"),
	("Attendance", ["employee", "attendance_date"], "employee_attendance_date_index"),
	("Attendance", ["leave_application"], "leave_application_index"),
]


def execute():
	for doctype, fields, index_name in INDEXES:
		if frappe.db.table_exists(doctype) and all(frappe.db.has_column(doctype, f) for f in fields):
			frappe.db.add_index(doctype, fields, index_name)
