import frappe


def execute():
	current_options = frappe.get_meta("Attendance").get_field("status").options or ""
	existing = [opt for opt in current_options.split("\n") if opt]

	if "Visit" not in existing:
		new_options = current_options.rstrip("\n") + "\nVisit"
		frappe.make_property_setter({
			"doctype": "Attendance",
			"fieldname": "status",
			"property": "options",
			"value": new_options,
			"property_type": "Text",
		})

	frappe.db.commit()
