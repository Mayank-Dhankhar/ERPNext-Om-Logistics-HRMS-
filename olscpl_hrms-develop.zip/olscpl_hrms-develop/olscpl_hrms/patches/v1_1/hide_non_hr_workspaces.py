import frappe

def execute():
	"""
	Hides non-HR/Payroll workspaces from the sidebar (Accounts, Buying,
	Selling, Stock, CRM, Manufacturing, etc.) so the app presents as an
	HRMS-only portal, matching the manual cleanup already done on UAT.
	Sets is_hidden=1 (hides from sidebar) - does NOT delete workspaces,
	so nothing is lost and this is safe to re-run.
	"""
	keep_workspaces = [
		"Home",
		"HR",
		"Support",
		"Users",
		"Payroll",
		"ERPNext Settings",
		"Build",
	]
	all_workspaces = frappe.get_all("Workspace", fields=["name", "public", "is_hidden"])
	hidden_count = 0
	for ws in all_workspaces:
		if ws.name in keep_workspaces:
			continue
		if ws.public and not ws.is_hidden:
			frappe.db.set_value("Workspace", ws.name, "is_hidden", 1)
			hidden_count = hidden_count + 1
	frappe.db.commit()
	frappe.clear_cache()
	frappe.logger().info(
		f"hide_non_hr_workspaces patch: hidden {hidden_count} non-HR workspaces."
	)
	