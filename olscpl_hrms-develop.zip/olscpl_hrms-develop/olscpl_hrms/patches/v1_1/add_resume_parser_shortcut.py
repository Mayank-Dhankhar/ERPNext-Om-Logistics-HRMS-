# olscpl_hrms/patches/v1_1/add_resume_parser_shortcut.py
#
# "Parse Resume" shortcut on the Recruitment workspace, next to its other
# shortcuts: opens the Job Applicant list with #parse-resume, which opens the
# resume-upload dialog (public/js/job_applicant_list.js). Same approach as
# add_careers_page_shortcuts.py, for the same reason (workspace sync doesn't
# update an existing workspace's shortcuts).
import frappe

from olscpl_hrms.patches.v1_1.add_careers_page_shortcuts import _no_fixture_export, _shortcut_row_insert_position

LABEL = "Parse Resume"


def execute():
	if not frappe.db.exists("Workspace", "Recruitment"):
		return
	doc = frappe.get_doc("Workspace", "Recruitment")
	if any(s.label == LABEL for s in doc.shortcuts):
		return
	content = frappe.parse_json(doc.content)
	with _no_fixture_export():
		doc.append("shortcuts", {"label": LABEL, "type": "URL", "url": "/app/job-applicant#parse-resume", "color": "Blue", "doc_view": ""})
		content.insert(_shortcut_row_insert_position(content), {"id": "rcShortcutParseResume", "type": "shortcut", "data": {"shortcut_name": LABEL, "col": 3}})
		doc.content = frappe.as_json(content)
		doc.save(ignore_permissions=True)
	frappe.db.commit()
