# olscpl_hrms/patches/v1_1/fix_duplicate_onboarding_consent_questions.py
#
# Onboarding Consent Question uses naming_rule: Random - a real, already-
# live site that manually created these 13 questions before this app's
# fixtures/onboarding_consent_question.json managed them at all ends up
# with two completely different sets of random names for the same
# question text once the fixture syncs: Frappe matches fixture records by
# exact name, and a Random-named doctype's names carry no relationship to
# its content, so the fixture's own 13 (independently regenerated on a
# dev site, unrelated names) land as 13 brand-new inserts alongside the
# site's original 13 instead of updating them in place. seed_onboarding_
# children() (events/employee_onboarding.py) then seeds every Employee
# Onboarding it fires on with all 26 "active" questions, and every
# consent question shows up twice on the printed form/Digital File and
# twice while the candidate is actually answering it.
#
# Fixed at the rendering layer already (_dedupe_consent_rows() in
# api/employee_data.py's PDF STYLE, dedupeConsentRows() in
# onboarding-documents.html) - that's what makes the Digital File and the
# candidate portal correct regardless of whether this patch has run yet.
# This patch is the underlying data cleanup: disables (never deletes -
# reversible, and the rows a candidate already answered stay intact)
# whichever copy of each duplicate pair ISN'T the one this app's fixture
# tracks going forward, then collapses the same duplication out of every
# Employee Onboarding record's own consent_responses table (preferring
# whichever row of a pair the candidate actually answered).
#
# Disables rather than the fixture's own names, not the other way around
# - fixtures/onboarding_consent_question.json sets disabled: 0 on its own
# 13, so leaving the *other* set enabled would just have every future
# `bench migrate` silently undo this by re-enabling the fixture's set
# without touching the stray set at all.
import frappe

from olscpl_hrms.api.employee_data import _dedupe_consent_rows


def execute():
	groups = {}
	for q in frappe.get_all(
		"Onboarding Consent Question", fields=["name", "question", "disabled"], order_by="creation asc"
	):
		groups.setdefault(q.question, []).append(q)

	fixture_names = _fixture_question_names()

	keep_by_question = {}
	disabled_count = 0
	for question, rows in groups.items():
		if len(rows) <= 1:
			keep_by_question[question] = rows[0].name if rows else None
			continue
		keep = next((r for r in rows if r.name in fixture_names), rows[0])
		keep_by_question[question] = keep.name
		for r in rows:
			if r.name != keep.name and not r.disabled:
				frappe.db.set_value("Onboarding Consent Question", r.name, "disabled", 1)
				disabled_count += 1

	if disabled_count:
		frappe.clear_cache(doctype="Onboarding Consent Question")

	fixed_records = 0
	for ob_name in frappe.get_all("Employee Onboarding", pluck="name"):
		doc = frappe.get_doc("Employee Onboarding", ob_name)
		rows = doc.get("consent_responses") or []
		deduped = _dedupe_consent_rows([dict(r.as_dict()) for r in rows])
		if len(deduped) == len(rows):
			continue

		# _dedupe_consent_rows() only picks which duplicate to keep - still
		# need to point that row at whichever master question record
		# stayed enabled above, if it wasn't already.
		for row in deduped:
			canonical = keep_by_question.get(row.get("question_text"))
			if canonical:
				row["question"] = canonical

		doc.set("consent_responses", [])
		for row in deduped:
			doc.append(
				"consent_responses",
				{
					"question": row.get("question"),
					"question_text": row.get("question_text"),
					"candidate_response": row.get("candidate_response"),
				},
			)
		doc.save(ignore_permissions=True)
		fixed_records += 1

	frappe.db.commit()
	print(
		f"fix_duplicate_onboarding_consent_questions: disabled {disabled_count} duplicate "
		f"question(s), de-duplicated {fixed_records} Employee Onboarding record(s)."
	)


def _fixture_question_names():
	"""Names the app's own fixture tracks for this doctype - these are the
	ones every future `bench migrate` will force disabled=0 on, so they're
	the side every duplicate pair should keep enabled."""
	import json
	import os

	path = frappe.get_app_path("olscpl_hrms", "fixtures", "onboarding_consent_question.json")
	if not os.path.exists(path):
		return set()
	with open(path) as f:
		return {e["name"] for e in json.load(f)}
