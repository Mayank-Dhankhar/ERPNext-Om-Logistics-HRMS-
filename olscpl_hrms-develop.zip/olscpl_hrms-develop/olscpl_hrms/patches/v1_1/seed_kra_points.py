# Loads data/kra_points.json ("Designation": [point, point, ...]) straight
# into an Appraisal Template per designation - hrms core's own KRA mechanism
# (Appraisal Cycle -> Appraisee -> Appraisal pulls an employee's "KRA vs
# Goals" table from Designation.appraisal_template -> Appraisal Template's
# goals) - reusing hrms core's existing KRA doctype (title + description) as
# the point catalog instead of storing point text of our own. A point
# already used by another designation (several KPIs repeat verbatim across
# designations in the source spreadsheet) reuses the same KRA record rather
# than creating a duplicate.
#
# An earlier version of this patch went through a custom "Designation KRA"
# doctype as a middle step; that's gone now (see
# remove_designation_kra_doctype.py) - this seeds Appraisal Template
# directly, and the mobile app's KRA tab reads the same Appraisal Template
# via the employee's own Designation link instead.
#
# Weightage is split equally across a designation's KRAs - Appraisal
# Template refuses to save unless weightage sums to exactly 100.00%, which
# an even split like 100/7 doesn't hit on its own (14.2857...% x 7 =
# 99.99... after rounding), so the last row absorbs whatever rounding
# remainder is left to make the total land on exactly 100.00.
#
# Additive and idempotent - safe to re-run after HR edits the file. Leaves
# a template alone once HR has set real weightage on it (sum != 0).
import json
import os

import frappe
from frappe.utils import flt


def equal_weightage(n):
	per_item = flt(100 / n, 2)
	weights = [per_item] * (n - 1)
	weights.append(flt(100 - sum(weights), 2))
	return weights


def execute():
	path = os.path.join(frappe.get_app_path("olscpl_hrms"), "data", "kra_points.json")
	with open(path) as f:
		data = json.load(f)

	for designation, points in data.items():
		kra_names = [_get_or_create_kra(point) for point in points]
		weights = equal_weightage(len(kra_names))
		goals = [{"key_result_area": kra_name, "per_weightage": w} for kra_name, w in zip(kra_names, weights)]

		if frappe.db.exists("Appraisal Template", designation):
			doc = frappe.get_doc("Appraisal Template", designation)
			if sum(flt(g.per_weightage) for g in doc.goals) == 0:
				doc.set("goals", goals)
				doc.save(ignore_permissions=True)
			# else: already weighted (by HR or an earlier run) - leave it alone
		else:
			frappe.get_doc({
				"doctype": "Appraisal Template",
				"template_title": designation,
				"description": f"KRAs for {designation}.",
				"goals": goals,
			}).insert(ignore_permissions=True)

		# The source spreadsheet's designation names don't reliably match
		# the Designation doctype's own (case, slashes, extra words) -
		# only wire the ones that do, case-insensitively; the rest stay as
		# unlinked Appraisal Templates until someone fixes the designation
		# name or links the template manually.
		real_designation = frappe.db.sql(
			"select name, appraisal_template from `tabDesignation` where lower(name)=lower(%s)",
			(designation,),
			as_dict=True,
		)
		if real_designation and not real_designation[0].appraisal_template:
			frappe.db.set_value("Designation", real_designation[0].name, "appraisal_template", designation)

	frappe.db.commit()


def _get_or_create_kra(title):
	if frappe.db.exists("KRA", title):
		return title
	return frappe.get_doc({"doctype": "KRA", "title": title}).insert(ignore_permissions=True).name
