# olscpl_hrms/patches/v1_1/convert_user_signature_to_upload.py
#
# HR wants to upload a scanned/photographed signature instead of drawing one.
# User.custom_signature (a draw-on-screen Signature field) can't simply change
# type - Frappe refuses Signature -> Attach Image - so a new Attach Image field,
# custom_signature_image, takes over and the old one is hidden.
#
# Every signature already drawn is saved out as a private File into the new
# field, so nobody has to redo it, and the old value is then cleared - it's
# not a fallback (removing the upload must really remove the signature).
# Idempotent.
import base64

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_field

OLD = "custom_signature"
NEW = "custom_signature_image"


def execute():
	create_custom_field(
		"User",
		{
			"fieldname": NEW,
			"label": "Signature",
			"fieldtype": "Attach Image",
			"insert_after": OLD,
			"description": (
				"Upload an image of your signature (PNG/JPG, ideally dark ink on a white "
				"background). It's used as the Authorised Signatory signature on onboarding "
				"forms, the Letter of Intent and appointment letters."
			),
		},
	)
	if frappe.db.exists("Custom Field", f"User-{OLD}"):
		frappe.db.set_value("Custom Field", f"User-{OLD}", "hidden", 1)
	frappe.clear_cache(doctype="User")

	for user, value in frappe.db.sql(
		f"""select name, `{OLD}` from `tabUser`
		where `{OLD}` like 'data:image%%' and ifnull(`{NEW}`, '') = ''"""
	):
		try:
			header, b64data = value.split(",", 1)
			ext = "jpg" if "jpeg" in header else "png"
			file_doc = frappe.get_doc(
				{
					"doctype": "File",
					"file_name": f"signature-{frappe.scrub(user)}.{ext}",
					"content": base64.b64decode(b64data),
					"is_private": 1,
					"attached_to_doctype": "User",
					"attached_to_name": user,
					"attached_to_field": NEW,
				}
			).insert(ignore_permissions=True)
			frappe.db.set_value(
				"User", user, {NEW: file_doc.file_url, OLD: None}, update_modified=False
			)
		except Exception:
			# Unreadable drawing - left as is (unused); the user is asked to
			# upload one by signature_gate.js the next time it's needed.
			frappe.log_error(title=f"Signature conversion failed for {user}")

	frappe.db.commit()
