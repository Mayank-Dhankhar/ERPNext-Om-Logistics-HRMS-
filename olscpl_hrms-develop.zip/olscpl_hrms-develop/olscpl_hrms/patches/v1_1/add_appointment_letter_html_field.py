# Holds HR's own edited wording for an employee's Appointment Letter (see
# olscpl_hrms/api/appointment_letter.py's get_editable_body/
# save_appointment_letter_body/reset_appointment_letter_body and public/js/
# employee.js's "Edit Letter" button), once they've saved one - the
# always-fresh auto-filled version is used instead whenever this is empty.
# Hidden/read-only for the same reason as the sent-on/sent-by fields
# add_appointment_letter_sent_fields.py added: this is state for that
# dialog, not a regular form field anyone should see/edit outside it.
import frappe


def execute():
	f = {
		"doctype": "Custom Field",
		"dt": "Employee",
		"fieldname": "custom_appointment_letter_html",
		"fieldtype": "Long Text",
		"label": "Appointment Letter (Edited)",
		"insert_after": "custom_appointment_letter_sent_by",
		"read_only": 1,
		"hidden": 1,
	}
	docname = f"{f['dt']}-{f['fieldname']}"
	if frappe.db.exists("Custom Field", docname):
		return
	frappe.get_doc(f).insert(ignore_permissions=True)

	frappe.db.commit()
