# olscpl_hrms/patches/v1_1/add_job_offer_sitting_branch.py
#
# Job Offer > Details: "Sitting Branch" - the branch the candidate will sit
# at, picked from Branch, right after State Wage Category.
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def execute():
	create_custom_fields({"Job Offer": [{
		"fieldname": "custom_sitting_branch", "label": "Sitting Branch", "fieldtype": "Link", "options": "Branch",
		"insert_after": "custom_state_wage_category",
	}]}, update=True)
