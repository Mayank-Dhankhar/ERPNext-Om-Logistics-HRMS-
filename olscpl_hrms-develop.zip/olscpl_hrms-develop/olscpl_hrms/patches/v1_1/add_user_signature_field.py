# A signature drawn once on the sender's own User profile, reused
# automatically wherever an onboarding form needs "Signature of
# Employer / Authorised Signatory" - see employee_data.py/
# onboarding-documents.html, which look this up via Employee
# Onboarding.portal_link_sent_by (already set whenever a link is sent).
import frappe


def execute():
	docname = "User-custom_signature"
	if frappe.db.exists("Custom Field", docname):
		return

	frappe.get_doc({
		"doctype": "Custom Field",
		"dt": "User",
		"fieldname": "custom_signature",
		"fieldtype": "Signature",
		"label": "Signature",
		# Not "email_signature" - that field sits inside an unlabelled
		# collapsible "Email" section on the More Information tab (no
		# label was ever set on that Section Break, so stock Frappe never
		# renders a header/toggle for it - there's no way to expand it
		# from the UI at all). "bio" is the last field actually visible
		# on that tab.
		"insert_after": "bio",
		"description": "Used on onboarding forms wherever your signature is needed as the authorised signatory - draw it once here.",
	}).insert(ignore_permissions=True)

	frappe.db.commit()
