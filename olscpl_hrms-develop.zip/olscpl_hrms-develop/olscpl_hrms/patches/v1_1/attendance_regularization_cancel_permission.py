# olscpl_hrms/patches/v1_1/attendance_regularization_cancel_permission.py
#
# HR Manager and System Manager may cancel an approved Attendance
# Regularization (workflow "Cancel" -> Cancelled; the day's attendance is
# recalculated from the real punches - events/attendance_regularization).
# Only those role/permlevel-0 rows are touched. Idempotent.
import frappe
from frappe.permissions import add_permission, update_permission_property


def execute():
	for role in ("HR Manager", "System Manager"):
		if not frappe.db.exists("Custom DocPerm", {"parent": "Attendance Regularization", "role": role, "permlevel": 0}):
			add_permission("Attendance Regularization", role, 0)
		update_permission_property("Attendance Regularization", role, 0, "cancel", 1)
	frappe.clear_cache(doctype="Attendance Regularization")
