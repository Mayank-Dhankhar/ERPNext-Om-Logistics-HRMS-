import frappe


def execute():
	"""
	Recreates the 'Professional Tax Slab' DocType definition, which was
	missing from the database despite the underlying tabProfessional Tax Slab
	table and its data being intact (orphaned metadata, discovered during
	Salary Slip migration - July 2026).

	This patch is safe to re-run: if the DocType already exists, it exits
	without modifying anything.
	"""
	if frappe.db.exists("DocType", "Professional Tax Slab"):
		return

	doc = frappe.get_doc({
		"doctype": "DocType",
		"name": "Professional Tax Slab",
		"module": "Payroll",
		"custom": 1,
		"istable": 1,
		"editable_grid": 1,
		"fields": [
			{"fieldname": "from_amount", "fieldtype": "Currency", "label": "From Amount", "in_list_view": 1},
			{"fieldname": "to_amount", "fieldtype": "Currency", "label": "To Amount", "in_list_view": 1},
			{"fieldname": "pt_amount", "fieldtype": "Currency", "label": "PT Amount", "in_list_view": 1},
			{"fieldname": "special_month_amount", "fieldtype": "Currency", "label": "Special Month Amount", "in_list_view": 1},
		],
		"permissions": [
			{"role": "System Manager", "read": 1, "write": 1, "create": 1, "delete": 1}
		]
	})
	doc.insert(ignore_permissions=True)
	frappe.db.commit()