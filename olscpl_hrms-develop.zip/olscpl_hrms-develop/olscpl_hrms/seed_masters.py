"""Insert-only seeding of HR-maintained master data.

Why not fixtures? Frappe re-imports every fixture on each `bench migrate` and
overwrites records with the same name, so HR's edits on the site are lost
after each deployment. Here a row is created only if it does not already exist
and existing records are never touched.

Called from the one-time patch (existing sites) and `after_install` (new sites).
"""
import json
import os

import frappe

# doctype -> (seed file, field(s) identifying a row). Single doctypes use None.
MASTERS = {
	"State Wage Master": ("state_wage_master.json", ["state"]),
	"Professional Tax Rule": ("professional_tax_rule.json", ["state"]),
	"LWF Configuration": ("lwf_configuration.json", ["state"]),
	"ESI Rule": ("esi_rule.json", ["rule_name"]),
	"Bonus Payable": ("bonus_payable.json", ["company"]),
	"Loan Type": ("loan_type.json", ["loan_type_name"]),
	"Onboarding Document Type": ("onboarding_document_type.json", ["document_name"]),
	"Onboarding Consent Question": ("onboarding_consent_question.json", ["question"]),
	"Income Tax Surcharge Rule": ("income_tax_surcharge_rule.json", None),
}

SKIP_KEYS = {"name", "modified", "creation", "owner", "modified_by", "parent", "parenttype", "parentfield", "idx"}


def _clean(row):
	out = {}
	for k, v in row.items():
		if k in SKIP_KEYS:
			continue
		out[k] = [_clean(c) for c in v] if isinstance(v, list) else v
	return out


def seed_masters():
	base = os.path.join(frappe.get_app_path("olscpl_hrms"), "seed_data")
	for doctype, (fname, keys) in MASTERS.items():
		if not frappe.db.exists("DocType", doctype):
			continue
		with open(os.path.join(base, fname), encoding="utf-8") as f:
			rows = json.load(f)

		if keys is None:  # Single doctype: seed only if nothing is configured yet
			doc = frappe.get_single(doctype)
			if any(doc.get(t.fieldname) for t in doc.meta.get_table_fields()):
				continue
			for k, v in _clean(rows[0]).items():
				doc.set(k, v)
			doc.flags.ignore_permissions = True
			doc.save()
			continue

		created = 0
		for row in rows:
			filters = {k: row.get(k) for k in keys}
			if frappe.db.exists(doctype, filters):
				continue
			doc = frappe.get_doc({"doctype": doctype, **_clean(row)})
			doc.flags.ignore_permissions = True
			doc.insert()
			created += 1
		if created:
			print(f"seed_masters: {doctype}: created {created} missing record(s)")
	frappe.db.commit()
