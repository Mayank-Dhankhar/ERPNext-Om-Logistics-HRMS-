# Business Requirements Document: Recruitment and Onboarding

## 1. Purpose

Define the business workflow from approved hiring demand through creation of an active Employee record in the installed Arjun HRMS environment. Payroll is expressly outside this BRD.

## 2. Scope and current-system basis

This BRD is based on the installed Frappe apps: `frappe`, `erpnext`, `hrms`, `olscpl_hrms`, and `arjun_theme`. Recruitment and onboarding use standard HRMS DocTypes. `olscpl_hrms` adds Job Offer salary-annexure fields and client-side calculations, but does not override the Recruitment, Appointment Letter, or Employee Onboarding controllers.

| Current capability | Implemented evidence | Requirement interpretation |
|---|---|---|
| Requisition to opening | Job Requisition creates/associates a Job Opening | An approved hiring request must result in a trackable opening. |
| Candidate pipeline | Job Applicant supports interviews and an accepted applicant can create/view a Job Offer | A candidate must remain the shared identity across recruitment documents. |
| Offer | Job Offer has applicant, status, terms, term template, company, designation and vacancy validation | Only an accepted offer may begin onboarding. |
| Appointment Letter | It requires `job_applicant`, appointment date, company, template, and content | It is an optional candidate document, not the trigger for onboarding. |
| Onboarding | Employee Onboarding requires both `job_applicant` and `job_offer` | Onboarding must be created against the accepted offer and candidate. |
| Employee creation | Onboarding must be submitted and all required activities completed before its `make_employee` action succeeds | No Employee record may be created before mandatory onboarding checks pass. |
| Task orchestration | Submission creates a Project and Task records from the onboarding activities | Owners must receive onboarding work through tasks and the onboarding status must be traceable. |

## 3. Business objective

HR must manage a controlled, auditable hiring journey that preserves candidate context, records the accepted offer and its salary annexure, assigns pre-joining activities, and blocks employee creation until required onboarding activities are complete.

## 4. Actors

| Actor | Responsibilities |
|---|---|
| Hiring Manager | Raises/approves the requisition and participates in interviews. |
| Recruiter / HR User | Publishes openings, manages applicants, interviews, offers, and appointment letters. |
| HR Manager | Owns recruitment/onboarding approval and employee creation authority. |
| Onboarding Task Owner | Completes assigned onboarding tasks such as IT, facilities, documentation, or induction. |
| Candidate | Supplies application information and accepts/rejects the offer outside or through the organization’s agreed communication process. |

## 5. Required business flow

1. HR creates a Staffing Plan where capacity planning is used, then creates and approves a Job Requisition.
2. The requisition creates or is associated with a Job Opening. The opening is published or otherwise used as the recruitment source.
3. A Job Applicant is created from the portal, referral, or manual entry. Interviews and Interview Feedback are recorded against that applicant.
4. HR creates one Job Offer for the applicant. Its status is updated to `Accepted` or `Rejected`; HRMS propagates that decision to the applicant record.
5. HR may create an Appointment Letter for the same Job Applicant from an Appointment Letter Template. This is a parallel document, not an onboarding prerequisite in the current implementation.
6. For an accepted offer, HR creates and submits Employee Onboarding. The record must carry the same Job Applicant and the accepted Job Offer, joining date, company, and onboarding template.
7. Submission creates a Project and the configured boarding Tasks, assigns the task owners, and sets boarding status to Pending/In Process/Completed.
8. After all activities marked `required_for_employee_creation` are Completed or Cancelled, an authorized user creates the Employee from Employee Onboarding. The Employee is set Active and receives its personal email from the Job Applicant.

## 6. Functional requirements

| ID | Requirement | Priority | Acceptance criterion |
|---|---|---|---|
| RON-01 | The system shall retain one Job Applicant reference across Job Offer, Appointment Letter, Employee Onboarding, and Employee. | Must | Each related record can be reached and reconciled by Job Applicant. |
| RON-02 | The system shall permit at most one active Job Offer per Job Applicant. | Must | A second non-cancelled Job Offer is rejected by validation. |
| RON-03 | Only an accepted Job Offer may be selected for Employee Onboarding. | Must | Enforce with a link filter or server validation; the standard DocType currently requires a Job Offer but does not itself filter it to Accepted. |
| RON-04 | Employee Onboarding shall require Job Applicant, Job Offer, date of joining, company, and an onboarding template before submission. | Must | Submission is blocked when any mandatory field is absent. |
| RON-05 | Submitting Employee Onboarding shall create a project and activities as tasks, with owners based on the configured user or role. | Must | Project and task records exist and task owners receive assignments. |
| RON-06 | The system shall block Employee creation until the onboarding record is submitted and every activity marked required is Completed or Cancelled. | Must | The Create Employee action returns the current validation error until conditions are met. |
| RON-07 | Appointment Letter shall remain an optional document associated with Job Applicant. | Must | No automatic Appointment Letter → Employee Onboarding dependency is introduced. |
| RON-08 | HR shall be able to produce an appointment letter from a controlled template with company, appointment date, and terms. | Should | Printed letter contains the selected template content and applicant data. |
| RON-09 | Job Offer salary-annexure fields shall calculate salary breakup, allowances, deductions, benefits, CTC, and net salary according to the configured OLSCPL structure. | Must | Saving a Job Offer enforces the current recurring allowance cap and refreshes calculated totals. |
| RON-10 | The system shall maintain document audit history and restrict offer, appointment letter, onboarding, and employee creation to HR roles. | Must | Existing DocType permissions and change tracking are retained; role matrix is approved before go-live. |

## 7. Business rules and data relationships

| Relationship | Implementation status | Rule |
|---|---|---|
| Job Requisition → Job Opening | Implemented | A Job Opening stores the originating Job Requisition. |
| Job Applicant → Job Offer | Implemented | Job Offer requires Job Applicant and updates applicant status when accepted/rejected. |
| Job Applicant → Appointment Letter | Implemented | Appointment Letter requires Job Applicant; there is no Job Offer or Employee Onboarding link on this DocType. |
| Job Applicant + Job Offer → Employee Onboarding | Implemented | Both links are mandatory on Employee Onboarding. |
| Employee Onboarding → Project / Task | Implemented | Submission creates the project and tasks. |
| Employee Onboarding → Employee | Implemented | Employee creation is gated by submitted status and required-task completion. |

## 8. Gap decisions

1. **Appointment Letter is not connected to Onboarding by code.** This is intentional in the architecture diagram. It shares the Job Applicant identifier only. If the business requires the letter to be accepted or issued before onboarding starts, implement an explicit custom field/status on Employee Onboarding or a server-side validation. Do not infer it from the current data model.
2. **Accepted-offer guard.** The current Employee Onboarding form requires a Job Offer but its JSON definition does not restrict the selected offer to `Accepted`. Add a server-side validation and a UI link filter if this is mandatory policy.
3. **Document verification.** Standard onboarding tasks can model document verification, but no dedicated document-verification DocType was found in `olscpl_hrms`. If structured verification status, expiry, or approval evidence is required, define a new DocType and make it a required onboarding activity.
4. **Offer-to-employee compensation handoff.** The custom Job Offer script calculates annexure values. This BRD does not assume those values automatically create Salary Structure Assignments; that downstream mapping must be separately specified and tested.

## 9. Non-functional requirements

- All status changes and document amendments must be auditable through Frappe’s versioning/change history.
- Candidate personal data and letters must be accessible only to authorized roles.
- Employee creation and task generation must be idempotent: repeated user actions must not create duplicate active onboarding records, projects, or employee records.
- The workflow must surface validation messages that explain the missing task or required record.

## 10. Out of scope

Payroll processing, attendance, leave, statutory filings, bank payments, job-board integrations, e-signature, background verification vendor integration, and offboarding are out of scope for this BRD.

## 11. Source-code traceability

- `apps/hrms/hrms/hr/doctype/appointment_letter/appointment_letter.json`: Appointment Letter fields and its Job Applicant-only link.
- `apps/hrms/hrms/hr/doctype/employee_onboarding/employee_onboarding.json`: required Job Applicant and Job Offer links.
- `apps/hrms/hrms/hr/doctype/employee_onboarding/employee_onboarding.py`: duplicate onboarding protection and Employee creation gate/mapping.
- `apps/hrms/hrms/controllers/employee_boarding_controller.py`: project/task generation and task assignment.
- `apps/hrms/hrms/hr/doctype/job_offer/job_offer.py`: offer uniqueness, vacancy validation, and applicant-status update.
- `apps/olscpl_hrms/olscpl_hrms/public/js/job_offer.js`: OLSCPL salary-annexure calculation and recurring allowance validation.
