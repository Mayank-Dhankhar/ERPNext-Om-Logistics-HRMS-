# Careers API

Base URL: `https://atlas.omone.in/api/method/<endpoint>`

| Endpoint | Method | Auth | Purpose |
|---|---|---|---|
| `get_published_jobs` | GET | None | List all open, published jobs |
| `get_published_job` | GET | None | Get one job by id |
| `submit_job_application` | POST | API key | Create a job application from your form |

## `get_published_jobs`

| Param | Required |
|---|---|
| `company` | no |

```bash
curl 'https://atlas.omone.in/api/method/get_published_jobs'
curl 'https://atlas.omone.in/api/method/get_published_jobs?company=TRANSAFE%20SERVICES%20LTD'
```

Response: `{"message": {"jobs": [ {job}, ... ]}}`

## `get_published_job`

| Param | Required |
|---|---|
| `job_opening` | yes |

```bash
curl 'https://atlas.omone.in/api/method/get_published_job?job_opening=HR-OPN-2026-0019'
```

Response: `{"message": {job}}`. 404 if not found or no longer published.

<div style="break-before: page"></div>

## Job fields

Each `{job}` in both responses has:

| Field | Example |
|---|---|
| `id` | `HR-OPN-2026-0019` |
| `title` | `Backend Developer` |
| `company` | `OM Logistics Supply Chain PVT. LTD.` |
| `department` | `IT` |
| `location` | `Delhi` |
| `employment_type` | `Full-time` |
| `description` | HTML, e.g. `<p>...</p>` |
| `posted_on` | `2026-09-30` |
| `closes_on` | `2026-10-31` or `null` |
| `salary_range` | `{"currency", "lower", "upper", "per"}` or `null` |
| `applications_received` | `12` or `null` |
| `detail_url` | Public job page URL |
| `apply_url` | Hosted application form URL |

`salary_range` and `applications_received` are `null` unless HR chose to publish them for that job.


<div style="break-before: page"></div>

## `submit_job_application`

Use this when your site has its own Apply form. Your **server** posts the form here, and the application appears in our HRMS as a Job Applicant against that job.

**Server-to-server only.** Send the `X-Careers-Api-Key` header from your backend. Never call this endpoint from the browser, because anyone could then read the key from the page. We share the key separately, not in this document.

`POST`, `multipart/form-data`

| Field | Required | Notes |
|---|---|---|
| `job_opening` | yes | `id` from `get_published_jobs` |
| `applicant_name` | yes | |
| `email` | yes | |
| `phone` | no | |
| `cover_letter` | no | |
| `country` | no | Country name, e.g. `India` |
| `resume` | one of `resume` / `resume_link` | File: PDF, DOC or DOCX, max 5 MB |
| `resume_link` | one of `resume` / `resume_link` | URL to the resume |

```bash
curl -X POST 'https://atlas.omone.in/api/method/submit_job_application' \
  -H 'X-Careers-Api-Key: <API_KEY>' \
  -F 'job_opening=HR-OPN-2026-0019' \
  -F 'applicant_name=Rahul Sharma' \
  -F 'email=rahul.sharma@example.com' \
  -F 'phone=9876543210' \
  -F 'cover_letter=I have 4 years of backend experience.' \
  -F 'country=India' \
  -F 'resume=@/path/to/resume.pdf'
```

Success (200):

```json
{ "message": { "application_id": "rahul.sharma@example.com", "status": "Open" } }
```

### Errors

Errors return JSON. Read `exception` for the reason, or `_server_messages` for a message you can show the user.

| HTTP | When |
|---|---|
| 401 | Missing or wrong `X-Careers-Api-Key` |
| 404 | Job not found, closed, or unpublished |
| 409 | This email has already applied for this job |
| 417 | Validation: missing name, bad email, no resume, wrong file type, file over 5 MB, unreadable file |
| 429 | Over 300 applications per hour from your server |
