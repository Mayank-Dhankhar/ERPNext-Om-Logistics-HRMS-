# Recruitment, Onboarding, and Payroll Architecture

This design extends the existing Frappe/HRMS and ERPNext deployment.  Frappe
remains the system of record and workflow engine; integration adapters isolate
third-party job boards, biometric devices, banks, and statutory services.

```mermaid
flowchart LR
  subgraph Users["Users and channels"]
    C["Candidate portal / job boards"]
    R["Recruiter and hiring manager"]
    E["Employee self-service"]
    A["HR, payroll, and finance"]
    D["Biometric device / attendance app"]
  end

  subgraph HRMS["Frappe HRMS / OLSCPL HRMS"]
    IAM["Identity, RBAC, approvals, audit"]
    ATS["Recruitment: requisition, job opening, candidate, interview, offer"]
    ONB["Onboarding: checklist, documents, equipment, induction"]
    CORE["Employee master: employment, org, compensation, bank, tax"]
    TLM["Time and leave: shifts, attendance, leave, regularization"]
    PAY["Payroll: salary structure, inputs, tax, payroll entry, payslip"]
    DOC["Document store and e-sign status"]
    EVT["Outbox events and scheduled jobs"]
  end

  subgraph Platform["Platform services"]
    DB[("MariaDB: transactional system of record")]
    FILES[("Private files / object storage")]
    REDIS[("Redis: cache, queue, real-time")]
    BI[("Reporting warehouse / BI")]
  end

  subgraph External["External systems"]
    JOB["Job boards / career site"]
    IDV["Background check, e-sign, identity verification"]
    IT["ITSM / asset management / IAM provisioning"]
    BANK["Bank / payment file or API"]
    GOV["Tax, PF/ESI, statutory portals"]
    GL["ERPNext general ledger"]
    MSG["Email, SMS, WhatsApp"]
  end

  C --> ATS
  R --> ATS
  E --> ONB
  E --> TLM
  A --> PAY
  D --> TLM
  IAM --- ATS
  IAM --- ONB
  IAM --- CORE
  IAM --- TLM
  IAM --- PAY
  ATS --> ONB --> CORE --> PAY
  TLM --> PAY
  ATS --> DB
  ONB --> DB
  CORE --> DB
  TLM --> DB
  PAY --> DB
  DOC --> FILES
  EVT --> REDIS
  ATS <--> JOB
  ONB <--> IDV
  ONB <--> IT
  PAY <--> BANK
  PAY <--> GOV
  PAY --> GL
  EVT --> MSG
  DB --> BI
```

## End-to-end lifecycle

```mermaid
sequenceDiagram
  autonumber
  participant HM as Hiring manager
  participant ATS as Recruitment
  participant HR as HR operations
  participant ONB as Onboarding
  participant EMP as Employee master
  participant TIME as Time and leave
  participant PAY as Payroll
  participant FIN as Finance / bank

  HM->>ATS: Approve requisition and publish job
  ATS->>ATS: Capture candidate, screening, interviews
  ATS->>HR: Offer approved and accepted
  HR->>ONB: Create onboarding project and pre-boarding tasks
  ONB->>ONB: Verify documents; complete background check and provisioning
  ONB->>EMP: Convert candidate to employee on joining date
  EMP->>PAY: Create employment, salary structure, tax and bank setup
  EMP->>TIME: Assign shift, holiday list, leave policy and attendance device ID
  TIME->>PAY: Send approved attendance, leave and payroll adjustments
  PAY->>PAY: Calculate, validate, approve and submit payroll
  PAY->>FIN: Create bank payment instruction and accounting journal
  FIN-->>PAY: Payment status / reconciliation result
  PAY-->>EMP: Publish secured payslip and notifications
```

## Domain boundaries and ownership

| Domain | Primary records | Responsible role | Output contract |
|---|---|---|---|
| Recruitment | Job Requisition, Job Opening, Job Applicant, Interview, Offer | Recruiter / hiring manager | `offer.accepted` |
| Onboarding | Employee Onboarding, tasks, document-verification state | HR operations | `onboarding.completed` |
| Employee core | Employee, Employment Type, Department, designation, bank/tax identifiers | HR master-data owner | `employee.activated` |
| Time and leave | Shift Assignment, Employee Checkin, Attendance, Leave Application, Additional Salary | Employee / manager / HR | `payroll.input.approved` |
| Payroll | Salary Structure Assignment, Payroll Entry, Salary Slip, payroll payment | Payroll owner | `payroll.submitted`, `payment.reconciled` |
| Finance and compliance | Journal Entry, payment file, statutory return/status | Finance / compliance | `payment.completed`, `statutory.filed` |

## Key controls

- Use an immutable candidate-to-employee link; do not duplicate personal data after conversion.
- Make employee activation dependent on mandatory identity, tax, bank, policy, and approval checks. Keep sensitive documents in private storage with role-based access.
- Treat approved attendance, leave, incentives, deductions, arrears, and reimbursement as versioned payroll inputs. Lock the payroll period once approval begins; adjustments go to the next run or an explicit supplemental run.
- Use an outbox table and background workers for every external call. Consumers must be idempotent, record correlation IDs, retry safely, and expose a reconciliation queue.
- Separate duties: recruiter cannot approve their own offer; HR cannot approve their own compensation change; payroll preparer, approver, and bank-file releaser must be distinct roles.
- Retain audit trails for approval, salary changes, document access, payroll recalculation, payment export, and statutory filing. Encrypt PII at rest and redact it from logs.

## Integration and failure model

Synchronous APIs are appropriate for interactive lookups and immediate validation. Use asynchronous events for provisioning, notifications, job-board updates, attendance imports, bank submission, and statutory filing. A failed integration must not silently change HR/payroll state: persist the request, status, source payload reference, retry count, and a human resolution action.

## Payroll close checklist

1. Close attendance and leave cut-off; resolve exceptions and lock inputs.
2. Generate a draft payroll run; validate missing bank/tax data, negative net pay, outlier variance, and duplicate employees.
3. Obtain payroll approval, submit salary slips, create accounting entries, and generate the payment file/API batch.
4. Reconcile bank acknowledgements and payment failures; issue supplemental/reversal entries only through an approved correction workflow.
5. Publish payslips, archive statutory artifacts, and send reconciled figures to BI.

## Deployment recommendation

Start as a modular Frappe application with bounded modules and a shared MariaDB transaction boundary—the operational risk of split payroll data is higher than the benefit of early microservices. Scale workers independently for integrations, document processing, attendance imports, and payroll calculations. Extract an integration service only when third-party traffic, independent release cadence, or availability needs justify it.
