# Deploy notes: /jobs redesign, onboarding fix, careers API

For whoever deploys `olscpl_hrms` to atlas.omone.in. Everything below lives in the
`olscpl_hrms` app, branch `feature/onboarding-document-checklist`.

## What this deploy includes

1. **Employee Onboarding attachments** — documents attached to an Employee Onboarding
   record (Aadhaar, PAN, marksheets, etc.) now copy onto the resulting Employee record
   automatically when it's created. Previously they never carried over.
2. **Public `/jobs` pages redesigned** — listing page, job detail page, and the
   `/job_application/new` apply form now carry the navy "OmOne ATLAS" branding
   (matching the login page and desk) instead of looking like an unbranded default
   Frappe site: navy navbar/sidebar/footer, centered header panel, styled job cards,
   10 postings per page instead of 20.
3. **Careers API** — new public read-only endpoints (`get_published_jobs`,
   `get_published_job`) for the external company career-page team to pull job
   listings from and link "Apply" straight at our hosted form. See
   `docs/careers_api.md` — that's the doc for *them*, this one is for deploying it.

## Already live on atlas.omone.in — not waiting on this deploy

Two fixes from earlier in this work were applied directly to atlas.omone.in's database
(via the Frappe API) rather than only through code, because they were blocking issues
found while testing:

- **Job Requisition workflow** — was missing the Filled/On Hold/Cancelled states
  entirely, so closing any Job Opening linked to a Job Requisition crashed. The
  Workflow record on atlas.omone.in already has the fix; this deploy just brings the
  fixture files that produce the same result on a fresh install into version control.
- **Outgoing Salary chart** (Payroll workspace) — was scoped to the viewing user's
  default company (rendered empty for most people) and had a stale server-side cache.
  Already cleared on atlas.omone.in directly; this deploy adds a patch
  (`fix_outgoing_salary_chart_company_scope`) so the fix also applies automatically on
  any future fresh install or site restore.

Don't expect either of those to *change* anything after this deploy — they're already
in the state this code produces. If a fresh migrate somehow reports a conflict on
either, that's worth a second look, not something to force through.

## Before you deploy

- **Not yet committed as of writing this**: `olscpl_hrms/api/careers.py`, the two
  `get_published_job*` aliases in `hooks.py`, and this `docs/` folder's contents.
  Confirm these are committed on `feature/onboarding-document-checklist` before
  deploying — `git log --stat -3` should show them.
- Confirm `feature/onboarding-document-checklist` is merged into whatever branch
  atlas.omone.in actually deploys from (`release`? `develop`? check your deploy
  pipeline config) — pushing this branch to GitHub by itself does not deploy it.

## Deploy steps

Run on the atlas.omone.in server, from the bench root:

```bash
# 1. Pull the code
cd apps/olscpl_hrms
git fetch origin
git checkout <your-deploy-branch>   # after the above branch is merged into it
git pull

# 2. Rebuild assets - required for the CSS/JS changes to actually be served.
#    Skipping this step is the most likely reason a deploy "doesn't show" the change.
cd ../..
bench build --app olscpl_hrms

# 3. Run migrations - applies the Outgoing Salary patch (harmless / no-op if you
#    already cleared it manually, see above) and picks up the new Custom Field /
#    doctype fixtures if any were added.
bench --site <site-name> migrate

# 4. Restart so hooks.py (new whitelisted method aliases, new doc_events) reloads.
#    Skip if the site runs with developer_mode=1 and a file-watching dev server -
#    those already pick up .py changes without a restart, but assets still need
#    step 2's build regardless of developer_mode.
bench restart
```

## Verify after deploy

- `https://atlas.omone.in/jobs` — navy navbar, navy full-height sidebar with Filters,
  centered "Job Openings" header panel, 10 results per page if more than 10 are
  published.
- Open any published job's detail page — navy navbar, white card, centered
  breadcrumb, indigo "Apply Now" button.
- Click "Apply Now" — navy navbar, centered white form card, indigo "Submit" button,
  no stray empty sidebar column.
- `curl https://atlas.omone.in/api/method/get_published_jobs` — no auth header, 200
  response, `{"message": {"jobs": [...]}}` with every currently-published Open job
  opening. Confirm `apply_url`/`detail_url` in the response actually point at
  `atlas.omone.in` (they're built from `frappe.utils.get_url()`, so they should
  automatically resolve correctly on that site - just worth the one manual check).
- Create a test Employee via an Employee Onboarding's "Create > Employee" button
  (an onboarding record that has attachments on it) and confirm the new Employee's
  Attachments panel shows the same files.

## Rollback

Everything here is additive/isolated to `olscpl_hrms` (no core `frappe`/`erpnext`/
`hrms` files touched) and CSS/behavior is scoped by `body[data-path=...]` selectors,
so reverting is just `git revert` back to commit `e0c35dc` (or whichever commit was
last deployed) on this app, followed by the same build + migrate + restart steps
above. The two DB-level fixes noted above will remain in whatever state they're
already in on atlas.omone.in regardless of an app-level rollback, since they were
applied directly to the database, not through this code path.
