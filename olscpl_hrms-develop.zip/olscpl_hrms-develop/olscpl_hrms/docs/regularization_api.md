# Attendance Regularization API

Base URL: `https://hrms.omone.in/api/method/<endpoint>` (POST unless noted)
Auth header (all endpoints): `Authorization: token 4eed5c90eb35029:89a2f89952f805a`

Every response is wrapped: `{"message": {"success": bool, "payload": ..., "message": "..."}}`.
HTTP status: 200 on success, 400 on handled failure.

## 1. `create_and_submit_regularization`

| Param | Type | Required | Notes |
|---|---|---|---|
| `caller_employee` | string | yes | Employee ID this request is from |
| `for_date` | date string | yes | Must have an existing Attendance record already |
| `regularization_type` | string | yes | `Missing Punch IN` / `Missing Punch OUT` / `Both Punches Missing` / `Less Working Hours` |
| `reason` | string | yes | |
| `requested_punch_in_time` | time string | conditional | Required for `Missing Punch IN` / `Both Punches Missing` |
| `requested_punch_out_time` | time string | conditional | Required for `Missing Punch OUT` / `Both Punches Missing` / `Less Working Hours` |
| `employee` | string | no | Employee ID this request is *for*, if submitting on someone else's behalf (must be HR or that employee's manager) |

```bash
curl --location 'https://hrms.omone.in/api/method/create_and_submit_regularization' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699999",
    "for_date": "2026-08-01",
    "regularization_type": "Missing Punch OUT",
    "reason": "Forgot to punch out",
    "requested_punch_out_time": "18:30:00"
}'
```

## 2. `action_regularization`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes — Employee ID of the acting manager/HR user |
| `name` | string | yes — the regularization document's ID |
| `action` | string | yes — `Approve` or `Reject` |
| `remarks` | string | no |

```bash
curl --location 'https://hrms.omone.in/api/method/action_regularization' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699998",
    "name": "<regularization name from step 1>",
    "action": "Approve",
    "remarks": "Verified with biometric log"
}'
```

## 3. `get_my_regularizations`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes |
| `from_date`, `to_date` | date string | no |
| `workflow_state` | string | no — `Pending` / `Approved` / `Rejected` |
| `limit`, `start` | int | no — default `limit=50, start=0` |

```bash
curl --location 'https://hrms.omone.in/api/method/get_my_regularizations?caller_employee=699999&workflow_state=Pending' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a'
```

## 4. `get_team_regularizations`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes — Employee ID of the acting manager/HR user |
| `workflow_state`, `from_date`, `to_date`, `limit`, `start` | | same as above |
| `employee` | string | no — filter to one specific report |

```bash
curl --location 'https://hrms.omone.in/api/method/get_team_regularizations?caller_employee=699998&workflow_state=Pending' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a'
```

## 5. `get_attendance_regularization_details`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes |
| `name` | string | yes |

```bash
curl --location 'https://hrms.omone.in/api/method/get_attendance_regularization_details' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699999",
    "name": "<regularization name from step 1>"
}'
```

## Business rules

- A regularization can only be filed for a date that already has an Attendance record.
- Requests older than 7 days are rejected.
- Max 4 requests per payroll cycle (26th–25th); the 5th+ is hard-blocked.
- **One active request per employee per date.** If a Pending or Approved request already exists for that employee+date, `create_and_submit_regularization` fails with "A regularization request already exists for this employee and date". A Rejected request does not block resubmission for the same date.
- Only HR, or the specific employee's actual manager (`Employee.reports_to`), can approve/reject or view a request — not any generic "Manager"-role user.
