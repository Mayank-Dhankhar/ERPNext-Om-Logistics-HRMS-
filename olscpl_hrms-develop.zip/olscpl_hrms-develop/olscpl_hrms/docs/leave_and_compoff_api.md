# Leave & Compensatory Leave API

Base URL: `https://hrms.omone.in/api/method/<endpoint>` (POST unless noted)
Auth header (all endpoints): `Authorization: token 4eed5c90eb35029:89a2f89952f805a`

Every response is wrapped: `{"message": {"success": bool, "payload": ..., "message": "..."}}`.
HTTP status: 200 on success, 400 on handled failure.

## Leave Application

### 1. `create_and_submit_leave_application`

| Param | Type | Required | Notes |
|---|---|---|---|
| `caller_employee` | string | yes | Employee ID this request is from |
| `leave_type` | string | yes | e.g. `Leave` |
| `from_date` | date string | yes | |
| `to_date` | date string | yes | |
| `reason` | string | yes | |
| `half_day` | int | no | `1` for a half-day leave |
| `half_day_date` | date string | conditional | Required if `half_day` is `1` |
| `employee` | string | no | Employee ID this request is *for*, if submitting on someone else's behalf (must be HR or that employee's manager) |
| `against_compensatory_leave_request` | string | conditional | **Required when `leave_type` is `Comp Off`.** The name of one of this employee's own Approved, not-yet-availed Compensatory Leave Requests — get the list from `get_available_comp_off_dates` (endpoint 6) first. Ignored/not needed for any other leave type. |

```bash
curl --location 'https://hrms.omone.in/api/method/create_and_submit_leave_application' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699999",
    "leave_type": "Leave",
    "from_date": "2026-08-10",
    "to_date": "2026-08-10",
    "reason": "Family function"
}'
```

Availing Comp Off leave instead (note the extra field):

```bash
curl --location 'https://hrms.omone.in/api/method/create_and_submit_leave_application' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699999",
    "leave_type": "Comp Off",
    "from_date": "2026-08-10",
    "to_date": "2026-08-10",
    "reason": "Taking my comp-off",
    "against_compensatory_leave_request": "HR-CMP-26-08-00003"
}'
```

### 2. `action_leave_application`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes — Employee ID of the acting manager/HR user |
| `name` | string | yes — the leave application's ID |
| `action` | string | yes — `Approve` or `Reject` |
| `remarks` | string | no |

```bash
curl --location 'https://hrms.omone.in/api/method/action_leave_application' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699998",
    "name": "<leave application name from step 1>",
    "action": "Approve",
    "remarks": "Approved"
}'
```

### 3. `get_my_leave_applications`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes |
| `from_date`, `to_date` | date string | no |
| `status` | string | no — `Open` / `Approved` / `Rejected` |
| `limit`, `start` | int | no — default `limit=50, start=0` |

```bash
curl --location 'https://hrms.omone.in/api/method/get_my_leave_applications?caller_employee=699999&status=Open' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a'
```

### 4. `get_team_leave_applications`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes — Employee ID of the acting manager/HR user |
| `status`, `from_date`, `to_date`, `limit`, `start` | | same as above |
| `employee` | string | no — filter to one specific report |

```bash
curl --location 'https://hrms.omone.in/api/method/get_team_leave_applications?caller_employee=699998&status=Open' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a'
```

### 5. `get_leave_application_details`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes |
| `name` | string | yes |

```bash
curl --location 'https://hrms.omone.in/api/method/get_leave_application_details' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699999",
    "name": "<leave application name from step 1>"
}'
```

### 6. `get_available_comp_off_dates`

Lists the employee's acquired Compensatory Leave Requests that are Approved but not yet availed against — use this to build the "which date am I taking as comp-off" picker before calling endpoint 1 with `leave_type: "Comp Off"`.

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes |
| `employee` | string | no — check another employee's availability (must be HR or that employee's manager) |

```bash
curl --location 'https://hrms.omone.in/api/method/get_available_comp_off_dates?caller_employee=699999' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a'
```

### Leave Application business rules

- Standard leave balance, overlap, and back-dated-application checks apply (same as the Desk form) — a failure returns its message as-is in `message`.
- Only HR, or the specific employee's actual manager (`Employee.reports_to`), can approve/reject or view a request — not any generic "Manager"-role user.
- `action_leave_application` only works on a request in `Open` status; an already-Approved/Rejected request returns "Request is not open for action".
- **Comp Off leave must be availed against a specific acquired credit.** `leave_type: "Comp Off"` requires `against_compensatory_leave_request` (see endpoint 1) — a credit already claimed by another active (Open or Approved) leave application can't be picked again, and it's freed back up automatically if that application is later Rejected.

## Compensatory Leave Request

### 7. `create_and_submit_compensatory_leave_request`

| Param | Type | Required | Notes |
|---|---|---|---|
| `caller_employee` | string | yes | Employee ID this request is from |
| `leave_type` | string | yes | e.g. `Comp Off` |
| `work_from_date` | date string | yes | Must be a holiday for the employee, with a submitted Attendance (Present/WFH/Half Day/On Duty) on that date |
| `work_end_date` | date string | yes | |
| `reason` | string | yes | |
| `half_day` | int | no | `1` for a half-day comp-off |
| `half_day_date` | date string | conditional | Required if `half_day` is `1` |
| `employee` | string | no | Employee ID this request is *for*, if submitting on someone else's behalf (must be HR or that employee's manager) |

```bash
curl --location 'https://hrms.omone.in/api/method/create_and_submit_compensatory_leave_request' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699999",
    "leave_type": "Comp Off",
    "work_from_date": "2026-08-02",
    "work_end_date": "2026-08-02",
    "reason": "Worked on a company holiday"
}'
```

### 8. `action_compensatory_leave_request`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes — Employee ID of the acting manager/HR user |
| `name` | string | yes — the compensatory leave request's ID |
| `action` | string | yes — `Approve` or `Reject` |
| `remarks` | string | no |

```bash
curl --location 'https://hrms.omone.in/api/method/action_compensatory_leave_request' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699998",
    "name": "<compensatory leave request name from step 7>",
    "action": "Approve",
    "remarks": "Confirmed with biometric log"
}'
```

### 9. `get_my_compensatory_leave_requests`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes |
| `from_date`, `to_date` | date string | no |
| `workflow_state` | string | no — `Pending` / `Approved` / `Rejected` |
| `limit`, `start` | int | no — default `limit=50, start=0` |

```bash
curl --location 'https://hrms.omone.in/api/method/get_my_compensatory_leave_requests?caller_employee=699999&workflow_state=Pending' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a'
```

### 10. `get_team_compensatory_leave_requests`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes — Employee ID of the acting manager/HR user |
| `workflow_state`, `from_date`, `to_date`, `limit`, `start` | | same as above |
| `employee` | string | no — filter to one specific report |

```bash
curl --location 'https://hrms.omone.in/api/method/get_team_compensatory_leave_requests?caller_employee=699998&workflow_state=Pending' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a'
```

### 11. `get_compensatory_leave_request_details`

| Param | Type | Required |
|---|---|---|
| `caller_employee` | string | yes |
| `name` | string | yes |

```bash
curl --location 'https://hrms.omone.in/api/method/get_compensatory_leave_request_details' \
--header 'Authorization: token 4eed5c90eb35029:89a2f89952f805a' \
--header 'Content-Type: application/json' \
--data '{
    "caller_employee": "699999",
    "name": "<compensatory leave request name from step 7>"
}'
```

### Compensatory Leave Request business rules

- The worked date must already be a holiday for the employee, with a submitted Attendance record (Present/WFH/Half Day/On Duty) — otherwise creation fails with a message naming the missing piece.
- Worked hours on that Attendance decide the credit: ≥6 hours = full day, ≥3 hours = half day, under 3 hours is rejected outright.
- **Max 5 Compensatory Leaves per calendar month** per leave type; the 6th+ in the same month is hard-blocked.
- Only one active request per employee per overlapping date range — a second request for an already-requested date is rejected.
- Only HR, or the specific employee's actual manager (`Employee.reports_to`), can approve/reject or view a request — not any generic "Manager"-role user.
- `action_compensatory_leave_request` only works on a request in `Pending` state; approving creates the employee's Leave Allocation, rejecting leaves the record at docstatus 0 for history.
