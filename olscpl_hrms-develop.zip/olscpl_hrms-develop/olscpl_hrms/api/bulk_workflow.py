"""
olscpl_hrms/api/bulk_workflow.py

Server-side helpers for bulk-migrating Visit, Work From Home Request, and
Compensatory Leave Request records (Oracle -> ERPNext), used by
erpnext_leave_migration.py in place of that DAG's previous raw-REST
create + two-PUT workflow walk for each of these three doctypes.

WHY THIS EXISTS
----------------
migrate_visits(), migrate_wfh_attendance(), and the DAG's
_get_or_create_approved_comp_off_request() previously drove each of these
doctypes' Draft -> Pending -> Approved workflow via three separate HTTP
calls (POST create, PUT workflow_state=Pending, PUT workflow_state=
Approved) straight against /api/resource/<doctype>. That works, but
nothing on that path can suppress the Notification/Workflow email alerts
each save()/workflow transition can fire -- there is no "mute emails"
REST header, only the frappe.flags.mute_emails Python flag, which only
exists inside a running request on the server. At migration volume (one
row = up to 3 HTTP calls, each capable of firing mail) that floods
mailboxes with alerts about years-old historical data.

Each function below does the exact same create + workflow_state walk,
but server-side in ONE call, with frappe.flags.mute_emails set for the
duration and always restored in a finally block (same pattern as
api/bulk_attendance.py's bulk_backfill_attendance and api/leave.py's
create_and_submit_leave_application -- see those files' own "EMAIL
SUPPRESSION" notes).

Callable only by System Manager / Administrator (same DAG API key user as
every other bulk endpoint in this app).
"""
import frappe


def _run_muted(fn):
    """Run fn() with frappe.flags.mute_emails set, always restoring the
    previous value afterward -- even if fn() raises."""
    previous_mute = frappe.flags.mute_emails
    frappe.flags.mute_emails = True
    # historical rows: don't share them with today's approvers (utils/reporting_person.py)
    frappe.flags.skip_reporting_share = True
    try:
        return fn()
    finally:
        frappe.flags.mute_emails = previous_mute
        frappe.flags.skip_reporting_share = False


@frappe.whitelist()
def create_and_approve_visit(
    employee, reporting_person, visit_type, source, destination,
    from_date, to_date, day_portion, remarks=None,
):
    """Mirrors the DAG's migrate_visits() per-row flow: duplicate check on
    (employee, from_date, to_date), then Draft -> Pending -> Approved.
    Visit's workflow_state field carries no read-only lock (unlike Leave
    Application's status field), so a straight frappe.get_doc save-chain
    works the same way the DAG's raw REST PUTs did."""
    frappe.only_for(("System Manager",))

    existing = frappe.db.get_value(
        "Visit",
        {"employee": employee, "from_date": from_date, "to_date": to_date, "docstatus": ["!=", 2]},
        ["name", "workflow_state"],
        as_dict=True,
    )
    if existing:
        return {"success": True, "skipped": True, "name": existing.name, "workflow_state": existing.workflow_state}

    def _do():
        doc = frappe.new_doc("Visit")
        doc.employee = employee
        doc.reporting_person = reporting_person
        doc.visit_type = visit_type
        doc.source = source
        doc.destination = destination
        doc.from_date = from_date
        doc.to_date = to_date
        doc.day_portion = day_portion
        doc.remarks = remarks or "Visit"
        doc.workflow_state = "Draft"
        doc.flags.ignore_permissions = True
        doc.insert()

        doc.workflow_state = "Pending"
        doc.save()

        # Oracle's EMP_VISIT_APP is already filtered to APPROVAL_STATUS='Y',
        # so every row reaching here is approved in the source system.
        doc.workflow_state = "Approved"
        doc.save()

        frappe.db.commit()
        return doc

    try:
        doc = _run_muted(_do)
        return {"success": True, "skipped": False, "name": doc.name, "workflow_state": doc.workflow_state}
    except Exception as e:
        frappe.db.rollback()
        return {"success": False, "error": str(e)[:300]}


@frappe.whitelist()
def create_and_approve_wfh(employee, reporting_person, date, description=None):
    """Mirrors the DAG's migrate_wfh_attendance() per-row flow: duplicate
    check on (employee, date), then Draft -> Pending -> Approved. Same
    unlocked-workflow_state reasoning as create_and_approve_visit."""
    frappe.only_for(("System Manager",))

    existing = frappe.db.get_value(
        "Work From Home Request",
        {"employee": employee, "date": date, "docstatus": ["!=", 2]},
        ["name", "workflow_state"],
        as_dict=True,
    )
    if existing:
        return {"success": True, "skipped": True, "name": existing.name, "workflow_state": existing.workflow_state}

    def _do():
        doc = frappe.new_doc("Work From Home Request")
        doc.employee = employee
        doc.reporting_person = reporting_person
        doc.date = date
        doc.append("work_details", {"description": description or "Work From Home"})
        doc.workflow_state = "Draft"
        doc.flags.ignore_permissions = True
        doc.insert()

        doc.workflow_state = "Pending"
        doc.save()

        # Oracle's WORK_AT_HOME_M is already filtered to APPROVAL_STATUS='Y'.
        doc.workflow_state = "Approved"
        doc.save()

        frappe.db.commit()
        return doc

    try:
        doc = _run_muted(_do)
        return {"success": True, "skipped": False, "name": doc.name, "workflow_state": doc.workflow_state}
    except Exception as e:
        frappe.db.rollback()
        return {"success": False, "error": str(e)[:300]}


@frappe.whitelist()
def create_and_approve_comp_off_request(
    employee, work_from_date, work_end_date, half_day=0, half_day_date=None, reason=None,
):
    """Mirrors the DAG's _get_or_create_approved_comp_off_request():
    reuses an existing request for the same (employee, work_from_date,
    work_end_date) if one's already there -- pushing a leftover
    Draft/Pending the rest of the way to Approved instead of creating a
    duplicate (an earlier partial run may have left one at Draft/Pending)
    -- else creates one with custom_skip_attendance_validation=1, exactly
    as the DAG's caller already computes (work_from_date/work_end_date
    MUST already be a real holiday on the employee's Holiday List --
    CompensatoryLeaveRequest.validate_holidays() enforces this
    unconditionally; that resolution logic stays in the DAG, unchanged,
    this endpoint only removes the raw-REST create+2-PUT round trip)."""
    frappe.only_for(("System Manager",))

    def _do():
        existing = frappe.db.get_value(
            "Compensatory Leave Request",
            {
                "employee": employee,
                "work_from_date": work_from_date,
                "work_end_date": work_end_date,
                "docstatus": ["!=", 2],
            },
            ["name", "workflow_state"],
            as_dict=True,
        )
        if existing and existing.workflow_state == "Approved":
            return existing.name, "Approved"

        if existing:
            doc = frappe.get_doc("Compensatory Leave Request", existing.name)
        else:
            doc = frappe.new_doc("Compensatory Leave Request")
            doc.employee = employee
            doc.leave_type = "Comp Off"
            doc.work_from_date = work_from_date
            doc.work_end_date = work_end_date
            doc.half_day = half_day
            doc.half_day_date = half_day_date
            doc.reason = reason or "Historical Comp Off migration"
            doc.custom_skip_attendance_validation = 1
            doc.workflow_state = "Draft"
            doc.flags.ignore_permissions = True
            doc.insert()

        doc.workflow_state = "Pending"
        doc.save()

        doc.workflow_state = "Approved"
        doc.save()

        frappe.db.commit()
        return doc.name, doc.workflow_state

    try:
        name, state = _run_muted(_do)
        return {"success": True, "name": name, "workflow_state": state}
    except Exception as e:
        frappe.db.rollback()
        return {"success": False, "error": str(e)[:300]}
