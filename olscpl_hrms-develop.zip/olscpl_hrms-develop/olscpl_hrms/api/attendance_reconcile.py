"""
olscpl_hrms/api/attendance_reconcile.py   (Frappe / ERPNext HRMS v15.9)

Server-side helpers for the nightly "rolling window" attendance reconcile DAG.

Rules enforced here (not in the DAG) so they can't be bypassed by a bad payload:
  * ONLY submitted Attendance whose status is exactly "Absent" is ever cancelled.
    On Leave / Half Day / Work From Home / Present / Holiday / Week Off are never touched.
  * One savepoint per record: a failure rolls back only that record.
  * Callable only by System Manager / Administrator (the DAG's API key user).
  * Bulk call: Notification/Workflow email alerts are muted for the whole
    batch (frappe.flags.mute_emails) so cancelling/recreating thousands of
    records doesn't fire thousands of emails -- always restored in a
    finally block, even on error.
"""
import json

import frappe


def _load(records):
    return json.loads(records) if isinstance(records, str) else records


@frappe.whitelist()
def cancel_absent_attendance(records):
    """records: [{"employee": "14966", "date": "2026-09-10"}, ...]
    Cancels the Absent Attendance for each pair. Returns the keys it really cancelled."""
    frappe.only_for(("System Manager",))
    out = {"cancelled_keys": [], "skipped_not_absent": 0, "skipped_missing": 0, "errors": []}

    previous_mute = frappe.flags.mute_emails
    frappe.flags.mute_emails = True
    try:
        for rec in _load(records):
            emp, dt = rec["employee"], rec["date"]
            try:
                frappe.db.savepoint("recon_cancel")
                row = frappe.db.get_value(
                    "Attendance",
                    {"employee": emp, "attendance_date": dt, "docstatus": 1},
                    ["name", "status"],
                    as_dict=True,
                )
                if not row:
                    out["skipped_missing"] += 1
                    continue
                if row.status != "Absent":
                    out["skipped_not_absent"] += 1
                    continue

                doc = frappe.get_doc("Attendance", row.name)
                doc.flags.ignore_permissions = True
                doc.cancel()
                out["cancelled_keys"].append([emp, dt])
            except Exception as e:
                frappe.db.rollback(save_point="recon_cancel")
                out["errors"].append({"employee": emp, "date": dt, "error": str(e)[:300]})
    finally:
        frappe.flags.mute_emails = previous_mute
    return out


@frappe.whitelist()
def find_missing_attendance(records):
    """records: [{"employee","date"}, ...]. Returns the pairs that have NO live
    (docstatus != 2) Attendance. Used to heal a record that was cancelled but
    whose re-creation failed, so nobody is left with a hole in the month."""
    frappe.only_for(("System Manager",))
    records = _load(records)
    if not records:
        return []

    employees = sorted({r["employee"] for r in records})
    dates = sorted({r["date"] for r in records})
    existing = set()
    for i in range(0, len(employees), 500):
        chunk = employees[i:i + 500]
        for row in frappe.get_all(
            "Attendance",
            filters={
                "employee": ["in", chunk],
                "attendance_date": ["between", [dates[0], dates[-1]]],
                "docstatus": ["!=", 2],
            },
            fields=["employee", "attendance_date"],
            limit_page_length=0,
        ):
            existing.add((row.employee, str(row.attendance_date)))

    return [r for r in records if (r["employee"], r["date"]) not in existing]
