# olscpl_hrms/api/compensatory_leave.py
#
# Mobile-app facing APIs for the stock "Compensatory Leave Request"
# DocType. Same server-to-server model as api/regularization.py (see that
# file's module-level note) - every function takes a trusted
# `caller_employee` and is gated to the shared Administrator credential.
#
# FIELDS (frappe.get_meta("Compensatory Leave Request")): employee,
# employee_name, department, leave_type, leave_allocation, work_from_date,
# work_end_date, half_day, half_day_date, reason, workflow_state,
# docstatus, amended_from.
#
# WORKFLOW ("Comp Off Approval", already live on this site but previously
# untracked in olscpl_hrms - now added to fixtures/workflow.json and
# hardened to require HR or the employee's actual reports_to manager,
# same fix as Attendance Regularization Workflow):
#   States:      Draft(docstatus 0) -> Pending(0) -> Approved(1) / Rejected(0)
#   Transitions: Draft --Submit--> Pending (allowed role: Employee)
#                Pending --Approve--> Approved (allowed: Manager + reports_to/HR condition)
#                Pending --Reject--> Rejected (allowed: Manager + reports_to/HR condition)
#   NOTE: only "Approve" actually submits the document (docstatus 0 -> 1),
#   which is what triggers Compensatory Leave Request.on_submit() to
#   create/update the employee's Leave Allocation. As with
#   Attendance Regularization, workflow_state is set directly here rather
#   than via apply_workflow(), which checks the Workflow's own
#   role/condition against frappe.session.user - meaningless when every
#   caller is the shared Administrator account.
#
# VALIDATION NOTE: the doctype's own validate() requires every day in
# [work_from_date, work_end_date] to already be both a holiday for the
# employee and covered by a submitted Attendance record (Present/WFH/Half
# Day) - that data must exist before create_and_submit_compensatory_leave_request
# will succeed; failures surface as a normal ValidationError message.
import frappe
from frappe import _
from frappe.utils import getdate

from olscpl_hrms.utils.reporting_person import omstaff_can_approve, omstaff_team_filters
DOCTYPE = "Compensatory Leave Request"
# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _is_trusted_caller():
    return frappe.session.user == "Administrator"
def _is_hr_manager_employee(employee):
    user = frappe.db.get_value("Employee", employee, "user_id")
    if not user:
        return False
    return "HR Manager" in frappe.get_roles(user)
def _is_direct_manager(employee, caller_employee):
    manager_employee = frappe.db.get_value("Employee", employee, "reports_to")
    return bool(manager_employee) and manager_employee == caller_employee
def _is_authorized_viewer(doc, caller_employee):
    return doc.employee == caller_employee or omstaff_can_approve(doc, caller_employee)
def _response(success, payload=None, message=""):
    frappe.response["http_status_code"] = 200 if success else 400
    frappe.local.message_log = []
    return {"success": success, "payload": payload, "message": message}
def _serialize(doc):
    return {
        "name": doc.name,
        "employee": doc.employee,
        "employee_name": doc.employee_name,
        "leave_type": doc.leave_type,
        "work_from_date": doc.work_from_date,
        "work_end_date": doc.work_end_date,
        "half_day": doc.half_day,
        "half_day_date": doc.half_day_date,
        "reason": doc.reason,
        "workflow_state": doc.workflow_state,
        "docstatus": doc.docstatus,
        "leave_allocation": doc.leave_allocation,
        "creation": doc.creation,
        "modified": doc.modified,
    }
# ---------------------------------------------------------------------------
# 1. CREATE + SUBMIT (single call for the mobile app)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def create_and_submit_compensatory_leave_request(
    caller_employee,
    leave_type,
    work_from_date,
    work_end_date,
    reason,
    half_day=0,
    half_day_date=None,
    employee=None,
):
    """
    Creates a Compensatory Leave Request (Draft) and immediately moves it
    to Pending in the employee's manager's queue. `caller_employee` is
    trusted (see api/regularization.py's module-level note) as the
    Employee ID of whoever the app's backend has already authenticated.
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if not reason:
            return _response(False, None, _("Reason is mandatory"))
        employee = employee or caller_employee
        if employee != caller_employee and not (
            _is_hr_manager_employee(caller_employee) or _is_direct_manager(employee, caller_employee)
        ):
            return _response(False, None, _("You can only raise a request for yourself, or for your direct reports"))
        doc = frappe.new_doc(DOCTYPE)
        doc.flags.ignore_permissions = True
        doc.employee = employee
        doc.leave_type = leave_type
        doc.work_from_date = getdate(work_from_date)
        doc.work_end_date = getdate(work_end_date)
        doc.half_day = half_day
        doc.half_day_date = getdate(half_day_date) if half_day_date else None
        doc.reason = reason
        # doc.insert() runs the doctype's own validate() chain (holiday +
        # attendance coverage checks, date validity, overlap) - any
        # failure there raises ValidationError, caught below.
        doc.insert()
        doc.workflow_state = "Pending"
        doc.save()
        doc.reload()
        frappe.db.commit()  # noqa: frappe.db.commit is intentional at API boundary
        return _response(True, _serialize(doc), _("Record submitted successfully"))
    except frappe.ValidationError as e:
        frappe.db.rollback()
        return _response(False, None, str(e))
    except Exception:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Compensatory Leave Request: create_and_submit failed")
        return _response(False, None, _("Something went wrong while submitting your request"))
# ---------------------------------------------------------------------------
# 2. MANAGER ACTION - approve / reject
# ---------------------------------------------------------------------------
@frappe.whitelist()
def action_compensatory_leave_request(caller_employee, name, action, remarks=None):
    """
    action: "Approve" or "Reject". Restricted to HR Manager, or the
    specific employee's own reports_to manager. Approve submits the
    document (triggering Leave Allocation creation); Reject just updates
    workflow_state, leaving the record docstatus 0 for history.
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if action not in ("Approve", "Reject"):
            return _response(False, None, _("Invalid action. Use 'Approve' or 'Reject'"))
        doc = frappe.get_doc(DOCTYPE, name)
        doc.flags.ignore_permissions = True
        if not omstaff_can_approve(doc, caller_employee):
            return _response(False, None, _("Not permitted to action this request"))
        if doc.workflow_state != "Pending":
            return _response(False, None, _("Request is not pending approval"))
        caller_name = frappe.db.get_value("Employee", caller_employee, "employee_name")
        comment_text = f"{action} by {caller_name} ({caller_employee})"
        if remarks:
            comment_text += f": {remarks}"
        doc.add_comment("Comment", comment_text)
        if action == "Approve":
            doc.workflow_state = "Approved"
            doc.submit()
        else:
            doc.workflow_state = "Rejected"
            doc.save()
        doc.reload()
        frappe.db.commit()  # noqa
        msg = _("Request approved successfully") if action == "Approve" else _("Request rejected")
        return _response(True, _serialize(doc), msg)
    except frappe.DoesNotExistError:
        return _response(False, None, _("Compensatory leave request not found"))
    except frappe.ValidationError as e:
        frappe.db.rollback()
        return _response(False, None, str(e))
    except Exception:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Compensatory Leave Request: action failed")
        return _response(False, None, _("Something went wrong while processing this action"))
# ---------------------------------------------------------------------------
# 3a. VIEW - employee's own records
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_my_compensatory_leave_requests(
    caller_employee, from_date=None, to_date=None, workflow_state=None, limit=50, start=0
):
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        filters = {"employee": caller_employee}
        if workflow_state:
            filters["workflow_state"] = workflow_state
        if from_date and to_date:
            filters["work_from_date"] = ["between", [getdate(from_date), getdate(to_date)]]
        rows = frappe.get_all(
            DOCTYPE,
            filters=filters,
            fields=[
                "name", "employee", "employee_name", "leave_type", "work_from_date", "work_end_date",
                "half_day", "half_day_date", "reason", "workflow_state", "docstatus",
                "leave_allocation", "creation", "modified",
            ],
            order_by="creation desc",
            limit_page_length=int(limit),
            limit_start=int(start),
        )
        return _response(True, rows, _("Records fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Compensatory Leave Request: get_my failed")
        return _response(False, None, _("Something went wrong while fetching your records"))
# ---------------------------------------------------------------------------
# 3b. VIEW - manager's queue
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_team_compensatory_leave_requests(
    caller_employee, workflow_state=None, employee=None, from_date=None, to_date=None, limit=50, start=0
):
    """HR Manager sees the whole company; anyone else sees only their own
    direct reports (Employee.reports_to)."""
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        filters = omstaff_team_filters(DOCTYPE, caller_employee, employee)
        if workflow_state:
            filters["workflow_state"] = workflow_state
        if from_date and to_date:
            filters["work_from_date"] = ["between", [getdate(from_date), getdate(to_date)]]
        rows = frappe.get_all(
            DOCTYPE,
            filters=filters,
            fields=[
                "name", "employee", "employee_name", "leave_type", "work_from_date", "work_end_date",
                "half_day", "half_day_date", "reason", "workflow_state", "docstatus",
                "leave_allocation", "creation", "modified",
            ],
            order_by="creation desc",
            limit_page_length=int(limit),
            limit_start=int(start),
        )
        return _response(True, rows, _("Records fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Compensatory Leave Request: get_team failed")
        return _response(False, None, _("Something went wrong while fetching team records"))
# ---------------------------------------------------------------------------
# 3c. VIEW - single record by name
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_compensatory_leave_request_details(caller_employee=None):
    """Fetches one Compensatory Leave Request by name. `caller_employee`
    is trusted as the Employee ID of whoever the app has authenticated -
    own record, HR Manager, or the target employee's actual reports_to
    manager may view it."""
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        data = frappe.request.get_json(silent=True) or frappe.form_dict
        name = data.get("name")
        caller_employee = caller_employee or data.get("caller_employee")
        if not caller_employee or not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if not name:
            return _response(False, None, _("Compensatory leave request name is required"))
        if not frappe.db.exists(DOCTYPE, name):
            return _response(False, None, _("Compensatory Leave Request not found"))
        doc = frappe.get_doc(DOCTYPE, name)
        if not _is_authorized_viewer(doc, caller_employee):
            return _response(False, None, _("You are not authorized to view this request"))
        return _response(True, _serialize(doc), _("Record fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Compensatory Leave Request: get_details failed")
        return _response(False, None, _("Something went wrong while fetching this record"))
