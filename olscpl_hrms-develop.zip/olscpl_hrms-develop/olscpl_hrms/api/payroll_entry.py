# olscpl_hrms/api/payroll_entry.py
#
# Payroll Entry "Get Employees", faster (public/js/payroll_entry.js).
# Stock HRMS returns every employee row to the browser, which then saves the
# whole Payroll Entry back - ~7,000 rows took ~15s of server save plus three
# ~4MB round trips, behind a blank "Fetching Employees" freeze. Here the same
# stock selection (PayrollEntry.fill_employee_details) runs on the server and
# the rows are written in bulk, with progress pushed to the browser so it can
# show how many are done. The form then reloads.
import frappe
from frappe import _
from frappe.utils import now

CHUNK = 500
PROGRESS_EVENT = "payroll_entry_fetch_progress"


def _progress(name, done, total, stage):
	frappe.publish_realtime(
		PROGRESS_EVENT,
		{"name": name, "done": done, "total": total, "stage": stage},
		user=frappe.session.user,
		after_commit=False,
	)


@frappe.whitelist()
def fetch_employees(name):
	# the header only - its old employee rows are replaced anyway, no need to load them
	head = frappe.db.get_value("Payroll Entry", name, "*", as_dict=True)
	if not head:
		frappe.throw(_("Payroll Entry {0} not found").format(name), frappe.DoesNotExistError)
	doc = frappe.get_doc({**head, "doctype": "Payroll Entry"})
	doc.check_permission("write")
	if doc.docstatus != 0:
		frappe.throw(_("Employees can only be fetched on a draft Payroll Entry"))

	_progress(name, 0, 0, "finding")
	unmarked = doc.fill_employee_details()  # stock selection + withheld salaries
	rows = doc.employees
	total = len(rows)
	_progress(name, 0, total, "saving")

	frappe.db.delete("Payroll Employee Detail", {"parent": name, "parenttype": "Payroll Entry"})
	ts, user = now(), frappe.session.user
	fields = ["name", "parent", "parenttype", "parentfield", "idx", "docstatus", "owner", "modified_by",
		"creation", "modified", "employee", "employee_name", "department", "designation", "is_salary_withheld"]
	values = [
		(frappe.generate_hash(length=10), name, "Payroll Entry", "employees", i, 0, user, user, ts, ts,
			r.employee, r.employee_name, r.department, r.designation, r.get("is_salary_withheld") or 0)
		for i, r in enumerate(rows, start=1)
	]
	for start in range(0, total, CHUNK):
		frappe.db.bulk_insert("Payroll Employee Detail", fields, values[start:start + CHUNK])
		_progress(name, min(start + CHUNK, total), total, "saving")

	doc.number_of_employees = total
	doc.set_status()
	frappe.db.set_value("Payroll Entry", name, {"number_of_employees": total, "status": doc.status})
	frappe.db.commit()
	_progress(name, total, total, "done")
	return {"count": total, "validate_attendance": doc.get("validate_attendance"), "unmarked": unmarked}


# ── Create Salary Slips: parallel chunks + progress (overrides/payroll_entry.py) ──
# Stock HRMS queues one job that inserts every slip in a single transaction:
# one failing employee rolls the whole run back, and only one worker ever
# does the work. Here the employees are split across as many jobs as there
# are workers on the long queue, each slip is committed on its own (a
# failure skips just that employee and is reported), and get_slip_progress()
# feeds the progress dialog in public/js/payroll_entry.js.
import contextlib
import copy
import json
import os

from frappe.utils import now_datetime

RUN_KEY = "olscpl_payroll_slip_run:{0}"
MAX_JOBS = 8
MIN_CHUNK = 150


def _long_workers():
	try:
		from frappe.utils.background_jobs import get_workers

		return max(1, sum(1 for w in get_workers() if any(q.name.endswith(":long") for q in w.queues)))
	except Exception:
		return 1


def _run_key(name):
	return RUN_KEY.format(name)


def _run(name):
	return frappe.cache().get_value(_run_key(name))


def _save_run(name, run):
	frappe.cache().set_value(_run_key(name), run, expires_in_sec=60 * 60 * 24)


def _done_jobs_incr(name):
	cache = frappe.cache()
	key = cache.make_key(_run_key(name) + ":done_jobs")
	n = cache.incrby(key, 1)
	cache.expire(key, 60 * 60 * 24)
	return n


# Per-process progress for the panel's process chips: Redis hashes keyed by pid,
# through plain redis calls (frappe's wrapper pickles hset/hgetall but not hincrby).
_PROC_HASHES = (":ptotal", ":pdone", ":pend")
from redis import Redis as _Redis


def _proc_reset(key):
	cache = frappe.cache()
	for h in _PROC_HASHES:
		cache.delete(cache.make_key(key + h))


def _proc_start(key, total):
	cache = frappe.cache()
	_Redis.hset(cache, cache.make_key(key + ":ptotal"), os.getpid(), total)
	cache.expire(cache.make_key(key + ":ptotal"), 60 * 60 * 24)


def _proc_tick(key):
	cache = frappe.cache()
	cache.hincrby(cache.make_key(key + ":pdone"), os.getpid(), 1)


def _proc_end(key):
	cache = frappe.cache()
	_Redis.hset(cache, cache.make_key(key + ":pend"), os.getpid(), 1)
	for h in _PROC_HASHES:
		cache.expire(cache.make_key(key + h), 60 * 60 * 24)


def _procs(key):
	"""[{done, total, finished}] per process, in start order."""
	cache = frappe.cache()
	total, done, end = (
		{k.decode(): int(v) for k, v in (_Redis.hgetall(cache, cache.make_key(key + h)) or {}).items()} for h in _PROC_HASHES)
	return [{"done": done.get(pid, 0), "total": t, "finished": pid in end} for pid, t in total.items()]


def start_slip_creation(payroll_entry, employees, args):
	"""Queue the chunk jobs; called from CustomPayrollEntry.create_salary_slips."""
	from hrms.payroll.doctype.payroll_entry.payroll_entry import get_existing_salary_slips

	todo = sorted(set(employees) - set(get_existing_salary_slips(employees, args)))
	workers = _long_workers()
	jobs = max(1, min(MAX_JOBS, workers, (len(todo) + MIN_CHUNK - 1) // MIN_CHUNK)) if todo else 0
	chunks = [todo[i::jobs] for i in range(jobs)] if jobs else []
	name = payroll_entry.name
	run = {"todo": len(todo), "jobs": jobs, "workers": workers, "processes": jobs * _slip_processes(jobs),
		"started": str(now_datetime()), "finished": None}
	cache = frappe.cache()
	_save_run(name, run)
	cache.delete_value(_run_key(name) + ":failed")
	cache.delete(cache.make_key(_run_key(name) + ":done_jobs"))
	cache.delete_value(_run_key(name) + ":stop")
	_proc_reset(_run_key(name))
	payroll_entry.db_set({"status": "Queued", "error_message": ""})
	if not jobs:
		_finish(name)
		return
	for i, chunk in enumerate(chunks):
		frappe.enqueue(
			"olscpl_hrms.api.payroll_entry.create_slips_chunk",
			queue="long",
			timeout=4 * 60 * 60,
			job_id=f"payroll_slips::{name}::{i}",
			deduplicate=True,
			enqueue_after_commit=True,
			payroll_entry=name,
			employees=chunk,
			args=args,
		)


def _slip_processes(jobs=1):
	"""Parallel processes per chunk job - site_config "payroll_slip_processes",
	default 8, but leaving 2 CPUs for the web server and other jobs. That total
	is shared by the chunk jobs running at once (one per long-queue worker),
	so more workers don't overload the CPU."""
	import os

	cpus = os.cpu_count() or 2
	n = frappe.utils.cint(frappe.conf.get("payroll_slip_processes") or 8)
	return max(1, min(n, max(1, cpus - 2), 16) // max(1, jobs))


# Setup data that cannot change during a run: identical lookups of these are
# answered from memory after the first time (keyed by the full call).
_STATIC_DOCTYPES = {
	"Salary Component", "Company", "Letter Head", "Income Tax Slab", "ESI Rule", "Bonus Payable",
	"Leave Type", "Workflow Document State", "Department Approver", "Transaction Deletion Record",
	"Property Setter", "Payroll Period", "Holiday List", "Salary Structure",
}
BATCH = 25


@contextlib.contextmanager
def _bulk_mode():
	"""Memoise static lookups, take shared naming numbers without holding the
	lock, and skip approver sharing of the auto-created leaves."""
	db = frappe.db
	orig_get_value, orig_get_all = db.get_value, frappe.get_all
	memo = {}

	def get_value(doctype, *a, **k):
		if doctype not in _STATIC_DOCTYPES or k.get("for_update"):
			return orig_get_value(doctype, *a, **k)
		key = ("v", doctype, repr(a), repr(sorted(k.items())))
		if key not in memo:
			memo[key] = orig_get_value(doctype, *a, **k)
		return copy.deepcopy(memo[key])

	def get_all(doctype, *a, **k):
		if doctype not in _STATIC_DOCTYPES:
			return orig_get_all(doctype, *a, **k)
		key = ("a", doctype, repr(a), repr(sorted(k.items())))
		if key not in memo:
			memo[key] = orig_get_all(doctype, *a, **k)
		return copy.deepcopy(memo[key])

	# Shared naming counters (Leave Application HR-LAP-, Attendance HR-ATT- from
	# the auto leave conversion) would stay row-locked until the slip commits,
	# so the parallel processes queue on them. They are incremented on a second
	# connection that commits at once, and a deleted document does not give its
	# number back (leaving a gap) - the lock lasts milliseconds.
	from frappe.model import delete_doc as delete_doc_module
	from frappe.model import naming

	orig_getseries = naming.getseries
	orig_revert = naming.revert_series_if_last
	orig_revert_dd = delete_doc_module.revert_series_if_last
	counter_db = []

	def getseries(key, digits, *a, **k):
		if str(key).startswith("Sal Slip/"):  # per-employee counter, never contended
			return orig_getseries(key, digits, *a, **k)
		if not counter_db:
			from frappe.database import get_db

			c = frappe.local.conf
			conn = get_db(socket=c.db_socket, host=c.db_host, port=c.db_port, user=c.db_name,
				password=c.db_password, cur_db_name=c.db_name)
			conn.connect()
			counter_db.append(conn)
		conn = counter_db[0]
		row = conn.sql("SELECT `current` FROM `tabSeries` WHERE `name`=%s FOR UPDATE", (key,))
		if row and row[0][0] is not None:
			current = frappe.utils.cint(row[0][0]) + 1
			conn.sql("UPDATE `tabSeries` SET `current` = %s WHERE `name`=%s", (current, key))
		else:
			current = 1
			conn.sql("INSERT INTO `tabSeries` (`name`, `current`) VALUES (%s, 1)", (key,))
		conn.commit()
		return ("%0" + str(digits) + "d") % current

	def no_revert(*a, **k):
		return None

	db.get_value, frappe.get_all = get_value, get_all
	naming.getseries = getseries
	naming.revert_series_if_last = delete_doc_module.revert_series_if_last = no_revert
	frappe.flags.skip_reporting_share = True
	try:
		yield
	finally:
		db.get_value, frappe.get_all = orig_get_value, orig_get_all
		naming.getseries, naming.revert_series_if_last, delete_doc_module.revert_series_if_last = orig_getseries, orig_revert, orig_revert_dd
		frappe.flags.skip_reporting_share = False
		for conn in counter_db:
			conn.close()


def _make_slips(payroll_entry, employees, args):
	"""Create the slips, committing every BATCH; a failing employee is rolled
	back to its own savepoint and reported, the rest of the batch is kept."""
	key = _run_key(payroll_entry)
	_proc_start(key, len(employees))
	with _bulk_mode():
		for i, emp in enumerate(employees, start=1):
			if i % 5 == 1 and frappe.cache().get_value(key + ":stop"):
				break  # Stop clicked on the progress panel
			sp = f"slip_{i}"
			frappe.db.savepoint(sp)
			try:
				frappe.get_doc({**args, "doctype": "Salary Slip", "employee": emp}).insert()
			except Exception as e:
				frappe.db.rollback(save_point=sp)
				msg = frappe.utils.strip_html(str(e))[:300] or type(e).__name__
				frappe.cache().rpush(key + ":failed", json.dumps({"employee": emp, "error": msg}))
				frappe.message_log = []
			_proc_tick(key)
			if i % BATCH == 0:
				frappe.db.commit()  # nosemgrep
		frappe.db.commit()  # nosemgrep
	_proc_end(key)


def _process_main(site, sites_path, user, payroll_entry, employees, args):
	"""Entry point of a spawned process: its own Frappe context and DB connection."""
	frappe.init(site=site, sites_path=sites_path)
	frappe.connect()
	try:
		frappe.set_user(user)
		_make_slips(payroll_entry, employees, frappe._dict(args))
	finally:
		frappe.destroy()


def create_slips_chunk(payroll_entry, employees, args):
	"""One queued job: its employees split across several processes (one slip
	at a time is ~0.6s, mostly waiting on the database - processes overlap that)."""
	import multiprocessing
	import os

	args = dict(args)
	procs = min(_slip_processes((_run(payroll_entry) or {}).get("jobs") or 1), max(1, len(employees) // 20))
	if procs <= 1:
		_make_slips(payroll_entry, employees, frappe._dict(args))
	else:
		site, sites_path = frappe.local.site, os.path.abspath(frappe.local.sites_path)
		ctx = multiprocessing.get_context("spawn")
		workers = [
			ctx.Process(target=_process_main, args=(site, sites_path, frappe.session.user, payroll_entry, employees[i::procs], args))
			for i in range(procs)
		]
		for w in workers:
			w.start()
		for w in workers:
			w.join()
		frappe.db.rollback()  # fresh snapshot - the processes committed their slips on other connections
	run = _run(payroll_entry) or {}
	if _done_jobs_incr(payroll_entry) >= (run.get("jobs") or 1):
		_finish(payroll_entry)


def _failures(name):
	return [json.loads(x) for x in frappe.cache().lrange(_run_key(name) + ":failed", 0, -1) or []]


def _finish(name):
	failed = _failures(name)
	pe = frappe.get_doc("Payroll Entry", name)
	stopped_by = frappe.cache().get_value(_run_key(name) + ":stop")
	if stopped_by:
		made = frappe.db.count("Salary Slip", {"payroll_entry": name, "docstatus": ["<", 2]})
		pe.db_set({"status": "Failed", "salary_slips_created": 0,
			"error_message": _("Stopped by {0} after {1} salary slip(s) were created. Cancel this Payroll Entry, "
				"or click Create Salary Slips to continue with the remaining employees.").format(stopped_by, made)})
	elif failed:
		lines = "\n".join(f"{f['employee']}: {f['error']}" for f in failed[:200])
		pe.db_set({"status": "Failed", "salary_slips_created": 0,
			"error_message": _("{0} salary slip(s) could not be created - fix and click Create Salary Slips "
				"again to retry only these:").format(len(failed)) + "\n" + lines})
	else:
		pe.db_set({"status": "Submitted", "salary_slips_created": 1, "error_message": ""})
	run = _run(name) or {}
	run["finished"] = str(now_datetime())
	_save_run(name, run)
	frappe.db.commit()  # nosemgrep
	frappe.publish_realtime("completed_salary_slip_creation", {"name": name})


@frappe.whitelist()
def get_slip_progress(name):
	frappe.has_permission("Payroll Entry", "read", name, throw=True)
	pe = frappe.db.get_value("Payroll Entry", name,
		["status", "number_of_employees", "salary_slips_created", "salary_slips_submitted"], as_dict=True)
	sub = submit_progress(name, pe)
	if sub:
		return sub
	created = frappe.db.count("Salary Slip", {"payroll_entry": name, "docstatus": ["<", 2]})
	failed = _failures(name)
	run = _run(name) or {}
	if not run and created:
		# cache emptied (bench restart / clear-cache): time the run from the slips themselves
		run["started"], run["finished"] = frappe.db.sql(
			"select min(creation), max(creation) from `tabSalary Slip` where payroll_entry = %s", name)[0]
	return {
		"status": pe.status,
		"total": pe.number_of_employees or frappe.db.count("Payroll Employee Detail", {"parent": name}),
		"created": created,
		"failed_count": len(failed),
		"failed": failed[-50:],
		"jobs": run.get("processes") or run.get("jobs"),
		"procs": _procs(_run_key(name)),
		"workers": run.get("workers"),
		"started": run.get("started"),
		"finished": run.get("finished"),
		"done": pe.status != "Queued",
	}


def _jobs_alive(name):
	"""Any of this run's chunk jobs still queued or running."""
	try:
		from frappe.utils.background_jobs import get_queue

		q = get_queue("long")
		ids = set(q.job_ids) | set(q.started_job_registry.get_job_ids())
		return any(f"payroll_slips::{name}::" in i or i == f"payroll_submit::{name}" for i in ids)
	except Exception:
		return False


@frappe.whitelist()
def stop_slip_creation(name):
	"""Progress panel "Stop": running jobs stop after their current slip and
	_finish() marks the entry Failed (so it can be cancelled or resumed). If no
	job is alive (e.g. the worker died) the entry is released at once."""
	frappe.has_permission("Payroll Entry", "write", name, throw=True)
	status, docstatus = frappe.db.get_value("Payroll Entry", name, ["status", "docstatus"])
	if docstatus != 1 or status != "Queued":
		return {"stopped": True}
	submitting = (_submit_run(name) or {}).get("phase") not in (None, "done")
	key = SUBMIT_KEY.format(name) if submitting else _run_key(name)
	frappe.cache().set_value(key + ":stop", frappe.session.user, expires_in_sec=60 * 60 * 24)
	if not _jobs_alive(name):
		if submitting:
			frappe.db.set_value("Payroll Entry", name, {"status": "Failed", "error_message": _(
				"Stopped by {0}. Click Submit Salary Slip to continue.").format(frappe.session.user)})
			_set_phase(name, "done", finished=str(now_datetime()))
		else:
			_finish(name)
		return {"stopped": True}
	return {"stopped": False}


# ── Submit Salary Slip: parallel + progress (overrides/payroll_entry.submit_salary_slips) ──
# Stock submits every slip one by one in one job (~0.22s each), then makes the
# accrual Journal Entry, then emails each slip (~1.2s each - a PDF is
# rendered); for ~7,000 slips that is hours, past the stock 50-minute job
# timeout. Same steps here: each slip still goes through the stock submit(),
# by several processes; then the one accrual Journal Entry; then the stock
# email per slip, again by several processes. Slips with negative net pay are
# skipped, as stock does.
SUBMIT_KEY = "olscpl_payroll_submit_run:{0}"


def _submit_run(name):
	return frappe.cache().get_value(SUBMIT_KEY.format(name))


def _save_submit_run(name, run):
	frappe.cache().set_value(SUBMIT_KEY.format(name), run, expires_in_sec=60 * 60 * 24)


def _submit_failures(name):
	return [json.loads(x) for x in frappe.cache().lrange(SUBMIT_KEY.format(name) + ":failed", 0, -1) or []]


def _unaccounted_slips(name):
	"""Submitted slips of this entry still without their accrual Journal Entry."""
	return frappe.get_all("Salary Slip", pluck="name", filters={
		"payroll_entry": name, "docstatus": 1, "journal_entry": ["in", ["", None]]})


def start_slip_submission(payroll_entry, slips):
	"""Queue the submit job; called from CustomPayrollEntry.submit_salary_slips."""
	name = payroll_entry.name
	cache = frappe.cache()
	_save_submit_run(name, {
		"phase": "submit", "total": len(slips), "processes": _slip_processes(), "started": str(now_datetime()),
		"finished": None, "base": frappe.db.count("Salary Slip", {"payroll_entry": name, "docstatus": 1}),
	})
	for suffix in (":failed", ":stop"):
		cache.delete_value(SUBMIT_KEY.format(name) + suffix)
	cache.delete(cache.make_key(SUBMIT_KEY.format(name) + ":emailed"))
	_proc_reset(SUBMIT_KEY.format(name))
	payroll_entry.db_set({"status": "Queued", "error_message": ""})
	frappe.enqueue(
		"olscpl_hrms.api.payroll_entry.submit_slips_job",
		queue="long",
		timeout=6 * 60 * 60,
		job_id=f"payroll_submit::{name}",
		deduplicate=True,
		enqueue_after_commit=True,
		payroll_entry=name,
		slips=slips,
	)


def _submit_slips(payroll_entry, names):
	"""Stock submit per slip, committing every BATCH; failures are reported."""
	key = SUBMIT_KEY.format(payroll_entry)
	frappe.flags.via_payroll_entry = True  # stock: no per-slip email here, sent after the Journal Entry
	_proc_start(key, len(names))
	with _bulk_mode():
		for i, name in enumerate(names, start=1):
			if i % 5 == 1 and frappe.cache().get_value(key + ":stop"):
				break
			_proc_tick(key)
			slip = frappe.get_doc("Salary Slip", name)
			if slip.docstatus != 0:
				continue
			if slip.net_pay < 0:  # stock leaves these unsubmitted
				frappe.cache().rpush(key + ":failed", json.dumps({"employee": slip.employee, "slip": name,
					"error": _("Net pay is negative ({0}) - not submitted").format(slip.net_pay)}))
				continue
			frappe.db.savepoint(f"sub_{i}")
			try:
				slip.submit()
			except Exception as e:
				frappe.db.rollback(save_point=f"sub_{i}")
				frappe.cache().rpush(key + ":failed", json.dumps({"employee": slip.employee, "slip": name,
					"error": frappe.utils.strip_html(str(e))[:300] or type(e).__name__}))
				frappe.message_log = []
			if i % BATCH == 0:
				frappe.db.commit()  # nosemgrep
		frappe.db.commit()  # nosemgrep
	_proc_end(key)


def _email_slips(payroll_entry, names):
	"""Stock email per slip (renders its PDF); a failure is reported, not fatal."""
	cache = frappe.cache()
	key = SUBMIT_KEY.format(payroll_entry)
	counter = cache.make_key(key + ":emailed")
	_proc_start(key, len(names))
	for i, name in enumerate(names, start=1):
		try:
			frappe.get_doc("Salary Slip", name).email_salary_slip()
		except Exception as e:
			cache.rpush(key + ":failed", json.dumps({"slip": name, "employee": frappe.db.get_value("Salary Slip", name, "employee"),
				"error": _("Email not sent: {0}").format(frappe.utils.strip_html(str(e))[:250] or type(e).__name__)}))
			frappe.message_log = []
		cache.incrby(counter, 1)
		_proc_tick(key)
		if i % BATCH == 0:
			frappe.db.commit()  # nosemgrep
	cache.expire(counter, 60 * 60 * 24)
	frappe.db.commit()  # nosemgrep
	_proc_end(key)


def _submit_process_main(site, sites_path, user, payroll_entry, names, step):
	frappe.init(site=site, sites_path=sites_path)
	frappe.connect()
	try:
		frappe.set_user(user)
		(_submit_slips if step == "submit" else _email_slips)(payroll_entry, names)
	finally:
		frappe.destroy()


def _in_processes(payroll_entry, names, step):
	import multiprocessing
	import os

	procs = min(_slip_processes(), max(1, len(names) // 20))
	if procs <= 1:
		(_submit_slips if step == "submit" else _email_slips)(payroll_entry, names)
		return
	site, sites_path = frappe.local.site, os.path.abspath(frappe.local.sites_path)
	ctx = multiprocessing.get_context("spawn")
	workers = [
		ctx.Process(target=_submit_process_main, args=(site, sites_path, frappe.session.user, payroll_entry, names[i::procs], step))
		for i in range(procs)
	]
	for w in workers:
		w.start()
	for w in workers:
		w.join()
	frappe.db.rollback()  # fresh snapshot - the processes committed on other connections


def _set_phase(name, phase, **extra):
	run = _submit_run(name) or {}
	run.update(phase=phase, **extra)
	_save_submit_run(name, run)


def submit_slips_job(payroll_entry, slips):
	"""The queued job: submit (parallel) -> accrual Journal Entry -> emails (parallel)."""
	name = payroll_entry
	if slips:
		_in_processes(name, slips, "submit")
	stopped_by = frappe.cache().get_value(SUBMIT_KEY.format(name) + ":stop")
	pe = frappe.get_doc("Payroll Entry", name)
	submitted = _unaccounted_slips(name)
	if submitted:
		_set_phase(name, "accounts")
		try:
			pe.make_accrual_jv_entry([frappe._dict(name=n) for n in submitted])
			frappe.db.commit()  # nosemgrep
		except Exception as e:
			frappe.db.rollback()
			pe.db_set({"status": "Failed", "error_message": _(
				"{0} salary slip(s) were submitted, but the accrual Journal Entry could not be made: {1}\n"
				"Fix it and click Submit Salary Slip again - only the Journal Entry and emails are left.").format(
				len(submitted), frappe.utils.strip_html(str(e))[:500])})
			_set_phase(name, "accounts", finished=str(now_datetime()))
			frappe.db.commit()  # nosemgrep
			frappe.publish_realtime("completed_salary_slip_submission", user=frappe.session.user)
			return
		if frappe.db.get_single_value("Payroll Settings", "email_salary_slip_to_employee"):
			_set_phase(name, "email", email_total=len(submitted))
			_proc_reset(SUBMIT_KEY.format(name))  # the chips now follow the email processes
			_in_processes(name, submitted, "email")

	failed = _submit_failures(name)
	lines = "\n".join(f"{f.get('employee') or ''} {f.get('slip') or ''}: {f['error']}" for f in failed[:200])
	if stopped_by:
		pe.db_set({"status": "Failed", "salary_slips_submitted": 0, "error_message": _(
			"Stopped by {0} after {1} salary slip(s) were submitted (Journal Entry and emails done for those). "
			"Click Submit Salary Slip to continue with the rest.").format(stopped_by, len(submitted)) + ("\n" + lines if lines else "")})
	elif submitted or not failed:
		# stock: Submitted once anything went through; the ones left unsubmitted are listed
		pe.db_set({"salary_slips_submitted": 1, "status": "Submitted", "error_message": _(
			"{0} salary slip(s) were not submitted or emailed:").format(len(failed)) + "\n" + lines if failed else ""})
	else:
		pe.db_set({"status": "Failed", "error_message": _("No salary slip could be submitted:") + "\n" + lines})
	_set_phase(name, "done", finished=str(now_datetime()))
	frappe.db.commit()  # nosemgrep
	frappe.publish_realtime("completed_salary_slip_submission", user=frappe.session.user)


def submit_progress(name, pe):
	"""get_slip_progress() while/after Submit Salary Slip ran; None if it never did."""
	run = _submit_run(name)
	if not run and not pe.salary_slips_submitted:
		return None
	submitted_now = frappe.db.count("Salary Slip", {"payroll_entry": name, "docstatus": 1})
	failed = _submit_failures(name)
	if not run:  # cache emptied (bench restart / clear-cache): rebuilt from the slips
		run = {"phase": "done", "base": 0, "total": frappe.db.count("Salary Slip", {"payroll_entry": name, "docstatus": ["<", 2]})}
		run["started"], run["finished"] = frappe.db.sql(
			"select min(modified), max(modified) from `tabSalary Slip` where payroll_entry = %s and docstatus = 1", name)[0]
	cache = frappe.cache()
	return {
		"mode": "submit",
		"phase": run.get("phase"),
		"status": pe.status,
		"total": run.get("total") or 0,
		"created": max(0, submitted_now - (run.get("base") or 0)),
		"failed_count": len(failed),
		"failed": failed[-50:],
		"emailed": frappe.utils.cint(cache.get(cache.make_key(SUBMIT_KEY.format(name) + ":emailed"))),
		"email_total": run.get("email_total") or 0,
		"jobs": run.get("processes"),
		"procs": _procs(SUBMIT_KEY.format(name)),
		"started": run.get("started"),
		"finished": run.get("finished"),
		"done": pe.status != "Queued",
	}


# ── Cancel progress (overrides/payroll_entry.CustomPayrollEntry.cancel) ──
# Cancelling stays stock (each slip cancelled/deleted with delete_doc); this
# only reports how far it is for the panel in public/js/payroll_entry.js.
CANCEL_KEY = "olscpl_payroll_cancel:{0}"


def note_cancel_start(name, total):
	cache = frappe.cache()
	cache.set_value(CANCEL_KEY.format(name), {"total": total, "started": str(now_datetime())},
		expires_in_sec=60 * 60 * 24)
	cache.delete(cache.make_key(CANCEL_KEY.format(name) + ":removed"))


def count_cancelled_slip(doc, method=None):
	"""Salary Slip on_trash: the stock cancel deletes slips inside one long
	transaction, so the count is kept in the cache (visible right away)."""
	if not doc.payroll_entry:
		return
	cache = frappe.cache()
	if cache.get_value(CANCEL_KEY.format(doc.payroll_entry)):
		key = cache.make_key(CANCEL_KEY.format(doc.payroll_entry) + ":removed")
		cache.incrby(key, 1)
		cache.expire(key, 60 * 60 * 24)


@frappe.whitelist()
def get_cancel_progress(name):
	frappe.has_permission("Payroll Entry", "read", name, throw=True)
	doc = frappe.get_doc("Payroll Entry", name)
	info = frappe.cache().get_value(CANCEL_KEY.format(name)) or {}
	cache = frappe.cache()
	counted = frappe.utils.cint(cache.get(cache.make_key(CANCEL_KEY.format(name) + ":removed")))
	total = info.get("total") or frappe.db.count("Salary Slip", {"payroll_entry": name})
	removed = total if doc.docstatus == 2 else min(total, counted)
	return {
		"running": bool(doc.is_locked) and doc.docstatus == 1,
		"cancelled": doc.docstatus == 2,
		"total": total,
		"removed": removed,
		"remaining": max(0, total - removed),
		"started": info.get("started"),
		"tracked": bool(info),
	}


# ── Faster cancel, same steps (overrides/payroll_entry.delete_linked_salary_slips) ──
# Each draft slip is still removed with the stock frappe.delete_doc (link
# checks, on_trash, Deleted Document, feed, attachments...) - just by several
# processes at once. delete_doc queues one "delete_dynamic_links" job per slip;
# those calls are collected and run in a single job instead (same function,
# every slip), so thousands of tiny jobs don't block the worker.
DELETE_BATCH = 25


def _delete_slips(names):
	"""Stock delete_doc for each slip; returns [(name, error)] for failures."""
	collected, failed = [], []
	orig_enqueue = frappe.enqueue

	def enqueue(method, *a, **k):
		if method == "frappe.model.delete_doc.delete_dynamic_links":
			collected.append(k.get("name"))
			return None
		return orig_enqueue(method, *a, **k)

	frappe.enqueue = enqueue
	try:
		for i, name in enumerate(names, start=1):
			frappe.db.savepoint(f"del_{i}")
			try:
				frappe.delete_doc("Salary Slip", name)
			except Exception as e:
				frappe.db.rollback(save_point=f"del_{i}")
				collected_name = name
				if collected and collected[-1] == collected_name:
					collected.pop()
				failed.append((name, frappe.utils.strip_html(str(e))[:300] or type(e).__name__))
				frappe.message_log = []
			if i % DELETE_BATCH == 0:
				frappe.db.commit()  # nosemgrep
		frappe.db.commit()  # nosemgrep
	finally:
		frappe.enqueue = orig_enqueue
	if collected:
		frappe.enqueue("olscpl_hrms.api.payroll_entry.delete_dynamic_links_bulk", queue="long", timeout=4 * 60 * 60,
			doctype="Salary Slip", names=collected)
	return failed


def delete_dynamic_links_bulk(doctype, names):
	"""The stock per-document cleanup, for every slip in one job."""
	from frappe.model.delete_doc import delete_dynamic_links

	for i, name in enumerate(names, start=1):
		delete_dynamic_links(doctype, name)
		if i % 100 == 0:
			frappe.db.commit()  # nosemgrep
	frappe.db.commit()  # nosemgrep


def _delete_process_main(site, sites_path, user, names, key):
	frappe.init(site=site, sites_path=sites_path)
	frappe.connect()
	try:
		frappe.set_user(user)
		for name, error in _delete_slips(names):
			frappe.cache().rpush(key, json.dumps({"slip": name, "error": error}))
	finally:
		frappe.destroy()


def delete_draft_slips_parallel(payroll_entry, names):
	"""Delete the draft slips with several processes; returns the failures."""
	import multiprocessing
	import os

	key = CANCEL_KEY.format(payroll_entry) + ":failed"
	frappe.cache().delete_value(key)
	procs = min(_slip_processes(), max(1, len(names) // 50))
	if procs <= 1:
		return [{"slip": n, "error": e} for n, e in _delete_slips(names)]
	# the slip processes read the Payroll Entry while this job holds its cancel
	# open - commit nothing here; they only touch Salary Slip rows
	site, sites_path = frappe.local.site, os.path.abspath(frappe.local.sites_path)
	ctx = multiprocessing.get_context("spawn")
	workers = [
		ctx.Process(target=_delete_process_main, args=(site, sites_path, frappe.session.user, names[i::procs], key))
		for i in range(procs)
	]
	for w in workers:
		w.start()
	for w in workers:
		w.join()
	return [json.loads(x) for x in frappe.cache().lrange(key, 0, -1) or []]
