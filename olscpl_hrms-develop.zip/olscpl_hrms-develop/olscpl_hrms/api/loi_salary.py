import json
import frappe
from olscpl_hrms.utils.payroll_changeable_component_utils import get_component_value
from olscpl_hrms.utils.payroll_constants import (
    ONE_TIME_COMPONENTS,
    BASE_BASIC_RATE,
    BASE_HRA_RATE,
    EMPLOYEE_PF_RATE_DEFAULT,
    EMPLOYER_PF_RATE_DEFAULT,
    is_manual_salary_structure,
    is_base_salary_structure,
    calc_gratuity,
    calc_leave_encashment,
    is_no_deduction_employment_type,
)

# ─────────────────────────────────────────────
# SAFE ARITHMETIC PARSER (supports multi ops)
# ─────────────────────────────────────────────
def parse_arith(expr):
    try:
        expr = str(expr).strip()

        while expr.lower().startswith('round(') and expr.endswith(')'):
            inner = expr[6:-1].strip()
            comma_idx = inner.rfind(',')
            if comma_idx > 0:
                val_expr   = inner[:comma_idx].strip()
                places_str = inner[comma_idx + 1:].strip()
                try:
                    places = int(float(places_str))
                    return round(parse_arith(val_expr), places)
                except Exception:
                    pass
            return round(parse_arith(inner))

        while expr.startswith('(') and expr.endswith(')'):
            inner_check = expr[1:-1]
            depth = 0
            valid = True
            for ch in inner_check:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                if depth < 0:
                    valid = False
                    break
            if valid and depth == 0:
                expr = inner_check.strip()
            else:
                break

        while '(' in expr:
            start = -1
            end = -1
            for i, ch in enumerate(expr):
                if ch == '(':
                    start = i
                elif ch == ')':
                    end = i
                    break
            if start == -1 or end == -1:
                break
            inner_val = parse_arith(expr[start + 1:end])
            expr = expr[:start] + str(inner_val) + expr[end + 1:]
            expr = expr.strip()

        tokens = []
        num = ""

        for ch in str(expr):
            if ch in "+-*/":
                if num:
                    tokens.append(float(num))
                    num = ""
                tokens.append(ch)
            else:
                num += ch

        if num:
            tokens.append(float(num))

        i = 0
        while i < len(tokens):
            if tokens[i] == '*':
                tokens[i - 1] = tokens[i - 1] * tokens[i + 1]
                del tokens[i:i + 2]
                i -= 1
            elif tokens[i] == '/':
                tokens[i - 1] = tokens[i - 1] / tokens[i + 1] if tokens[i + 1] != 0 else 0
                del tokens[i:i + 2]
                i -= 1
            i += 1

        result = tokens[0]
        i = 1
        while i < len(tokens):
            if tokens[i] == '+':
                result += tokens[i + 1]
            elif tokens[i] == '-':
                result -= tokens[i + 1]
            i += 2

        return result

    except Exception:
        return 0.0


# ─────────────────────────────────────────────
# custom_state if/else parser
# ─────────────────────────────────────────────
def resolve_custom_state(f, custom_state):
    while 'custom_state' in f:
        if_marker = ' if custom_state == '
        else_marker = ' else '

        if_idx = f.find(if_marker)
        if if_idx == -1:
            break

        true_expr = f[:if_idx].strip()
        rest = f[if_idx + len(if_marker):]

        quote_char = None
        if rest.startswith('"'):
            quote_char = '"'
        elif rest.startswith("'"):
            quote_char = "'"
        else:
            break

        close_quote = rest.find(quote_char, 1)
        if close_quote == -1:
            break

        state_val = rest[1:close_quote]
        after_quote = rest[close_quote + 1:].strip()

        if not after_quote.startswith(else_marker.strip()):
            break

        false_expr = after_quote[len(else_marker.strip()):].strip()
        f = true_expr if custom_state == state_val else false_expr

    return f


# ─────────────────────────────────────────────
# FORMULA EVALUATOR
# ─────────────────────────────────────────────
def eval_formula(formula_str, base_val, gross_val, comp_map, custom_state=''):
    f = str(formula_str).strip()

    if 'custom_state' in f:
        f = resolve_custom_state(f, custom_state)

    f = f.replace(' or 0', '')
    f = f.replace('gross_pay', str(float(gross_val)))
    f = f.replace('base', str(float(base_val)))
    f = f.replace('gross', str(float(gross_val)))

    for key, val in sorted(comp_map.items(), key=lambda x: -len(x[0])):
        f = f.replace(key, str(float(val)))
        f = f.replace(key.lower(), str(float(val)))

    f = f.strip()

    if f.startswith('(') and ' if ' in f and ' else ' in f:
        depth = 0
        close_at = -1
        for i, ch in enumerate(f):
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    close_at = i
                    break

        if close_at > 0 and close_at < len(f) - 1:
            inner_expr = f[1:close_at]
            trailing_expr = f[close_at + 1:].strip()

            if trailing_expr and trailing_expr[0] in '+-*/':
                inner_val = eval_formula(inner_expr, base_val, gross_val, comp_map, custom_state)
                combined = str(inner_val) + ' ' + trailing_expr
                return parse_arith(combined)

    while f.startswith('(') and f.endswith(')'):
        inner_check = f[1:-1]
        depth = 0
        valid = True
        for ch in inner_check:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            if depth < 0:
                valid = False
                break
        if valid and depth == 0:
            f = inner_check.strip()
        else:
            break

    if ' if ' in f and ' else ' in f:
        if_idx = f.find(' if ')
        else_idx = f.find(' else ', if_idx)

        true_expr = f[:if_idx].strip()
        cond_str = f[if_idx + 4:else_idx].strip()
        false_expr = f[else_idx + 6:].strip()

        if false_expr.startswith('(') and false_expr.endswith(')'):
            false_expr = false_expr[1:-1].strip()

        cond_result = False

        for op in ['<=', '>=', '!=', '<', '>', '==']:
            if op in cond_str:
                idx = cond_str.find(op)
                lhs = cond_str[:idx].strip().strip('()')
                rhs = cond_str[idx + len(op):].strip().strip('()')
                try:
                    lv = parse_arith(lhs)
                    rv = parse_arith(rhs)
                    if op == '<=':
                        cond_result = lv <= rv
                    elif op == '>=':
                        cond_result = lv >= rv
                    elif op == '<':
                        cond_result = lv < rv
                    elif op == '>':
                        cond_result = lv > rv
                    elif op == '==':
                        cond_result = lv == rv
                    elif op == '!=':
                        cond_result = lv != rv
                except Exception:
                    pass
                break

        chosen = true_expr if cond_result else false_expr

        if ' if ' in chosen and ' else ' in chosen:
            return eval_formula(chosen, base_val, gross_val, comp_map, custom_state)

        chosen = chosen.strip()
        while chosen.startswith('(') and chosen.endswith(')'):
            inner_check = chosen[1:-1]
            depth = 0
            valid = True
            for ch in inner_check:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                if depth < 0:
                    valid = False
                    break
            if valid and depth == 0:
                chosen = inner_check.strip()
            else:
                break

        f = chosen

    fl = f.lower()
    if (fl.startswith('min(') or fl.startswith('max(')) and f.endswith(')'):
        is_min = fl.startswith('min(')
        inner = f[4:-1]
        depth = 0
        comma = -1
        for ci, ch in enumerate(inner):
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 0:
                comma = ci
                break
        if comma > 0:
            try:
                v1 = eval_formula(inner[:comma].strip(), base_val, gross_val, comp_map, custom_state)
                v2 = eval_formula(inner[comma + 1:].strip(), base_val, gross_val, comp_map, custom_state)
                return min(v1, v2) if is_min else max(v1, v2)
            except Exception:
                return 0.0

    return parse_arith(f)


# ─────────────────────────────────────────────
# ★ DYNAMIC ESI CALCULATION HELPER
# ─────────────────────────────────────────────
def calculate_esi_for_annexure(employee_name, monthly_gross, esic_wage):

    result = {"employee_esi": 0, "employer_esi": 0}

    esi_rule = frappe.db.get_value(
        "ESI Rule",
        {"is_active": 1},
        ["wage_limit", "employee_rate", "employer_rate"],
        as_dict=True
    )

    if not esi_rule:
        return result

    wage_limit = float(esi_rule.wage_limit or 21000)
    employee_rate = float(esi_rule.employee_rate or 0.75)
    employer_rate = float(esi_rule.employer_rate or 3.25)

    today = frappe.utils.getdate(frappe.utils.today())
    today_str = str(today)

    coverage = frappe.db.get_value(
        "Employee ESI Coverage",
        {
            "employee": employee_name,
            "period_start": ["<=", today_str],
            "period_end": [">=", today_str],
            "is_active": 1
        },
        ["name", "esi_eligible"],
        as_dict=True
    )

    eligible = 0

    if coverage:
        eligible = int(coverage.esi_eligible or 0)
    else:
        if monthly_gross <= wage_limit:
            eligible = 1

    if eligible:
        raw_emp = esic_wage * (employee_rate / 100)
        employee_esi = int(raw_emp)
        if raw_emp > employee_esi:
            employee_esi += 1

        raw_emp_er = esic_wage * (employer_rate / 100)
        employer_esi = int(raw_emp_er)
        if raw_emp_er > employer_esi:
            employer_esi += 1

        result["employee_esi"] = employee_esi
        result["employer_esi"] = employer_esi

    return result


# ─────────────────────────────────────────────
# ★ DYNAMIC BONUS PAYABLE % HELPER (company-based)
# ─────────────────────────────────────────────
def get_bonus_payable_percentage(company):
    """
    Fetches the Bonus Payable Percentage for the given company from the
    'Bonus Payable' doctype. Falls back to the most recently created
    Bonus Payable record if no company-specific record exists, and
    finally to 20% if nothing is configured at all.
    Returns the percentage as a plain number (e.g. 20 for 20%), or None
    if no 'Bonus Payable' record exists anywhere in the system.
    """
    percentage_value = None

    if company:
        percentage_value = frappe.db.get_value(
            "Bonus Payable",
            {"company": company},
            "bonus_payable_percentage"
        )

    if percentage_value is None:
        fallback = frappe.get_all(
            "Bonus Payable",
            fields=["bonus_payable_percentage"],
            order_by="creation desc",
            limit=1
        )
        percentage_value = fallback[0].get("bonus_payable_percentage") if fallback else None

    return float(percentage_value) if percentage_value is not None else None


def get_bonus_ceiling_amount(as_on_date=None):
    """
    Fetches the effective-dated Bonus Ceiling Amount from
    'Payroll Changeable Component' (current value or audit trail,
    whichever was in force on as_on_date). Defaults to today if no
    date is given. Returns None only if genuinely nothing is configured.
    """
    as_on_date = as_on_date or frappe.utils.today()
    value = get_component_value("Bonus Ceiling Amount", as_on_date)
    return float(value) if value not in (None, '') else None


@frappe.whitelist()
def get_bonus_config(company=None, salary_structure=None, date_of_joining=None):
    """
    Lightweight endpoint the client calls to pull the current, real
    Bonus Ceiling Amount and Bonus Payable Percentage straight from the
    doctypes — with NO hardcoded fallback values. If a value genuinely
    isn't configured yet in Frappe, this returns None for it, and the
    client is expected to hold off on calculating Ex-Gratia rather than
    substitute a made-up number.

    `company` (Job Offer's own company field) takes priority; if not
    supplied, falls back to the company on the given Salary Structure.

    `date_of_joining` is the "as of" date for the effective-dated Bonus
    Ceiling lookup. Callers with no real date-of-joining field (e.g. Job
    Offer, which only has Offer Date) can pass any reasonable stand-in
    date here — it's just the point in time this quote should reflect.
    """
    company = str(company or '').strip()
    if not company and salary_structure:
        company = frappe.db.get_value("Salary Structure", salary_structure, "company")

    return {
        'bonus_ceiling_amount': get_bonus_ceiling_amount(date_of_joining),
        'bonus_payable_percentage': get_bonus_payable_percentage(company),
    }


# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────
EMPLOYER_COMPS = [
    'Employer ESI', 'Employer PF', 'Gratuity',
    'Leave Encashment', 'Ex-Gratia', 'Medical Insurance',
    'Meal Voucher', 'ACCOM'
]

ALLOWANCE_COMPS = [
    'CCA', 'Special Allowance', 'Performance Bonus',
    'Conveyance', 'Child Education Allowance', 'Uniform Allowance',
    'Conveyance Reimbursement', 'Helper Reimbursement',
    'Education Scholarship', 'LTA'
]

EARNINGS_TEMPLATE = ['Basic', 'House Rent Allowance', 'Advance Bonus']
ALLOWANCES_TEMPLATE = ['Conveyance', 'Child Education Allowance', 'Uniform Allowance', 'Incentive']
DEDUCTIONS_TEMPLATE = ['Provident Fund', 'ESIC', 'Professional Tax', 'LWF']
OTHER_BENEFITS_TEMPLATE = [
    'Employer PF', 'Employer ESI', 'Leave Encashment',
    'Ex-Gratia', 'Gratuity', 'Meal Voucher', 'Medical Insurance'
]


def merge_with_template(template_list, actual_list, append_extras=False):
    actual_map = {item['component'].lower(): item['per_month'] for item in actual_list}
    result = []
    for comp in template_list:
        result.append({'component': comp, 'per_month': actual_map.get(comp.lower(), 0)})
    if append_extras:
        template_lower = [t.lower() for t in template_list]
        for item in actual_list:
            if item['component'].lower() not in template_lower:
                result.append(item)
    return result


@frappe.whitelist()
def get_loi_salary_data(
    salary_structure=None,
    base=0,
    custom_state='',
    custom_state_wage_category='',
    special_allowance=0,
    custom_pf_applicable="Yes",
    sitting_location='',
    employee='',
    date_of_joining=None,
    salary_breakup="[]",
    allowances="[]",
    company=None,
    employment_type='',
):
    base = float(base or 0)
    custom_state = str(custom_state or '').strip()
    custom_state_wage_category = str(custom_state_wage_category or '').strip()
    manual_spall = float(special_allowance or 0)
    employee_name = str(employee or '').strip()

    try:
        salary_breakup = json.loads(salary_breakup or "[]")
    except Exception:
        salary_breakup = []

    try:
        allowances = json.loads(allowances or "[]")
    except Exception:
        allowances = []

    # ── MANUAL GROSS ──
    manual_gross = 0
    for row in salary_breakup:
        if not row:
            continue
        try:
            manual_gross += float(str(row.get("per_month") or 0).replace(",", ""))
        except Exception:
            pass
    for row in allowances:
        if not row:
            continue
        try:
            manual_gross += float(str(row.get("per_month") or 0).replace(",", ""))
        except Exception:
            pass

    ESIC_INCLUDED_COMPS = [
        'basic', 'house rent allowance', 'conveyance',
        'child education allowance', 'uniform allowance',
        'special allowance', 'advance bonus', 'cca'
    ]

    esic_gross = 0.0
    for row in salary_breakup:
        if not row:
            continue
        comp = (row.get("particulars") or "").strip().lower()
        if comp in ESIC_INCLUDED_COMPS:
            try:
                esic_gross += float(str(row.get("per_month") or 0).replace(",", ""))
            except Exception:
                pass
    for row in allowances:
        if not row:
            continue
        comp = (row.get("particulars") or "").strip().lower()
        if comp in ESIC_INCLUDED_COMPS:
            try:
                esic_gross += float(str(row.get("per_month") or 0).replace(",", ""))
            except Exception:
                pass
    esic_gross = round(max(esic_gross, 0), 2)

    is_manual_structure = is_manual_salary_structure(salary_structure)
    is_dynamic_structure = is_base_salary_structure(salary_structure)
    is_state_min_wage_structure = 'STATE MINIMUM WAGE' in str(salary_structure or "").upper()

    state_min_wage = 0
    if custom_state:
        wage_row = frappe.db.get_value(
            "State Wage Master",
            {"state": custom_state},
            ["unskilled", "semi_skilled", "skilled", "highly_skilled"],
            as_dict=True
        )
        if wage_row:
            if custom_state_wage_category == "Unskilled":
                state_min_wage = float(wage_row.unskilled or 0)
            elif custom_state_wage_category == "Semi-Skilled":
                state_min_wage = float(wage_row.semi_skilled or 0)
            elif custom_state_wage_category == "Skilled":
                state_min_wage = float(wage_row.skilled or 0)
            elif custom_state_wage_category == "Highly Skilled":
                state_min_wage = float(wage_row.highly_skilled or 0)
            else:
                state_min_wage = float(wage_row.unskilled or 0)

    if not salary_structure:
        return {'error': 'Salary Structure required'}

    

    earnings_rows = frappe.db.sql(
        '''SELECT salary_component, abbr, amount_based_on_formula, formula, amount
           FROM `tabSalary Detail`
           WHERE parent = %s AND parentfield = 'earnings'
           ORDER BY idx''',
        (salary_structure,), as_dict=True
    )

    deduction_rows = frappe.db.sql(
        '''SELECT salary_component, abbr, amount_based_on_formula, formula, amount, `condition`
           FROM `tabSalary Detail`
           WHERE parent = %s AND parentfield = 'deductions'
           ORDER BY idx''',
        (salary_structure,), as_dict=True
    )

    earnings_list = []
    allowances_list = []
    deductions_list = []
    other_benefits_list = []

    comp_map = {}
    comp_map['STATE_WAGE'] = state_min_wage
    gross = 0.0

    # CHANGED: effective-dated lookup against Payroll Changeable Component
    # (Item + Audit). date_of_joining is whatever "as of" date the caller
    # passed — Job Offer sends its Offer Date here (it has no real
    # Date of Joining field); Employee Onboarding can send its actual
    # Date of Joining. Falls back to today if nothing was passed.
    as_on_date = date_of_joining or frappe.utils.today()
    #
    as_on_date = frappe.utils.getdate(as_on_date)
    #
    pf_ceiling = float(get_component_value("PF Ceiling Amount", as_on_date) or 15000)
    bonus_limit = float(get_component_value("Bonus Limit Amount", as_on_date) or 21000)
    bonus_ceiling = float(get_component_value("Bonus Ceiling Amount", as_on_date) or 7000)

    pf_type = custom_pf_applicable or "Yes"

    # ★ Bonus Payable Percentage is fetched dynamically based on Company —
    # NOT hardcoded, and NOT just "latest record".
    #
    # The Job Offer's own `company` field is the primary source, since that's
    # the actual employing company for this offer (and it's reliable even for
    # a shared/generic structure like "OLSCPL Manual Salary Structure" that
    # isn't itself tied to one company). If `company` isn't passed for some
    # reason, we fall back to the company on the selected Salary Structure.
    company = str(company or '').strip()
    if not company:
        company = frappe.db.get_value("Salary Structure", salary_structure, "company")

    bonus_payable_percentage_value = get_bonus_payable_percentage(company)
    if bonus_payable_percentage_value is None:
        # No 'Bonus Payable' record exists anywhere in the system yet.
        # 20% is used only as a last-resort so payroll math doesn't break;
        # create a 'Bonus Payable' record for the company to override this.
        bonus_payable_percentage_value = 20.0
    bonus_percentage = bonus_payable_percentage_value / 100

    # 29/10/2026
    # Outsourced / Apprentice: flat 60/40 Basic/HRA, no minimum wage, no deductions.
    # Every section is still returned with its normal rows, as for any other offer.
    # This sits here (not earlier) because Ex-Gratia needs bonus_ceiling and bonus_percentage.
    if is_no_deduction_employment_type(employment_type):
        flat_basic = round(base * BASE_BASIC_RATE, 2)
        flat_hra = round(base * BASE_HRA_RATE, 2)

        exg_ceiling_amt = round(bonus_ceiling * bonus_percentage, 2)
        ex_gratia = round(
            (flat_basic * bonus_percentage) if flat_basic < bonus_ceiling else exg_ceiling_amt,
            2
        )

        # Employer PF / Employer ESI are left out on purpose, so the template keeps
        # them at 0 (no PF/ESI for these types). The rest is calculated as usual.
        benefits = [
            {'component': 'Leave Encashment', 'per_month': calc_leave_encashment(flat_basic)},
            {'component': 'Ex-Gratia', 'per_month': ex_gratia},
            {'component': 'Gratuity', 'per_month': calc_gratuity(flat_basic)},
        ]

        return {
            'earnings': [
                {'component': 'Basic', 'per_month': flat_basic},
                {'component': 'House Rent Allowance', 'per_month': flat_hra},
            ],
            'allowances': merge_with_template(ALLOWANCES_TEMPLATE, [], append_extras=False),
            'deductions': merge_with_template(DEDUCTIONS_TEMPLATE, [], append_extras=True),
            'other_benefits': merge_with_template(OTHER_BENEFITS_TEMPLATE, benefits, append_extras=True),
            'gross': round(flat_basic + flat_hra, 2),
            'esic_applicable': 0,
            'recurring_allowance_total': 0,
            'allowance_cap': round(base * 0.20, 2),
            'allowance_cap_exceeded': False,
            'bonus_ceiling_amount': bonus_ceiling,
            'bonus_payable_percentage': round(bonus_payable_percentage_value, 4),
        }

    minimum_wage_override = False
    new_basic = base * BASE_BASIC_RATE
    advance_bonus = 0
    new_hra = 0
    other_deduction = 0

    pending = []

    if not is_manual_structure:
        for row in earnings_rows:
            abbr = (row.get("abbr") or "").upper()
            comp = str(row.get('salary_component') or '')

            if row.get('amount_based_on_formula') and row.get('formula'):
                pending.append(row)
                continue

            amt = round(float(row.get('amount') or 0), 2)
            if abbr:
                comp_map[abbr] = amt

            is_employer_comp = any(ec.lower() in comp.lower() for ec in EMPLOYER_COMPS)
            if not is_employer_comp:
                gross += amt

    if is_manual_structure:
        gross = round(manual_gross, 2)
        comp_map['gross_pay'] = gross
        comp_map['gross'] = gross

        for sb_row in salary_breakup:
            if (sb_row.get("particulars") or "").strip().lower() == "basic":
                comp_map['BASIC'] = float(sb_row.get("per_month") or 0)
        for sb_row in allowances:
            if (sb_row.get("particulars") or "").strip().lower() == "special allowance":
                comp_map['SPALL'] = float(sb_row.get("per_month") or 0)

    KNOWN_ABBRS = [
        'BASIC', 'HRA', 'CONV', 'CEA', 'UNIFORM', 'CCA', 'SPALL', 'EDUSCH', 'PERFBON', 'ADVBON',
        'INCENT', 'MOBILE', 'WASH', 'OTHERALL', 'LAPTOP', 'EEMPPF', 'EEMPESI', 'LVENC', 'EXGRAT',
        'GRAT', 'MEAL', 'PF', 'ESI', 'PT', 'LWF', 'VPF', 'ARREAR', 'LTA', 'CONVREIMB', 'HELPER',
        'MEDINS', 'ACCOM', 'BONUS', 'ADVANCE', 'LOAN', 'MOBDED', 'OTHDED', 'DRF'
    ]
    for abbr in KNOWN_ABBRS:
        if abbr not in comp_map:
            comp_map[abbr] = 0.0

    if not is_manual_structure:
        for row in pending:
            abbr = (row.get("abbr") or "").upper()
            if abbr and abbr not in comp_map:
                comp_map[abbr] = 0.0

        for _ in range(10):
            changed = False
            comp_map['gross_pay'] = round(gross, 2)
            comp_map['gross'] = round(gross, 2)

            for row in pending:
                abbr = (row.get("abbr") or "").upper()
                comp = str(row.get('salary_component') or '')
                is_employer_comp = any(ec.lower() in comp.lower() for ec in EMPLOYER_COMPS)

                amt = round(eval_formula(row.get('formula'), base, gross, comp_map, custom_state), 2)
                old_val = comp_map.get(abbr, 0.0)

                if old_val != amt:
                    changed = True
                    if not is_employer_comp:
                        gross -= old_val
                        gross += amt
                    comp_map[abbr] = amt

            comp_map['gross_pay'] = round(gross, 2)
            comp_map['gross'] = round(gross, 2)

            if not changed:
                break

    if is_state_min_wage_structure:
        min_wage_basic = round(state_min_wage, 2)
        sixty_pct = round(base * BASE_BASIC_RATE, 2)

        new_basic = min_wage_basic if sixty_pct < min_wage_basic else sixty_pct
        new_basic = round(new_basic, 2)
        new_hra = round(base - new_basic, 2)
        if new_hra < 0:
            new_hra = 0.0

        old_basic = comp_map.get('BASIC', 0.0)
        old_hra = comp_map.get('HRA', 0.0)

        gross = round(gross - old_basic - old_hra + new_basic + new_hra, 2)
        comp_map['BASIC'] = new_basic
        comp_map['HRA'] = new_hra
        comp_map['gross_pay'] = gross
        comp_map['gross'] = gross

    if is_manual_structure:
        for sb_row in salary_breakup:
            comp = str(sb_row.get('particulars') or '').strip()
            amt = float(str(sb_row.get('per_month') or 0).replace(',', ''))
            if comp:
                earnings_list.append({'component': comp, 'per_month': amt})
        for al_row in allowances:
            comp = str(al_row.get('particulars') or '').strip()
            amt = float(str(al_row.get('per_month') or 0).replace(',', ''))
            if comp:
                allowances_list.append({'component': comp, 'per_month': amt})

    if is_dynamic_structure:
        sixty_percent_of_base = base * BASE_BASIC_RATE

        if state_min_wage > 0 and (
            sixty_percent_of_base < state_min_wage
            or (sixty_percent_of_base >= state_min_wage and sixty_percent_of_base <= bonus_limit)
        ):
            minimum_wage_override = True
            new_basic = state_min_wage if sixty_percent_of_base < state_min_wage else sixty_percent_of_base
            new_basic = round(new_basic, 2)

            advance_bonus = 0
            if new_basic <= bonus_limit:
                effective_bonus_ceiling = max(bonus_ceiling, state_min_wage)
                bonus_base = min(state_min_wage, effective_bonus_ceiling)
                gross_bonus = bonus_base * bonus_percentage
                advance_bonus = round(gross_bonus - (bonus_ceiling * bonus_percentage), 2)
                if advance_bonus < 0:
                    advance_bonus = 0

            if new_basic > bonus_limit and state_min_wage > sixty_percent_of_base:
                extra_basic = new_basic - sixty_percent_of_base
                new_hra = round(comp_map.get('HRA', 0) - extra_basic, 2)
            else:
                new_hra = round(base - new_basic - advance_bonus, 2)

            if new_hra < 0:
                other_deduction = abs(new_hra)
                new_hra = 0

            old_basic = comp_map.get('BASIC', 0.0)
            old_hra = comp_map.get('HRA', 0.0)
            old_bonus = comp_map.get('ADVBON', 0.0)

            gross = round(gross - old_basic - old_hra - old_bonus + new_basic + new_hra + advance_bonus, 2)
            comp_map['BASIC'] = new_basic
            comp_map['HRA'] = new_hra
            comp_map['ADVBON'] = advance_bonus
            comp_map['gross_pay'] = gross
            comp_map['gross'] = gross

    if not is_manual_structure:
        esic_gross = 0.0
        ESIC_ABBR_MAP = {
            'basic': 'BASIC', 'house rent allowance': 'HRA', 'conveyance': 'CONV',
            'child education allowance': 'CEA', 'uniform allowance': 'UNIFORM',
            'special allowance': 'SPALL', 'advance bonus': 'ADVBON', 'cca': 'CCA'
        }
        for comp_lower, abbr in ESIC_ABBR_MAP.items():
            esic_gross += float(comp_map.get(abbr, 0))
        esic_gross = round(max(esic_gross, 0), 2)

    # ESI eligibility and contribution are based on Basic only, not full gross
    basic_for_esi = round(float(comp_map.get('BASIC', 0) or 0), 2)

    esi_result = calculate_esi_for_annexure(employee_name, basic_for_esi, basic_for_esi)
    employee_esi_amount = esi_result.get("employee_esi", 0)
    employer_esi_amount = esi_result.get("employer_esi", 0)

    if not is_manual_structure:
        for row in earnings_rows:
            comp = str(row['salary_component'])
            abbr = (row.get("abbr") or "").upper()
            amt = comp_map.get(abbr, 0)

            is_allowance = any(ac.lower() in comp.lower() for ac in ALLOWANCE_COMPS)
            is_employer = any(ec.lower() in comp.lower() for ec in EMPLOYER_COMPS)

            if comp.strip().upper() == "ADVANCE BONUS":
                amt = advance_bonus if minimum_wage_override else 0
                if is_employer:
                    other_benefits_list.append({'component': comp, 'per_month': amt})
                elif is_allowance:
                    allowances_list.append({'component': comp, 'per_month': amt})
                else:
                    earnings_list.append({'component': comp, 'per_month': amt})
                continue

            if minimum_wage_override and 'BASIC' in comp.upper():
                amt = new_basic
            elif minimum_wage_override and ('HOUSE RENT' in comp.upper() or abbr == 'HRA'):
                amt = new_hra

            if 'EMPLOYER PF' in comp.upper() or abbr == 'EEMPPF':
                basic_amt = new_basic if minimum_wage_override else (comp_map.get("BASIC") or comp_map.get("BSC") or 0)
                spall_amt = comp_map.get("SPALL") or manual_spall or 0
                basic_for_pf = float(basic_amt)
                spall_for_pf = float(spall_amt)
                pf_wage = min(basic_for_pf + spall_for_pf, pf_ceiling) if basic_for_pf < pf_ceiling else basic_for_pf

                if pf_type == "Yes":
                    amt = round(pf_wage * EMPLOYER_PF_RATE_DEFAULT, 2)
                elif pf_type == "No":
                    amt = 0 if basic_amt > pf_ceiling else round(pf_wage * EMPLOYER_PF_RATE_DEFAULT, 2)
                elif pf_type == "Ceiling":
                    amt = round(min(pf_wage, pf_ceiling) * EMPLOYER_PF_RATE_DEFAULT, 2)

            if 'EMPLOYER ESI' in comp.upper() or abbr == 'EEMPEI':
                amt = employer_esi_amount

            

            if 'GRATUITY' in comp.upper() or abbr == 'GRAT':
                amt = calc_gratuity(comp_map.get('BASIC'))

            if 'LEAVE ENCASHMENT' in comp.upper() or abbr == 'LVENC':
                amt = calc_leave_encashment(comp_map.get('BASIC'))




            if 'EX-GRATIA' in comp.upper() or abbr == 'EXGRAT':
                # ★ Same treatment as Employer PF / Employer ESI above: override
                # whatever the Salary Structure's stored formula computed, with
                # a live, company-driven calculation. This is required because
                # a non-manual structure's Ex-Gratia formula is static text
                # sitting in the Salary Structure doc (e.g. a literal
                # "(basic*0.2) if basic<7000 else 1400") — it has no way to
                # know about company or the Payroll Changeable Component /
                # Bonus Payable doctypes, so without this override it would
                # keep producing the old hardcoded value regardless of company.
                # basic_for_exg = new_basic if minimum_wage_override else (comp_map.get("BASIC") or comp_map.get("BSC") or 0)
                # basic_for_exg = float(basic_for_exg or 0)
                # exg_ceiling_amt = round(bonus_ceiling * bonus_percentage, 2)
                # exg_base = (basic_for_exg * bonus_percentage) if basic_for_exg < bonus_ceiling else exg_ceiling_amt
                # adv_bonus_for_exg = advance_bonus if minimum_wage_override else 0
                # amt = round(exg_base - adv_bonus_for_exg, 2)
                # if amt < 0:
                #     amt = 0


                #13-10-2026
                # (keep your existing comment)
                basic_for_exg = float(comp_map.get("BASIC") or 0)
                exg_ceiling_amt = round(bonus_ceiling * bonus_percentage, 2)
                amt = round(
                    (basic_for_exg * bonus_percentage) if basic_for_exg < bonus_ceiling
                    else exg_ceiling_amt,
                    2
                )


            if is_employer:
                other_benefits_list.append({'component': comp, 'per_month': amt})
            elif is_allowance:
                allowances_list.append({'component': comp, 'per_month': amt})
            else:
                earnings_list.append({'component': comp, 'per_month': amt})

    if is_manual_structure:
        basic_amt = comp_map.get('BASIC') or 0
        spall_amt = comp_map.get('SPALL') or manual_spall or 0
        basic_for_pf = float(basic_amt)
        spall_for_pf = float(spall_amt)
        pf_wage = min(basic_for_pf + spall_for_pf, pf_ceiling) if basic_for_pf < pf_ceiling else basic_for_pf

        if pf_type == "Yes":
            employer_pf = round(pf_wage * EMPLOYER_PF_RATE_DEFAULT, 2)
        elif pf_type == "No":
            employer_pf = 0 if basic_amt > pf_ceiling else round(pf_wage * EMPLOYER_PF_RATE_DEFAULT, 2)
        elif pf_type == "Ceiling":
            employer_pf = round(min(pf_wage, pf_ceiling) * EMPLOYER_PF_RATE_DEFAULT, 2)
        else:
            employer_pf = 0

        gratuity = calc_gratuity(basic_amt)
        leave_encashment = calc_leave_encashment(basic_amt)

        # ★ Ex-Gratia is now fully dynamic:
        #   - "ceiling" is Bonus Ceiling Amount from Payroll Changeable Component
        #   - "rate" is Bonus Payable Percentage from Bonus Payable, matched to
        #     the Company on the Salary Structure
        #   - The old hardcoded "1400" was simply 7000 * 20% — it is now
        #     bonus_ceiling * bonus_percentage, so it updates automatically if
        #     either value changes for that company.
        ex_gratia_ceiling_amt = round(bonus_ceiling * bonus_percentage, 2)
        ex_gratia_base = (basic_amt * bonus_percentage) if basic_amt < bonus_ceiling else ex_gratia_ceiling_amt
        ex_gratia = round(ex_gratia_base - advance_bonus, 2)
        if ex_gratia < 0:
            ex_gratia = 0

        other_benefits_list = []
        for tmpl_comp in OTHER_BENEFITS_TEMPLATE:
            if 'EMPLOYER PF' in tmpl_comp.upper():
                other_benefits_list.append({'component': tmpl_comp, 'per_month': employer_pf})
            elif 'EMPLOYER ESI' in tmpl_comp.upper():
                other_benefits_list.append({'component': tmpl_comp, 'per_month': employer_esi_amount})
            elif 'LEAVE ENCASHMENT' in tmpl_comp.upper():
                other_benefits_list.append({'component': tmpl_comp, 'per_month': leave_encashment})
            elif 'EX-GRATIA' in tmpl_comp.upper():
                other_benefits_list.append({'component': tmpl_comp, 'per_month': ex_gratia})
            elif 'GRATUITY' in tmpl_comp.upper():
                other_benefits_list.append({'component': tmpl_comp, 'per_month': gratuity})
            else:
                other_benefits_list.append({'component': tmpl_comp, 'per_month': 0})

    gross = round(gross, 2)
    comp_map['gross_pay'] = gross
    comp_map['gross'] = gross

    if is_manual_structure and not deduction_rows:
        deduction_rows = [
            {"salary_component": "Provident Fund", "abbr": "EPF"},
            {"salary_component": "ESIC", "abbr": "ESI"},
            {"salary_component": "Professional Tax", "abbr": "PT"},
            {"salary_component": "LWF", "abbr": "LWF"}
        ]

    for row in deduction_rows:
        comp = str(row['salary_component'])
        abbr = (row.get("abbr") or "").upper()

        if comp.upper() in ('TDS', 'INCOME TAX', 'INCOME TAX (TDS)'):
            continue

        if 'PROVIDENT FUND' in comp.upper() or abbr == 'EPF':
            if is_manual_structure:
                basic_amt = 0
                spall_amt = 0
                for pf_row in salary_breakup or []:
                    if (pf_row.get("particulars") or "").lower() == "basic":
                        try:
                            basic_amt = float(str(pf_row.get("per_month") or 0).replace(",", ""))
                        except Exception:
                            basic_amt = 0
                        break
                for pf_row in allowances or []:
                    if (pf_row.get("particulars") or "").lower() == "special allowance":
                        try:
                            spall_amt = float(str(pf_row.get("per_month") or 0).replace(",", ""))
                        except Exception:
                            spall_amt = 0
                        break
            else:
                basic_amt = new_basic if minimum_wage_override else (comp_map.get("BASIC") or comp_map.get("BSC") or 0)
                spall_amt = comp_map.get("SPALL") or manual_spall or 0

            basic_for_pf = float(basic_amt)
            spall_for_pf = float(spall_amt)
            pf_wage = min(basic_for_pf + spall_for_pf, pf_ceiling) if basic_for_pf < pf_ceiling else basic_for_pf

            if custom_pf_applicable == "Yes":
                employee_pf = round(pf_wage * EMPLOYEE_PF_RATE_DEFAULT, 2)
            elif custom_pf_applicable == "Ceiling":
                employee_pf = round(min(pf_wage, pf_ceiling) * EMPLOYEE_PF_RATE_DEFAULT, 2)
            else:
                employee_pf = 0

            deductions_list.append({'component': comp, 'per_month': employee_pf})
            continue

        if 'ESIC' in comp.upper() or comp.upper() == 'ESI':
            deductions_list.append({'component': comp, 'per_month': employee_esi_amount})
            continue

        if 'PROFESSIONAL TAX' in comp.upper() or comp.upper() == 'PT':
            pt_amount = 0
            current_month = 0
            if date_of_joining:
                date_parts = str(date_of_joining).split("-")
                if len(date_parts) >= 2:
                    current_month = int(date_parts[1])

            pt_rule_name = frappe.db.get_value(
                "Professional Tax Rule", {"state": custom_state, "is_active": 1}, "name"
            )

            if pt_rule_name:
                pt_rule = frappe.get_doc("Professional Tax Rule", pt_rule_name)
                special_month = pt_rule.special_month or 0
                pt_gross = manual_gross if manual_gross > 0 else gross

                for slab in pt_rule.pt_slabs:
                    from_amount = slab.from_amount or 0
                    to_amount = slab.to_amount or 999999999
                    if pt_gross >= from_amount and pt_gross <= to_amount:
                        special_amount = slab.special_month_amount or 0
                        if current_month == special_month and special_amount > 0:
                            pt_amount = special_amount
                        else:
                            pt_amount = slab.pt_amount or 0
                        break

            deductions_list.append({'component': comp, 'per_month': round(pt_amount, 2)})
            continue

        if 'LWF' in comp.upper() or 'LABOUR WELFARE FUND' in comp.upper():
            lwf_amount = 0
            lwf_doc_name = frappe.db.get_value(
                "LWF Configuration", {"state": custom_state, "is_active": 1}, "name"
            )
            if lwf_doc_name:
                lwf_doc = frappe.get_doc("LWF Configuration", lwf_doc_name)
                if lwf_doc.employee_type == "Fixed":
                    lwf_amount = lwf_doc.employee_amount or 0
                elif lwf_doc.employee_type == "Percentage":
                    percentage = lwf_doc.employee_percentage or 0
                    lwf_gross = manual_gross if manual_gross > 0 else gross
                    lwf_amount = round(lwf_gross * (percentage / 100), 0)
                    max_cap = lwf_doc.employee_max_cap or 0
                    if max_cap > 0 and lwf_amount > max_cap:
                        lwf_amount = max_cap

            deductions_list.append({'component': comp, 'per_month': round(lwf_amount, 2)})
            continue

        if 'OTHER DEDUCTION' in comp.upper():
            if other_deduction > 0:
                deductions_list.append({'component': comp, 'per_month': round(other_deduction, 2)})
            continue

        condition = (row.get('condition') or '').strip()
        condition_met = True

        if condition:
            cond = condition.replace('gross_pay', str(float(gross)))
            cond = cond.replace('gross', str(float(gross)))
            cond = cond.replace('base', str(float(base)))

            for op in ['<=', '>=', '!=', '<', '>', '==']:
                if op in cond:
                    idx = cond.find(op)
                    lhs = cond[:idx].strip().strip('()')
                    rhs = cond[idx + len(op):].strip().strip('()')
                    try:
                        lv = parse_arith(lhs)
                        rv = parse_arith(rhs)
                        if op == '<=':
                            condition_met = lv <= rv
                        elif op == '>=':
                            condition_met = lv >= rv
                        elif op == '<':
                            condition_met = lv < rv
                        elif op == '>':
                            condition_met = lv > rv
                        elif op == '==':
                            condition_met = lv == rv
                        elif op == '!=':
                            condition_met = lv != rv
                    except Exception:
                        condition_met = False
                    break

        if not condition_met:
            amt = 0.0
        elif row.get('amount_based_on_formula') and row.get('formula'):
            amt = eval_formula(row.get('formula'), base, gross, comp_map, custom_state)
        else:
            amt = float(row.get('amount') or 0)

        amt = round(amt, 2)

        ALLOWED_DEDUCTION_COMPS = [
            'provident fund', 'esic', 'esi', 'professional tax', 'lwf',
            'labour welfare fund', 'other deduction', 'other deductions'
        ]

        if not any(a in comp.lower() for a in ALLOWED_DEDUCTION_COMPS):
            continue

        is_employer = any(ec.lower() in comp.lower() for ec in EMPLOYER_COMPS)

        if is_employer:
            other_benefits_list.append({'component': comp, 'per_month': amt})
        else:
            deductions_list.append({'component': comp, 'per_month': amt})

    already_has_other_deduction = any('other deduction' in item['component'].lower() for item in deductions_list)
    if other_deduction > 0 and not already_has_other_deduction:
        deductions_list.append({'component': 'Other Deduction', 'per_month': round(other_deduction, 2)})

    if is_manual_structure:
        if salary_breakup and len(salary_breakup) > 0:
            final_earnings = []
            for row in salary_breakup:
                comp = str(row.get('particulars') or '').strip()
                amt = float(str(row.get('per_month') or 0).replace(',', ''))
                if comp:
                    final_earnings.append({'component': comp, 'per_month': amt})
        else:
            final_earnings = [{'component': c, 'per_month': 0} for c in EARNINGS_TEMPLATE]

        if allowances and len(allowances) > 0:
            final_allowances = []
            for row in allowances:
                comp = str(row.get('particulars') or '').strip()
                amt = float(str(row.get('per_month') or 0).replace(',', ''))
                if comp:
                    final_allowances.append({'component': comp, 'per_month': amt})
        else:
            final_allowances = [{'component': c, 'per_month': 0} for c in ALLOWANCES_TEMPLATE]

        final_deductions = merge_with_template(DEDUCTIONS_TEMPLATE, deductions_list, append_extras=True)
        final_other_benefits = merge_with_template(OTHER_BENEFITS_TEMPLATE, other_benefits_list, append_extras=True)
    else:
        final_earnings = merge_with_template(EARNINGS_TEMPLATE, earnings_list, append_extras=False)
        final_allowances = merge_with_template(ALLOWANCES_TEMPLATE, allowances_list, append_extras=False)
        final_deductions = merge_with_template(DEDUCTIONS_TEMPLATE, deductions_list, append_extras=True)
        final_other_benefits = merge_with_template(OTHER_BENEFITS_TEMPLATE, other_benefits_list, append_extras=True)

    esic_applicable = 1 if basic_for_esi <= 21000 else 0

    one_time_allowance_comps = {component.lower() for component in ONE_TIME_COMPONENTS}
    recurring_allowance_total = sum(
        float(item.get('per_month') or 0)
        for item in final_allowances
        if item.get('component', '').strip().lower() not in one_time_allowance_comps
    )
    recurring_allowance_total = round(recurring_allowance_total, 2)

    allowance_cap = round(base * 0.20, 2)
    allowance_cap_exceeded = recurring_allowance_total > allowance_cap

    return {
        'earnings': final_earnings,
        'allowances': final_allowances,
        'deductions': final_deductions,
        'other_benefits': final_other_benefits,
        'gross': round(gross, 2),
        'esic_applicable': esic_applicable,
        'recurring_allowance_total': recurring_allowance_total,
        'allowance_cap': allowance_cap,
        'allowance_cap_exceeded': allowance_cap_exceeded,
        # ★ Sent to the client so recalcAllTotals() on the frontend can also
        # compute Ex-Gratia dynamically (e.g. when a row is edited locally
        # without a fresh server round-trip).
        'bonus_ceiling_amount': bonus_ceiling,
        'bonus_payable_percentage': round(bonus_payable_percentage_value, 4),
    }