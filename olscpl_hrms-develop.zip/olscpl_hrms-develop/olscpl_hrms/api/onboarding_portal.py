# olscpl_hrms/api/onboarding_portal.py
#
# Guest-facing endpoints behind the candidate onboarding page
# (olscpl_hrms/www/onboarding_documents.py). Everything here is scoped to
# the single Employee Onboarding record resolved from the caller's portal
# key - nothing else is reachable, and hr_received / hr_change_request_notes
# are never writable from any of these (hr_received is permlevel 1, gated
# to the "Onboarding Verifier" role; the correction-notes field is only
# ever set from the desk side).
import base64
import json
import re

import frappe
from frappe import _
from frappe.utils.file_manager import save_file
from olscpl_hrms.utils.email_layout import company_email

from olscpl_hrms.events.employee_onboarding import (
	get_onboarding_by_key,
	notify_hr_if_documents_complete,
)

MAX_DOC_FILE_SIZE_BYTES = 5 * 1024 * 1024  # 5 MB, matches the old portal's document-upload cap

PERSONAL_DATA_FIELDS = [
	"father_name", "gender", "candidate_dob", "place_of_birth", "marital_status", "nationality", "religion",
	"dependents", "candidate_phone", "candidate_email", "permanent_address", "present_address",
	"pincode", "aadhaar_number", "parents_phone_number", "lives_in",
	"technical_typing", "technical_stenography", "technical_computer", "technical_other",
	"is_experienced", "extra_curricular_activities",
	"salary_basic", "salary_da", "salary_hra", "salary_cca", "salary_conveyance",
	"salary_other_allowance", "expected_gross_salary",
	"connected_to_business", "connected_to_business_details",
	"relatives_in_om_group", "relatives_in_om_group_details",
	"relatives_in_govt", "relatives_in_govt_details",
	"has_pf_account", "has_pf_account_details",
	"prior_arrest", "prior_arrest_details",
	"height", "weight", "physical_disability", "serious_illness", "accident_details",
]

CHILD_TABLE_FIELDS = {
	"kyc_details": ["kyc_type", "name_on_document", "number", "remarks"],
	"education_details": ["examination_passed", "year_of_passing", "institute", "subject", "percentage_marks", "grade_obtained"],
	"employment_history": ["from_date", "to_date", "company_address", "designation", "gross_emoluments", "reason_for_leaving"],
	"languages_known": ["language", "understand", "speak", "read", "write", "remarks"],
	"family_members": ["member_name", "relation", "qualification", "occupation", "mobile_no", "address", "date_of_birth", "residing_with", "nominee", "share_percentage", "guardian_details"],
	"job_references": ["reference_name", "status_and_address"],
}

# HR-only, filled from the desk side (see Employee Onboarding's "Statutory
# Declarations" tab) - included in get_application_data for the shared
# Review view but deliberately absent from save_personal_data, so the
# guest/candidate endpoint can never write to them.
STATUTORY_FIELDS = [
	"esic_insurance_no", "esic_employer_code", "esic_local_office", "esic_dispensary",
	"epf_account_no", "epf_date_of_membership", "epfo_uan",
	"form11_prior_establishment_name", "form11_left_service_on", "form11_scheme_certificate_no",
	"form11_ppo_no", "form11_is_international_worker", "form11_passport_no",
	"gratuity_village", "gratuity_thana", "gratuity_sub_division", "gratuity_post_office",
	"gratuity_district", "gratuity_state",
	"gratuity_witness1_name", "gratuity_witness1_address", "gratuity_witness2_name", "gratuity_witness2_address",
]

STATUTORY_CHILD_TABLE_FIELDS = {
	"esic_family_members": ["member_name", "date_of_birth", "relationship", "residing_with"],
	"epf_nominees": ["nominee_name", "address", "relationship", "date_of_birth", "share_percentage", "guardian_details"],
	"eps_family_members": ["nominee_name", "address", "relationship", "date_of_birth"],
	"gratuity_nominees": ["nominee_name", "address", "relationship", "date_of_birth", "share_percentage"],
}


def _load(value):
	if isinstance(value, str):
		return json.loads(value)
	return value


def _safe_filename_part(text):
	"""Strips characters that are illegal (or just awkward - a bare "/"
	would otherwise be read as a folder separator) in a filename on any
	common filesystem, collapsing them to a single space. Used to build
	upload_document()'s "<Document Type>_<Applicant Name>.<ext>" filename
	and _save_signature_file()'s "Signature_<Applicant Name>.png" out of
	free text (a checklist row's document_type, the onboarding record's
	own employee_name) that was never validated as filename-safe."""
	return re.sub(r'[\\/:*?"<>|]+', " ", (text or "").strip()).strip()


def _save_signature_file(doc):
	"""Alongside candidate_signature (kept as-is - the signature pad
	reloads from that base64 field to let the candidate re-draw/re-submit,
	and every existing read path - the PDF, the portal's own print preview
	- already works against it), also writes the same signature, flattened
	the same way employee_data.py's PDF does (_flatten_signature_on_white -
	the "poorly-lit photo of a paper signature" fix), as an actual named
	File attached to this record. Purely an additional artifact so the
	signature shows up in the Files list the same readable way
	resume/documents already do - "Signature_<Applicant Name>.png" - not a
	replacement for the base64 field or any of its existing readers.

	Deletes any previous such File first rather than leaving every past
	signature attached - save_personal_data() can be called repeatedly as
	the candidate works through the form (a redraw, a re-submit of the
	same step), and only the current signature should be on record."""
	from olscpl_hrms.api.employee_data import _flatten_signature_on_white

	flattened = _flatten_signature_on_white(doc.candidate_signature)
	if not flattened or "," not in flattened:
		return
	content = base64.b64decode(flattened.split(",", 1)[1])

	for old in frappe.get_all(
		"File",
		filters={
			"attached_to_doctype": "Employee Onboarding",
			"attached_to_name": doc.name,
			"attached_to_field": "candidate_signature",
		},
		pluck="name",
	):
		frappe.delete_doc("File", old, ignore_permissions=True, delete_permanently=True)

	applicant = _safe_filename_part(doc.employee_name) or doc.name
	save_file(
		f"Signature_{applicant}.png",
		content,
		"Employee Onboarding",
		doc.name,
		folder="Home/Attachments",
		is_private=1,
		df="candidate_signature",
	)


def _ensure_editable(doc):
	"""Once the candidate has clicked Save & Submit, the application is
	locked - no further edits, uploads, or consent changes - until HR
	explicitly requests changes (request_changes() clears
	portal_submitted_on to reopen it). This is the actual enforcement;
	the guest page also disables the form fields, but that's a UX nicety
	only - this is what a candidate replaying an old request against the
	same key can't get around."""
	if doc.get("portal_submitted_on"):
		frappe.throw(
			_(
				"This application has already been submitted and can't be edited. "
				"If something needs to change, HR will send you a note and a fresh link."
			),
			frappe.PermissionError,
		)


@frappe.whitelist(allow_guest=True)
def get_application_data(key: str) -> dict:
	"""Full current state for the guest page to render/pre-fill - the same
	data whether this is a first-time fill or a candidate returning after
	HR requested corrections. Includes the HR-filled statutory fields too
	(read-only, for the shared Review view) but never hr_received - that
	one stays gated behind the real permlevel/role check, not this method.
	"""
	doc = get_onboarding_by_key(key, allow_hr_view=True)
	if not doc:
		frappe.throw(_("This link is invalid or has expired."), frappe.PermissionError)

	from olscpl_hrms.api.employee_data import (
		_embed_file,
		_flatten_signature_on_white,
		company_address_line,
		get_user_signature,
	)

	data = {f: doc.get(f) for f in PERSONAL_DATA_FIELDS}
	# Pre-formatted "COMPANY NAME, address..." text for the statutory
	# forms' "Name and Address of Employer/Establishment" cells (ESIC TIC,
	# EPF Nomination, Gratuity Form F) - see company_address_line()'s own
	# docstring for why this lives in employee_data.py rather than being
	# duplicated here.
	data["company_address_line"] = company_address_line(doc.company)
	# Same normalisation the PDF applies (see _flatten_signature_on_white's
	# own docstring) - a signature drawn/uploaded this poorly-lit/low-
	# contrast should look the same fixed way everywhere it's shown, not
	# just in the downloaded PDF.
	data["candidate_signature"] = _flatten_signature_on_white(doc.candidate_signature)
	# Whoever actually sent this candidate their link (see
	# generate_portal_link) stands in as "Employer/Authorised Signatory"
	# on the statutory forms' review - their own drawn signature (User.
	# custom_signature), not the raw user id, is what the guest page needs.
	data["hr_signature"] = _flatten_signature_on_white(get_user_signature(doc.portal_link_sent_by))
	# Logo + name for the Application Form header on the Review/print view -
	# same as the Employee Digital File's header (see _header_html in
	# employee_data.py), where they also fill the left column next to the photo.
	data["company"] = doc.company
	data["company_logo"] = _embed_file(
		frappe.db.get_value("Company", doc.company, "company_logo"), "Company", doc.company
	)
	data["declaration_agreed"] = doc.declaration_agreed
	data["hr_change_request_notes"] = doc.hr_change_request_notes
	data["employee_name"] = doc.employee_name
	data["date_of_joining"] = doc.date_of_joining
	data["designation"] = doc.designation
	data["portal_submitted_on"] = doc.portal_submitted_on

	for table_field, fields in CHILD_TABLE_FIELDS.items():
		data[table_field] = [{f: row.get(f) for f in fields} for row in (doc.get(table_field) or [])]

	for f in STATUTORY_FIELDS:
		data[f] = doc.get(f)
	for table_field, fields in STATUTORY_CHILD_TABLE_FIELDS.items():
		data[table_field] = [{f: row.get(f) for f in fields} for row in (doc.get(table_field) or [])]

	data["checklist"] = [
		{
			"name": r.name,
			"document_type": r.document_type,
			"particulars": r.particulars,
			"mandatory": r.mandatory,
			"candidate_submitted": r.candidate_submitted,
			# Only the filename/extension is exposed here - not a fetchable
			# URL (these files are private; the actual bytes are only
			# ever served through get_document_file(), scoped to this same
			# key). Lets the print view tell image uploads from PDF
			# uploads without an extra round trip.
			"file_name": (r.file or "").rsplit("/", 1)[-1] if r.file else None,
		}
		for r in (doc.get("onboarding_documents") or [])
	]

	data["consent"] = [
		{"name": r.name, "question": r.question_text, "candidate_response": r.candidate_response}
		for r in (doc.get("consent_responses") or [])
	]

	return data


@frappe.whitelist(allow_guest=True)
def save_personal_data(key: str, data):
	"""Saves the Personal Data step: scalar fields + the repeatable
	KYC/Education/Employment/Languages/Family/References tables, plus the
	drawn signature and the declaration checkbox. Whatever the candidate
	submits fully replaces the previous content of these specific tables
	(the candidate is always editing their own single record, resolved
	only via their own key)."""
	doc = get_onboarding_by_key(key)
	if not doc:
		frappe.throw(_("This link is invalid or has expired."), frappe.PermissionError)
	_ensure_editable(doc)

	data = _load(data)

	for fieldname in PERSONAL_DATA_FIELDS:
		if fieldname in data:
			doc.set(fieldname, data[fieldname])

	if data.get("candidate_signature"):
		doc.candidate_signature = data["candidate_signature"]
	if data.get("declaration_agreed"):
		doc.declaration_agreed = 1

	for table_field, fields in CHILD_TABLE_FIELDS.items():
		if table_field not in data:
			continue
		doc.set(table_field, [])
		for row in data[table_field]:
			doc.append(table_field, {f: row.get(f) for f in fields if f in row})

	# Basic totals server-side rather than trusting a client-computed number.
	doc.salary_grand_total = sum(
		frappe.utils.flt(doc.get(f))
		for f in ("salary_basic", "salary_da", "salary_hra", "salary_cca", "salary_conveyance", "salary_other_allowance")
	)

	doc.save(ignore_permissions=True)

	# Only when a new signature actually came in this request (not every
	# save of this step) - avoids redoing the flatten/write/delete-old
	# work on every field the candidate fills in along the way, and
	# doc.name/employee_name are only guaranteed present after the save
	# above (a first-time save can still be inserting the record).
	if data.get("candidate_signature"):
		_save_signature_file(doc)

	frappe.db.commit()

	return {"saved": True}


@frappe.whitelist(allow_guest=True)
def save_consent_responses(key: str, responses):
	doc = get_onboarding_by_key(key)
	if not doc:
		frappe.throw(_("This link is invalid or has expired."), frappe.PermissionError)
	_ensure_editable(doc)

	responses = _load(responses)
	by_name = {r.get("name"): r.get("candidate_response") for r in responses}

	for row in doc.get("consent_responses") or []:
		if row.name in by_name and by_name[row.name] in ("Yes", "No"):
			row.candidate_response = by_name[row.name]

	doc.save(ignore_permissions=True)
	frappe.db.commit()

	return {"saved": True}


@frappe.whitelist(allow_guest=True)
def upload_document(key: str, row_name: str):
	doc = get_onboarding_by_key(key)
	if not doc:
		frappe.throw(_("This link is invalid or has expired."), frappe.PermissionError)
	_ensure_editable(doc)

	row = next((r for r in doc.get("onboarding_documents") if r.name == row_name), None)
	if not row:
		frappe.throw(_("Unknown document row."), frappe.PermissionError)

	uploaded = frappe.request.files.get("file")
	if not uploaded:
		frappe.throw(_("No file was uploaded."))

	content = uploaded.stream.read()
	if len(content) > MAX_DOC_FILE_SIZE_BYTES:
		frappe.throw(_("File must be smaller than 5 MB."))

	# Named after the document type + applicant, not kept as whatever the
	# candidate's own file happened to be called - a generic
	# "IMG_20230101.jpg" or "scan1.pdf" tells HR nothing once dozens of
	# these pile up in the Files list. "<Document Type>_<Applicant Name>.
	# <ext>", e.g. "Aadhaar Card_Ritika Nain.pdf".
	#
	# This also sidesteps most of frappe.utils.file_manager.get_file_name()'s
	# site-wide same-name collision handling (it appends an unreadable
	# content-hash suffix on any collision - e.g. "Aadhaar.pdf" becomes
	# "Aadhaar_4f9a21.pdf" - which was the actual reason the exact original
	# filename used to be kept here): two different candidates rarely share
	# both a document type and a full name, so this new name is already
	# collision-resistant. The onboarding record's own name is still the
	# fallback prefix for the rare case where it does collide (e.g. two
	# same-named candidates onboarding at once), instead of falling through
	# to core's hash suffix.
	ext = f".{uploaded.filename.rsplit('.', 1)[-1]}" if "." in uploaded.filename else ""
	doc_type = _safe_filename_part(row.document_type) or "Document"
	applicant = _safe_filename_part(doc.employee_name) or doc.name
	filename = f"{doc_type}_{applicant}{ext}"
	if frappe.db.exists("File", {"file_name": filename}):
		filename = f"{doc.name}-{filename}"

	file_doc = save_file(
		filename,
		content,
		"Employee Onboarding",
		doc.name,
		folder="Home/Attachments",
		is_private=1,
	)

	frappe.db.set_value(
		"Onboarding Checklist Item",
		row_name,
		{"file": file_doc.file_url, "candidate_submitted": 1},
	)
	frappe.db.commit()

	notify_hr_if_documents_complete(doc.name)

	return {"file_url": file_doc.file_url}


@frappe.whitelist(allow_guest=True)
def get_document_file(key: str, row_name: str):
	"""Serves one of the candidate's own uploaded onboarding documents
	inline - scoped strictly to their own record via their portal key,
	same access model as every other endpoint here. Needed because
	Frappe's own /private/files/... route hard-blocks Guest sessions
	entirely (frappe.utils.response.download_private_file) - and these
	uploads are correctly private, not something a bare URL should serve
	to anyone who finds it. Used by the Review step's print view to embed
	each uploaded document (image or PDF) inline instead of just listing
	a submitted checkmark."""
	doc = get_onboarding_by_key(key, allow_hr_view=True)
	if not doc:
		frappe.throw(_("This link is invalid or has expired."), frappe.PermissionError)

	row = next((r for r in doc.get("onboarding_documents") if r.name == row_name), None)
	if not row or not row.file:
		frappe.throw(_("File not found."), frappe.DoesNotExistError)

	file_doc = frappe.get_doc(
		"File",
		{"file_url": row.file, "attached_to_doctype": "Employee Onboarding", "attached_to_name": doc.name},
	)
	with open(file_doc.get_full_path(), "rb") as f:
		content = f.read()

	frappe.local.response.filename = file_doc.file_name
	frappe.local.response.filecontent = content
	frappe.local.response.display_content_as = "inline"
	frappe.local.response.type = "download"


@frappe.whitelist(allow_guest=True)
def final_submit(key: str):
	"""Candidate-facing confirmation that they're done - the candidate has
	explicitly clicked "Save & Submit" (and confirmed the "this goes to
	HR" prompt) on the Review step. This is the one point HR actually
	gets notified from - not the moment documents happen to be complete
	(see notify_hr_if_documents_complete, which only tracks a timestamp
	now), since a candidate can finish uploading files well before
	they've actually reviewed and confirmed the rest of the form.

	Only notifies the specific person who sent this candidate their link
	- never guesses a recipient. Empty/Administrator means no one
	specifically expects this candidate, so this stays silent rather
	than picking an arbitrary HR Manager."""
	doc = get_onboarding_by_key(key)
	if not doc:
		frappe.throw(_("This link is invalid or has expired."), frappe.PermissionError)
	# Every other write on this portal (save_personal_data,
	# save_consent_responses, upload_document) already refuses to touch an
	# already-submitted application - this was the one gap: calling
	# final_submit() a second time on a locked application silently
	# stamped a fresh portal_submitted_on with no error, which looks
	# exactly like a real resubmission (HR gets notified, the timestamp
	# updates) even though nothing underneath it actually changed.
	_ensure_editable(doc)

	doc.db_set("portal_submitted_on", frappe.utils.now_datetime(), update_modified=False)
	frappe.db.commit()

	notify_user = doc.get("portal_link_sent_by")
	if notify_user and notify_user != "Administrator":
		review_url = frappe.utils.get_url(f"/app/employee-onboarding/{doc.name}")
		frappe.get_doc(
			{
				"doctype": "ToDo",
				"allocated_to": notify_user,
				"reference_type": "Employee Onboarding",
				"reference_name": doc.name,
				"description": frappe._("{0} has submitted their onboarding application. Review: {1}").format(
					doc.employee_name, review_url
				),
				"priority": "Medium",
			}
		).insert(ignore_permissions=True)
		frappe.db.commit()

		user_email = frappe.db.get_value("User", notify_user, "email")
		if user_email:
			try:
				message = frappe.render_template(
					(
						"<p>{{ applicant_name }} has submitted their completed onboarding application.</p>"
						"<p><a href='{{ url }}'>Review their submission</a></p>"
					),
					{"applicant_name": doc.employee_name, "url": review_url},
				)
				frappe.sendmail(
					recipients=[user_email],
					subject=frappe._("{0}: onboarding application submitted, ready for review").format(
						doc.employee_name
					),
					message=company_email(doc.company, frappe._("Onboarding Submitted"), message, signoff=True),
					now=True,
				)
			except Exception:
				frappe.log_error(title="Onboarding-submitted notification email failed")

	return {"submitted_on": doc.portal_submitted_on}
