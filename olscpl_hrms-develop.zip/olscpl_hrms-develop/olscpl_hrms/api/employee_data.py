# olscpl_hrms/api/employee_data.py
#
# "Download Employee Data" button on the Employee form (see
# public/js/employee.js). Generates one combined PDF: every section from the
# candidate's Employee Onboarding submission, laid out with the exact same
# tables/boxes/grid structure as the onboarding portal's own "Review" step
# (www/onboarding-documents.html -> renderReview()) - that step is the
# source the company's real paper Application Form packet was printed from,
# so this mirrors it field-for-field and table-for-table rather than
# approximating it: same section boxes, same multi-column grid tables for
# ESIC / EPF / Gratuity / Form 11 (not stacked label:value lines), same
# order. Followed by every file attached to the Employee record (which,
# since events/employee.copy_onboarding_attachments runs on every new hire,
# already includes everything gathered during onboarding: Aadhaar, PAN,
# marksheets, photo, medical fitness certificate, etc.).
import base64
import io
from collections import Counter

import frappe
from frappe import _
from frappe.utils import cint, format_date
from frappe.utils.pdf import get_pdf
from PIL import Image, ImageDraw, ImageOps
from pypdf import PdfReader, PdfWriter

EMBEDDABLE_IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "gif", "bmp", "webp", "tiff"}

# Same class names/structure as onboarding-documents.html's .ob-print-*
# rules, minus flexbox (wkhtmltopdf's WebKit doesn't support it - see the
# earlier "dossier" version's commit for that lesson): the two flex rows
# (office-wrap, sign-row) become two-cell tables instead, everything else
# is identical.
STYLE = """
	/* Poppins (loaded from Google Fonts in the <head> above) + #082f32,
	   not Arial + near-black - both the actual theme font and base text
	   color (arjun_theme.css: font-family: 'Poppins', ...; --font-color:
	   #082f32), which the Review page gets for free by rendering inside
	   the full themed site. Matched here explicitly for the same reason
	   as .ob-print-box below - this PDF has nothing else to inherit
	   either from. 'Noto Sans Devanagari' comes right after Poppins for
	   exactly the bilingual consent questions (onboarding_consent_
	   question.json's fixture data, e.g. "Do you have conveyance. क्या
	   आपके पास कन्वेंस है?") - Poppins has no Devanagari glyphs at all, and
	   unlike a real browser (which silently substitutes a system font
	   for whatever glyphs the page font is missing), wkhtmltopdf's
	   WebKit renders those characters as a row of missing-glyph boxes
	   instead if NO font in the whole stack can supply them. Per-glyph
	   font-family fallback (CSS's normal behaviour) means English text
	   in the same string still renders in Poppins; only the Hindi
	   portion falls through. Noto Sans Devanagari itself is embedded as
	   a base64 @font-face (_embedded_devanagari_font_css(), prepended to
	   this STYLE block in download_employee_data()), not loaded from the
	   Google Fonts <head> link the way Poppins still is - a production
	   server with no outbound access to third-party domains silently
	   dropped that link entirely, which this bundled-file approach
	   doesn't depend on. */
	body { font-family: 'Poppins', 'Noto Sans Devanagari', Arial, Helvetica, sans-serif; color: #082f32; margin: 0; font-size: 11.5px; }
	/* Uppercases every rendered value/label in the digital-file PDF - a
	   CSS transform, not a data change (the doc fields underneath are
	   untouched) - matching the same rule on the reference
	   onboarding-documents.html page's #review-content. Scoped to
	   .content, not body, so the .footer line (generated-by timestamp/
	   username, not part of the form itself) keeps its normal casing. */
	.content { padding: 24px 40px; text-transform: uppercase; }
	.company { font-size: 15px; font-weight: bold; text-align: center; }
	.company-logo { display: block; margin: 0 auto 12px; max-height: 140px; max-width: 440px; }
	.ob-print-title { text-align: center; color: #c23b3b; font-weight: 700; font-size: 17px; margin-bottom: 14px; letter-spacing: .02em; }
	/* Logo/company/title/office-table on the left, photo box on the right,
	   as ONE table row - not the photo trailing in normal flow after the
	   title block (which is what put it low on the page, well past the
	   header, instead of sitting in the top-right corner next to the logo
	   like an application-form photo box should). vertical-align:top pins
	   both columns to the same starting line. */
	table.header-wrap { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
	table.header-wrap td { vertical-align: top; padding: 0; }
	table.header-wrap td.header-photo { text-align: right; width: 240px; padding-left: 24px; }
	/* table-layout:fixed + an explicit width, unlike the reference page -
	   the reference sizes this table by flexbox content-fit (no equivalent
	   in wkhtmltopdf's WebKit, see the file-level note), so it needs its
	   own explicit sizing here instead; padding/font-size below still
	   match the reference exactly, so it doesn't come out visually
	   cramped next to everything else. */
	.ob-print-office-table { border-collapse: collapse; table-layout: fixed; width: 560px; }
	.ob-print-office-table th, .ob-print-office-table td { border: 1px solid #c23b3b; color: #c23b3b; padding: 9px 16px; font-size: 13px; text-align: center; vertical-align: middle; word-wrap: break-word; }
	.page-break { page-break-before: always; height: 0; margin: 0; padding: 0; }
	.ob-print-side { font-size: 13px; color: #082f32; display: inline-block; text-align: left; }
	.ob-print-side div { margin-bottom: 26px; border-bottom: 1px solid #333; padding-bottom: 3px; min-width: 180px; }
	.photo { width: 200px; height: 240px; border: 1px solid #000; object-fit: cover; margin-bottom: 8px; }
	/* On the onboarding portal's own print-preview page (onboarding-
	   documents.html), these section titles pick up a teal color from the
	   site's global theme stylesheet (arjun_theme) - that page is
	   rendered inside the full website, so the theme's CSS cascades in
	   for free. This PDF has no such thing to inherit from: it's built as
	   one isolated, self-contained HTML document handed straight to
	   wkhtmltopdf, with nothing loaded but this STYLE block - so without
	   setting it explicitly here, every section title fell back to plain
	   body-text black/gray instead of matching. #082f32 is that same
	   theme's brand teal (also used for "Explore"/"Social Posts" on Hrms
	   Home - see arjun_theme.css). */
	/* display:table (not inline-block) so margin:auto actually centers it -
	   inline-block only honors a *parent's* text-align, margin:auto does
	   nothing on it; display:table shrink-wraps to its content exactly
	   like inline-block did, but is a block-level box margin:auto can
	   center, and wkhtmltopdf's WebKit renders it fine (unlike flexbox). */
	.ob-print-box { display: table; border: 1.5px solid #333; color: #082f32; padding: 6px 16px; font-weight: 700; font-size: 14px; margin: 20px auto 12px; letter-spacing: .01em; page-break-after: avoid; }
	.ob-print-box.blue { border-color: #2952cc; color: #2952cc; }
	/* page-break-after:avoid on the box above is a one-sided, advisory rule
	   wkhtmltopdf's WebKit doesn't reliably honour on its own - a section
	   heading (e.g. "DECLARATION") could still land as the very last thing
	   on a page with its own paragraph/table pushed alone onto the next
	   one, reading as content cut off mid-section. Reinforcing from the
	   other side too - the element immediately following a box also
	   refusing to start a fresh page - makes the pair behave as one unit:
	   if it doesn't fit together, the whole thing moves to the next page
	   instead of splitting apart. */
	.ob-print-box + p,
	.ob-print-box + div,
	.ob-print-box + table { page-break-before: avoid; }
	.ob-form-divider { border: none; border-top: 3px double #999; margin: 36px 0; }
	.ob-print-fine { font-size: 12px; color: #555; margin: 6px 0; }
	.ob-print-fine ul, .ob-print-fine ol { margin: 4px 0 4px 18px; padding: 0; }
	.ob-print-blank-line { border-bottom: 1px solid #333; display: inline-block; min-width: 260px; }
	/* display:table - not text-align:center on each line, which centers
	   every "Label: value" div independently and, since each line's total
	   width differs with its value text, throws the fixed-width label
	   column out of alignment between rows (a ragged zigzag instead of a
	   clean block). This shrink-wraps the whole field list to its widest
	   line (same trick as .ob-print-box above), which is what keeps every
	   line's label column aligned with the others - no margin:auto here,
	   the block stays flush against the page's left edge like the rest of
	   the form. Matches the reference onboarding-documents.html page's
	   equivalent rule. */
	/* Fixed width (not 100%) so the label column below (a % width) has a
	   definite value to resolve against, and so the field list stays
	   within a printed A4/Letter page's content width - a page is
	   roughly 700-750px wide after margins at this rendering's scale, and
	   .ob-print-office-table above is already fixed at 560px for the same
	   reason. 700px matches the reference onboarding-documents.html
	   page's equivalent rule (that page's much wider on-screen container
	   has room to spare, but keeping the same figure in both keeps the
	   print preview and this PDF looking like the same form). */
	.ob-print-fields { width: 700px; font-size: 13px; line-height: 2.1; color: #082f32; text-align: left; }
	/* fields_block()'s label:value rows, as a real <table> - not the
	   inline-block + %-width column trick the reference onboarding-
	   documents.html page uses (which works fine there, in a real
	   browser). wkhtmltopdf's WebKit measures this same CSS with wider
	   font metrics, so "Father's / Husband's Name" wrapped mid-phrase at
	   the same %-width that never wraps on-screen, and a follow-up
	   text-indent hanging-indent attempt (matching .ob-print-fields'
	   *own* usual technique elsewhere in this file) clipped the label
	   off-page entirely instead - table layout is what this file's own
	   top-of-file note already prefers for exactly this class of
	   cross-renderer risk, so use it here too rather than fight
	   inline-block sizing further. Cell layout, not the inline-block/
	   colon trick, is what makes both the label (nowrap, generous
	   min-width) and a wrapped value (indented under itself via the
	   value cell's own left edge, not the page margin) reliable. */
	.ob-print-fields table.field-rows { width: 100%; border-collapse: collapse; }
	.ob-print-fields table.field-rows td { vertical-align: top; padding: 0; }
	.ob-print-fields table.field-rows td.lbl { font-weight: 600; white-space: nowrap; min-width: 200px; padding-right: 6px; }
	.ob-print-fields table.field-rows td.colon { width: 14px; }
	.ob-print-table { width: 100%; border-collapse: collapse; margin-bottom: 6px; font-size: 12.5px; }
	.ob-print-table th, .ob-print-table td { border: 1px solid #333; padding: 7px 8px; text-align: center; }
	.ob-print-table th { font-weight: 600; background: #f7f7f7; }
	/* Row-level, not on the table itself - the table as a whole is still
	   free to break across a page between rows (that's fine and normal),
	   this only stops one individual row's cells from being sliced in
	   half by a page boundary, which is what actually reads as "cut off"
	   and unprofessional on the 5 statutory forms (ESIC/EPF/Gratuity/
	   Form 11) each of which already starts on its own fresh page - see
	   the page-break div before each of their box() calls below. */
	.ob-print-table tr, .ob-print-office-table tr, table.sign-row tr { page-break-inside: avoid; }
	.ob-print-declaration { font-size: 12.5px; margin: 8px 0 22px; color: #082f32; }
	table.sign-row { width: 100%; margin-bottom: 30px; font-size: 13px; border-collapse: collapse; }
	table.sign-row td { vertical-align: top; padding: 0; }
	table.sign-row td.right { text-align: right; }
	.sub-label { font-size: 12.5px; font-weight: 600; margin: 10px 0 4px; }
	.section-title { font-size: 13px; font-weight: 700; margin: 16px 0 4px; }
	.doclist { font-size: 11px; margin: 0; padding-left: 18px; }
	.doclist li { margin-bottom: 3px; }
	.footer { font-size: 9px; color: #666; padding: 14px 40px; }
	.muted { font-style: italic; color: #666; }
	.sig { height: 50px; margin-bottom: 4px; }
"""


def _yn(value):
	return "Yes" if cint(value) else "No"


def _fmt(value, fieldtype=None):
	if not value:
		return ""
	if fieldtype == "Date":
		try:
			return format_date(value)
		except Exception:
			return value
	return value


def esc(value):
	if value in (None, ""):
		return ""
	return frappe.utils.escape_html(str(value))


def print_table(headers, rows, min_blank_rows=1):
	"""Mirrors onboarding-documents.html's JS printTable(headers, rows,
	minBlankRows) exactly: one header row, then either the given data rows
	or (if there are none) min_blank_rows worth of blank cells."""
	head = "".join(f"<th>{h}</th>" for h in headers)
	if not rows:
		body_rows = "".join(
			"<tr>" + "".join("<td>&nbsp;</td>" for _h in headers) + "</tr>" for _i in range(min_blank_rows)
		)
	else:
		body_rows = ""
		for row in rows:
			cells = "".join(f"<td>{esc(c) or '&nbsp;'}</td>" for c in row)
			body_rows += f"<tr>{cells}</tr>"
	return f"<table class='ob-print-table'><thead><tr>{head}</tr></thead><tbody>{body_rows}</tbody></table>"


def fields_block(rows):
	"""Mirrors .ob-print-fields: stacked "Label: value" lines - used only
	where the reference itself uses this (Personal Data's main field list,
	Employee History's Fresher/Experienced line), not as a substitute for
	print_table."""
	rows_html = "".join(
		f"<tr><td class='lbl'>{esc(k)}</td><td class='colon'>:</td><td>{esc(v) or '&nbsp;'}</td></tr>"
		for k, v in rows
	)
	return f"<div class='ob-print-fields'><table class='field-rows'>{rows_html}</table></div>"


def _val(*candidates):
	"""First truthy value - lets a section fall back from Employee
	Onboarding data to the Employee doctype's own matching field (Father
	Name, Current/Permanent Address, Aadhaar Number, ESIC Number, UAN -
	all present as real fields on Employee's own Personal Details/Address
	tabs) whenever an employee has no linked onboarding at all, or the
	onboarding record just never had that particular field filled in.
	Without this, an employee created directly (no job_applicant, so
	_get_onboarding() returns None - e.g. bulk-imported or manually added
	staff) prints every one of these as blank even when HR has since filled
	the same fact in on the Employee record itself."""
	for c in candidates:
		if c:
			return c
	return None


def box(title, blue=False):
	cls = "ob-print-box blue" if blue else "ob-print-box"
	return f"<div class='{cls}'>{esc(title)}</div>"


def child_rows(rows, columns):
	"""columns: list of fieldnames (or callables taking a row) in table-column order."""
	out = []
	for row in rows or []:
		cells = []
		for col in columns:
			cells.append(col(row) if callable(col) else row.get(col))
		out.append(cells)
	return out


def _get_onboarding(emp_doc):
	if not emp_doc.get("job_applicant"):
		return None
	name = frappe.db.get_value("Employee Onboarding", {"job_applicant": emp_doc.job_applicant}, "name")
	if not name:
		return None
	return frappe.get_doc("Employee Onboarding", name)


def _embed_file(file_url, attached_to_doctype=None, attached_to_name=None):
	"""Base64 data-URI for a File record, resolved the same way regardless
	of what it's attached to (employee photo, company logo, ...). Returns
	None (never raises) if the file can't be read - callers just omit the
	<img> in that case."""
	if not file_url:
		return None
	import base64

	filters = {"file_url": file_url}
	if attached_to_doctype:
		filters["attached_to_doctype"] = attached_to_doctype
		filters["attached_to_name"] = attached_to_name
	try:
		file_doc = frappe.get_doc("File", filters)
	except Exception:
		try:
			file_doc = frappe.get_doc("File", {"file_url": file_url})
		except Exception:
			return None
	try:
		content = file_doc.get_content()
	except Exception:
		return None

	ext = (file_url.rsplit(".", 1)[-1] or "png").lower()
	mime = {"jpg": "jpeg"}.get(ext, ext)
	if mime not in ("png", "jpeg", "gif", "webp", "svg+xml"):
		mime = "png"
	return f"data:image/{mime};base64,{base64.b64encode(content).decode()}"


def _company_logo_html(emp_doc):
	logo_url = frappe.db.get_value("Company", emp_doc.company, "company_logo")
	data_uri = _embed_file(logo_url, "Company", emp_doc.company)
	if not data_uri:
		return ""
	return f'<img src="{data_uri}" class="company-logo">'


COMPANY_LETTERHEAD_PREFIX = {
	"OM Logistics Supply Chain PVT. LTD.": "olscpl",
	"SANJVIK TERMINALS PVT LTD": "sanjvik",
	"OM TELECOM LOGISTICS PVT LTD": "telecom",
	"OPEN SOURCE BUSINESS SOLUTIONS PVT LTD": "rapidshyp",
	"TRANSAFE SERVICES LTD": "transafe",
}


def company_letterhead_urls(company):
	"""(header_url, footer_url) for this company's letterhead crops under
	public/files/letterheads/ (see the README there), or (None, None) if
	this company doesn't have one. Shared by
	patches/v1_1/setup_company_letterheads.py (wires these into Frappe's
	own Letter Head doctype, for every print format that already checks
	the document's/company's letterhead) and appointment_letter.py (which
	builds its own standalone PDF outside that system and embeds these
	images directly) - one mapping, not duplicated in each."""
	prefix = COMPANY_LETTERHEAD_PREFIX.get(company)
	if not prefix:
		return None, None
	base = "/assets/olscpl_hrms/files/letterheads"
	return f"{base}/{prefix}_header.jpg", f"{base}/{prefix}_footer.jpg"


def company_address_line(company):
	"""Plain 'COMPANY NAME, address line, city, state pincode, country' text
	for the statutory forms' blank "Name and Address of Employer/
	Establishment" cells (ESIC TIC, EPF Nomination & Declaration) - those
	were always just left blank (&nbsp;) for someone to write in by hand,
	which made sense on the original paper form but not on a system-
	generated one where the employer is always the same company and its
	address is already on file. get_address_display() (the usual Frappe
	helper for this) also appends an Email: line, which reads oddly
	crammed into a small table cell here - built directly from the
	Address doctype's own fields instead, comma-joined, skipping any
	that are empty. Returns "" (not the bare company name) if the
	company has no address on file, since a half-filled cell reads worse
	than one still blank - shared by both employee_data.py and
	onboarding_portal.py's get_application_data() (the two places this
	is used), not duplicated in each.
	"""
	if not company:
		return ""
	from frappe.contacts.doctype.address.address import get_default_address

	address_name = get_default_address("Company", company)
	if not address_name:
		return ""
	addr = frappe.db.get_value(
		"Address",
		address_name,
		["address_line1", "address_line2", "city", "state", "pincode", "country"],
		as_dict=True,
	)
	if not addr:
		return ""
	parts = [company, addr.address_line1, addr.address_line2, addr.city, addr.state, addr.pincode, addr.country]
	return ", ".join(p for p in parts if p)


def _header_html(emp_doc, ob=None):
	# emp_doc.image (the Employee doctype's own photo field) is almost
	# never actually set - copy_onboarding_attachments() (events/
	# employee.py) copies the candidate's uploaded documents over as plain
	# File attachments on hire, it doesn't populate this field. The photo
	# the candidate actually uploaded during onboarding lives in their
	# Document Checklist instead, as the "file" on whichever row's
	# document_type is "Photograph" - that's the real source for this box,
	# with emp_doc.image only as a fallback for a photo HR set manually
	# after the fact.
	if emp_doc.image:
		photo_uri = _embed_file(emp_doc.image, "Employee", emp_doc.name)
	else:
		photo_uri = None
		for row in (ob.get("onboarding_documents") if ob else None) or []:
			if row.get("document_type") == "Photograph" and row.get("file"):
				photo_uri = _embed_file(row.get("file"))
				break

	image_html = f'<img src="{photo_uri}" class="photo">' if photo_uri else ""

	office_table = f"""
	<table class="ob-print-office-table">
		<tr><th colspan="4">FOR OFFICE USE ONLY</th></tr>
		<tr><th>D.O.J</th><th>STATION BRANCH</th><th>DEPTT.</th><th>SALARY AT TIME OF JOINING</th></tr>
		<tr>
			<td>{esc(_fmt(emp_doc.date_of_joining, "Date")) or "&nbsp;"}</td>
			<td>{esc(emp_doc.branch) or "&nbsp;"}</td>
			<td>{esc(emp_doc.department) or "&nbsp;"}</td>
			<td>&nbsp;</td>
		</tr>
	</table>
	"""
	side = f"""
	<div class="ob-print-side">
		{image_html}
		<div>Post Applied For: {esc(emp_doc.designation)}</div>
		<div>Employee Code: {esc(emp_doc.name)}</div>
	</div>
	"""

	main = f"""
	{_company_logo_html(emp_doc)}
	<div class="company">{esc(emp_doc.company)}</div>
	<div class="ob-print-title">APPLICATION FORM</div>
	{office_table}
	"""

	# One row, not the photo trailing after the logo/title/office-table in
	# normal document flow - that put it well down the page instead of in
	# the top-right corner where an application-form photo box belongs.
	return f"""
	<table class="header-wrap"><tr>
		<td>{main}</td>
		<td class="header-photo">{side}</td>
	</tr></table>
	"""


def _personal_data_section(emp_doc, ob):
	html = box("PERSONAL DATA", blue=True)
	html += fields_block([
		("Name", emp_doc.employee_name),
		("Father's / Husband's Name", _val(ob.father_name if ob else None, emp_doc.get("custom_father_name"))),
		("Present Address", _val(ob.present_address if ob else None, emp_doc.get("current_address"))),
		("Permanent Address", _val(ob.permanent_address if ob else None, emp_doc.get("permanent_address"))),
		("Pin Code", ob.pincode if ob else None),
		("Phone Number", _val(ob.candidate_phone if ob else None, emp_doc.cell_number)),
		("Parents Number", ob.parents_phone_number if ob else None),
		("Aadhaar No", _val(ob.aadhaar_number if ob else None, emp_doc.get("custom_aadhaar_number"))),
		("Whether you live in", ob.lives_in if ob else None),
		("Sex", _val(ob.gender if ob else None, emp_doc.gender)),
		("E-mail Id", _val(ob.candidate_email if ob else None, emp_doc.personal_email)),
	])
	html += print_table(
		["DOB", "Place of Birth", "Nationality", "Religion", "Marital Status", "Dependents"],
		[[
			_fmt(_val(ob.candidate_dob if ob else None, emp_doc.date_of_birth), "Date"),
			ob.place_of_birth if ob else None,
			ob.nationality if ob else None,
			ob.religion if ob else None,
			ob.marital_status if ob else None,
			ob.dependents if ob else None,
		]],
	)
	return html


def _kyc_section(ob):
	html = box("KYC DETAILS")
	html += print_table(
		["KYC Document Type", "Name as on KYC Document", "Number", "Remarks"],
		child_rows(ob.get("kyc_details") if ob else [], ["kyc_type", "name_on_document", "number", "remarks"]),
	)
	return html


def _education_section(ob):
	html = box("EDUCATIONAL QUALIFICATION")
	html += print_table(
		["Examination Passed", "Year of Passing", "School/College/Univ.", "Subject", "%Age of Marks", "Div/Grade Obtained"],
		child_rows(
			ob.get("education_details") if ob else [],
			["examination_passed", "year_of_passing", "institute", "subject", "percentage_marks", "grade_obtained"],
		),
	)
	return html


def _technical_qualification_section(ob):
	html = box("TECHNICAL QUALIFICATION")
	html += print_table(
		["Typing (speed)", "Stenography (speed)", "Computer (Know How)", "Any other"],
		[[ob.technical_typing, ob.technical_stenography, ob.technical_computer, ob.technical_other]] if ob else [],
	)
	return html


def _employment_history_section(ob):
	html = box("EMPLOYEE HISTORY")
	fresher_experienced = "Experienced" if (ob and cint(ob.is_experienced)) else "Fresher"
	html += fields_block([("Fresher / Experienced", fresher_experienced)])
	html += print_table(
		["From", "To", "Company Name & Address", "Designation & Nature of Work", "Gross Emoluments", "Reason for Leaving"],
		child_rows(
			ob.get("employment_history") if ob else [],
			[
				lambda r: _fmt(r.get("from_date"), "Date"),
				lambda r: _fmt(r.get("to_date"), "Date"),
				"company_address", "designation", "gross_emoluments", "reason_for_leaving",
			],
		),
	)
	return html


def _extra_curricular_section(ob):
	html = box("EXTRA CURRICULAR ACTIVITIES")
	value = esc(ob.extra_curricular_activities) if ob else ""
	html += f"<div class='ob-print-fields'><div>{value or '&nbsp;'}</div></div>"
	return html


def _salary_breakup_section(ob):
	html = box("PRESENT SALARY BREAK-UP")
	if ob:
		grand_total = ob.get("salary_grand_total") or sum(
			frappe.utils.flt(ob.get(f))
			for f in ("salary_basic", "salary_da", "salary_hra", "salary_cca", "salary_conveyance", "salary_other_allowance")
		)
		row = [ob.salary_basic, ob.salary_da, ob.salary_hra, ob.salary_cca, ob.salary_conveyance,
			ob.salary_other_allowance, grand_total or None, ob.expected_gross_salary]
	else:
		row = []
	html += print_table(
		["Basic", "DA", "HRA", "CCA", "Conveyance", "Other Allowance", "Grand Total", "Expected Gross Salary"],
		[row] if ob else [],
	)
	return html


def _languages_section(ob):
	html = box("LANGUAGES KNOWN")
	html += print_table(
		["Language", "Understand", "Speak", "Read", "Write", "Other Remarks"],
		child_rows(
			ob.get("languages_known") if ob else [],
			["language", lambda r: _yn(r.get("understand")), lambda r: _yn(r.get("speak")),
			 lambda r: _yn(r.get("read")), lambda r: _yn(r.get("write")), "remarks"],
		),
	)
	return html


def _family_background_section(ob):
	html = box("FAMILY BACKGROUND")
	html += print_table(
		["Name", "Relation", "Qualification", "Occupation", "Mobile No", "DOB", "Residing With", "Nominee"],
		child_rows(
			ob.get("family_members") if ob else [],
			["member_name", "relation", "qualification", "occupation", "mobile_no",
			 lambda r: _fmt(r.get("date_of_birth"), "Date"), lambda r: _yn(r.get("residing_with")), lambda r: _yn(r.get("nominee"))],
		),
	)
	return html


def _background_integrity_section(ob):
	html = box("BACKGROUND & INTEGRITY")
	if ob:
		rows = [
			["Personally connected with any business at present?", _yn(ob.connected_to_business), ob.connected_to_business_details],
			["Relation/friends working in OM Group?", _yn(ob.relatives_in_om_group), ob.relatives_in_om_group_details],
			["Relation/friends in prominent Govt. positions?", _yn(ob.relatives_in_govt), ob.relatives_in_govt_details],
			["Has a Provident Fund Account?", _yn(ob.has_pf_account), ob.has_pf_account_details],
			["Self or family member arrested/prosecuted/convicted?", _yn(ob.prior_arrest), ob.prior_arrest_details],
		]
	else:
		rows = []
	html += print_table(["Question", "Response", "Details"], rows)
	return html


def _physical_data_section(ob):
	html = box("PHYSICAL DATA")
	html += print_table(
		["Height", "Weight", "Physical Disability", "Had Serious Illness", "Accident, if any"],
		[[ob.height, ob.weight, _yn(ob.physical_disability), _yn(ob.serious_illness), ob.accident_details]] if ob else [],
	)
	return html


def _reference_section(ob):
	html = box("REFERENCE")
	html += print_table(
		["Name", "Status & Address"],
		child_rows(ob.get("job_references") if ob else [], ["reference_name", "status_and_address"]),
	)
	return html


def _document_checklist_section(ob):
	html = box("DOCUMENT CHECKLIST")
	html += print_table(
		["Document", "Mandatory", "Status"],
		child_rows(
			ob.get("onboarding_documents") if ob else [],
			["document_type", lambda r: _yn(r.get("mandatory")), lambda r: "Submitted" if cint(r.get("candidate_submitted")) else "Pending"],
		),
	)
	return html


def _dedupe_consent_rows(rows):
	"""A onetime data issue (two independent "Onboarding Consent Question"
	master records ended up existing for the same question text - a
	fixture-vs-already-existing-data collision, not something this
	function can fix at the source) has left some Employee Onboarding
	records with the same question appearing twice in consent_responses.
	Collapses to one row per question_text, preferring whichever copy
	actually has a candidate_response (Yes/No) over a still-blank one, so
	the printed form doesn't show every question doubled regardless of
	whether/when the underlying master data gets cleaned up."""
	by_question = {}
	order = []
	for row in rows or []:
		key = row.get("question_text")
		if key not in by_question:
			by_question[key] = row
			order.append(key)
		elif not by_question[key].get("candidate_response") and row.get("candidate_response"):
			by_question[key] = row
	return [by_question[k] for k in order]


def _consent_section(ob):
	html = box("CONSENT FORM")
	html += print_table(
		["Question", "Response"],
		child_rows(
			_dedupe_consent_rows(ob.get("consent_responses")) if ob else [],
			["question_text", lambda r: r.get("candidate_response") or ""],
		),
	)
	return html


_BLANK_SIG = "<span class='ob-print-blank-line'>&nbsp;</span>"


def get_user_signature(user):
	"""A user's signature for "Authorised Signatory" lines: their uploaded
	image (User.custom_signature_image). The old drawn custom_signature is
	not a fallback - it was moved into the upload field and cleared (see
	patches/v1_1/convert_user_signature_to_upload.py), so removing the upload
	really removes the signature. Raw value - pass it through
	_flatten_signature_on_white() before putting it in an <img>."""
	if not user:
		return None
	return frappe.db.get_value("User", user, "custom_signature_image")


def _flatten_signature_on_white(data_url):
	"""Two independent things can make a signature unreadable here, both
	fixed once, in one place, before it ever reaches an <img> tag:

	1. HR's own signature is drawn with the Signature fieldtype's canvas
	   (jSignature) on their User profile - that canvas itself starts
	   fully transparent (only the CSS background behind it is colored,
	   which the exported image never captures), so it exports with real
	   alpha transparency. Fine in a browser; wkhtmltopdf renders PNG
	   alpha incorrectly and paints every transparent pixel solid black
	   instead of compositing it - flattening onto an explicit white
	   background sidesteps that renderer bug entirely.

	2. The candidate's signature is a photo they uploaded (see
	   onboarding-documents.html's initSignaturePad - it's a plain file
	   input, not a drawing pad), and a photo taken in bad light can come
	   out almost uniformly dark - technically not a bug in anything here,
	   just a bad photo, but one candidates are likely to submit often
	   enough (photographing ink on paper) that it's worth rescuing:
	   stretch the contrast, and if the dominant colour is dark (background
	   ended up darker than the ink, i.e. inverted from a normal white-
	   paper photo), invert it back the right way round. A photo that's
	   already a normal light-paper/dark-ink shot is left as it was -
	   autocontrast on an already high-contrast image is a no-op, and the
	   inversion only fires when the *background* reads as dark.
	"""
	if not data_url:
		return data_url
	# An uploaded signature (User.custom_signature_image, a /files/ or
	# /private/files/ URL) - embed it so it renders in wkhtmltopdf and on the
	# guest onboarding portal regardless of the file being private.
	if not data_url.startswith("data:image"):
		data_url = _embed_file(data_url) or data_url
		if not data_url.startswith("data:image"):
			return data_url
	try:
		_header, b64data = data_url.split(",", 1)
		img = Image.open(io.BytesIO(base64.b64decode(b64data)))
		if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
			img = img.convert("RGBA")
			white_bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
			white_bg.paste(img, mask=img.split()[-1])
			img = white_bg.convert("RGB")
		else:
			img = img.convert("RGB")

		small = img.resize((60, 60))
		dominant = Counter(small.getdata()).most_common(1)[0][0]
		dominant_luminance = sum(dominant) / 3

		img = ImageOps.autocontrast(img, cutoff=1)
		if dominant_luminance < 128:
			img = ImageOps.invert(img)
		img = _isolate_signature_ink(img)

		buf = io.BytesIO()
		img.save(buf, format="PNG")
		return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
	except Exception:
		frappe.log_error(title="Signature flatten failed")
		return data_url


# Pixels darker than this are ink; a light card border, paper tone or
# shadow is not. Anything lighter than PAPER_FLOOR becomes pure white.
_INK_MAX = 140
_PAPER_FLOOR = 200


def _isolate_signature_ink(img):
	"""Just the signature: crop to the ink strokes (dropping the empty margins
	and any light frame/card border around them, e.g. a screenshot of a
	signature card) and turn the remaining paper tone pure white, so it
	vanishes on the white page. Stays white, not transparent - see
	_flatten_signature_on_white (wkhtmltopdf paints alpha black)."""
	# A dark image corner is the area outside a card/frame (e.g. a screenshot
	# of a rounded signature card has solid black corners), not ink - paint
	# it white first so it neither counts as ink nor shows on the letter.
	w, h = img.size
	corners = ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1))
	if any(sum(img.getpixel(c)) / 3 < _INK_MAX for c in corners):
		# A framed card: clear everything non-white that touches the image
		# edge (the corners, the card's border line and its anti-aliasing).
		# Only for this case - a photo's ink near an edge is left alone.
		edge = [(x, 0) for x in range(w)] + [(x, h - 1) for x in range(w)]
		edge += [(0, y) for y in range(h)] + [(w - 1, y) for y in range(h)]
		for xy in edge:
			if sum(img.getpixel(xy)) / 3 < 235:
				ImageDraw.floodfill(img, xy, (255, 255, 255), thresh=90)
		# The rounded corners' anti-aliased inner curve sits a few px inside
		# the edge - the signature is well inside the card, so look for ink
		# only away from that band.
		band = max(6, round(min(w, h) * 0.04))
	else:
		band = 0
	ink = img.convert("L").point(lambda v: 255 if v < _INK_MAX else 0)
	box = ink.crop((band, band, w - band, h - band)).getbbox()
	if box and band:
		box = (box[0] + band, box[1] + band, box[2] + band, box[3] + band)
	if not box:
		return img  # nothing clearly ink-dark - leave the image as it was
	pad = max(4, round(min(img.size) * 0.02))
	img = img.crop((
		max(box[0] - pad, 0), max(box[1] - pad, 0),
		min(box[2] + pad, img.width), min(box[3] + pad, img.height),
	))
	return img.point(lambda v: 255 if v > _PAPER_FLOOR else v)


def _employee_signature_html(ob):
	"""The candidate's own signature, drawn on the signature pad during
	onboarding (Employee Onboarding.candidate_signature - a data-URL, same
	field the portal's own review step already renders). Used everywhere a
	form asks for "Signature of the Employee/Member/Subscriber/Insured
	Person" - it's the same person, just worded differently per statutory
	form. No leading <br> here (unlike this function's older version) -
	see _signature_block() below, which is what every call site now uses
	to put this above its own label instead of below it."""
	if ob and ob.candidate_signature:
		sig = _flatten_signature_on_white(ob.candidate_signature)
		return f"<img src='{sig}' class='sig'>"
	return _BLANK_SIG


def _hr_signature_html(ob):
	"""Whoever actually sent this candidate their onboarding link
	(Employee Onboarding.portal_link_sent_by, set in generate_portal_link)
	signs on their own User profile once (see the "Signature" field added
	in patches/v1_1/add_user_signature_field.py); that's who's standing in
	for "Employer/Authorised Signatory" on every form here."""
	if not ob or not ob.portal_link_sent_by:
		return _BLANK_SIG
	signature = get_user_signature(ob.portal_link_sent_by)
	if signature:
		sig = _flatten_signature_on_white(signature)
		return f"<img src='{sig}' class='sig'>"
	return _BLANK_SIG


def _signature_block(label, sig_html):
	"""Signature (or a blank line to sign on, for a still-blank template)
	above its own caption - "Signature of the Employee" etc. printed
	*underneath* the mark, the way a real paper form works (you sign on
	the line; the line's caption sits below it), not the caption followed
	by the signature underneath it, which every call site used to do and
	reads backwards next to an actual signed/printed form."""
	return f"{sig_html}<br>{label}"


def _declaration_section(emp_doc, ob):
	sig_html = _employee_signature_html(ob)
	date_str = frappe.utils.format_datetime(ob.portal_submitted_on, "dd-MM-yyyy") if ob and ob.get("portal_submitted_on") else frappe.utils.now_datetime().strftime("%d-%m-%Y")
	html = box("Declaration")
	html += (
		"<p class='ob-print-declaration'>I do hereby declare that I have correctly furnished all above "
		"information after fully understanding the questions &amp; the same are true &amp; complete in every "
		"respect to the best of my knowledge &amp; belief. I further undertake that in the event above "
		"information being found untrue or material information is found to have been with held by me; I "
		"hereby accept the right of the company to terminate my services forthwith, without assigning any "
		"reason thereof. Further my appointment is subject to my being found fit by the medical officer of "
		"the company or other medical officer designated by the company for the purpose.</p>"
	)
	html += f"""
	<table class="sign-row"><tr>
		<td>Date: {esc(date_str)}</td>
		<td class="right">{_signature_block("Signature:", sig_html)}</td>
	</tr></table>
	"""
	return html


# ==================================================================
# Statutory declaration forms - same section boxes and multi-column grid
# tables as onboarding-documents.html's renderReview(), populated with
# whatever's on record (that page itself prints these blank, since at
# candidate-fill time HR hasn't entered them yet; by the time an Employee
# record exists, Employee Onboarding's "Statutory Declarations" tab
# usually has). Any cell without a matching field is left blank exactly
# like the reference, not guessed.
# ==================================================================


def _esic_family_rows(ob):
	"""esic_family_members (see the STATUTORY_CHILD_TABLE_FIELDS comment
	in onboarding_portal.py) is its own separate child table from
	family_members (candidate-filled in Personal Data / Family
	Background), so a submitted application that predates the candidate
	portal's ESIC pre-fill (see onboarding-documents.html's
	loadApplicationData) - or where the candidate just left it empty -
	prints this table blank even though the same names/DOBs already exist
	one section earlier. Falls back to family_members, mapped onto
	esic_family_members' narrower shape (its "relation" -> "relationship";
	qualification/occupation/mobile_no/nominee have no equivalent column
	here and are dropped), whenever esic_family_members itself is empty."""
	if not ob:
		return []
	rows = ob.get("esic_family_members") or []
	if rows:
		return rows
	return [
		{
			"member_name": m.get("member_name"),
			"date_of_birth": m.get("date_of_birth"),
			"relationship": m.get("relation"),
			"residing_with": m.get("residing_with"),
		}
		for m in (ob.get("family_members") or [])
	]


def _esic_nominee_rows(ob):
	"""The ESIC TIC's own "Nomination - u/s 50(2)... for Payment of Any
	Benefit Due in the Event of Death" table - who's nominated, not the
	whole family (that's _esic_family_rows(), used by the Declaration
	Form's "Particulars of Family" table above it on the same page).
	esic_family_members has no nominee flag of its own to filter by, so
	this always derives from family_members' "Nominee" checkbox via
	_family_nominee_rows() (same spouse/mother default when nobody was
	explicitly ticked), same as _epf_nominee_rows()/_gratuity_nominee_rows()
	- this table was wrongly reusing _esic_family_rows() (the whole
	family) until this was split out, which showed every family member as
	if each were a nominee."""
	return [
		{
			"member_name": m.get("member_name"),
			"date_of_birth": m.get("date_of_birth"),
			"relationship": m.get("relation"),
		}
		for m in _family_nominee_rows(ob)
	]


def _esic_declaration_section(emp_doc, ob):
	html = "<div class='page-break'></div><hr class='ob-form-divider'>"
	html += box("DECLARATION FORMS (ESIC)", blue=True)
	html += (
		"<p class='ob-print-fine'>Form 1 &middot; Regulation 11 &amp; 12 (To be filled in only if the "
		"employee has not been insured earlier &mdash; Serial No. in Return of Declaration Form No. 3)</p>"
	)
	dob = _fmt(_val(ob.candidate_dob if ob else None, emp_doc.date_of_birth), "Date")
	doj = _fmt(emp_doc.date_of_joining, "Date")
	html += print_table(["ESIC / Insurance No", "Marital Status", "Employer's Code No"],
		[[_val(ob.esic_insurance_no if ob else None, emp_doc.get("custom_esic_number")), ob.marital_status if ob else None, ob.esic_employer_code if ob else None]])
	html += print_table(["Sex", "Name", "DOB"],
		[[_val(ob.gender if ob else None, emp_doc.gender), emp_doc.employee_name, dob]])
	html += print_table(["Father's/Husband's Name", "Date of Appointment"],
		[[_val(ob.father_name if ob else None, emp_doc.get("custom_father_name")), doj]])
	html += print_table(["Permanent Address", "Present Address"],
		[[_val(ob.permanent_address if ob else None, emp_doc.get("permanent_address")), _val(ob.present_address if ob else None, emp_doc.get("current_address"))]])
	html += print_table(["Local Office", "Dispensary"],
		[[ob.esic_local_office, ob.esic_dispensary]] if ob else [])
	html += (
		"<p class='ob-print-fine'>(State whether Bachelor, Spinster, Married, Widow or Widower.) N.B. Family "
		"particulars are required in duplicate. Please fold the TIC below backward &amp; insert carbon. "
		"Please see overleaf for definition of family.</p>"
	)
	html += "<p class='sub-label'>Particulars of Family</p>"
	html += print_table(
		["No.", "Name", "DOB", "Relationship with Insured Person", "Whether Residing with Him/Her or Not"],
		[
			[i + 1, r.get("member_name"), _fmt(r.get("date_of_birth"), "Date"), r.get("relationship"), _yn(r.get("residing_with"))]
			for i, r in enumerate(_esic_family_rows(ob))
		],
		min_blank_rows=3,
	)
	return html


def _esic_tic_section(emp_doc, ob):
	dob = _fmt(_val(ob.candidate_dob if ob else None, emp_doc.date_of_birth), "Date")
	doj = _fmt(emp_doc.date_of_joining, "Date")
	html = "<div class='page-break'></div><hr class='ob-form-divider'>"
	html += box("EMPLOYEES STATE INSURANCE CORPORATION (TEMPORARY IDENTIFICATION CERTIFICATE)")
	html += print_table(["ESIC / Insurance No", "Marital Status", "Employer's Code No"],
		[[_val(ob.esic_insurance_no if ob else None, emp_doc.get("custom_esic_number")), ob.marital_status if ob else None, ob.esic_employer_code if ob else None]])
	html += print_table(["Name", "Date of Appointment", "DOB"],
		[[emp_doc.employee_name, doj, dob]])
	html += print_table(["Present Residential Address", "Father's/Husband's Name", "Local Office"],
		[[_val(ob.present_address if ob else None, emp_doc.get("current_address")), _val(ob.father_name if ob else None, emp_doc.get("custom_father_name")), ob.esic_local_office if ob else None]])
	html += print_table(["Sex", "Dispensary"],
		[[_val(ob.gender if ob else None, emp_doc.gender), ob.esic_dispensary if ob else None]])
	html += f"""<table class="sign-row"><tr><td>&nbsp;</td>
		<td class="right">{_signature_block("Signature of Insured Person:", _employee_signature_html(ob))}</td>
	</tr></table>"""
	html += (
		"<p class='ob-print-fine'>Family means the spouse and minor legitimate/adopted children dependent on "
		"the insured person and his dependent parents (See (ii) of the ESI Act, 1948).</p>"
	)
	html += "<p class='sub-label'>'A' Particulars of Employment</p>"
	html += print_table(["Whether Employed Directly/Through Contractor", "Department", "Nature of Work"],
		[[None, emp_doc.department, emp_doc.designation]])
	html += "<p class='sub-label'>Nomination &mdash; u/s 50(2) for Females Only and 71 of the ESI Act, for Payment of Any Benefit Due in the Event of Death</p>"
	# This was always print_table(..., []) - hardcoded blank regardless of
	# data - then (still a bug) briefly sourced from _esic_family_rows(),
	# the whole family, showing every family member as if each were a
	# nominee. This is specifically a nomination, same concept as EPF's
	# Part A / Gratuity's Nominee(s) table, not a family listing (that's
	# the "Particulars of Family" table just above, on this same form) -
	# _esic_nominee_rows() is the ESIC-shaped version of the same
	# nominee-selection _epf_nominee_rows()/_gratuity_nominee_rows() use.
	# No dedicated "Father's Name"/"Address" column exists on this data
	# either way, so those two stay blank per row.
	html += print_table(
		["Name of Nominee", "DOB", "Father's Name", "Relationship of the Nominee with Insured Person", "Address"],
		child_rows(
			_esic_nominee_rows(ob),
			["member_name", lambda r: _fmt(r.get("date_of_birth"), "Date"), lambda r: None, "relationship", lambda r: None],
		),
	)
	html += (
		"<p class='ob-print-fine'>I affirm that I have not been previously insured under the Act and no "
		"identity card has been issued to me. I hereby declare that the above particulars have been given by "
		"me and are correct to the best of my knowledge and belief. I also undertake to intimate the "
		"Corporation of any change in the membership of my family within 15 days of such change having "
		"occurred.</p>"
	)
	html += f"""<table class="sign-row"><tr>
		<td>Place: <span class="ob-print-blank-line">&nbsp;</span><br>Date of Signing the Form: <span class="ob-print-blank-line">&nbsp;</span></td>
		<td class="right">{_signature_block("Signature of the Employee:", _employee_signature_html(ob))}</td>
	</tr></table>"""
	# Not print_table() - that escapes every cell (fine for plain data, but
	# would turn the signature <img> into literal escaped markup).
	html += f"""<table class='ob-print-table'><thead><tr>
		<th>Name and Address of Employer</th><th>Counter Signature of Employer, Designation</th>
	</tr></thead><tbody><tr>
		<td>{esc(company_address_line(emp_doc.company)) or "&nbsp;"}</td><td>{_hr_signature_html(ob)}</td>
	</tr></tbody></table>"""
	return html


def _family_nominee_rows(ob):
	"""Who Part A's (EPF) nomination table, and Part B's (EPS) second
	table - the explicit "nominate the following person... without
	leaving any eligible family member for receiving pension" fallback,
	not Part B's first table (see _eps_family_rows() for that one, which
	wants the whole family regardless of nomination) - should list, when
	epf_nominees itself is empty. Same situation _esic_family_rows()
	handles for the ESIC Declaration (a separate HR-only table nobody had
	a reason to fill a second time, duplicating Family Background), but
	scoped to actual nominees rather than the whole family: only the
	family_members rows the candidate ticked "Nominee" on. If they didn't
	tick anyone, defaults to the spouse (Wife/Husband) when married,
	otherwise the mother - standard EPF/EPS practice for an application
	with no explicit nomination made, rather than leaving the form blank."""
	if not ob:
		return []
	family = ob.get("family_members") or []
	nominees = [m for m in family if cint(m.get("nominee"))]
	if nominees:
		return nominees
	if (ob.marital_status or "") == "Married":
		return [m for m in family if m.get("relation") in ("Wife", "Husband")]
	return [m for m in family if m.get("relation") == "Mother"]


def _epf_nominee_rows(ob):
	rows = ob.get("epf_nominees") if ob else []
	if rows:
		return rows
	return [
		{
			"nominee_name": m.get("member_name"),
			"address": m.get("address"),
			"relationship": m.get("relation"),
			"date_of_birth": m.get("date_of_birth"),
			"share_percentage": m.get("share_percentage"),
			"guardian_details": m.get("guardian_details"),
		}
		for m in _family_nominee_rows(ob)
	]


def _gratuity_nominee_rows(ob):
	"""Same situation as _epf_nominee_rows() - gratuity_nominees is its
	own separate HR-only table (see STATUTORY_CHILD_TABLE_FIELDS in
	onboarding_portal.py), duplicating whoever's already ticked "Nominee"
	in Family Background. No guardian_details column here (Gratuity Form
	F's nominee table doesn't have one, unlike EPF's), everything else the
	same, including the same spouse/mother default via
	_family_nominee_rows() when nobody was explicitly ticked."""
	rows = ob.get("gratuity_nominees") if ob else []
	if rows:
		return rows
	return [
		{
			"nominee_name": m.get("member_name"),
			"address": m.get("address"),
			"relationship": m.get("relation"),
			"date_of_birth": m.get("date_of_birth"),
			"share_percentage": m.get("share_percentage"),
		}
		for m in _family_nominee_rows(ob)
	]


def _eps_family_rows(ob):
	"""Part B's FIRST table - "particulars of the members of my family who
	would be eligible to receive widow/children pension" - a full-family
	disclosure like ESIC's Particulars of Family, not a nomination choice.
	Falls back from eps_family_members to the whole family_members list
	(not just nominees - see _family_nominee_rows() for that, used by
	Part B's second table instead)."""
	if not ob:
		return []
	rows = ob.get("eps_family_members") or []
	if rows:
		return rows
	return [
		{
			"nominee_name": m.get("member_name"),
			"address": m.get("address"),
			"relationship": m.get("relation"),
			"date_of_birth": m.get("date_of_birth"),
		}
		for m in (ob.get("family_members") or [])
	]


def _eps_fallback_nominee_rows(ob):
	"""Part B's SECOND table - "I hereby nominate the following person for
	receiving the monthly widow pension... in the event of my death
	without leaving any eligible family member for receiving pension."
	This is the actual "no nomination made" fallback case the form itself
	describes, so it's exactly where _family_nominee_rows()'s spouse/
	mother default belongs - not the first table above, which wants every
	eligible family member, chosen-as-nominee or not."""
	return [
		{
			"nominee_name": m.get("member_name"),
			"address": m.get("address"),
			"relationship": m.get("relation"),
			"date_of_birth": m.get("date_of_birth"),
		}
		for m in _family_nominee_rows(ob)
	]


def _epf_nomination_section(emp_doc, ob):
	dob = _fmt(_val(ob.candidate_dob if ob else None, emp_doc.date_of_birth), "Date")
	html = "<div class='page-break'></div><hr class='ob-form-divider'>"
	html += box("Nomination & Declaration Form")
	html += "<p class='ob-print-fine' style='text-align:center;'>(FOR UNEXEMPTED/EXEMPTED ESTABLISHMENTS)</p>"
	html += (
		"<p class='sub-label'>Declaration &amp; Nomination Form under the Employee's Provident Fund &amp; "
		"Employee's Pension Schemes</p>"
	)
	html += (
		"<p class='ob-print-fine'>Paragraph 33 and 61(1) of the Employee's Provident Fund Scheme, 1952 and "
		"paragraph 18 of the Employee's Pension Schemes 1995</p>"
	)
	html += print_table(["Name", "Father's/Husband's Name", "DOB"],
		[[emp_doc.employee_name, _val(ob.father_name if ob else None, emp_doc.get("custom_father_name")), dob]])
	html += print_table(["Sex", "Marital Status", "Account No"],
		[[_val(ob.gender if ob else None, emp_doc.gender), ob.marital_status if ob else None, ob.epf_account_no if ob else None]])
	html += print_table(["Permanent Address", "Temporary Address"],
		[[_val(ob.permanent_address if ob else None, emp_doc.get("permanent_address")), _val(ob.present_address if ob else None, emp_doc.get("current_address"))]])
	epf_membership = _fmt(ob.epf_date_of_membership, "Date") if ob else None
	html += print_table(["Date of Membership — E.P.F", "Date of Membership — E.P.S"],
		[[epf_membership, epf_membership]])

	html += "<p class='section-title'>PART - A (EPF)</p>"
	html += (
		"<p class='ob-print-fine'>I hereby nominate the person(s)/cancel the nomination made by me previously "
		"&amp; nominate the person(s) mentioned below to receive the amount standing to my credit in the "
		"Employee's Provident Fund, in the event of my death.</p>"
	)
	html += print_table(
		["Name of the Nominee", "Address", "Nominee's Relationship with the Member", "DOB",
		 "Total Amount of Share", "If the Nominee is a Minor — Name, Relationship & Address of the Guardian"],
		child_rows(
			_epf_nominee_rows(ob),
			["nominee_name", "address", "relationship", lambda r: _fmt(r.get("date_of_birth"), "Date"),
			 "share_percentage", "guardian_details"],
		),
		min_blank_rows=3,
	)
	html += """<div class="ob-print-fine"><ol>
		<li>Certificate that I have no family as in para 2(g) of the Employee's Provident Fund Scheme, 1952 &amp; should I acquire a family hereafter the above nomination shall be deemed as cancelled.</li>
		<li>Certified that my father/mother is/are dependent on me.</li>
	</ol></div>"""
	html += f"""<table class="sign-row"><tr><td>&nbsp;</td>
		<td class="right">{_signature_block("Signature of the Subscriber:", _employee_signature_html(ob))}</td>
	</tr></table>"""

	html += "<p class='section-title'>PART - B (EPS) (Para 18)</p>"
	html += (
		"<p class='ob-print-fine'>I hereby furnish the particulars of the members of my family who would be "
		"eligible to receive widow/children pension in the event of my premature death.</p>"
	)
	html += print_table(
		["Name & Address of the Family Member", "DOB", "Relationship with the Member"],
		child_rows(
			_eps_family_rows(ob),
			[
				lambda r: " / ".join(filter(None, [r.get("nominee_name"), r.get("address")])),
				lambda r: _fmt(r.get("date_of_birth"), "Date"),
				"relationship",
			],
		),
		min_blank_rows=3,
	)
	html += (
		"<p class='ob-print-fine'>Certified that I have no family, as defined in para 2(vii) of the Employee's "
		"Pension Scheme, 1995 and should I acquire a family hereafter I shall furnish particulars thereof in "
		"the above form. I hereby nominate the following person for receiving the monthly widow pension "
		"admissible under para 16(2)(a)(i) &amp; (ii) in the event of my death without leaving any eligible "
		"family member for receiving pension.</p>"
	)
	html += print_table(
		["Name & Address of the Nominee", "DOB", "Relationship with the Member"],
		child_rows(
			_eps_fallback_nominee_rows(ob),
			[
				lambda r: " / ".join(filter(None, [r.get("nominee_name"), r.get("address")])),
				lambda r: _fmt(r.get("date_of_birth"), "Date"),
				"relationship",
			],
		),
		min_blank_rows=2,
	)
	html += f"""<table class="sign-row"><tr><td>&nbsp;</td>
		<td class="right">{_signature_block("Signature of the Subscriber:", _employee_signature_html(ob))}</td>
	</tr></table>"""

	html += "<p class='section-title'>CERTIFICATE BY EMPLOYER</p>"
	html += (
		"<p class='ob-print-fine'>Certified that the above declaration and nomination has been "
		f"signed/thumb impressed before me by Shri/Smt./Kum. {esc(emp_doc.employee_name)} employed in my establishment, "
		"after he/she has read the entries/the entries have been read over to him/her by me and got confirmed "
		"by him/her.</p>"
	)
	html += f"""<table class="sign-row"><tr>
		<td>Place: <span class="ob-print-blank-line">&nbsp;</span></td>
		<td class="right">{_signature_block("Signature of the Employer or Other Authorised Officer of the Establishment:", _hr_signature_html(ob))}</td>
	</tr></table>"""
	html += print_table(["Name & Address of the Factory/Estt.", "Designation (Director/Auth. Sign)"],
		[[company_address_line(emp_doc.company), None]])
	return html


def _gratuity_form_f_section(emp_doc, ob):
	dob = _fmt(ob.candidate_dob, "Date") if ob else None
	doj = _fmt(emp_doc.date_of_joining, "Date")
	html = "<div class='page-break'></div><hr class='ob-form-divider'>"
	html += box("PAYMENT OF GRATUITY (CENTRAL) RULES — FORM F")
	html += "<p class='ob-print-fine'>See Sub-rule (1) of Rule 6 &middot; Nomination</p>"
	html += (
		"<p class='ob-print-fine'>To: (Give here name or description of the establishment with full address) "
		f"<span class='ob-print-blank-line'>{esc(company_address_line(emp_doc.company))}</span></p>"
	)
	html += f"""<div class="ob-print-fine"><ol>
		<li>Shri/Shrimati/Kumari <strong>{esc(emp_doc.employee_name)}</strong>, whose particulars are given in the statement below, hereby nominate the person(s) mentioned below to receive the gratuity payable after my death as also the gratuity standing to my credit in the event of my death before that amount has become payable, or having become payable has not been paid, and direct that the said amount of gratuity shall be paid in proportion indicated against the name(s) of the nominee(s).</li>
		<li>I hereby certify that the person(s) mentioned is/are a member(s) of my family within the meaning of clause (h) of section 2 of the Payment of Gratuity Act, 1972.</li>
		<li>I hereby declare that I have no family within the meaning of clause (h) of section 2 of the said Act.</li>
		<li>(A) My father/mother/parents is/are not dependent on me. (B) My husband's father/mother/parents is/are not dependent on my husband. I have excluded my husband from my family by a notice dated the _______________ to the controlling authority in terms of the proviso to clause (h) of section 2 of the said Act. Nomination made herein invalidates my previous nomination.</li>
	</ol></div>"""
	html += print_table(["Village", "Thana", "Sub Division", "Post Office", "District", "State"],
		[[ob.gratuity_village, ob.gratuity_thana, ob.gratuity_sub_division, ob.gratuity_post_office,
		  ob.gratuity_district, ob.gratuity_state]] if ob else [])
	html += "<p class='sub-label'>Nominee(s)</p>"
	html += print_table(
		["Name in Full with Full Address of Nominee(s)", "Relationship with the Employee", "DOB of Nominee",
		 "Proportion by which the Gratuity will be Shared"],
		child_rows(
			_gratuity_nominee_rows(ob),
			[
				lambda r: " / ".join(filter(None, [r.get("nominee_name"), r.get("address")])),
				"relationship",
				lambda r: _fmt(r.get("date_of_birth"), "Date"),
				"share_percentage",
			],
		),
		min_blank_rows=3,
	)
	html += "<p class='sub-label'>Statement</p>"
	html += print_table(["1. Name of Employee in Full", "2. Sex", "3. Religion", "4. Marital Status"],
		[[emp_doc.employee_name, ob.gender if ob else emp_doc.gender, ob.religion if ob else None, ob.marital_status if ob else None]])
	html += print_table(
		["5. Dept/Branch/Section where Employed", "6. Post Held / Ticket or Serial No", "7. Date of Appointment", "8. Permanent Address"],
		[[emp_doc.department, emp_doc.designation, doj, _val(ob.permanent_address if ob else None, emp_doc.get("permanent_address"))]],
	)
	html += f"""<table class="sign-row"><tr>
		<td>Place: <span class="ob-print-blank-line">&nbsp;</span><br>Date: <span class="ob-print-blank-line">&nbsp;</span></td>
		<td class="right">{_signature_block("Signature of the Employee:", _employee_signature_html(ob))}</td>
	</tr></table>"""

	html += "<p class='sub-label'>Declaration by Witnesses</p>"
	html += "<p class='ob-print-fine'>Nomination signed/thumb-impressed before me. Name in full and full address of witnesses:</p>"
	witness_rows = []
	if ob and (ob.gratuity_witness1_name or ob.gratuity_witness1_address):
		witness_rows.append(["1", " / ".join(filter(None, [ob.gratuity_witness1_name, ob.gratuity_witness1_address])), ""])
	if ob and (ob.gratuity_witness2_name or ob.gratuity_witness2_address):
		witness_rows.append(["2", " / ".join(filter(None, [ob.gratuity_witness2_name, ob.gratuity_witness2_address])), ""])
	if not witness_rows:
		witness_rows = [["1", "", ""], ["2", "", ""]]
	html += print_table(["Witness", "Name & Address", "Signature"], witness_rows)
	html += """<table class="sign-row"><tr>
		<td>Place: <span class="ob-print-blank-line">&nbsp;</span></td>
		<td class="right">Date: <span class="ob-print-blank-line">&nbsp;</span></td>
	</tr></table>"""

	html += "<p class='sub-label'>Certificate by the Employer</p>"
	html += "<p class='ob-print-fine'>Certified that the particulars of the above nomination have been verified and recorded in this establishment.</p>"
	# Not print_table() - see the note on the same pattern in
	# _esic_tic_section above.
	html += f"""<table class='ob-print-table'><thead><tr>
		<th>Employer's Reference No</th><th>Date</th>
		<th>Signature of Employer / Authorised Signatory, Designation</th><th>Name &amp; Address of the Establishment</th>
	</tr></thead><tbody><tr>
		<td>&nbsp;</td><td>&nbsp;</td><td>{_hr_signature_html(ob)}</td><td>{esc(company_address_line(emp_doc.company)) or "&nbsp;"}</td>
	</tr></tbody></table>"""
	return html


def _form11_section(emp_doc, ob):
	html = "<div class='page-break'></div><hr class='ob-form-divider'>"
	html += box("EMPLOYEES' PROVIDENT FUND ORGANISATION — New Form No. 11 Declaration", blue=True)
	html += "<p class='ob-print-fine'>Employees Provident Fund Scheme, 1952 (Para 34 &amp; 57) &amp; Employees Pension Scheme, 1995 (Para 24)</p>"

	bank_kyc = None
	kyc_uan = None
	if ob:
		for r in ob.get("kyc_details") or []:
			# Keeps the original "first match wins" behaviour for bank_kyc
			# (only set once) while still scanning the rest of the rows for
			# a UAN Number entry, instead of a single break stopping the
			# loop at whichever of the two came first.
			if bank_kyc is None and r.get("kyc_type") in ("Bank Account", "Aadhaar", "PAN", "Driving Licence"):
				bank_kyc = f"{r.get('kyc_type')}: {r.get('number')}"
			if kyc_uan is None and r.get("kyc_type") == "UAN Number" and r.get("number"):
				kyc_uan = r.get("number")

	# A UAN Number row in KYC Details (candidate-filled, unlike epfo_uan
	# below which is HR-only - see STATUTORY_FIELDS in onboarding_portal.py)
	# means the applicant already has a UAN from a previous employer, which
	# in turn means they were already enrolled under both EPF, 1952 and
	# EPS, 1995 (a UAN is only ever issued once EPF/EPS membership starts)
	# - so rows 7 & 8 below answer themselves from that alone. Falls back
	# to the HR-entered epfo_uan if the candidate didn't provide one via
	# KYC Details but HR has since filled it in from the desk side.
	uan_value = kyc_uan or (ob.epfo_uan if ob else None) or emp_doc.get("custom_uan")

	rows = [
		["1", "Name of the Member", emp_doc.employee_name],
		["2", "Father's Name / Spouse Name", _val(ob.father_name if ob else None, emp_doc.get("custom_father_name"))],
		["3", "Date of Birth", _fmt(_val(ob.candidate_dob if ob else None, emp_doc.date_of_birth), "Date")],
		["4", "Gender", _val(ob.gender if ob else None, emp_doc.gender)],
		["5", "Marital Status", ob.marital_status if ob else None],
		["6", "Email ID / Mobile No", " / ".join(filter(None, [ob.candidate_email if ob else None, ob.candidate_phone if ob else None])) or None],
		["7", "Earlier a member of EPF Scheme, 1952?", "Yes" if uan_value else None],
		["8", "Earlier a member of EPS, 1995?", "Yes" if uan_value else None],
		["9", "UAN / Previous PF A/c No / Exit Date / Scheme Cert. No / PPO No",
			" / ".join(filter(None, [
				uan_value,
				_fmt(ob.form11_left_service_on, "Date") if ob else None,
				ob.form11_scheme_certificate_no if ob else None,
				ob.form11_ppo_no if ob else None,
			])) or None],
		["10", "International Worker / Passport No",
			(_yn(ob.form11_is_international_worker) + (f" / {ob.form11_passport_no}" if ob.form11_passport_no else "")) if ob else None],
		["11", "Bank Account / Aadhaar / PAN / Driving Licence", bank_kyc],
	]
	html += print_table(["S.No", "Field", "Details"], rows)

	html += "<p class='sub-label'>Undertaking</p>"
	html += """<div class="ob-print-fine"><ul>
		<li>I certify that all the information given above is true to the best of my knowledge and belief.</li>
		<li>If earlier a member of EPF Scheme 1952 and/or EPS 1995, I have ensured the correctness of my UAN/previous PF member ID; this may also be treated as my request to transfer funds and service details from the previous account to the present PF account (subject to the previous employer's KYC verification via Digital Signature Certificate).</li>
		<li>I am aware that I can submit my nomination form through the UAN-based member portal.</li>
	</ul></div>"""
	html += f"""<table class="sign-row"><tr><td>&nbsp;</td>
		<td class="right">{_signature_block("Signature of Member:", _employee_signature_html(ob))}</td>
	</tr></table>"""

	html += "<p class='sub-label'>Declaration by Present Employer</p>"
	html += (
		f"<p class='ob-print-fine' style='text-align:center;'>The member Mr./Ms./Mrs. <strong>{esc(emp_doc.employee_name)}</strong> has joined on "
		f"<strong>{esc(_fmt(emp_doc.date_of_joining, 'Date')) or '_______'}</strong> and has been "
		f"allotted PF Member ID <strong>{esc((ob.epf_account_no if ob else None)) or '_______'}</strong>.</p>"
	)
	# uan_value (computed above for row 9 of the S.No table) is the same
	# UAN this bullet is asking about, whether it's a pre-existing one the
	# candidate declared via KYC Details or one HR has since entered - the
	# "[ ] Verified"/"[ ] Confirmed" checkboxes right after stay as blank
	# tick-boxes though: those are an HR sign-off action taken while
	# reviewing this form, not data the candidate already supplied.
	html += f"""<div class="ob-print-fine"><ul>
		<li>If the person was earlier not a member of EPF Scheme 1952 and EPS 1995 (post allotment of UAN): the UAN allotted for the member is {esc(uan_value) or '_______'}. KYC details of the above member in the UAN database: [ ] Verified.</li>
		<li>If the person was earlier a member of EPF Scheme 1952 and EPS 1995: the above member ID has been tagged with his/her UAN/previous member ID as declared by the member: [ ] Confirmed.</li>
	</ul></div>"""
	html += f"""<table class="sign-row"><tr><td>&nbsp;</td>
		<td class="right">{_signature_block("Signature of Employer:", _hr_signature_html(ob))}</td>
	</tr></table>"""
	return html


def _embedded_devanagari_font_css():
	"""@font-face for Noto Sans Devanagari, embedded as base64 data URIs
	from the two .ttf files bundled in public/fonts/ - not the Google
	Fonts <link> this PDF used to rely on entirely (see the STYLE
	docstring above). That link works fine wherever this was built/
	tested, but a production server with no outbound internet access to
	third-party domains (a common, deliberate firewall policy) silently
	drops it - both Poppins and Noto Sans Devanagari never load there.
	Poppins' absence is invisible (Arial, the next fallback, covers the
	same Latin glyphs just fine), but nothing else in the font stack has
	any Devanagari glyphs at all, so every Hindi word in the bilingual
	consent questions rendered as a row of missing-glyph boxes on that
	one server while looking correct everywhere else. Bundling the font
	file directly removes the external-network dependency for this one
	font entirely - wkhtmltopdf reads it out of the same HTML string
	instead of fetching it from a third-party CDN. Cached (data URI
	length makes re-encoding real work) - never changes at runtime."""

	def _load():
		import base64
		import os

		fonts_dir = frappe.get_app_path("olscpl_hrms", "public", "fonts")
		with open(os.path.join(fonts_dir, "NotoSansDevanagari-Regular.ttf"), "rb") as f:
			regular = base64.b64encode(f.read()).decode()
		with open(os.path.join(fonts_dir, "NotoSansDevanagari-Bold.ttf"), "rb") as f:
			bold = base64.b64encode(f.read()).decode()
		return (
			"@font-face { font-family: 'Noto Sans Devanagari'; font-weight: 400; "
			f"src: url(data:font/ttf;base64,{regular}) format('truetype'); }}\n"
			"@font-face { font-family: 'Noto Sans Devanagari'; font-weight: 700; "
			f"src: url(data:font/ttf;base64,{bold}) format('truetype'); }}"
		)

	return frappe.cache().get_value("olscpl_hrms_devanagari_font_css", generator=_load)


@frappe.whitelist()
def download_employee_data(employee: str):
	emp_doc = frappe.get_doc("Employee", employee)
	emp_doc.check_permission("read")

	ob = _get_onboarding(emp_doc)

	files = frappe.get_all(
		"File",
		filters={"attached_to_doctype": "Employee", "attached_to_name": employee},
		fields=["name", "file_name"],
		order_by="creation asc",
	)
	if files:
		items = "".join(f"<li>{esc(f.file_name)}</li>" for f in files)
		attachments_html = "<div class='page-break'></div>" + box(f"Attached Documents ({len(files)})") + f"<ul class='doclist'>{items}</ul>"
	else:
		attachments_html = "<div class='page-break'></div>" + box("Attached Documents") + "<p class='muted'>None attached.</p>"

	body = f"""
	<html><head><meta charset="utf-8">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
	<style>{_embedded_devanagari_font_css()}{STYLE}</style></head><body>
		<div class="content">
			{_header_html(emp_doc, ob)}
			{_personal_data_section(emp_doc, ob)}
			{_kyc_section(ob)}
			{_education_section(ob)}
			{_technical_qualification_section(ob)}
			{_employment_history_section(ob)}
			{_extra_curricular_section(ob)}
			{_salary_breakup_section(ob)}
			{_languages_section(ob)}
			{_family_background_section(ob)}
			{_background_integrity_section(ob)}
			{_physical_data_section(ob)}
			{_reference_section(ob)}
			{_document_checklist_section(ob)}
			{_consent_section(ob)}
			{_declaration_section(emp_doc, ob)}
			{_esic_declaration_section(emp_doc, ob)}
			{_esic_tic_section(emp_doc, ob)}
			{_epf_nomination_section(emp_doc, ob)}
			{_gratuity_form_f_section(emp_doc, ob)}
			{_form11_section(emp_doc, ob)}
			{attachments_html}
		</div>
		<div class="footer">Generated {frappe.utils.now_datetime().strftime("%d %b %Y, %H:%M")} by {frappe.session.user}
		{" &middot; source onboarding: " + ob.name if ob else " &middot; no linked Employee Onboarding found"}</div>
	</body></html>
	"""

	# A4 (this file's previous default, and wkhtmltopdf's own default when
	# no page-size is given) is only 210mm wide - minus the 15mm margins
	# frappe.utils.pdf always adds on both sides, that's ~180mm of usable
	# width for tables that on the reference onboarding-documents.html
	# page (a fluid web page, not a printed page - .onboarding-page there
	# goes up to 1600px wide) have 4-7 columns each. Every one of those
	# tables is already width:100% in STYLE above, so it fills whatever
	# width it's given - A3 (297mm, ~41% wider) is what actually fixes the
	# cramped/wrapped columns rather than just visually resembling a fix.
	writer = PdfWriter()
	_append_pdf_bytes(writer, get_pdf(body, options={"page-size": "A3"}))

	for f in files:
		file_doc = frappe.get_doc("File", f.name)
		ext = (f.file_name or "").rsplit(".", 1)[-1].lower() if "." in (f.file_name or "") else ""
		try:
			content = file_doc.get_content()
		except Exception:
			_append_pdf_bytes(writer, get_pdf(_placeholder_page_html(f.file_name)))
			continue
		try:
			if ext == "pdf":
				_append_pdf_bytes(writer, content)
			elif ext in EMBEDDABLE_IMAGE_EXTENSIONS:
				_append_image_as_page(writer, content)
			else:
				_append_pdf_bytes(writer, get_pdf(_placeholder_page_html(f.file_name)))
		except Exception:
			_append_pdf_bytes(writer, get_pdf(_placeholder_page_html(f"{f.file_name} (could not be read)")))

	out = io.BytesIO()
	writer.write(out)

	frappe.local.response.filename = f"{emp_doc.name}-employee-data.pdf"
	frappe.local.response.filecontent = out.getvalue()
	frappe.local.response.type = "download"


def _placeholder_page_html(filename):
	return f"""
	<html><head><style>{STYLE}</style></head><body style="padding: 60px;">
		<div class="ob-print-box">Attachment: {esc(filename)}</div>
		<p>This file's format can't be embedded directly as a page in this PDF.
		Open it separately from the Employee record's Attachments panel.</p>
	</body></html>
	"""


def _append_pdf_bytes(writer, pdf_bytes):
	reader = PdfReader(io.BytesIO(pdf_bytes))
	for page in reader.pages:
		writer.add_page(page)


def _append_image_as_page(writer, content):
	img = Image.open(io.BytesIO(content))
	if img.mode in ("RGBA", "P", "LA"):
		img = img.convert("RGB")
	buf = io.BytesIO()
	img.save(buf, format="PDF")
	_append_pdf_bytes(writer, buf.getvalue())
