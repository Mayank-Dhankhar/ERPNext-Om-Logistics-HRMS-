# olscpl_hrms/api/regularization.py
#
# Mobile-app facing APIs for the "Attendance Regularization" DocType.
# ERPNext v15.9 / Frappe framework.
#
# FIELDS (confirmed via `bench --site uat-copy.local console`,
# frappe.get_meta("Attendance Regularization")):
#   employee, employee_name, for_date, requested_punch_in_time,
#   requested_punch_out_time, regularization_type (mandatory Select:
#   "Missing Punch IN" / "Missing Punch OUT" / "Both Punches Missing" /
#   "Less Working Hours"), reason, workflow_state, recalculation_done,
#   monthly_regularization_count, original_status, requires_hr_approval,
#   days_since_attendance, attendance_link, amended_from
#
# WORKFLOW (confirmed via frappe.get_doc("Workflow",
# "Attendance Regularization Workflow")):
#   States:      Draft(docstatus 0) -> Pending(0) -> Approved(1) / Rejected(0)
#   Transitions: Draft  --Submit--> Pending   (allowed role: Employee)
#                Pending --Approve--> Approved (allowed role: Manager)
#                Pending --Reject-->  Rejected (allowed role: Manager)
#   NOTE: "Approve" submits the document (docstatus 0 -> 1) as part of the
#   workflow transition — apply_workflow() handles this automatically.
#
# RESPONSE ENVELOPE (per spec):
#   {"success": bool, "payload": <data or null>, "message": "<text>"}
import frappe
from frappe import _
from frappe.utils import getdate

from olscpl_hrms.utils.reporting_person import omstaff_can_approve, omstaff_team_filters
DOCTYPE = "Attendance Regularization"
REGULARIZATION_TYPES = (
    "Missing Punch IN",
    "Missing Punch OUT",
    "Both Punches Missing",
    "Less Working Hours",
)
# The OM Staff App authenticates its own end users with its own credentials
# (not Frappe logins) and calls this API server-to-server using the
# Administrator API key/secret. Because of that, frappe.session.user is
# ALWAYS Administrator, never the real employee using the app - it carries
# no per-user identity at all. Every function below therefore takes an
# explicit `caller_employee` parameter (the employee ID the app's backend
# has already authenticated) and trusts it completely. That credential must
# never leave the app's backend - anyone holding it has full control of
# this entire site, not just the ability to claim to be any employee here.
# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _is_trusted_caller():
    return frappe.session.user == "Administrator"
def _is_authorized_viewer(doc, caller_employee):
    return doc.employee == caller_employee or omstaff_can_approve(doc, caller_employee)
def _response(success, payload=None, message=""):
    frappe.response["http_status_code"] = 200 if success else 400
    # frappe.throw()/frappe.msgprint() calls made anywhere upstream (e.g. in
    # the DocType's own validate() hook) push onto frappe.local.message_log,
    # which Frappe auto-serializes into "_server_messages" on every response.
    # We already surface the same text via our own "message" field, so clear
    # the log to avoid duplicating it in a format the app doesn't expect.
    frappe.local.message_log = []
    return {"success": success, "payload": payload, "message": message}
def _is_hr_manager_employee(employee):
    """Is the Employee (identified by ID, not a Frappe session) linked to a
    User holding the "HR Manager" role? Cannot use frappe.get_roles() on
    frappe.session.user here - that's always the shared integration
    account, not this specific employee."""
    user = frappe.db.get_value("Employee", employee, "user_id")
    if not user:
        return False
    return "HR Manager" in frappe.get_roles(user)
def _is_direct_manager(employee, caller_employee):
    """True only if caller_employee is the Employee record's actual
    reports_to manager - compared directly by Employee ID now that identity
    comes from an explicit trusted parameter, not a Frappe session."""
    manager_employee = frappe.db.get_value("Employee", employee, "reports_to")
    return bool(manager_employee) and manager_employee == caller_employee
def _serialize(doc):
    return {
        "name": doc.name,
        "employee": doc.employee,
        "employee_name": doc.employee_name,
        "for_date": doc.for_date,
        "requested_punch_in_time": doc.requested_punch_in_time,
        "requested_punch_out_time": doc.requested_punch_out_time,
        "regularization_type": doc.regularization_type,
        "reason": doc.reason,
        "workflow_state": doc.workflow_state,
        "docstatus": doc.docstatus,
        "requires_hr_approval": doc.requires_hr_approval,
        "attendance_link": doc.attendance_link,
        "creation": doc.creation,
        "modified": doc.modified,
    }
# ---------------------------------------------------------------------------
# 1. CREATE + SUBMIT (single call for the mobile app)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def create_and_submit_regularization(
    caller_employee,
    for_date,
    regularization_type,
    reason,
    requested_punch_in_time=None,
    requested_punch_out_time=None,
    employee=None,
):
    """
    Creates an Attendance Regularization request (Draft) and immediately
    moves it to Pending in the employee's manager's queue.
    Called by: the OM Staff App backend, server-to-server, using the
    Administrator credential (see module-level note above). `caller_employee`
    is the Employee ID of whoever the app has already authenticated - it is
    trusted completely, which is why access is gated to Administrator only.
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if not reason:
            return _response(False, None, _("Reason is mandatory"))
        if regularization_type not in REGULARIZATION_TYPES:
            return _response(
                False, None,
                _("Regularization Type must be one of: {0}").format(", ".join(REGULARIZATION_TYPES)),
            )
        if regularization_type in ("Missing Punch IN", "Both Punches Missing") and not requested_punch_in_time:
            return _response(False, None, _("Requested Punch IN Time is required for this regularization type"))
        if regularization_type in ("Missing Punch OUT", "Both Punches Missing") and not requested_punch_out_time:
            return _response(False, None, _("Requested Punch OUT Time is required for this regularization type"))
        employee = employee or caller_employee
        # Employees may only raise requests for themselves. Managers may
        # raise on behalf of others only if they are HR, or the specific
        # employee's own reports_to manager - holding a generic "Manager"
        # role alone is not enough (it's shared across unrelated
        # departments and isn't the same as "manages this employee").
        if employee != caller_employee and not (
            _is_hr_manager_employee(caller_employee) or _is_direct_manager(employee, caller_employee)
        ):
            return _response(False, None, _("You can only raise a request for yourself, or for your direct reports"))
        # Nothing else in the validation chain checks this - without it,
        # the same employee+date can have multiple simultaneous Pending
        # requests, leaving a manager with no clean way to know which one
        # to act on, and no defined behavior if more than one somehow gets
        # approved (each approval independently overwrites the same
        # Attendance record, so the last one processed silently wins).
        existing = frappe.db.exists(
            DOCTYPE,
            {
                "employee": employee,
                "for_date": getdate(for_date),
                "workflow_state": ["in", ["Pending", "Approved"]],
            },
        )
        if existing:
            return _response(
                False, None,
                _("A regularization request already exists for this employee and date ({0})").format(existing),
            )
        doc = frappe.new_doc(DOCTYPE)
        # Set on the object itself (not just passed per-call) so it holds
        # across insert/save/reload - frappe.session.user is the shared
        # integration account here, not the real employee, and our explicit
        # checks above are the actual authorization, not Frappe's
        # session-based DocType permission engine, which has no concept of
        # caller_employee.
        doc.flags.ignore_permissions = True
        doc.employee = employee
        doc.for_date = getdate(for_date)
        doc.regularization_type = regularization_type
        doc.requested_punch_in_time = requested_punch_in_time
        doc.requested_punch_out_time = requested_punch_out_time
        doc.reason = reason
        doc.insert()
        # Draft -> Pending. Set directly rather than apply_workflow(), which
        # checks the Workflow's own role/condition against
        # frappe.session.user - meaningless here for the same reason.
        doc.workflow_state = "Pending"
        doc.save()
        doc.reload()
        frappe.db.commit()  # noqa: frappe.db.commit is intentional at API boundary
        return _response(True, _serialize(doc), _("Record submitted successfully"))
    except frappe.ValidationError as e:
        frappe.db.rollback()
        return _response(False, None, str(e))
    except Exception:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Attendance Regularization: create_and_submit failed")
        return _response(False, None, _("Something went wrong while submitting your request"))
# ---------------------------------------------------------------------------
# 2. MANAGER ACTION — approve / reject
# ---------------------------------------------------------------------------
@frappe.whitelist()
def action_regularization(caller_employee, name, action, remarks=None):
    """
    action: "Approve" or "Reject". Restricted to HR Manager, or the specific
    employee's own reports_to manager - NOT to anyone holding a generic
    "Manager" role, since that's shared across unrelated departments and
    isn't the same as "manages this employee". `caller_employee` is trusted
    (see module-level note above) as the Employee ID of whoever the app's
    backend has already authenticated as the acting manager/HR user.
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if action not in ("Approve", "Reject"):
            return _response(False, None, _("Invalid action. Use 'Approve' or 'Reject'"))
        doc = frappe.get_doc(DOCTYPE, name)
        # See create_and_submit_regularization for why ignore_permissions is
        # needed and set on the object itself.
        doc.flags.ignore_permissions = True
        if not omstaff_can_approve(doc, caller_employee):
            return _response(False, None, _("Not permitted to action this request"))
        if doc.workflow_state != "Pending":
            return _response(False, None, _("Request is not pending approval"))
        # frappe.session.user is the shared integration account, so
        # comments/frappe's own audit trail won't show who really actioned
        # this - stamp the actual caller into the comment text itself.
        caller_name = frappe.db.get_value("Employee", caller_employee, "employee_name")
        comment_text = f"{action} by {caller_name} ({caller_employee})"
        if remarks:
            comment_text += f": {remarks}"
        doc.add_comment("Comment", comment_text)
        if action == "Approve":
            doc.workflow_state = "Approved"
            doc.submit()
        else:
            doc.workflow_state = "Rejected"
            doc.save()
        doc.reload()
        frappe.db.commit()  # noqa
        msg = _("Request approved successfully") if action == "Approve" else _("Request rejected")
        return _response(True, _serialize(doc), msg)
    except frappe.DoesNotExistError:
        return _response(False, None, _("Regularization request not found"))
    except frappe.ValidationError as e:
        frappe.db.rollback()
        return _response(False, None, str(e))
    except Exception:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Attendance Regularization: action failed")
        return _response(False, None, _("Something went wrong while processing this action"))
# ---------------------------------------------------------------------------
# 3a. VIEW — employee's own records
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_my_regularizations(caller_employee, from_date=None, to_date=None, workflow_state=None, limit=50, start=0):
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        filters = {"employee": caller_employee}
        if workflow_state:
            filters["workflow_state"] = workflow_state
        if from_date and to_date:
            filters["for_date"] = ["between", [getdate(from_date), getdate(to_date)]]
        rows = frappe.get_all(
            DOCTYPE,
            filters=filters,
            fields=[
                "name", "employee", "employee_name", "for_date",
                "requested_punch_in_time", "requested_punch_out_time",
                "regularization_type", "reason", "workflow_state", "docstatus",
                "requires_hr_approval", "creation", "modified",
            ],
            order_by="creation desc",
            limit_page_length=int(limit),
            limit_start=int(start),
        )
        return _response(True, rows, _("Records fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Attendance Regularization: get_my failed")
        return _response(False, None, _("Something went wrong while fetching your records"))
# ---------------------------------------------------------------------------
# 3b. VIEW — manager's queue (pending + actioned by them)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_team_regularizations(
    caller_employee, workflow_state=None, employee=None, from_date=None, to_date=None, limit=50, start=0
):
    """
    Manager view. `caller_employee` is the trusted (see module-level note
    above) Employee ID of whoever the app has authenticated as the acting
    manager/HR user. HR Manager sees the whole company; anyone else sees
    only their own direct reports (Employee.reports_to).
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        filters = omstaff_team_filters(DOCTYPE, caller_employee, employee)
        if workflow_state:
            filters["workflow_state"] = workflow_state
        if from_date and to_date:
            filters["for_date"] = ["between", [getdate(from_date), getdate(to_date)]]
        rows = frappe.get_all(
            DOCTYPE,
            filters=filters,
            fields=[
                "name", "employee", "employee_name", "for_date",
                "requested_punch_in_time", "requested_punch_out_time",
                "regularization_type", "reason", "workflow_state", "docstatus",
                "requires_hr_approval", "creation", "modified",
            ],
            order_by="creation desc",
            limit_page_length=int(limit),
            limit_start=int(start),
        )
        return _response(True, rows, _("Records fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Attendance Regularization: get_team failed")
        return _response(False, None, _("Something went wrong while fetching team records"))
# ---------------------------------------------------------------------------
# 3c. VIEW — single record by name (carried over from the original
# Server-Script-derived get_details(), normalized to the standard envelope
# and reusing _serialize() for a consistent payload shape)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_details(caller_employee=None):
    """
    Fetches one Attendance Regularization by name. `caller_employee` is
    trusted (see module-level note above) as the Employee ID of whoever the
    app has authenticated - own record, HR Manager, or the target
    employee's actual reports_to manager may view it.
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        data = frappe.request.get_json(silent=True) or frappe.form_dict
        name = data.get("name")
        caller_employee = caller_employee or data.get("caller_employee")
        if not caller_employee or not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if not name:
            return _response(False, None, _("Regularization document name is required"))
        if not frappe.db.exists(DOCTYPE, name):
            return _response(False, None, _("Attendance Regularization not found"))
        doc = frappe.get_doc(DOCTYPE, name)
        if not _is_authorized_viewer(doc, caller_employee):
            return _response(False, None, _("You are not authorized to view this request"))
        return _response(True, _serialize(doc), _("Record fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Attendance Regularization: get_details failed")
        return _response(False, None, _("Something went wrong while fetching this record"))
