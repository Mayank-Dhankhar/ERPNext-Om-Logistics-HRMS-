# olscpl_hrms/api/leave.py
#
# Mobile-app facing APIs for the stock "Leave Application" DocType.
# Same server-to-server model as api/regularization.py (see that file's
# module-level note) - every function takes a trusted `caller_employee`
# and is gated to the shared Administrator credential.
#
# FIELDS (frappe.get_meta("Leave Application")): employee, employee_name,
# leave_type, from_date, to_date, half_day, half_day_date, total_leave_days,
# description (this is the "reason" field), status (Select: Open / Approved
# / Rejected / Cancelled, permlevel 1), leave_approver, docstatus,
# amended_from.
#
# APPROVAL MODEL: Employee role has create/write but NOT submit on this
# doctype - only HR User/HR Manager/Leave Approver can submit. So unlike
# Attendance Regularization, "create" naturally leaves the doc as a Draft
# (docstatus 0, status "Open") awaiting the approver, and "action" is what
# submits it (docstatus 0 -> 1) with status set to Approved or Rejected -
# both are terminal/final states here since only HR/Approver roles can
# submit, and submission is what finalizes either outcome.
#
# EMAIL SUPPRESSION (Sep 28, 2026): these functions are called once per
# leave record from erpnext_leave_migration.py, which can run thousands
# of times in a single migration/reconcile pass. Each insert()/submit()
# can fire Notification-doctype and Workflow email alerts configured
# against Leave Application, which at that volume means a flood of
# emails, not a useful notification. frappe.flags.mute_emails suppresses
# them (frappe.sendmail() and the Notification/Workflow alert machinery
# both check it) -- set True only around the doc write and always
# restored in a finally block, so interactive Desk/mobile-app use of
# these same endpoints outside a bulk migration is unaffected.
import frappe
from frappe import _
from frappe.utils import getdate

from olscpl_hrms.utils.reporting_person import omstaff_can_approve, omstaff_team_filters
DOCTYPE = "Leave Application"
# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _is_trusted_caller():
    return frappe.session.user == "Administrator"
def _is_hr_manager_employee(employee):
    user = frappe.db.get_value("Employee", employee, "user_id")
    if not user:
        return False
    return "HR Manager" in frappe.get_roles(user)
def _is_direct_manager(employee, caller_employee):
    manager_employee = frappe.db.get_value("Employee", employee, "reports_to")
    return bool(manager_employee) and manager_employee == caller_employee
def _is_authorized_viewer(doc, caller_employee):
    return doc.employee == caller_employee or omstaff_can_approve(doc, caller_employee)
def _response(success, payload=None, message=""):
    frappe.response["http_status_code"] = 200 if success else 400
    frappe.local.message_log = []
    return {"success": success, "payload": payload, "message": message}
def _serialize(doc):
    return {
        "name": doc.name,
        "employee": doc.employee,
        "employee_name": doc.employee_name,
        "leave_type": doc.leave_type,
        "from_date": doc.from_date,
        "to_date": doc.to_date,
        "half_day": doc.half_day,
        "half_day_date": doc.half_day_date,
        "total_leave_days": doc.total_leave_days,
        "reason": doc.description,
        "against_compensatory_leave_request": doc.custom_against_compensatory_leave_request,
        "status": doc.status,
        "docstatus": doc.docstatus,
        "creation": doc.creation,
        "modified": doc.modified,
    }
# ---------------------------------------------------------------------------
# 1. CREATE (leaves the request as Open, awaiting manager/HR action)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def create_and_submit_leave_application(
    caller_employee,
    leave_type,
    from_date,
    to_date,
    reason,
    half_day=0,
    half_day_date=None,
    employee=None,
    against_compensatory_leave_request=None,
):
    """
    Creates a Leave Application (status "Open"), submitted for the
    employee's manager/HR to act on. `caller_employee` is trusted (see
    api/regularization.py's module-level note) as the Employee ID of
    whoever the app's backend has already authenticated.

    `against_compensatory_leave_request` is required when leave_type is
    "Comp Off" - it must be the name of one of that employee's own
    Approved, not-yet-availed Compensatory Leave Requests (see
    get_available_comp_off_dates). Enforced in events/leave_application.py,
    which both this API and the Desk form go through identically.
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if not reason:
            return _response(False, None, _("Reason is mandatory"))
        employee = employee or caller_employee
        # Employees may only raise requests for themselves. Managers may
        # raise on behalf of others only if they are HR, or the specific
        # employee's own reports_to manager - a generic "Manager" role
        # alone is not enough (shared across unrelated departments).
        if employee != caller_employee and not (
            _is_hr_manager_employee(caller_employee) or _is_direct_manager(employee, caller_employee)
        ):
            return _response(False, None, _("You can only raise a request for yourself, or for your direct reports"))
        doc = frappe.new_doc(DOCTYPE)
        doc.flags.ignore_permissions = True
        doc.employee = employee
        doc.leave_type = leave_type
        doc.from_date = getdate(from_date)
        doc.to_date = getdate(to_date)
        doc.half_day = half_day
        doc.half_day_date = getdate(half_day_date) if half_day_date else None
        doc.description = reason
        doc.custom_against_compensatory_leave_request = against_compensatory_leave_request
        doc.status = "Open"
        # Bulk-migration callers (erpnext_leave_migration.py) invoke this
        # once per leave record, potentially thousands of times in one
        # run -- mute Notification/Workflow email alerts for just this
        # doc.insert() call, always restored below (see module docstring,
        # "EMAIL SUPPRESSION").
        previous_mute = frappe.flags.mute_emails
        frappe.flags.mute_emails = True
        try:
            # doc.insert() runs the doctype's own validate() chain (leave
            # balance, overlap, block days, back-dated limits, etc.) - any
            # failure there raises ValidationError, caught below.
            doc.insert()
        finally:
            frappe.flags.mute_emails = previous_mute
        doc.reload()
        frappe.db.commit()  # noqa: frappe.db.commit is intentional at API boundary
        return _response(True, _serialize(doc), _("Leave application submitted successfully"))
    except frappe.ValidationError as e:
        frappe.db.rollback()
        return _response(False, None, str(e))
    except Exception:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Leave Application: create_and_submit failed")
        return _response(False, None, _("Something went wrong while submitting your request"))
# ---------------------------------------------------------------------------
# 2. MANAGER ACTION - approve / reject
# ---------------------------------------------------------------------------
@frappe.whitelist()
def action_leave_application(caller_employee, name, action, remarks=None):
    """
    action: "Approve" or "Reject". Restricted to HR Manager, or the
    specific employee's own reports_to manager. Both outcomes submit the
    document (docstatus 0 -> 1) since only HR/manager roles can submit
    this doctype at all - submission is what finalizes either result.
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if action not in ("Approve", "Reject"):
            return _response(False, None, _("Invalid action. Use 'Approve' or 'Reject'"))
        doc = frappe.get_doc(DOCTYPE, name)
        doc.flags.ignore_permissions = True
        if not omstaff_can_approve(doc, caller_employee):
            return _response(False, None, _("Not permitted to action this request"))
        if doc.status != "Open":
            return _response(False, None, _("Request is not open for action"))
        caller_name = frappe.db.get_value("Employee", caller_employee, "employee_name")
        comment_text = f"{action} by {caller_name} ({caller_employee})"
        if remarks:
            comment_text += f": {remarks}"
        doc.add_comment("Comment", comment_text)
        doc.status = "Approved" if action == "Approve" else "Rejected"
        # Same bulk-call reasoning as create_and_submit_leave_application
        # above -- mute email alerts for just this doc.submit() call.
        previous_mute = frappe.flags.mute_emails
        frappe.flags.mute_emails = True
        try:
            doc.submit()
        finally:
            frappe.flags.mute_emails = previous_mute
        doc.reload()
        frappe.db.commit()  # noqa
        msg = _("Leave application approved successfully") if action == "Approve" else _("Leave application rejected")
        return _response(True, _serialize(doc), msg)
    except frappe.DoesNotExistError:
        return _response(False, None, _("Leave application not found"))
    except frappe.ValidationError as e:
        frappe.db.rollback()
        return _response(False, None, str(e))
    except Exception:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Leave Application: action failed")
        return _response(False, None, _("Something went wrong while processing this action"))
# ---------------------------------------------------------------------------
# 3a. VIEW - employee's own records
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_my_leave_applications(caller_employee, from_date=None, to_date=None, status=None, limit=50, start=0):
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        filters = {"employee": caller_employee}
        if status:
            filters["status"] = status
        if from_date and to_date:
            filters["from_date"] = ["between", [getdate(from_date), getdate(to_date)]]
        rows = frappe.get_all(
            DOCTYPE,
            filters=filters,
            fields=[
                "name", "employee", "employee_name", "leave_type", "from_date", "to_date",
                "half_day", "half_day_date", "total_leave_days", "description as reason",
                "status", "docstatus", "creation", "modified",
            ],
            order_by="creation desc",
            limit_page_length=int(limit),
            limit_start=int(start),
        )
        return _response(True, rows, _("Records fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Leave Application: get_my failed")
        return _response(False, None, _("Something went wrong while fetching your records"))
# ---------------------------------------------------------------------------
# 3b. VIEW - manager's queue
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_team_leave_applications(
    caller_employee, status=None, employee=None, from_date=None, to_date=None, limit=50, start=0
):
    """HR Manager sees the whole company; anyone else sees only their own
    direct reports (Employee.reports_to)."""
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        filters = omstaff_team_filters(DOCTYPE, caller_employee, employee)
        if status:
            filters["status"] = status
        if from_date and to_date:
            filters["from_date"] = ["between", [getdate(from_date), getdate(to_date)]]
        rows = frappe.get_all(
            DOCTYPE,
            filters=filters,
            fields=[
                "name", "employee", "employee_name", "leave_type", "from_date", "to_date",
                "half_day", "half_day_date", "total_leave_days", "description as reason",
                "status", "docstatus", "creation", "modified",
            ],
            order_by="creation desc",
            limit_page_length=int(limit),
            limit_start=int(start),
        )
        return _response(True, rows, _("Records fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Leave Application: get_team failed")
        return _response(False, None, _("Something went wrong while fetching team records"))
# ---------------------------------------------------------------------------
# 3c. VIEW - single record by name
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_leave_application_details(caller_employee=None):
    """Fetches one Leave Application by name. `caller_employee` is trusted
    as the Employee ID of whoever the app has authenticated - own record,
    HR Manager, or the target employee's actual reports_to manager may
    view it."""
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        data = frappe.request.get_json(silent=True) or frappe.form_dict
        name = data.get("name")
        caller_employee = caller_employee or data.get("caller_employee")
        if not caller_employee or not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        if not name:
            return _response(False, None, _("Leave application name is required"))
        if not frappe.db.exists(DOCTYPE, name):
            return _response(False, None, _("Leave Application not found"))
        doc = frappe.get_doc(DOCTYPE, name)
        if not _is_authorized_viewer(doc, caller_employee):
            return _response(False, None, _("You are not authorized to view this request"))
        return _response(True, _serialize(doc), _("Record fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Leave Application: get_details failed")
        return _response(False, None, _("Something went wrong while fetching this record"))
# ---------------------------------------------------------------------------
# 3d. VIEW - available (acquired, not-yet-availed) comp-off credits
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_available_comp_off_dates(caller_employee, employee=None):
    """
    Lists the employee's Approved Compensatory Leave Requests that
    haven't been availed against yet - this is what populates the "which
    date am I availing" picker before calling
    create_and_submit_leave_application with leave_type "Comp Off".
    """
    try:
        if not _is_trusted_caller():
            return _response(False, None, _("Not permitted"))
        if not frappe.db.exists("Employee", caller_employee):
            return _response(False, None, _("Unknown caller_employee"))
        employee = employee or caller_employee
        if employee != caller_employee and not (
            _is_hr_manager_employee(caller_employee) or _is_direct_manager(employee, caller_employee)
        ):
            return _response(False, None, _("You can only view your own, or your direct reports', available comp-off dates"))
        rows = frappe.get_all(
            "Compensatory Leave Request",
            filters={
                "employee": employee,
                "workflow_state": "Approved",
                "custom_consumption_status": "Available",
            },
            fields=[
                "name", "employee", "leave_type", "work_from_date", "work_end_date",
                "half_day", "half_day_date",
            ],
            order_by="work_from_date asc",
        )
        return _response(True, rows, _("Records fetched successfully"))
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Leave Application: get_available_comp_off_dates failed")
        return _response(False, None, _("Something went wrong while fetching available comp-off dates"))
