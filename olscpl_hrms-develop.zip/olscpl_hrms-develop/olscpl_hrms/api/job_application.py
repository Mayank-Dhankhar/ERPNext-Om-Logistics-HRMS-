# olscpl_hrms/api/job_application.py
#
# Choices for the public Job Application web form's custom fields
# (patches/v1_1/setup_job_application_reference_fields.py). Kept apart from
# api/careers.py, the external careers site's API.
import frappe


@frappe.whitelist(allow_guest=True)
def get_form_options(job_opening: str, company: str | None = None):
	"""A normal opening: its department, shown read-only. The pinned general
	opening: every company to choose from, then that company's
	departments (plus company-less ones) and its open, published jobs (all
	already public on /jobs)."""
	jo = frappe.db.get_value(
		"Job Opening",
		{"name": job_opening, "status": "Open", "publish": 1},
		["department", "custom_is_general"],
		as_dict=True,
	)
	if not jo:
		return {}
	if not jo.custom_is_general:
		return {"department": jo.department}
	companies = general_companies()
	out = {"is_general": 1, "companies": companies}
	if company in companies:
		out["departments"] = frappe.db.sql_list(
			"""select name from `tabDepartment` where is_group = 0 and disabled = 0
			and (company = %s or ifnull(company, '') = '') order by name""",
			company,
		)
		out["openings"] = frappe.get_all(
			"Job Opening",
			{"status": "Open", "publish": 1, "custom_is_general": 0, "company": company},
			["job_title as title"],
			order_by="job_title",
		)
	return out


def general_companies():
	"""Companies a General Application can be for: every company."""
	return frappe.get_all("Company", pluck="name", order_by="name")
