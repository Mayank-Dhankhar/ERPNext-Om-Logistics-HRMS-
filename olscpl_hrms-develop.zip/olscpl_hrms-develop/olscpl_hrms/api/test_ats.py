# Self-check for api/ats.py's text heuristics (no site needed for these):
#   cd sites && ../env/bin/python -m olscpl_hrms.api.test_ats
from olscpl_hrms.api import ats

RESUME = """Rahul Sharma
rahul.sharma@gmail.com | +91 98765 43210 | Gurugram, Haryana
Summary
Logistics operations manager with 6 years in line-haul and warehouse operations across North India, handling vendors and MIS reporting.
Experience
Operations Manager
ABC Logistics Pvt Ltd | Mar 2021 - Present
• Managed 40 vehicles and cut transit time by 12%
• Reduced freight cost by ₹15 lakh a year
Executive - Operations
XYZ Supply Chain Ltd | Jan 2018 - Feb 2021
• Handled MIS and vendor payments
Education
MBA (Operations), Delhi University, 2017, 68%
Skills
Excel, MIS, SAP, Transportation, Vendor Management, Tally
"""


def run():
	assert ats._highest_qual("B.Tech, Mechanical Engineering 2016") == "Graduate"
	assert ats._highest_qual("send me the engineering file 2019") is None
	assert ats._highest_qual("MBA (Finance)") == "Post Graduate"
	assert ats._highest_qual("worked 12 years") is None
	assert ats._ym("Mar 2021") == (2021, 3) and ats._ym("Jan'20") == (2020, 1) and ats._ym("06/2024") == (2024, 6)

	resume = {"text": RESUME, "pages": 1, "ext": "pdf", "bullets_xml": False, "has_photo": False}
	a = ats.analyse(resume)
	assert {"summary", "experience", "education", "skills"} <= set(a["secs"]), a["heads"]
	assert len(a["jobs"]) == 2 and a["years"] >= 8, (a["jobs"], a["years"])
	quality = ats.resume_score(resume, a)
	bare = ats.resume_score({**resume, "text": "Rahul Sharma\nrahul@gmail.com"}, ats.analyse({**resume, "text": "Rahul Sharma\nrahul@gmail.com"}))
	assert quality >= 75 and bare < 40, (quality, bare)
	ops = {"job_title": "Operations Manager", "location": "1306 - DELHI",
		"description": "Operations manager for line-haul logistics: vendors, warehouse, MIS reporting, freight cost, transit time"}
	acct = {"job_title": "Accountant", "location": "4907 - DHARUHERA",
		"description": "Accountant for GST returns, TDS filing, ledger reconciliation, audit support and balance sheet"}
	assert ats.job_fit(a, ops) > ats.job_fit(a, acct) + 30, (ats.job_fit(a, ops), ats.job_fit(a, acct))
	print("ats self-check ok:", quality, ats.job_fit(a, ops), ats.job_fit(a, acct))


if __name__ == "__main__":
	import frappe

	frappe.init("om-hrms", sites_path=".")
	frappe.connect()
	run()
