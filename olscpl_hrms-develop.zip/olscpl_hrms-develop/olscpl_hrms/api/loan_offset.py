import frappe
from frappe import _

BONUS_COMPONENTS = ["Bonus", "Leave Encashment"]

LOAN_TYPE_COMPONENT_MAP = {
	"Personal Loan": "LOAN-PERSONAL",
	"Mobile Loan": "LOAN-MOBILE",
	"Laptop Loan": "LOAN-LAPTOP",
}
LOAN_COMPONENT_FALLBACK = "LOAN"


@frappe.whitelist()
def get_offset_eligibility(salary_slip):
	"""
	Called by the Salary Slip form to determine whether the 'Apply Loan
	Offset' button should be shown, and to populate the confirmation dialog.
	Returns available bonus/encashment amount on this slip and the
	employee's total outstanding loan balance across active loans.
	"""
	doc = frappe.get_doc("Salary Slip", salary_slip)

	bonus_amount = sum(
		float(row.amount or 0) for row in doc.earnings
		if row.salary_component in BONUS_COMPONENTS
	)

	active_loans = frappe.get_all(
		"Employee Loan",
		filters={"employee": doc.employee, "status": "Active"},
		fields=["name", "loan_type", "outstanding_balance"],
		order_by="disbursement_date asc"
	)

	total_outstanding = sum(float(l.outstanding_balance or 0) for l in active_loans)

	return {
		"bonus_amount": bonus_amount,
		"total_outstanding": total_outstanding,
		"active_loans": active_loans,
		"eligible": bonus_amount > 0 and total_outstanding > 0
	}


@frappe.whitelist()
def apply_bonus_loan_offset(salary_slip, offset_amount):
	"""
	HR-triggered action (via Salary Slip button). Applies the confirmed
	offset_amount against the employee's active loans, earliest loan first,
	marking covered EMIs as 'Offset' (distinct from normal payroll 'Paid').
	Adds/updates the corresponding LOAN-* deduction row on this Salary Slip
	so it reflects in net pay immediately, matching policy points 7-8.
	"""
	offset_amount = float(offset_amount)

	if offset_amount <= 0:
		frappe.throw(_("Offset amount must be greater than zero."))

	doc = frappe.get_doc("Salary Slip", salary_slip)

	if doc.docstatus != 0:
		frappe.throw(_("Loan offset can only be applied while the Salary Slip is in Draft."))

	bonus_amount = sum(
		float(row.amount or 0) for row in doc.earnings
		if row.salary_component in BONUS_COMPONENTS
	)

	if offset_amount > bonus_amount:
		frappe.throw(
			_("Offset amount ({0}) cannot exceed available Bonus/Leave Encashment on this slip ({1}).")
			.format(offset_amount, bonus_amount)
		)

	active_loans = frappe.get_all(
		"Employee Loan",
		filters={"employee": doc.employee, "status": "Active"},
		fields=["name"],
		order_by="disbursement_date asc"
	)

	if not active_loans:
		frappe.throw(_("No active loans found for this employee."))

	remaining = offset_amount
	emi_by_component = {}
	loan_refs = []

	for loan_row in active_loans:
		if remaining <= 0:
			break

		loan = frappe.get_doc("Employee Loan", loan_row.name)

		if loan.outstanding_balance <= 0:
			continue

		component = LOAN_TYPE_COMPONENT_MAP.get(loan.loan_type, LOAN_COMPONENT_FALLBACK)

		for emi_row in loan.emi_schedule:
			if remaining <= 0:
				break
			if emi_row.status != "Pending":
				continue

			applied = min(remaining, emi_row.emi_amount)

			emi_row.status = "Offset"
			emi_row.paid_date = frappe.utils.today()
			emi_row.salary_slip = doc.name
			emi_row.remarks = f"Offset against Bonus/Leave Encashment via {doc.name}"

			loan_refs.append({
				"employee_loan": loan.name,
				"emi_amount": applied,
				"installment_number": emi_row.installment_number
			})

			emi_by_component[component] = emi_by_component.get(component, 0) + applied
			remaining = remaining - applied

		total_paid = sum(
			float(e.emi_amount or 0) for e in loan.emi_schedule if e.status in ("Paid", "Offset", "Prepaid")
		)
		loan.total_paid = total_paid
		loan.outstanding_balance = loan.principal_amount - total_paid

		if loan.outstanding_balance <= 0:
			loan.status = "Closed"
			loan.closed_date = frappe.utils.today()

		loan.save(ignore_permissions=True)

	applied_total = offset_amount - remaining

	for ref in loan_refs:
		doc.append("loan", ref)

	for component, amount in emi_by_component.items():
		row_found = False
		for row in doc.deductions:
			if row.salary_component == component:
				row.amount = round(float(row.amount or 0) + amount, 2)
				row_found = True
				break
		if not row_found:
			doc.append("deductions", {
				"salary_component": component,
				"amount": round(amount, 2)
			})

	doc.total_deduction = sum(float(d.amount or 0) for d in doc.deductions)
	doc.net_pay = round((doc.gross_pay or 0) - doc.total_deduction, 2)
	doc.save(ignore_permissions=True)

	return {
		"applied_amount": applied_total,
		"unapplied_amount": remaining,
		"message": f"₹{applied_total} applied against outstanding loan balance."
	}
