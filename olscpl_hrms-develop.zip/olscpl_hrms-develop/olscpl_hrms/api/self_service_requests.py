# olscpl_hrms/api/self_service_requests.py
#
# Mobile-app "My Requests"/"Team Requests" list APIs for Visit, Work From
# Home Request, and Compensatory Leave Request - olscpl_hrms/stock
# doctypes with real Frappe Workflows (Draft -> Pending ->
# Approved/Rejected), unlike hrms.api's own get_shift_requests/
# get_attendance_requests, which are hardcoded per doctype and don't
# cover these. Reuses hrms.api.get_filters and get_workflow_state_field
# directly rather than re-deriving the same approver/workflow-state
# permission logic - all three doctypes have an active Workflow, so
# get_filters' `if workflow := get_workflow(doctype)` branch
# (allowed-states-for-this-approver, permission-aware) already does the
# right thing without any doctype-specific approver_field_map entry.
import frappe
from hrms.api import get_filters, get_workflow_state_field

from olscpl_hrms.utils.reporting_person import team_pending_filters, team_request_names

VISIT_FIELDS = [
    "name",
    "employee",
    "employee_name",
    "visit_type",
    "from_date",
    "to_date",
    "day_portion",
    "docstatus",
    "creation",
]

WFH_FIELDS = [
    "name",
    "employee",
    "employee_name",
    "date",
    "location",
    "docstatus",
    "creation",
]

COMP_OFF_FIELDS = [
    "name",
    "employee",
    "employee_name",
    "leave_type",
    "work_from_date",
    "work_end_date",
    "custom_consumption_status",
    "docstatus",
    "creation",
]


def _get_requests(doctype, fields, employee, approver_id=None, for_approval=False, limit=None, order_by="creation desc"):
    filters = get_filters(doctype, employee, approver_id, for_approval)
    if frappe.utils.cint(for_approval):
        # Team Requests: only requests shared with me - i.e. I'm the chosen
        # Reporting Person or an HR of the employee's branch
        # (utils/reporting_person.py) - not everything my roles could read.
        # System Managers too: their company-wide list pushed the requests
        # actually assigned to them out of the app's top 10.
        filters["name"] = ["in", team_request_names(doctype)]
        filters.update(team_pending_filters(doctype))

    workflow_state_field = get_workflow_state_field(doctype)
    if workflow_state_field:
        fields = fields + [workflow_state_field]

    rows = frappe.get_list(
        doctype,
        fields=fields,
        filters=filters,
        order_by=order_by,
        limit=limit,
    )

    if workflow_state_field:
        for row in rows:
            row["workflow_state_field"] = workflow_state_field

    return rows


@frappe.whitelist()
def get_visit_requests(employee: str, approver_id: str | None = None, for_approval: bool = False, limit: int | None = None) -> list[dict]:
    return _get_requests("Visit", VISIT_FIELDS, employee, approver_id, for_approval, limit)


@frappe.whitelist()
def get_work_from_home_requests(employee: str, approver_id: str | None = None, for_approval: bool = False, limit: int | None = None) -> list[dict]:
    return _get_requests("Work From Home Request", WFH_FIELDS, employee, approver_id, for_approval, limit)


@frappe.whitelist()
def get_compensatory_leave_requests(employee: str, approver_id: str | None = None, for_approval: bool = False, limit: int | None = None) -> list[dict]:
    return _get_requests("Compensatory Leave Request", COMP_OFF_FIELDS, employee, approver_id, for_approval, limit)


LEAVE_FIELDS = [
    "name",
    "posting_date",
    "employee",
    "employee_name",
    "leave_type",
    "status",
    "from_date",
    "to_date",
    "half_day",
    "half_day_date",
    "description",
    "total_leave_days",
    "leave_balance",
    "leave_approver",
    "creation",
]


@frappe.whitelist()
def get_leave_requests(employee: str, approver_id: str | None = None, for_approval: bool = False, limit: int | None = None) -> list[dict]:
    """Same shape as hrms.api.get_leave_applications (the app's my-leaves
    list still uses that), plus the chosen-Reporting-Person scoping for
    Team Requests."""
    return _get_requests("Leave Application", LEAVE_FIELDS, employee, approver_id, for_approval, limit, order_by="posting_date desc")
