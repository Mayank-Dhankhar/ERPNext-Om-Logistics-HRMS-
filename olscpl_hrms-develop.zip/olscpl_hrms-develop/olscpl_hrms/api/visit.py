# olscpl_hrms/api/visit.py
#
# Mobile-app facing APIs for the "Visit" DocType. Same server-to-server
# model as api/regularization.py (see that file's module-level note) -
# every function takes a trusted `caller_employee` and is gated to the
# shared Administrator credential.
#
# FIELDS mirror the OMSTAFF Android app's existing "Branch Visit Entry"
# screen (activity/visit/AutoVisitReporting.java) exactly, since that's
# the payload shape the app already builds and POSTs today - just to a
# separate legacy endpoint (AppConfig.URL_VISIT, status="visit_entry")
# instead of this one:
#   empcode      -> employee (here: caller_employee/employee)
#   bcode        -> branch
#   visit_type   -> visit_type (Select: BRANCH/TRAINING/SEMINAR/OTHER/
#                  Client - same fixed list as the app's own "Select
#                  visit type" dialog)
#   source       -> source (Select: HOME/BRANCH/HOTEL - same fixed list
#                  as the app's own "Select Source Location" dialog)
#   destination  -> destination (free text - the app's own destination
#                  has no fixed list either, it's always either a branch
#                  name or a city name depending on visit_type)
#   from_date / to_date -> from_date / to_date
#   time         -> time
#   reporting_to -> reporting_person
#   remarks      -> remarks
#
# day_portion (Full Day/First Half/Second Half - not in the app's own
# payload, added on top of it) mirrors Attendance's existing Half Day
# concept: Attendance.status still ends up "Visit" either way, but a
# First/Second Half Visit writes a companion custom_visit_day_portion
# field on that Attendance record (patches/v1_1/
# add_visit_half_day_support.py) so it still counts as half a day for
# payroll - see events/salary_slip_steps.py's own note on this.
#
# lat/long/address/clients (the app's own location capture and dynamic
# client-name rows) are NOT fields here - out of scope for this doctype.
#
# WORKFLOW ("Visit Workflow", fixtures/workflow.json) - same shape as
# Work From Home Request's own workflow / Attendance Regularization
# Workflow:
#   States:      Draft(docstatus 0) -> Pending(0) -> Approved(1) / Rejected(0)
#   Transitions: Draft --Submit--> Pending (allowed: Employee)
#                Pending --Approve--> Approved (allowed: Manager + reports_to/HR condition)
#                Pending --Reject--> Rejected (allowed: Manager + reports_to/HR condition)
#   NOTE: only "Approve" actually submits the document (docstatus 0 -> 1),
#   which is what triggers events/visit.py's on_update() to
#   mark the employee's Attendance "Visit" for every day in [from_date,
#   to_date]. The legacy endpoint this doctype otherwise mirrors has no
#   approval step at all (submitting there is the whole flow) - only the
#   reporting-person notification (events/visit.py's after_insert(), the
#   Notification Log equivalent of the app's own PushNotification.send()
#   call) still fires immediately on create, same as the legacy app.
# workflow_state is set directly here rather than via apply_workflow(),
# which checks the Workflow's own role/condition against
# frappe.session.user - meaningless when every caller is the shared
# Administrator account (see api/regularization.py's note).
import frappe
from frappe import _
from frappe.utils import getdate

from olscpl_hrms.utils.reporting_person import omstaff_can_approve, omstaff_team_filters

DOCTYPE = "Visit"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _is_trusted_caller():
	return frappe.session.user == "Administrator"


def _response(success, payload=None, message=""):
	frappe.response["http_status_code"] = 200 if success else 400
	# See api/regularization.py's _response() for why message_log is cleared.
	frappe.local.message_log = []
	return {"success": success, "payload": payload, "message": message}


def _is_hr_manager_employee(employee):
	user = frappe.db.get_value("Employee", employee, "user_id")
	if not user:
		return False
	return "HR Manager" in frappe.get_roles(user)


def _is_direct_manager(employee, caller_employee):
	manager_employee = frappe.db.get_value("Employee", employee, "reports_to")
	return bool(manager_employee) and manager_employee == caller_employee


def _serialize(doc):
	return {
		"name": doc.name,
		"employee": doc.employee,
		"employee_name": doc.employee_name,
		"branch": doc.branch,
		"visit_type": doc.visit_type,
		"source": doc.source,
		"destination": doc.destination,
		"from_date": doc.from_date,
		"to_date": doc.to_date,
		"time": doc.time,
		"day_portion": doc.day_portion,
		"reporting_person": doc.reporting_person,
		"remarks": doc.remarks,
		"workflow_state": doc.workflow_state,
		"docstatus": doc.docstatus,
		"creation": doc.creation,
		"modified": doc.modified,
	}


# ---------------------------------------------------------------------------
# 1. CREATE + SUBMIT (single call for the mobile app)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def create_and_submit_visit(
	caller_employee,
	branch,
	visit_type,
	source,
	destination,
	from_date,
	to_date,
	reporting_person,
	time=None,
	day_portion="Full Day",
	remarks=None,
	employee=None,
):
	"""
	Creates a Visit (Draft) and immediately moves it to Pending in the
	reporting person's queue - same shape as
	create_and_submit_work_from_home_request(). Called by: the OM Staff
	App backend, server-to-server, using the Administrator credential.
	`caller_employee` is the Employee ID of whoever the app has already
	authenticated - it is trusted completely, which is why access is
	gated to Administrator only.
	"""
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		employee = employee or caller_employee
		if not frappe.db.exists("Employee", reporting_person):
			return _response(False, None, _("Unknown reporting_person"))
		if employee == reporting_person:
			return _response(False, None, _("Employee cannot be their own Reporting Person"))
		# Employees may only raise a visit for themselves. Managers may
		# raise on behalf of others only if they are HR, or the specific
		# employee's own reports_to manager - see api/regularization.py's
		# create_and_submit_regularization() for the same rule.
		if employee != caller_employee and not (
			_is_hr_manager_employee(caller_employee) or _is_direct_manager(employee, caller_employee)
		):
			return _response(False, None, _("You can only raise a visit for yourself, or for your direct reports"))
		doc = frappe.new_doc(DOCTYPE)
		doc.flags.ignore_permissions = True
		doc.employee = employee
		doc.branch = branch
		doc.visit_type = visit_type
		doc.source = source
		doc.destination = destination
		doc.from_date = getdate(from_date)
		doc.to_date = getdate(to_date)
		doc.time = time
		doc.day_portion = day_portion
		doc.reporting_person = reporting_person
		doc.remarks = remarks
		doc.insert()
		# Draft -> Pending. See create_and_submit_work_from_home_request()
		# for why this is set directly rather than via apply_workflow().
		doc.workflow_state = "Pending"
		doc.save()
		doc.reload()
		frappe.db.commit()  # noqa: frappe.db.commit is intentional at API boundary
		return _response(True, _serialize(doc), _("Visit submitted successfully"))
	except frappe.ValidationError as e:
		frappe.db.rollback()
		return _response(False, None, str(e))
	except Exception:
		frappe.db.rollback()
		frappe.log_error(frappe.get_traceback(), "Visit: create_and_submit failed")
		return _response(False, None, _("Something went wrong while submitting your visit"))


# ---------------------------------------------------------------------------
# 2. MANAGER ACTION — approve / reject
# ---------------------------------------------------------------------------
@frappe.whitelist()
def action_visit(caller_employee, name, action, remarks=None):
	"""
	action: "Approve" or "Reject". Restricted to HR Manager, or the
	specific employee's own reports_to manager - same rule as
	action_work_from_home_request(). `caller_employee` is trusted (see
	module-level note above) as the Employee ID of whoever the app's
	backend has already authenticated as the acting manager/HR user.
	"""
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		if action not in ("Approve", "Reject"):
			return _response(False, None, _("Invalid action. Use 'Approve' or 'Reject'"))
		doc = frappe.get_doc(DOCTYPE, name)
		doc.flags.ignore_permissions = True
		if not omstaff_can_approve(doc, caller_employee):
			return _response(False, None, _("Not permitted to action this request"))
		if doc.workflow_state != "Pending":
			return _response(False, None, _("Visit is not pending approval"))
		caller_name = frappe.db.get_value("Employee", caller_employee, "employee_name")
		comment_text = f"{action} by {caller_name} ({caller_employee})"
		if remarks:
			comment_text += f": {remarks}"
		doc.add_comment("Comment", comment_text)
		if action == "Approve":
			doc.workflow_state = "Approved"
			doc.submit()
		else:
			doc.workflow_state = "Rejected"
			doc.save()
		doc.reload()
		frappe.db.commit()  # noqa
		msg = _("Visit approved successfully") if action == "Approve" else _("Visit rejected")
		return _response(True, _serialize(doc), msg)
	except frappe.DoesNotExistError:
		return _response(False, None, _("Visit not found"))
	except frappe.ValidationError as e:
		frappe.db.rollback()
		return _response(False, None, str(e))
	except Exception:
		frappe.db.rollback()
		frappe.log_error(frappe.get_traceback(), "Visit: action failed")
		return _response(False, None, _("Something went wrong while processing this action"))


# ---------------------------------------------------------------------------
# 3a. VIEW — employee's own records ("My Visit Reports")
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_my_visits(caller_employee, from_date=None, to_date=None, workflow_state=None, limit=50, start=0):
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		filters = {"employee": caller_employee}
		if workflow_state:
			filters["workflow_state"] = workflow_state
		if from_date and to_date:
			filters["from_date"] = ["between", [getdate(from_date), getdate(to_date)]]
		rows = frappe.get_all(
			DOCTYPE,
			filters=filters,
			fields=[
				"name", "employee", "employee_name", "branch", "visit_type", "source", "destination",
				"from_date", "to_date", "time", "day_portion", "reporting_person", "remarks", "workflow_state", "docstatus",
				"creation", "modified",
			],
			order_by="creation desc",
			limit_page_length=int(limit),
			limit_start=int(start),
		)
		return _response(True, rows, _("Records fetched successfully"))
	except Exception:
		frappe.log_error(frappe.get_traceback(), "Visit: get_my failed")
		return _response(False, None, _("Something went wrong while fetching your records"))


# ---------------------------------------------------------------------------
# 3b. VIEW — visits reported to this manager/HR ("Visit MIS")
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_team_visits(caller_employee, workflow_state=None, employee=None, from_date=None, to_date=None, limit=50, start=0):
	"""
	Manager/HR view, mirroring VisitMIS.java. HR Manager sees every visit
	reported to any employee at the company; anyone else sees only visits
	reported to themselves as reporting_person.
	"""
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		filters = omstaff_team_filters(DOCTYPE, caller_employee, employee)
		if workflow_state:
			filters["workflow_state"] = workflow_state
		if from_date and to_date:
			filters["from_date"] = ["between", [getdate(from_date), getdate(to_date)]]
		rows = frappe.get_all(
			DOCTYPE,
			filters=filters,
			fields=[
				"name", "employee", "employee_name", "branch", "visit_type", "source", "destination",
				"from_date", "to_date", "time", "day_portion", "reporting_person", "remarks", "workflow_state", "docstatus",
				"creation", "modified",
			],
			order_by="creation desc",
			limit_page_length=int(limit),
			limit_start=int(start),
		)
		return _response(True, rows, _("Records fetched successfully"))
	except Exception:
		frappe.log_error(frappe.get_traceback(), "Visit: get_team failed")
		return _response(False, None, _("Something went wrong while fetching team records"))
