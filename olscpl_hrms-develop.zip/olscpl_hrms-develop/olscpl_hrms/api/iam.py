"""
olscpl_hrms/api/iam.py

Pull-based Employee Details API for User IAM, per the agreed contract:

    GET /api/method/olscpl_hrms.api.iam.get_employee_details?employee_id=OLSC0001

Auth: API key/secret (Frappe's standard token auth), per Chandan's
confirmation. IAM calls this with:

    Authorization: token <api_key>:<api_secret>

using a Frappe User created specifically for the IAM integration (create a
dedicated "iam-integration" User with only the permissions this endpoint
needs, then generate an API key/secret for it from that User's settings —
do NOT reuse a real employee's or admin's key).
"""

import frappe
from frappe import _

from olscpl_hrms.events.iam_sync import build_iam_payload


@frappe.whitelist()
def get_employee_details(employee_id: str):
	if not employee_id:
		frappe.throw(_("employee_id is required"), frappe.ValidationError)

	# employee_id from IAM is the business employee code (employee_number),
	# per the agreed contract — not the internal Employee doc name.
	name = frappe.db.get_value("Employee", {"employee_number": employee_id}, "name")
	if not name:
		frappe.local.response.http_status_code = 404
		return {"error": "not_found", "message": f"No employee found for employee_id={employee_id}"}

	doc = frappe.get_doc("Employee", name)
	return build_iam_payload(doc)
