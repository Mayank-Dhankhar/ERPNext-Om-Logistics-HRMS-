# olscpl_hrms/api/geocode.py
#
# Reverse geocoding (lat/long -> a readable address string) for whichever
# forms auto-fetch the browser's navigator.geolocation position
# (public/js/work_from_home_request.js, public/js/visit.js - see their
# own module-level notes on why that fetch exists and what gates it).
# Neither HRMS core's own Employee Checkin geolocation feature nor
# anything else in this codebase does reverse geocoding already (checked
# - no Google Maps API key or similar is configured anywhere in this
# site), so there's no existing paid/keyed service to reuse. Uses
# OpenStreetMap's free Nominatim API instead - no API key required,
# consistent with arjun_theme already vendoring Leaflet (OSM's own JS
# map library) rather than Google Maps anywhere in this app. Called
# server-side (not directly from the browser) to keep a single
# identifying User-Agent and avoid every client hitting Nominatim's
# public instance directly from the browser, which its usage policy
# (https://operations.osmfoundation.org/policies/nominatim/) asks
# integrators not to do.
import frappe
import requests

NOMINATIM_REVERSE_URL = "https://nominatim.openstreetmap.org/reverse"


@frappe.whitelist()
def reverse_geocode(latitude, longitude):
	"""Returns a short human-readable address for the given coordinates,
	or "" if the lookup fails for any reason (never raises - this is a
	best-effort convenience fill, not something a form should block on)."""
	try:
		response = requests.get(
			NOMINATIM_REVERSE_URL,
			params={"lat": latitude, "lon": longitude, "format": "jsonv2"},
			headers={"User-Agent": "olscpl_hrms (HR self-service forms)"},
			timeout=5,
		)
		response.raise_for_status()
		return response.json().get("display_name", "")
	except Exception:
		frappe.log_error(frappe.get_traceback(), "geocode: reverse_geocode failed")
		return ""
