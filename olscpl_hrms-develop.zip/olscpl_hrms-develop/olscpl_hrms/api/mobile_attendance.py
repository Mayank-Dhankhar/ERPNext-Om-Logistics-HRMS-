"""Attendance Regularization API for the Ionic/Vue mobile app
(apps/olscpl_hrms_mobile/frontend, forked from hrms's own frontend).

Session-based, unlike api/regularization.py (that one is for the separate
"OM Staff App", authenticates server-to-server as Administrator with an
explicitly-trusted caller_employee, and bypasses Frappe's permission system
entirely - it has no real per-request session to check against). Here the
logged-in user's own session is real, so every read/write below goes through
frappe's normal permission system unforced (no ignore_permissions) -
including the has_permission/permission_query_conditions hooks already
registered for this doctype in olscpl_hrms/permissions/queries.py, which is
what actually enforces "employees see their own + their manager's
records, managers/HR can act on their team's". This module only adds the
business-rule validation on top (regularization types, required punch
times, one pending request per employee/date) - not authorization.
"""

import frappe
from frappe import _
from frappe.utils import add_days, getdate

DOCTYPE = "Attendance Regularization"
REGULARIZATION_TYPES = (
    "Missing Punch IN",
    "Missing Punch OUT",
    "Both Punches Missing",
    "Less Working Hours",
)

FIELDS = [
    "name",
    "employee",
    "employee_name",
    "for_date",
    "requested_punch_in_time",
    "requested_punch_out_time",
    "regularization_type",
    "reason",
    "workflow_state",
    "reporting_person",
    "docstatus",
    "requires_hr_approval",
    "attendance_link",
    "creation",
    "modified",
]


def _current_employee():
    employee = frappe.db.get_value("Employee", {"user_id": frappe.session.user}, "name")
    if not employee:
        frappe.throw(_("No Employee record is linked to your user account"))
    return employee


def _fmt_time(value):
    """requested_punch_in_time/out_time come back from the DB as a raw
    Python timedelta (e.g. "12:22:7.901101" - unpadded, with microseconds)
    - neither this app's FormField.vue nor FormattedField.vue have a "Time"
    fieldtype case (both just show whatever string they're given), so
    format it into a plain HH:MM:SS here instead of relying on a frontend
    that has nowhere to do it."""
    if not value:
        return value
    t = frappe.utils.get_time(value)
    return t.strftime("%H:%M:%S")


def _fmt_doc_times(data):
    data["requested_punch_in_time"] = _fmt_time(data.get("requested_punch_in_time"))
    data["requested_punch_out_time"] = _fmt_time(data.get("requested_punch_out_time"))
    return data


@frappe.whitelist()
def get_regularization_requests(for_approval=False, limit=None):
    """Mirrors hrms.api.get_attendance_requests's shape (name/reason/
    employee/employee_name/workflow_state/creation/...) so the Vue list/
    item components built for "Attendance Request" need only a data-layer
    swap, not a rewrite - but queries this doctype and relies on its own
    permission_query_conditions hook for the for_approval scoping, instead
    of hand-rolling a manager/HR filter here.
    """
    for_approval = frappe.utils.cint(for_approval)
    filters = {}
    if not for_approval:
        filters["employee"] = _current_employee()
    else:
        # Team Requests: shared with me (their Reporting Person).
        # System Managers too - see self_service_requests._get_requests.
        from olscpl_hrms.utils.reporting_person import team_pending_filters, team_request_names

        filters["name"] = ["in", team_request_names(DOCTYPE)]
        filters["employee"] = ["!=", _current_employee()]
        filters.update(team_pending_filters(DOCTYPE))
    rows = frappe.get_list(
        DOCTYPE,
        fields=FIELDS,
        filters=filters,
        order_by="creation desc",
        limit_page_length=frappe.utils.cint(limit) if limit else None,
    )
    return [_fmt_doc_times(row) for row in rows]


@frappe.whitelist()
def get_regularization_request(name):
    """Single-record fetch for the mobile app's detail/view form - a thin
    wrapper around frappe.get_doc (same has_permission check as everything
    else here) that also applies _fmt_doc_times, so a native
    <input type="time"> on the frontend (which needs a strict HH:MM[:SS])
    doesn't get handed a raw unformatted timedelta straight from the DB."""
    doc = frappe.get_doc(DOCTYPE, name)
    data = _fmt_doc_times(doc.as_dict())
    data["can_cancel"] = doc.docstatus == 1 and bool(frappe.has_permission(DOCTYPE, "cancel", doc))
    return data


@frappe.whitelist()
def create_regularization_request(
    for_date,
    regularization_type,
    reason,
    requested_punch_in_time=None,
    requested_punch_out_time=None,
    reporting_person=None,
):
    employee = _current_employee()

    if not reason:
        frappe.throw(_("Reason is mandatory"))
    if regularization_type not in REGULARIZATION_TYPES:
        frappe.throw(
            _("Regularization Type must be one of: {0}").format(", ".join(REGULARIZATION_TYPES))
        )
    if regularization_type in ("Missing Punch IN", "Both Punches Missing") and not requested_punch_in_time:
        frappe.throw(_("Requested Punch IN Time is required for this regularization type"))
    # "Less Working Hours" belongs here too - see day_limit_and_punch_times
    # in olscpl_hrms/events/attendance_regularization_steps.py, the real
    # controller validation this has to match (and which would otherwise
    # throw its own, less specific error on insert()).
    if (
        regularization_type in ("Missing Punch OUT", "Both Punches Missing", "Less Working Hours")
        and not requested_punch_out_time
    ):
        frappe.throw(_("Requested Punch OUT Time is required for this regularization type"))

    existing = frappe.db.exists(
        DOCTYPE,
        {
            "employee": employee,
            "for_date": getdate(for_date),
            "workflow_state": ["in", ["Pending", "Approved"]],
        },
    )
    if existing:
        frappe.throw(
            _("A regularization request already exists for this date ({0})").format(existing)
        )

    doc = frappe.new_doc(DOCTYPE)
    doc.employee = employee
    doc.for_date = getdate(for_date)
    doc.regularization_type = regularization_type
    doc.requested_punch_in_time = requested_punch_in_time
    doc.requested_punch_out_time = requested_punch_out_time
    doc.reason = reason
    doc.reporting_person = reporting_person  # empty -> reports_to (events/attendance_regularization.py)
    doc.insert()
    doc.workflow_state = "Pending"
    doc.save()
    doc.reload()
    return _fmt_doc_times(doc.as_dict())


@frappe.whitelist()
def action_regularization_request(name, action, remarks=None):
    """action: "Approve" / "Reject" (Reporting Person), "Withdraw" (the
    employee, while Pending) or "Cancel" (HR Manager / System Manager, once
    Approved - see cancel_regularization). Same permission model as
    everything else here - frappe.get_doc()'s own has_permission check (see
    attendance_regularization_has_permission in queries.py) already
    determines whether this caller may open this specific document, this
    function only validates the action/state and applies it."""
    if action not in ("Approve", "Reject", "Withdraw", "Cancel"):
        frappe.throw(_("Invalid action. Use 'Approve', 'Reject', 'Withdraw' or 'Cancel'"))

    from olscpl_hrms.utils.reporting_person import is_system_manager

    doc = frappe.get_doc(DOCTYPE, name)
    if action == "Withdraw":
        withdraw_regularization(doc)
        return _fmt_doc_times(doc.as_dict())
    if action == "Cancel":
        cancel_regularization(doc)
        return _fmt_doc_times(doc.as_dict())
    if doc.workflow_state != "Pending":
        frappe.throw(_("Request is not pending approval"))
    # has_permission alone also lets the requester open their own request -
    # only the chosen Reporting Person or a System Manager may act on it.
    me = _current_employee() if not is_system_manager() else None
    if me:
        if doc.employee == me or doc.reporting_person != me:
            frappe.throw(
                _("Only the Reporting Person can approve or reject this request"),
                frappe.PermissionError,
            )

    if remarks:
        doc.add_comment("Comment", remarks)

    if action == "Approve":
        doc.workflow_state = "Approved"
        doc.submit()
    else:
        doc.workflow_state = "Rejected"
        doc.save()
    doc.reload()
    return _fmt_doc_times(doc.as_dict())


def withdraw_regularization(doc):
    """The employee takes back their own request while it is still Pending:
    nothing was applied to attendance yet. Set directly (not save()) so the
    raise-time checks - payroll cycle window, monthly limit - don't block
    withdrawing an older request."""
    from olscpl_hrms.utils.reporting_person import is_system_manager

    if doc.workflow_state != "Pending":
        frappe.throw(_("Only a pending request can be withdrawn"))
    if doc.employee != _current_employee() and not is_system_manager():
        frappe.throw(_("Only the employee who raised this request can withdraw it"), frappe.PermissionError)
    doc.db_set("workflow_state", "Withdrawn")
    doc.add_comment("Comment", _("Withdrawn by {0}").format(frappe.session.user))
    from frappe.desk.form.assign_to import clear

    clear(doc.doctype, doc.name, ignore_permissions=True)  # the approver's to-do


def cancel_regularization(doc):
    """HR takes back an approved request; on_cancel puts the day's attendance
    back to what the real punches give (events/attendance_regularization)."""
    if doc.docstatus != 1:
        frappe.throw(_("Only an approved request can be cancelled"))
    if not frappe.has_permission(DOCTYPE, "cancel", doc):
        frappe.throw(_("Only HR Manager can cancel an approved regularization"), frappe.PermissionError)
    doc.workflow_state = "Cancelled"
    doc.cancel()
    doc.reload()


# ── Pending requests on the attendance calendars ─────────────────────────────
# Same rules as the "Muster Roll" report on atlas, so every screen agrees:
#   R-PA   Attendance Regularization pending - replaces the day's symbol
#   L-PA   Leave Application pending (Open)   - only on a day marked Absent
#   WFH-PA Work From Home Request pending     - only on a day marked Absent
#   V-PA   Visit pending                      - only on a day marked Absent
# One symbol per day (R-PA, then L-PA, WFH-PA, V-PA). Used by the mobile app's
# AttendanceCalendar.vue and ess_dashboard's /ess-dashboard calendar.
def _pending_dates(doctype, employee, f_from, f_to, filters, start, end):
    rows = frappe.get_all(doctype, {"employee": employee, f_from: ["<=", end], f_to: [">=", start], **filters},
        [f"{f_from} as d_from", f"{f_to} as d_to"])
    days = set()
    for r in rows:
        day = max(getdate(r.d_from), start)
        while day <= min(getdate(r.d_to or r.d_from), end):
            days.add(day)
            day = add_days(day, 1)
    return days


def pending_codes(employee, from_date, to_date):
    """{date string: code} for this employee, Muster Roll rules."""
    start, end = getdate(from_date), getdate(to_date)
    pending = {"workflow_state": "Pending", "docstatus": ["<", 2]}
    reg = _pending_dates("Attendance Regularization", employee, "for_date", "for_date", pending, start, end)
    leave = _pending_dates("Leave Application", employee, "from_date", "to_date",
        {"status": "Open", "docstatus": ["<", 2]}, start, end)
    wfh = _pending_dates("Work From Home Request", employee, "date", "date", pending, start, end)
    visit = _pending_dates("Visit", employee, "from_date", "to_date", pending, start, end)
    absent = set(frappe.get_all("Attendance", {"employee": employee, "docstatus": 1, "status": "Absent",
        "attendance_date": ["between", [start, end]]}, pluck="attendance_date"))
    out = {}
    for day in sorted(reg | ((leave | wfh | visit) & absent)):
        if day in reg:
            out[str(day)] = "R-PA"
        elif day in leave:
            out[str(day)] = "L-PA"
        elif day in wfh:
            out[str(day)] = "WFH-PA"
        else:
            out[str(day)] = "V-PA"
    return out


@frappe.whitelist()
def get_pending_request_codes(from_date, to_date):
    """{date: [code]} for the logged-in employee - mobile AttendanceCalendar.vue."""
    return {d: [c] for d, c in pending_codes(_current_employee(), from_date, to_date).items()}


def today_preview(employee):
    """Today's attendance as a provisional row for the app's log: the real
    Attendance is only made the next day, but the check-ins are live - so run
    the same rules (events/attendance_steps) on an unsaved Attendance and
    roll back anything they touched. None when today already has one."""
    from olscpl_hrms.events import attendance_steps as steps

    today = frappe.utils.getdate()
    if not employee or frappe.db.exists("Attendance", {"employee": employee, "attendance_date": today, "docstatus": ["!=", 2]}):
        return None
    trial = frappe.get_doc({"doctype": "Attendance", "employee": employee, "attendance_date": today, "status": ""})
    frappe.db.savepoint("today_preview")
    try:
        steps.resolve_shift_policy(trial)
        steps.process_daily_attendance(trial)
    finally:
        frappe.db.rollback(save_point="today_preview")  # e.g. the month's tracker it may create

    status, detail = trial.status, trial.get("custom_status_detail")
    if detail == "No check-out yet":
        status, detail = "Checked In", _("Final attendance is calculated tomorrow")
    elif detail == "No valid check-ins found":
        status, detail = "Not Checked In", _("No check-in yet today")
    return frappe._dict(
        name="today-preview",
        attendance_date=today,
        status=status or "Not Checked In",
        custom_check_in_time=trial.get("custom_check_in_time"),
        custom_check_out_time=trial.get("custom_check_out_time"),
        custom_status_detail=detail,
        custom_violation_type=trial.get("custom_violation_type"),
        provisional=1,
    )
