"""
OLSCPL-HRMS-TDS-001 (v5) : Standard TDS Advisory Engine
------------------------------------------------------------------
App file: olscpl_hrms/api/tds_advisory.py

v5 replaces the flat monthly_gross x 12 annual projection with the
same cumulative "true-up" method used in the Salary Slip TDS script
(apply_tds_validation): actual gross for months already processed
(pulled from submitted Salary Slips) + recurring monthly gross
(one-time components stripped) x months remaining. This keeps the
Advisory page consistent with what actually gets deducted on the
slip each month, instead of drifting from a separate estimate.

v5 also returns a month-wise breakdown (monthly_gross / is_actual)
so the front-end table can show Apr/May/Jun as actuals and Jul-Mar
as projected recurring gross, matching the payroll cycle.

v4 fix (still included): interval-overlap test for slip/period
matching, in case payroll_period boundaries don't align exactly
with calendar months.

v3 fix (still included): Payroll Period is per-company, resolve
company via Salary Structure Assignment BEFORE querying Payroll
Period.
"""

import frappe
from frappe.utils import flt, today, getdate
from olscpl_hrms.utils.payroll_constants import ONE_TIME_COMPONENTS


OLD_REGIME_REBATE_LIMIT = 500000
OLD_REGIME_REBATE_MAX = 12500
NEW_REGIME_REBATE_LIMIT = 1200000
CESS_RATE = 0.04

# Must stay in sync with allowed_earnings in the "ZZ Salary Slip
# Fixed Component" script and ALLOWED_EARNINGS_FOR_SLIP in
# apply_tds_validation (Salary Slip Before Save).
ALLOWED_EARNINGS_FOR_SLIP = [
    "Basic",
    "House Rent Allowance",
    "Conveyance",
    "Child Education Allowance",
    "Uniform Allowance",
    "Advance Bonus",
]

MONTH_LABELS = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]


def _resolve_employee(employee):
    employee = employee or frappe.session.user
    if employee and "@" in str(employee):
        row = frappe.db.get_value("Employee", {"user_id": employee}, "name")
        return row
    return employee


def _get_active_ssa(employee, as_on_date):
    return frappe.db.get_value(
        "Salary Structure Assignment",
        {"employee": employee, "docstatus": 1, "from_date": ["<=", as_on_date]},
        ["name", "salary_structure", "income_tax_slab", "base", "company"],
        order_by="from_date desc",
        as_dict=True,
    )


def _get_payroll_period(company, fiscal_year):
    pp = frappe.get_all(
        "Payroll Period",
        filters={
            "company": company,
            "start_date": ["<=", "%s-12-31" % fiscal_year],
            "end_date": [">=", "%s-01-01" % fiscal_year],
        },
        fields=["name", "start_date", "end_date"],
        order_by="start_date desc",
        limit_page_length=1,
    )
    if pp:
        return pp[0].name, pp[0].start_date, pp[0].end_date
    return None, None, None


def _get_regime_slab(company, want_old_regime):
    filters = {"company": company, "allow_tax_exemption": 1 if want_old_regime else 0, "disabled": 0}
    candidates = frappe.get_all(
        "Income Tax Slab", filters=filters, fields=["name", "modified"], order_by="modified desc"
    )
    if not candidates:
        return None
    if len(candidates) > 1:
        frappe.log_error(
            title="TDS Advisory: duplicate Income Tax Slab candidates",
            message="Company=%s old_regime=%s candidates=%s. Using most recently modified: %s." % (
                company, want_old_regime, [c.name for c in candidates], candidates[0].name
            ),
        )
    return frappe.get_doc("Income Tax Slab", candidates[0].name)


def _slab_tax(taxable_income, slab_rows):
    tax = 0.0
    for row in slab_rows:
        from_amt = flt(row.from_amount)
        to_amt = flt(row.to_amount) if row.to_amount else taxable_income
        rate = flt(row.percent_deduction) / 100
        if taxable_income > from_amt:
            band = min(taxable_income, to_amt) - from_amt
            if band > 0:
                tax += band * rate
    return tax


def _apply_87a_rebate(tax, taxable_income, is_old_regime):
    if is_old_regime:
        if taxable_income <= OLD_REGIME_REBATE_LIMIT:
            return max(tax - OLD_REGIME_REBATE_MAX, 0) if tax > OLD_REGIME_REBATE_MAX else 0
        return tax
    else:
        if taxable_income <= NEW_REGIME_REBATE_LIMIT:
            return 0
        excess_income = taxable_income - NEW_REGIME_REBATE_LIMIT
        if excess_income < tax:
            return tax - (tax - excess_income)
        return tax


def _slab_tax_up_to(income_amount, is_old_regime):
    cache_key = "_slab_tax_cache_%s" % is_old_regime
    cache = getattr(frappe.local, cache_key, None)
    if cache is None:
        return 0
    return _slab_tax(income_amount, cache)


def _apply_surcharge(tax, taxable_income, is_old_regime, slab_rows):
    rule = frappe.get_doc("Income Tax Surcharge Rule")
    surcharge_rows = rule.old_regime_slabs if is_old_regime else rule.new_regime_slabs

    surcharge_rate = 0.0
    threshold = None
    for row in surcharge_rows:
        from_amt = flt(row.from_amount)
        to_amt = flt(row.to_amount) if row.to_amount else taxable_income
        if from_amt <= taxable_income <= to_amt:
            surcharge_rate = flt(row.surcharge_percentage)
            threshold = from_amt
            break

    if surcharge_rate <= 0:
        return tax, 0.0

    surcharge = tax * surcharge_rate / 100

    # Marginal relief: total (tax + surcharge) must not exceed
    # (tax + surcharge at the band limit) + (income above the limit)
    limit = threshold - 1
    prev_rate = 0.0
    for row in surcharge_rows:
        if flt(row.to_amount) == limit:
            prev_rate = flt(row.surcharge_percentage)
            break
    tax_at_limit = _slab_tax(limit, slab_rows) * (1 + prev_rate / 100)
    max_allowed = tax_at_limit + (taxable_income - limit)
    if (tax + surcharge) > max_allowed:
        surcharge = max(max_allowed - tax, 0)

    return tax + surcharge, surcharge


def _fy_month_number(a_date):
    """Apr=1 ... Mar=12"""
    if a_date.month >= 4:
        return a_date.month - 3
    return a_date.month + 9


def _get_additional_salary_components(employee, period_start, period_end):
    """
    Components with an Additional Salary record covering this period
    (recurring, or a one-off payroll_date within it). Used instead of
    Salary Detail's additional_salary link field, because the "ZZ
    Salary Slip Fixed Component" script does not persist that link
    when it rebuilds the earnings/deductions child tables -- relying
    on it for already-submitted slips silently drops components like
    CCA and Education Scholarship that were legitimately injected via
    Additional Salary.
    """
    rows = frappe.db.sql("""
        SELECT DISTINCT salary_component
        FROM `tabAdditional Salary`
        WHERE employee = %s
          AND docstatus = 1
          AND disabled = 0
          AND (
                (is_recurring = 1 AND from_date <= %s AND to_date >= %s)
                OR (payroll_date BETWEEN %s AND %s)
          )
    """, (employee, period_end, period_start, period_start, period_end), as_dict=True)
    return set(r.salary_component for r in rows)


def _get_recurring_gross_from_slip(slip_name):
    """
    Given a submitted Salary Slip name, compute the recurring monthly
    gross. Trusts Salary Detail as-is (no whitelist/Additional-Salary
    filtering) since the "ZZ Salary Slip Fixed Component" script has
    already filtered doc.earnings down to only genuine, visible
    components before save. One-time components (Leave Encashment,
    Incentive, Performance Bonus) are stripped by name regardless of
    how they entered the slip -- manually, or via Additional Salary.
    """
    rows = frappe.db.sql(
        """SELECT salary_component, amount
           FROM `tabSalary Detail`
           WHERE parent=%s AND parentfield='earnings'""",
        (slip_name,), as_dict=True,
    )

    current_month_gross = 0.0
    one_time_amount = 0.0

    for r in rows:
        comp = str(r.salary_component or "").strip()
        if not comp:
            continue
        amt = flt(r.amount)
        current_month_gross += amt
        if comp in ONE_TIME_COMPONENTS:
            one_time_amount += amt

    return current_month_gross, (current_month_gross - one_time_amount)


def _get_recurring_gross_from_ssa(ssa):
    """
    Fallback when no Salary Slip has been submitted yet this FY —
    derive a baseline recurring gross from the Salary Structure's
    template earnings (base + allowed components), since there is
    no actual slip yet to read from.
    """
    monthly_gross = flt(ssa.base)

    earning_rows = frappe.db.sql(
        """SELECT salary_component, amount FROM `tabSalary Detail`
           WHERE parent=%s AND parentfield='earnings'""",
        (ssa.salary_structure,), as_dict=True,
    )
    for e in earning_rows:
        comp = str(e.salary_component or "").strip()
        if comp and "basic" not in comp.lower() and comp in ALLOWED_EARNINGS_FOR_SLIP:
            monthly_gross += flt(e.amount)

    # Recurring Additional Salary (excludes one-off additional salary entries)
    additional_rows = frappe.db.sql(
        """SELECT amount FROM `tabAdditional Salary`
           WHERE employee=%s AND docstatus=1 AND is_recurring=1""",
        (ssa.employee,) if hasattr(ssa, "employee") else (None,), as_dict=True,
    ) if hasattr(ssa, "employee") else []

    for a in additional_rows:
        monthly_gross += flt(a.amount)

    return monthly_gross

def _get_component_amount_from_slip(slip_name, component_name):
    rows = frappe.db.sql(
        """SELECT amount FROM `tabSalary Detail`
           WHERE parent=%s AND parentfield='earnings' AND salary_component=%s""",
        (slip_name, component_name), as_dict=True,
    )
    return sum(flt(r.amount) for r in rows)

@frappe.whitelist()
def get_employee_tds_advisory(employee=None, fiscal_year=None):
    employee = _resolve_employee(employee)
    if not employee:
        return {"error": "No Employee record found for this user. Ask HR to set the user_id field on your Employee record."}

    fiscal_year = int(fiscal_year or getdate(today()).year)

    approx_fy_end = "%s-03-31" % (fiscal_year + 1)
    ssa = _get_active_ssa(employee, approx_fy_end)
    if not ssa:
        return {"error": "No active Salary Structure Assignment found for %s as of %s." % (employee, approx_fy_end)}
    company = ssa.company

    pp_name, pp_start, pp_end = _get_payroll_period(company, fiscal_year)
    if not pp_name:
        pp_name, pp_start, pp_end = "", "%s-04-01" % fiscal_year, "%s-03-31" % (fiscal_year + 1)

    fy_start_date = getdate("%s-04-01" % fiscal_year)
    fy_end_date = getdate("%s-03-31" % (fiscal_year + 1))

    # ============================================================
    # STEP: PULL ACTUAL SUBMITTED SLIPS FOR THIS FY (calendar-month
    # aligned start_date, per current payroll cycle configuration)
    # ============================================================
    submitted_slips = frappe.db.sql(
        """SELECT name, start_date, gross_pay, payment_days, total_working_days
           FROM `tabSalary Slip`
           WHERE employee=%s AND docstatus=1
             AND start_date >= %s AND start_date <= %s
           ORDER BY start_date ASC""",
        (employee, fy_start_date, fy_end_date), as_dict=True,
    )

    processed_months = {}   # fy_month_number -> {gross, tds, name, label}
    for slip in submitted_slips:
        slip_start = getdate(slip.start_date)
        month_no = _fy_month_number(slip_start)

        tds_row = frappe.db.sql(
            """SELECT amount FROM `tabSalary Detail`
               WHERE parent=%s AND parentfield='deductions'
                 AND salary_component='TDS' LIMIT 1""",
            (slip.name,), as_dict=True,
        )
        tds_amount = flt(tds_row[0].amount) if tds_row else 0.0

        processed_months[month_no] = {
            "slip": slip.name,
            "gross": flt(slip.gross_pay),
            "tds": tds_amount,
            "label": MONTH_LABELS[month_no - 1],
            "payment_days": flt(slip.payment_days),
            "total_working_days": flt(slip.total_working_days),
        }

    slips_processed = len(processed_months)
    months_left = max(12 - slips_processed, 0)

    # ============================================================
    # STEP: RECURRING MONTHLY GROSS FOR PROJECTING FUTURE MONTHS
    # Uses the latest processed slip if one exists, else falls back
    # to the Salary Structure template.
    # ============================================================
    recurring_source_slip_name = None

    if processed_months:
        latest_month_no = max(processed_months.keys())
        latest_slip_name = processed_months[latest_month_no]["slip"]

        latest_payment_days = processed_months[latest_month_no].get("payment_days") or 0
        latest_total_working_days = processed_months[latest_month_no].get("total_working_days") or 0
        latest_had_lop = (
            latest_total_working_days > 0
            and latest_payment_days > 0
            and latest_payment_days < latest_total_working_days
        )

        if latest_had_lop:
            full_attendance_slip_name = None
            for month_no in sorted(processed_months.keys(), reverse=True):
                m = processed_months[month_no]
                m_payment_days = m.get("payment_days") or 0
                m_total_working_days = m.get("total_working_days") or 0
                if m_total_working_days > 0 and m_payment_days >= m_total_working_days:
                    full_attendance_slip_name = m["slip"]
                    break

            if full_attendance_slip_name:
                recurring_source_slip_name = full_attendance_slip_name
                _, recurring_monthly_gross = _get_recurring_gross_from_slip(full_attendance_slip_name)
            else:
                recurring_source_slip_name = latest_slip_name
                _, recurring_monthly_gross = _get_recurring_gross_from_slip(latest_slip_name)
        else:
            recurring_source_slip_name = latest_slip_name
            _, recurring_monthly_gross = _get_recurring_gross_from_slip(latest_slip_name)
    else:
        recurring_monthly_gross = _get_recurring_gross_from_ssa(ssa)

    # ============================================================
    # STEP: BUILD MONTH-WISE BREAKDOWN (Apr..Mar) FOR THE UI TABLE
    # ============================================================
    monthly_breakdown = []
    actual_gross_total = 0.0

    for month_no in range(1, 13):
        label = MONTH_LABELS[month_no - 1]
        if month_no in processed_months:
            gross = processed_months[month_no]["gross"]
            tds = processed_months[month_no]["tds"]
            is_actual = True
            actual_gross_total += gross
        else:
            gross = recurring_monthly_gross
            tds = None
            is_actual = False

        monthly_breakdown.append({
            "month": label,
            "month_no": month_no,
            "gross": round(gross, 2),
            "tds": round(tds, 2) if tds is not None else None,
            "is_actual": is_actual,
        })

    projected_remaining_gross = recurring_monthly_gross * months_left
    annual_gross = actual_gross_total + projected_remaining_gross

    tds_ytd = sum(m["tds"] or 0 for m in processed_months.values()) if processed_months else 0.0
    

    #19-08-2026
    # ============================================================
    # STEP: OLD REGIME-ONLY EXEMPTION -- UNIFORM ALLOWANCE
    # Entire annual amount fully exempt under Old Regime. Actual
    # sum from processed months + LOP-aware recurring baseline
    # (recurring_source_slip_name, same source used for overall
    # recurring_monthly_gross above) x months remaining.
    # ============================================================
    uniform_actual_total = 0
    for m in processed_months.values():
        uniform_actual_total += _get_component_amount_from_slip(m["slip"], "Uniform Allowance")

    if recurring_source_slip_name:
        recurring_uniform = _get_component_amount_from_slip(recurring_source_slip_name, "Uniform Allowance")
    else:
        recurring_uniform = 0
        struct_rows = frappe.db.sql(
            """SELECT amount FROM `tabSalary Detail`
               WHERE parent=%s AND parentfield='earnings' AND salary_component='Uniform Allowance'""",
            (ssa.salary_structure,), as_dict=True,
        )
        for r in struct_rows:
            recurring_uniform += flt(r.amount)

    annual_uniform_allowance = uniform_actual_total + (recurring_uniform * months_left)

    # ============================================================
    # STEP: DECLARATIONS (existing category fetch, PLUS rent/metro
    # fields for month-wise HRA recompute below)
    # ============================================================
    declaration = frappe.get_all(
        "Employee Tax Exemption Declaration",
        filters={"employee": employee, "payroll_period": pp_name},
        fields=["name", "annual_hra_exemption", "monthly_house_rent", "rented_in_metro_city"],
        limit_page_length=1,
    )
    hra_exemption_declared = 0.0
    monthly_rent = 0
    is_metro = 0
    declared_by_category = {}
    if declaration:
        hra_exemption_declared = flt(declaration[0].annual_hra_exemption)
        monthly_rent = flt(declaration[0].monthly_house_rent)
        is_metro = declaration[0].rented_in_metro_city or 0
        cat_rows = frappe.db.sql(
            """SELECT exemption_category, amount FROM `tabEmployee Tax Exemption Declaration Category`
               WHERE parent=%s""",
            (declaration[0].name,), as_dict=True,
        )
        for r in cat_rows:
            declared_by_category[r.exemption_category] = declared_by_category.get(r.exemption_category, 0) + flt(r.amount)

    categories = frappe.get_all("Employee Tax Exemption Category", fields=["name", "max_amount"])
    total_declared_capped = 0.0
    category_breakdown = []
    for c in categories:
        declared = declared_by_category.get(c.name, 0)
        max_amt = flt(c.max_amount)
        capped = min(declared, max_amt) if max_amt else declared
        total_declared_capped += capped
        category_breakdown.append({"category": c.name, "max_amount": max_amt, "declared": round(declared, 2)})
    

    

    #24-08-2026
    # ============================================================
    # STEP: OLD REGIME HRA EXEMPTION -- MONTH-WISE RECOMPUTE
    # Mirrors apply_tds_validation: for EACH month, HRA exemption =
    # MIN(cap% * that month's Basic, that month's actual HRA, rent -
    # 10% * that month's Basic). Summed across 12 months. Actual
    # Basic/HRA for processed months; LOP-aware recurring baseline
    # (recurring_source_slip_name) for unprocessed months.
    # ============================================================

    def _compute_monthly_hra_exemption(basic_amt, hra_amt, rent, metro):
        cap_pct = 0.5 if metro else 0.4
        rent_limit = rent - (basic_amt * 0.10)
        if rent_limit < 0:
            rent_limit = 0
        return min(cap_pct * basic_amt, hra_amt, rent_limit)

    hra_exemption = hra_exemption_declared

    if monthly_rent > 0:
        monthly_basic = {}
        monthly_hra = {}
        for month_no, m in processed_months.items():
            rows = frappe.db.sql(
                """SELECT salary_component, amount FROM `tabSalary Detail`
                   WHERE parent=%s AND parentfield='earnings'
                     AND salary_component IN ('Basic', 'House Rent Allowance')""",
                (m["slip"],), as_dict=True,
            )
            for r in rows:
                if r.salary_component == "Basic":
                    monthly_basic[month_no] = monthly_basic.get(month_no, 0) + flt(r.amount)
                else:
                    monthly_hra[month_no] = monthly_hra.get(month_no, 0) + flt(r.amount)

        if recurring_source_slip_name:
            proj_basic = _get_component_amount_from_slip(recurring_source_slip_name, "Basic")
            proj_hra = _get_component_amount_from_slip(recurring_source_slip_name, "House Rent Allowance")
        else:
            proj_basic = flt(ssa.base)
            proj_hra = 0
            struct_rows = frappe.db.sql(
                """SELECT amount FROM `tabSalary Detail`
                   WHERE parent=%s AND parentfield='earnings' AND salary_component='House Rent Allowance'""",
                (ssa.salary_structure,), as_dict=True,
            )
            for r in struct_rows:
                proj_hra += flt(r.amount)

        hra_exemption_recomputed = 0
        for m in range(1, 13):
            b = monthly_basic.get(m, proj_basic)
            h = monthly_hra.get(m, proj_hra)
            hra_exemption_recomputed += _compute_monthly_hra_exemption(b, h, monthly_rent, is_metro)

        hra_exemption = hra_exemption_recomputed


    # ============================================================
    # STEP: TAX CALCULATION (unchanged logic, now on true-up annual_gross)
    # ============================================================
    result = {}
    for regime_key, is_old in (("old", True), ("new", False)):
        slab_doc = _get_regime_slab(company, is_old)
        if not slab_doc:
            result[regime_key] = {"error": "No Income Tax Slab configured for company %s, regime=%s" % (company, "Old" if is_old else "New")}
            continue

        std_deduction = flt(slab_doc.standard_tax_exemption_amount)
        exemptions = std_deduction
        if is_old:
            exemptions += total_declared_capped + hra_exemption + annual_uniform_allowance

        taxable_income = max(annual_gross - exemptions, 0)

        setattr(frappe.local, "_slab_tax_cache_%s" % is_old, slab_doc.slabs)

        tax = _slab_tax(taxable_income, slab_doc.slabs)
        tax = _apply_87a_rebate(tax, taxable_income, is_old)
        tax, surcharge = _apply_surcharge(tax, taxable_income, is_old, slab_doc.slabs)
        cess = tax * CESS_RATE
        total_tax = tax + cess

        result[regime_key] = {
            "slab_used": slab_doc.name,
            "standard_deduction": std_deduction,
            "total_exemptions": round(exemptions, 2),
            "taxable_income": round(taxable_income, 2),
            "surcharge": round(surcharge, 2),
            "tax_before_cess": round(tax, 2),
            "cess": round(cess, 2),
            "total_tax": round(total_tax, 2),
        }

    old_tax = result.get("old", {}).get("total_tax", 0)
    new_tax = result.get("new", {}).get("total_tax", 0)
    recommended = "New Regime" if new_tax <= old_tax else "Old Regime"
    best_tax = min(old_tax, new_tax) if (old_tax and new_tax) else (old_tax or new_tax)
    tds_remaining = max(best_tax - tds_ytd, 0)
    monthly_tds_forward = tds_remaining / months_left if months_left > 0 else tds_remaining

    return {
        "employee": employee,
        "company": company,
        "fiscal_year": fiscal_year,
        "payroll_period": pp_name,
        "annual_gross": round(annual_gross, 2),
        "actual_gross_to_date": round(actual_gross_total, 2),
        "recurring_monthly_gross": round(recurring_monthly_gross, 2),
        "monthly_breakdown": monthly_breakdown,
        "slips_processed": slips_processed,
        "months_left": months_left,
        "declarations": category_breakdown,
        "hra_exemption": round(hra_exemption, 2),
        "old_regime": result.get("old"),
        "new_regime": result.get("new"),
        "recommended_regime": recommended,
        "regime_saving": round(abs(old_tax - new_tax), 2),
        "tds_ytd": round(tds_ytd, 2),
        "tds_remaining": round(tds_remaining, 2),
        "monthly_tds_forward": round(monthly_tds_forward, 2),
    }


@frappe.whitelist()
def get_employee_tds_advisory_for_hr(employee, fiscal_year=None):
    if not frappe.has_permission("Employee", "read", user=frappe.session.user):
        frappe.throw("Not permitted")
    allowed_roles = {"HR Manager", "HR User", "Payroll Manager", "System Manager"}
    if not (allowed_roles & set(frappe.get_roles())):
        frappe.throw("Only HR/Payroll roles can look up another employee's TDS advisory.")
    return get_employee_tds_advisory(employee=employee, fiscal_year=fiscal_year)