# olscpl_hrms/api/ats.py
#
# ATS Score for the Job Applicant list's "Bulk Upload Resumes" table, so HR can
# compare the uploaded candidates and sort them (public/js/job_applicant_list.js).
#   resume quality /100 - what any good resume should contain: contact, the
#                         standard sections, dated roles with results, a layout
#                         an ATS can read, clean writing
#   fit /100            - against the picked Job Opening: its description
#                         keywords, title, relevant experience, location
# With an opening the score is the average of the two, without one quality alone.
#
# Runs on this server only - text from api/resume_parser.py's readers,
# everything else pattern matching; no resume is sent anywhere.
# ponytail: heuristics, not a language model - date-based items (experience,
# stability), layout and spelling are estimates; swap in a parser/LLM if HR
# needs judgement rather than keyword evidence.
import io
import math
import re
import zipfile
from collections import Counter
from datetime import date

import frappe
from frappe.utils import flt, strip_html

from olscpl_hrms.api.resume_parser import _unspace, extract_text, parse

# ── vocabulary ───────────────────────────────────────────────────────────────
SECTION_HEADS = [  # first match wins
	("summary", r"(?:professional |career |executive |personal )?(?:summary|profile|objective|about me|overview)|career objective"),
	("experience", r"(?:work |professional |employment |career |job |industrial |organi[sz]ational |relevant )?(?:experience|history|employment)(?: details| summary)?|work history"),
	("education", r"(?:educational |academic |professional )?(?:education|qualifications?|academics?)(?: details| background| qualifications?)?|academic (?:details|background|record)"),
	("skills", r"(?:key |technical |core |professional |it |computer |software )?(?:skills?|competenc(?:y|ies)|expertise|skill set|proficienc(?:y|ies)|strengths)"),
	("projects", r"(?:academic |key |major |live )?projects?|internships?(?: experience)?"),
	("extras", r"certifications?|courses?|trainings?(?: attended)?|achievements?|awards?(?: (?:and|&) recognitions?)?|accomplishments?|languages?(?: known)?|extra[- ]?curricular(?: activities)?|activities|hobbies|interests"),
	("personal", r"personal (?:details|information|profile|data)"),
	("declaration", r"declaration"),
]
HEAD_RE = [(k, re.compile(rf"^(?:{p})\s*:?$", re.I)) for k, p in SECTION_HEADS]
BULLET = r"[•●▪■◦○➢➤►▶✓✔✦❖*\-–-]"

MONTHS = {m: i for i, m in enumerate("jan feb mar apr may jun jul aug sep oct nov dec".split(), 1)}
MONTH = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\.?"
DATE = rf"(?:{MONTH}\s*[',’]?\s*(?:19|20)?\d{{2}}|\d{{1,2}}\s*[/.-]\s*(?:19|20)\d{{2}}|(?:19|20)\d{{2}})"
RANGE_RE = re.compile(rf"({DATE})\s*(?:-|–|—|to|till|until)\s*({DATE}|present|current(?:ly)?|now|till date|to date|date|ongoing|today)", re.I)

TITLE_WORDS = (r"manager|executive|engineer|developer|analyst|consultant|officer|accountant|assistant|associate|specialist"
	r"|coordinator|supervisor|lead|head|director|intern|trainee|representative|clerk|operator|technician|designer"
	r"|administrator|in-?charge|agent|advisor|architect|tester|programmer|controller|auditor|incharge|president|admin|hr")
TITLE_RE = re.compile(rf"\b(?:{TITLE_WORDS})s?\b", re.I)
COMPANY_RE = re.compile(r"\b(?:pvt|private|ltd|limited|llp|inc|corp(?:oration)?|company|technologies|solutions|services|logistics"
	r"|industries|enterprises|group|bank|consultancy|consultants|infotech|systems|software|international|associates"
	r"|traders|motors|pharma|hospitals?|foods|retail|labs?|global|ventures)\b", re.I)
EDU_WORD_RE = re.compile(r"\b(?:school|college|university|institute|board|cbse|icse|class|b\.?\s?tech|m\.?\s?tech|b\.?com|m\.?com|mba|bca|mca|bba|b\.?sc|m\.?sc|diploma|10th|12th|ssc|hsc|degree|graduat)", re.I)

VERBS = set("""achieved acted added administered advised analysed analyzed arranged assessed assisted audited automated
built calculated chaired championed closed coached collaborated compiled completed conceived conducted configured
consolidated controlled converted coordinated co-ordinated created cut decreased defined delivered deployed designed
developed devised directed drafted drove eliminated enabled engineered enhanced established evaluated executed expanded
facilitated finalised finalized forecasted formulated generated grew guided handled headed identified implemented
improved increased initiated inspected installed instituted integrated introduced investigated launched led liaised
maintained managed mapped maximised maximized mentored migrated minimised minimized modernised monitored motivated
negotiated onboarded operated optimised optimized orchestrated organised organized oversaw participated performed
pioneered planned prepared presented processed procured produced programmed promoted proposed published raised
rebuilt reconciled recruited redesigned reduced re-engineered refined reorganised reported represented researched
resolved restructured revamped reviewed revitalised saved scheduled screened secured simplified sourced spearheaded
standardised standardized streamlined strengthened structured supervised supported surpassed tested trained
transformed translated troubleshot upgraded validated won wrote""".split())
QUANT_RE = re.compile(r"\d+(?:\.\d+)?\s*%|₹\s*\d|\brs\.?\s*\d|\binr\s*\d|\d+(?:\.\d+)?\s*(?:lakhs?|lacs?|crores?|cr|million|mn|k)\b"
	r"|\b(?:increased|reduced|improved|grew|saved|decreased|achieved|cut|boosted|generated)\b[^.\n]{0,50}\d", re.I)
MARKS_RE = re.compile(r"\d{2}(?:\.\d+)?\s*%|\bc?gpa\b|\b\d{1,2}(?:\.\d{1,2})?\s*/\s*10\b|percentage|first division|distinction|\bmarks\b", re.I)
YEAR_RE = re.compile(r"\b(?:19|20)\d{2}\b")
CLICHES = ["hard working", "hard-working", "hardworking", "team player", "go-getter", "go getter", "self-motivated",
	"self motivated", "result-oriented", "results-oriented", "result oriented", "think outside the box", "detail-oriented",
	"dynamic personality", "quick learner", "fast learner", "best of my knowledge", "dedicated and sincere", "punctual"]
PERSONAL = {
	"date of birth": r"date of birth|\bd\.?o\.?b\b",
	"marital status": r"marital status|\b(?:un)?married\b",
	"religion": r"\breligion\b",
	"caste": r"\bcaste\b|\bcategory\s*:\s*(?:gen|obc|sc|st)\b",
	"father's name": r"father'?s?\s*name|\bs/o\b|\bd/o\b",
	"gender": r"\bgender\b|\bsex\s*:",
}
MISSPELLINGS = {
	"managment": "management", "responsibilty": "responsibility", "responsiblity": "responsibility", "recieved": "received",
	"acheived": "achieved", "acheivement": "achievement", "achievment": "achievement", "experiance": "experience",
	"knowlege": "knowledge", "comunication": "communication", "communcation": "communication", "proffesional": "professional",
	"profesional": "professional", "sucessful": "successful", "succesful": "successful", "accomodate": "accommodate",
	"occured": "occurred", "seperate": "separate", "definately": "definitely", "enviroment": "environment",
	"goverment": "government", "independant": "independent", "maintainance": "maintenance", "maintenence": "maintenance",
	"oppurtunity": "opportunity", "oppertunity": "opportunity", "organisaton": "organisation", "persue": "pursue",
	"posses": "possess", "prefered": "preferred", "refered": "referred", "relevent": "relevant", "reponsible": "responsible",
	"sincerly": "sincerely", "techincal": "technical", "tecnical": "technical", "untill": "until", "wich": "which",
	"carrer": "career", "qualificaton": "qualification", "qualifcation": "qualification", "adress": "address",
	"bussiness": "business", "buisness": "business", "calender": "calendar", "excercise": "exercise", "familar": "familiar",
	"higly": "highly", "langauge": "language", "secratary": "secretary", "strenght": "strength", "succes": "success",
	"thier": "their", "eligiblity": "eligibility", "coordinatior": "coordinator", "excellant": "excellent",
}
LOCATIONS = ("andhra pradesh|arunachal|assam|bihar|chhattisgarh|goa|gujarat|haryana|himachal|jharkhand|karnataka|kerala"
	"|madhya pradesh|maharashtra|manipur|meghalaya|mizoram|nagaland|odisha|orissa|punjab|rajasthan|sikkim|tamil nadu"
	"|telangana|tripura|uttar pradesh|uttarakhand|west bengal|delhi|new delhi|ncr|jammu|kashmir|ladakh|chandigarh|puducherry"
	"|mumbai|bombay|pune|nagpur|nashik|thane|navi mumbai|bengaluru|bangalore|mysore|mysuru|hyderabad|secunderabad|chennai"
	"|madras|coimbatore|madurai|kolkata|calcutta|howrah|ahmedabad|surat|vadodara|baroda|rajkot|jaipur|jodhpur|udaipur"
	"|kota|ajmer|lucknow|kanpur|agra|varanasi|prayagraj|allahabad|meerut|ghaziabad|noida|greater noida|gurgaon|gurugram"
	"|faridabad|sonipat|panipat|ambala|karnal|rohtak|hisar|ludhiana|amritsar|jalandhar|mohali|patiala|dehradun|haridwar"
	"|shimla|indore|bhopal|gwalior|jabalpur|raipur|bilaspur|patna|gaya|ranchi|jamshedpur|dhanbad|bhubaneswar|cuttack"
	"|guwahati|kochi|cochin|trivandrum|thiruvananthapuram|kozhikode|visakhapatnam|vizag|vijayawada|guntur|tirupati"
	"|warangal|aurangabad|solapur|kolhapur|belgaum|hubli|mangalore|mangaluru|siliguri|durgapur|asansol|bareilly|aligarh"
	"|moradabad|gorakhpur|jhansi|bhiwadi|neemrana|manesar|sri ganga ?nagar|bikaner|alwar|bharatpur|sikar|india")
LOCATION_RE = re.compile(rf"\b(?:{LOCATIONS})\b", re.I)
JUNK_EMAIL_RE = re.compile(r"\d{5,}|cute|sexy|hot|cool|rockstar|king|queen|angel|baby|devil|killer|smart|dude|babu|jaan|love", re.I)
STOPWORDS = set("""a about above across after again against all also am an and any are as at be because been before being
below between both but by can could did do does doing down during each few for from further had has have having he her
here hers him his how i if in into is it its just me more most my no nor not of off on once only or other our out over
own same she should so some such than that the their them then there these they this those through to too under until
up very was we were what when where which while who whom why will with would you your yours etc per via within across
candidate candidates role roles job jobs position responsibilities responsibility requirement requirements required
must ability able strong good excellent knowledge experience experienced years year work working should looking team
company organization organisation including include includes various etc preferred preferable plus minimum maximum
ensure ensuring manage managing handle handling well related relevant skills skill understanding using based new key
like make making provide providing support supporting time daily within across apply salary location qualification
degree graduate shall must-have nice-to-have""".split())
QUAL_RE = [  # highest first
	("Doctorate", r"\bph\.?\s?d\b|\bdoctorate\b"),
	("Post Graduate", r"\bm\.?\s?b\.?\s?a\b|\bm\.?\s?tech\b|\bm\.?\s?com\b|\bm\.?\s?c\.?\s?a\b|\bm\.?\s?sc\b|(?-i:\bM\.?\s?E\b)(?=.*(?:engg|engineering|\d{4}))|\bpgdm\b|\bpgdba\b|\bpost[- ]?graduat|\bmaster'?s?\b|(?-i:\bM\.?\s?A\b)\.?\s?(?=\(|in\b|,|\s+(?:english|economics|hindi|history|political|psychology|sociology))|(?-i:\bC\.?\s?A\b)(?=.*(?:icai|chartered|final))|\bchartered accountant\b|\bllm\b"),
	("Graduate", r"\bb\.?\s?tech\b|(?-i:\bB\.?\s?E\b)(?=.*(?:engg|engineering|\d{4}))|\bb\.?\s?com\b|\bb\.?\s?c\.?\s?a\b|\bb\.?\s?b\.?\s?a\b|\bb\.?\s?sc\b|(?-i:\bB\.?\s?A\b)\.?\s?(?=\(|in\b|,|\s+(?:english|economics|hindi|history|political|psychology|sociology|program|pass|hons))|\bbachelor|\bgraduat(?:e|ion)\b|\bllb\b|\bb\.?\s?pharm|\bbba\b|\bbca\b|\bbms\b"),
	("Diploma", r"\bdiploma\b|\biti\b|\bpolytechnic\b"),
	("12th", r"\b12th\b|\b12\s*(?:class|std|standard|grade|board|pass)|\bxii\b|\bh\.?s\.?c\b|\bintermediate\b|senior secondary"),
	("10th", r"\b10(?:th)?\b\s*(?:class|std|standard|grade|board|pass)|\b10th\b|\bx\b\s*(?:class|std|board)|\bs\.?s\.?c\b|\bmatric|high school|secondary school"),
]
GENERIC_PLACE = set("corporate office head branch hub warehouse regional zonal zone area depot site plant the of and ho".split())

# ── reading ──────────────────────────────────────────────────────────────────
def read_resume(file_url):
	"""-> dict(text, pages, ext, bullets_xml, has_photo), or None if no such file."""
	file_name = frappe.db.get_value("File", {"file_url": file_url}, "name")
	if not file_name:
		return None
	file_doc = frappe.get_doc("File", file_name)
	content = file_doc.get_content()
	if isinstance(content, str):
		content = content.encode()
	fname = (file_doc.file_name or file_url).lower()
	ext = fname.rsplit(".", 1)[-1] if "." in fname else ""
	out = {"text": "", "pages": 0, "ext": ext, "bullets_xml": False, "has_photo": False}
	try:
		if ext in ("pdf", "docx"):
			out["text"] = extract_text(content, fname)
		if ext == "pdf":
			from pypdf import PdfReader

			reader = PdfReader(io.BytesIO(content))
			out["pages"] = len(reader.pages)
			try:
				xobj = (reader.pages[0].get("/Resources") or {}).get("/XObject") or {}
				out["has_photo"] = any(xobj[k].get_object().get("/Subtype") == "/Image" for k in xobj)
			except Exception:
				pass
		elif ext == "docx":
			with zipfile.ZipFile(io.BytesIO(content)) as z:
				out["bullets_xml"] = b"<w:numPr>" in z.read("word/document.xml")
				out["has_photo"] = any(n.startswith("word/media/") for n in z.namelist())
	except Exception:
		frappe.log_error(title=f"ATS: could not read {file_url}")
	return out


def _lines(text):
	return [ln for ln in (re.sub(r"\s+", " ", _unspace(raw)).strip() for raw in (text or "").splitlines()) if ln]


def _heading(line):
	clean = re.sub(rf"^{BULLET}+\s*|[:\-–|]+$", "", line).strip()
	if not clean or len(clean) > 45 or len(clean.split()) > 5:
		return None
	return next((key for key, rx in HEAD_RE if rx.match(clean)), None)


def _sections(lines):
	"""-> ({section: [lines]}, [(line index, section)])"""
	secs, heads, cur = {"header": []}, [], "header"
	for i, ln in enumerate(lines):
		key = _heading(ln)
		if key:
			cur = key
			heads.append((i, key))
			secs.setdefault(key, [])
		else:
			secs.setdefault(cur, []).append(ln)
	return secs, heads


def _ym(token, is_end=False):
	t = token.lower().strip()
	if re.fullmatch(r"present|current(?:ly)?|now|till date|to date|date|ongoing|today", t):
		today = date.today()
		return today.year, today.month
	m = re.match(rf"({MONTH})\s*[',’]?\s*((?:19|20)?\d{{2}})$", t)
	if m:
		mon = MONTHS.get(m.group(1)[:3])
		year = int(m.group(2))
	else:
		m = re.match(r"(\d{1,2})\s*[/.-]\s*((?:19|20)\d{2})$", t)
		if m:
			mon, year = int(m.group(1)), int(m.group(2))
		else:
			mon, year = (12 if is_end else 1), int(t)
	if year < 100:
		year += 2000 if year <= date.today().year % 100 else 1900
	if not (1 <= (mon or 0) <= 12) or not 1970 <= year <= date.today().year + 1:
		return None
	return year, mon


def _date_style(token):
	t = token.lower().strip()
	if re.match(MONTH, t):
		return "Mon YY" if re.search(r"[',’]\s*\d{2}$|\s\d{2}$", t) and not re.search(r"\d{4}$", t) else "Mon YYYY"
	return "MM/YYYY" if re.match(r"\d{1,2}\s*[/.-]", t) else "YYYY"


def _ranges(lines, secs_of_line):
	"""Every from-to date range -> dicts with line index, section, months, start/end (as month numbers)."""
	out = []
	for i, ln in enumerate(lines):
		for m in RANGE_RE.finditer(ln):
			a, b = _ym(m.group(1)), _ym(m.group(2), is_end=True)
			if not a or not b:
				continue
			start, end = a[0] * 12 + a[1], b[0] * 12 + b[1]
			if end < start or end - start > 45 * 12:
				continue
			out.append({"i": i, "sec": secs_of_line[i], "start": start, "end": end, "months": max(1, end - start),
				"styles": {_date_style(m.group(1))} | ({_date_style(m.group(2))} if re.search(r"\d", m.group(2)) else set())})
	return out


def _merge(intervals):
	merged = []
	for s, e in sorted(intervals):
		if merged and s <= merged[-1][1]:
			merged[-1][1] = max(merged[-1][1], e)
		else:
			merged.append([s, e])
	return merged


def _months(intervals):
	return sum(e - s for s, e in _merge(intervals))


def _norm(text):
	t = re.sub(r"[^a-z0-9+#.]+", " ", (text or "").lower())
	return " " + re.sub(r"\.(?!\w)|(?<!\w)\.", " ", t) + " "


def _highest_qual(text):
	for level, rx in QUAL_RE:
		if re.search(rx, text, re.I):
			return level
	return None


# ── analysis ───────────────────────────────────────────
def analyse(resume):
	text = resume["text"] or ""
	lines = _lines(text)
	secs, heads = _sections(lines)
	sec_of_line, cur, hi = [], "header", dict(heads)
	for i in range(len(lines)):
		cur = hi.get(i, cur)
		sec_of_line.append(cur)
	ranges = _ranges(lines, sec_of_line)
	near_edu = lambda r: r["sec"] == "education" or any(  # noqa: E731
		EDU_WORD_RE.search(lines[j]) for j in range(max(0, r["i"] - 1), min(len(lines), r["i"] + 2)))
	jobs = [r for r in ranges if r["sec"] not in ("education", "projects", "extras") and not near_edu(r)]
	if any(r["sec"] == "experience" for r in jobs):
		jobs = [r for r in jobs if r["sec"] == "experience"]
	words = re.findall(r"[A-Za-z][A-Za-z'+#.-]*", text)
	job_months = _months([(r["start"], r["end"]) for r in jobs])
	stated = [flt(m.group(1)) for m in re.finditer(r"(\d{1,2}(?:\.\d)?)\+?\s*(?:years?|yrs?)\b(?:[^.\n]{0,25})\bexperience", text, re.I)]
	years = round(job_months / 12, 1) if jobs else (min(max(stated), 40) if stated else 0)
	return {
		"text": text, "lines": lines, "secs": secs, "heads": heads, "ranges": ranges, "jobs": jobs,
		"years": years, "words": words, "norm": _norm(text), "parsed": parse(text),
	}


def _item(group, label, weight, score, note=""):
	return {"group": group, "label": label, "weight": weight, "score": round(max(0.0, min(1.0, score)), 2), "note": note}


def _total(items):
	scored = [i for i in items if i["score"] is not None]
	weight = sum(i["weight"] for i in scored)
	return round(100 * sum(i["weight"] * i["score"] for i in scored) / weight) if weight else 0


def _band(n, full, half):
	return 1.0 if n >= full else 0.5 if n >= half else 0.0


# ── resume quality ─────────────────────────────────────────────────────────────
def resume_score(resume, a):
	items = []
	secs, text, lines = a["secs"], a["text"], a["lines"]
	readable = len(text.strip())
	exp_lines = secs.get("experience", []) + secs.get("projects", [])

	# Contact (10)
	p = a["parsed"]
	email = p.get("email_id") or ""
	junk = bool(email) and bool(JUNK_EMAIL_RE.search(email.split("@")[0]))
	top = "\n".join(lines[:40]) + "\n" + "\n".join(secs.get("personal", []))
	items += [
		_item("Contact", "Name", 2, 1 if p.get("applicant_name") else 0),
		_item("Contact", "Email", 2, (0.5 if junk else 1) if email else 0, "unprofessional address" if junk else ""),
		_item("Contact", "Phone", 2, 1 if p.get("phone_number") else 0),
		_item("Contact", "Location", 2, 1 if LOCATION_RE.search(top) else 0),
		_item("Contact", "LinkedIn / portfolio", 2, 1 if re.search(r"linkedin\.com|github\.com|behance\.net|portfolio|https?://", text, re.I) else 0),
	]

	# Sections (25)
	summary_words = len(" ".join(secs.get("summary", [])).split())
	skills_items = [s for s in re.split(rf"[,|;/\n]|{BULLET}", "\n".join(secs.get("skills", []))) if 1 < len(s.strip()) <= 45]
	edu_text = "\n".join(secs.get("education", []))
	has_degree = bool(_highest_qual(edu_text or text))
	items += [
		_item("Sections", "Summary / objective", 5, (1 if 15 <= summary_words <= 150 else 0.5) if "summary" in secs else 0,
			f"{summary_words} words" if "summary" in secs else "no summary heading"),
		_item("Sections", "Work experience", 6, 1 if secs.get("experience") or secs.get("projects") else 0,
			"" if secs.get("experience") else ("internships / projects (fresher)" if secs.get("projects") else "no experience section")),
		_item("Sections", "Education", 5, (1 if has_degree else 0.5) if "education" in secs else (0.5 if has_degree else 0)),
		_item("Sections", "Skills", 5, _band(len(skills_items), 5, 2) if "skills" in secs else 0,
			f"{len(skills_items)} listed" if "skills" in secs else "no skills section"),
		_item("Sections", "Certifications / projects / achievements", 4, 1 if ("extras" in secs or "projects" in secs) else 0),
	]

	# Experience quality (25)
	exp_ranges = [r for r in a["ranges"] if r["sec"] == "experience"] or a["jobs"]
	all_lines = a["lines"]
	role_lines = [ln for ln in secs.get("experience", []) if TITLE_RE.search(ln) and len(ln.split()) <= 7
		and (re.sub(rf"^{BULLET}+\s*", "", ln).split() or [""])[0].lower() not in VERBS]
	roles = min(len(role_lines), 15)
	if not secs.get("experience") and not exp_ranges:
		dates_score, roles_score = 0, 0
	else:
		dates_score = min(1, len(exp_ranges) / roles) if roles else (1 if exp_ranges else 0)
		with_both = sum(1 for r in exp_ranges if
			any(TITLE_RE.search(all_lines[j]) for j in range(max(0, r["i"] - 3), min(len(all_lines), r["i"] + 3))) and
			any(COMPANY_RE.search(all_lines[j]) for j in range(max(0, r["i"] - 3), min(len(all_lines), r["i"] + 3))))
		roles_score = with_both / len(exp_ranges) if exp_ranges else (0.5 if role_lines else 0)
	bullet_lines = sum(1 for ln in exp_lines if re.match(BULLET, ln))
	if bullet_lines >= 3 or (resume["ext"] == "docx" and resume["bullets_xml"] and exp_lines):
		bullets = 1
	else:
		bullets = 0.5 if len(exp_lines) >= 4 and sum(len(ln) for ln in exp_lines) / len(exp_lines) < 110 else 0
	first_words = [(re.sub(rf"^{BULLET}+\s*", "", ln).split() or [""])[0].lower().strip(",.:") for ln in exp_lines]
	verb_lines = sum(1 for w in first_words if w in VERBS)
	resp_lines = sum(1 for ln in exp_lines if re.search(r"responsible for|duties include|worked on", ln, re.I))
	verbs = min(1, verb_lines / 5) * (0.5 if resp_lines > verb_lines else 1)
	quants = len(QUANT_RE.findall("\n".join(exp_lines + secs.get("extras", []) + secs.get("summary", []))))
	no_exp = not exp_lines
	items += [
		_item("Experience", "Dates on every job", 6, dates_score, f"{len(exp_ranges)} dated of ~{roles or len(exp_ranges)} roles" if exp_ranges or roles else ""),
		_item("Experience", "Job title and company per role", 5, roles_score),
		_item("Experience", "Bullet points", 4, bullets),
		_item("Experience", "Action verbs", 4, verbs, f"{verb_lines} lines start with one" + (f"; {resp_lines} 'responsible for'" if resp_lines else "")),
		_item("Experience", "Numbers and results", 6, _band(quants, 3, 1), f"{quants} found"),
	]
	if no_exp:
		for it in items[-5:]:
			it["note"] = "no experience section"

	# Education quality (5)
	edu_src = edu_text or text
	items.append(_item("Education", "Year of passing and marks / CGPA", 5,
		0.5 * bool(YEAR_RE.search(edu_src)) + 0.5 * bool(MARKS_RE.search(edu_src))))

	# Formatting (20)
	nwords = len(a["words"])
	glued = len(re.findall(r"[a-z]{3,}[A-Z][a-z]{2,}", text)) * 1000 / max(nwords, 1)
	short = sum(1 for ln in lines if len(ln.split()) <= 2) / max(len(lines), 1)
	std = sum(1 for k in ("summary", "experience", "education", "skills") if k in secs or (k == "experience" and "projects" in secs))
	pages = resume["pages"] or max(1, math.ceil(nwords / 550))
	ideal = 2 if a["years"] < 10 else 3
	length = 0.5 if nwords < 200 else 1 if pages <= ideal else 0.5 if pages == ideal + 1 else 0
	items += [
		_item("Formatting", "Text readable by an ATS", 6, 1 if readable >= 300 else 0.5 if readable >= 50 else 0,
			"" if readable >= 300 else "scanned / image-only"),
		_item("Formatting", "Standard headings", 4, {4: 1, 3: 0.75, 2: 0.5}.get(std, 0), f"{std} of 4 (Summary, Experience, Education, Skills)"),
		_item("Formatting", "Simple layout", 4, 1 - 0.5 * (glued > 8) - 0.5 * (short > 0.45),
			"text comes out jumbled - columns or tables" if glued > 8 or short > 0.45 else ""),
		_item("Formatting", "File type", 2, 1 if resume["ext"] in ("pdf", "docx") else 0, resume["ext"].upper()),
		_item("Formatting", "Length", 4, length, f"{pages} page{'s' if pages != 1 else ''}, {nwords} words"),
	]

	# Writing (15)
	decl_start = next((i for i, k in a["heads"] if k == "declaration"), len(lines))
	body_text = "\n".join(ln for i, ln in enumerate(lines) if i < decl_start and not re.search(r"hereby|declare|certify", ln, re.I))
	first_person = len(re.findall(r"\bI\b|\b(?:my|me|myself)\b", body_text))
	cliches = sorted({c.replace("-", " ").replace("hardworking", "hard working") for c in CLICHES if c in text.lower()})
	styles = set().union(*[r["styles"] for r in a["ranges"]]) if a["ranges"] else set()
	personal = [k for k, rx in PERSONAL.items() if re.search(rx, text, re.I)] + (["photo"] if resume["has_photo"] else [])
	typos = sorted({w.lower() for w in a["words"] if w.lower() in MISSPELLINGS})
	items += [
		_item("Writing", "No first person (I, my, me)", 3, 1 if first_person <= 2 else 0.5 if first_person <= 5 else 0, f"{first_person} found"),
		_item("Writing", "No clichés", 3, 1 if not cliches else 0.5 if len(cliches) == 1 else 0, ", ".join(cliches)),
		_item("Writing", "Consistent date format", 3, 1 if len(styles) <= 1 else 0.5 if len(styles) == 2 else 0, ", ".join(sorted(styles))),
		_item("Writing", "No personal details", 3, 1 if not personal else 0.5 if len(personal) <= 2 else 0, ", ".join(personal)),
		_item("Writing", "Spelling", 3, 1 if not typos else 0.5 if len(typos) <= 2 else 0,
			", ".join(f"{t} → {MISSPELLINGS[t]}" for t in typos)),
	]
	if readable < 50:  # nothing to judge but the file itself
		for it in items:
			if it["label"] != "File type":
				it["score"] = 0

	return _total(items)


# ── fit to the opening ───────────────────────────────────────────────────────
def job_fit(a, opening):
	"""How well the resume fits the Job Opening: its description, title, location, and a steady relevant career."""
	norm, items = a["norm"], []
	desc = strip_html(opening.get("description") or "").lower()
	tokens = [t.strip(".") for t in re.findall(r"[a-z][a-z+#.]{3,}", desc)]
	keywords = [w for w, _ in Counter(t for t in tokens if t not in STOPWORDS).most_common(25)]
	if len(keywords) >= 5:
		items.append(_item("", "Description keywords", 30, sum(1 for k in keywords if f" {k} " in norm) / len(keywords)))

	title_bits = {w for t in (opening.get("job_title"), opening.get("designation")) for w in _norm(t).split()
		if len(w) > 2 and w not in STOPWORDS and w not in ("senior", "junior", "trainee")}
	phrase_hit = any(t and f" {_norm(t).strip()} " in norm for t in (opening.get("job_title"), opening.get("designation")))
	items.append(_item("", "Job title", 25, 1 if phrase_hit else (sum(1 for w in title_bits if f" {w} " in norm) / len(title_bits) if title_bits else 0)))

	lines = a["lines"]
	if a["jobs"]:
		relevant = [r for r in a["jobs"] if any(f" {w} " in _norm(" ".join(lines[max(0, r["i"] - 2): r["i"] + 3])) for w in title_bits)]
		items.append(_item("", "Relevant experience", 20, min(1, _months([(r["start"], r["end"]) for r in relevant]) / 24)))
		avg = sum(r["months"] for r in a["jobs"]) / len(a["jobs"])
		items.append(_item("", "Career stability", 10, 1 if avg >= 24 else 0 if avg < 12 else 0.5 + (avg - 12) / 24))

	place = [w for w in re.split(r"[^a-z]+", re.sub(r"^\s*\d+\s*-\s*", "", (opening.get("location") or "").lower())) if len(w) > 2 and w not in GENERIC_PLACE]
	if place:
		items.append(_item("", "Location", 15, 1 if any(f" {w} " in norm for w in place) or "relocat" in norm else 0))
	return _total(items)


@frappe.whitelist()
def scores(file_urls, job_title=None):
	"""Bulk Upload Resumes table: ATS Score per uploaded resume -> {file_url: score}.
	With a Job Opening: half resume quality, half fit to the opening; without one, resume quality alone."""
	frappe.has_permission("Job Applicant", "create", throw=True)
	opening = frappe.db.get_value("Job Opening", job_title, "*", as_dict=True) if job_title else None
	out = {}
	for url in frappe.parse_json(file_urls) if isinstance(file_urls, str) else file_urls:
		try:
			resume = read_resume(url)
			if not resume:
				continue
			a = analyse(resume)
			quality = resume_score(resume, a)
			out[url] = round((quality + job_fit(a, opening)) / 2) if opening and not opening.get("custom_is_general") else quality
		except Exception:
			frappe.log_error(title=f"ATS score failed for {url}")
	return out
