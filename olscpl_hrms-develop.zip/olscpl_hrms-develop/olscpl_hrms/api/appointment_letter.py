# olscpl_hrms/api/appointment_letter.py
#
# "Appointment Letter" button on the Employee form (see public/js/
# employee.js), to the left of "Download Employee Digital File". Opens a
# preview of the letter (this module's PDF, embedded inline - see
# get_preview_pdf) with a "Send Mail" button in that same dialog; clicking
# Send is the only way this ever actually reaches the employee's inbox
# (send_appointment_letter is a separate, explicit whitelisted call, never
# triggered as a side effect of anything else).
#
# Content mirrors an actual signed OLSC appointment letter this was modeled
# on (clauses 1-12, same wording/order) - merge-field-ized for name/
# designation/date/CTC/reference number, and generalized to the company
# name instead of hardcoding "Om Logistics Supply Chain Private Limited",
# since this now has to work for any of the three group companies with a
# letterhead set up (see employee_data.py's company_letterhead_urls). HR
# should treat a first-generated letter as a draft to review, the same as
# any other auto-filled legal document - this fills in the personalized
# fields, it doesn't replace someone actually reading it before it's sent.
#
# The letter body itself (everything but the letterhead header/footer
# images and the fixed <style> block) is also HR-editable before sending -
# see get_editable_body/save_appointment_letter_body/
# reset_appointment_letter_body below and employee.js's "Edit Letter"
# button. Employee.custom_appointment_letter_html holds a saved edit, once
# there is one; _default_body_html() below is what's shown/sent otherwise.
# Letterhead images and CSS stay outside the editable region entirely -
# not something to risk a rich-text editor mangling, and not something HR
# asked to change per employee anyway.
import base64
import functools
import io
import os
import re

import frappe
from frappe import _
from frappe.utils import fmt_money
from frappe.utils.pdf import get_pdf
from PIL import Image
from pypdf import PdfReader

from olscpl_hrms.api.employee_data import (
	_flatten_signature_on_white,
	company_letterhead_urls,
	esc,
	get_user_signature,
)
from olscpl_hrms.api.letter_of_intent import _article_for
from olscpl_hrms.utils.email_layout import company_email

MANAGER_ROLES = {"System Manager", "HR Manager"}

# Short employer code used in the reference number (Ref: HRD/<code>/<emp
# id>) - matches the style of the original OLSC letter this was modeled on
# (its own ref read "HRD/OLSC/600603"), extended to the other two group
# companies with their own natural short forms.
COMPANY_SHORT_CODE = {
	"OM Logistics Supply Chain PVT. LTD.": "OLSC",
	"SANJVIK TERMINALS PVT LTD": "SANJVIK",
	"OM TELECOM LOGISTICS PVT LTD": "OTLPL",
}

# OTPL's own QMS document-control code, printed above the Ref line on its
# appointment letters only - fixed (form number + revision), not per-
# employee, per HR's reference format. Not requested for the other two
# companies' letters, so no line is printed when a company has no entry.
COMPANY_FORM_CODE = {
	"OM TELECOM LOGISTICS PVT LTD": "OTLPL/HR/7.0/F30/RN02",
}

# Generous fixed margins (not tuned per company) so the tallest of the
# three letterheads' header/footer crops never overlaps the letter body -
# see the README in public/files/letterheads/ for each one's actual
# cropped height. A little extra whitespace on the shorter two is a far
# smaller problem than clipped/overlapping content on the tallest.
# dpi 300 + no smart shrinking: at wkhtmltopdf's default 96 dpi the Poppins text
# is laid out with screen-hinted widths but drawn with exact ones, and the drift
# along a run of regular text swallows the space before the next bold word
# ("as anHR Assistant", "will beRs. ..."). Same page size and margins.
PAGE_OPTIONS = {
	"margin-top": "48mm",
	"margin-bottom": "38mm",
	"margin-left": "20mm",
	"margin-right": "20mm",
	"dpi": "300",
	"disable-smart-shrinking": None,
}


def _is_manager():
	if frappe.session.user == "Administrator":
		return True
	return bool(set(frappe.get_roles(frappe.session.user)) & MANAGER_ROLES)


def _require_manager():
	if not _is_manager():
		frappe.throw(_("Only HR Manager/System Manager can send an Appointment Letter."), frappe.PermissionError)


def _salutation_and_relation(emp_doc):
	if emp_doc.gender == "Female":
		return "Ms.", "D/o"
	if emp_doc.gender == "Male":
		return "Mr.", "S/o"
	return "", ""


def _employee_email(emp_doc):
	return (
		emp_doc.personal_email
		or emp_doc.company_email
		or emp_doc.prefered_email
		or (emp_doc.user_id if emp_doc.user_id else None)
	)


def _sender_name_and_department():
	"""Whoever actually clicked Send, for the email's sign-off - same
	frappe.session.user the CC below also uses. department comes from
	their own linked Employee record (HR users are usually Employees
	too) - omitted from the sign-off entirely if there isn't one (e.g.
	Administrator), rather than showing a blank line."""
	user = frappe.get_doc("User", frappe.session.user)
	name = user.full_name or user.name
	department = frappe.db.get_value("Employee", {"user_id": frappe.session.user}, "department")
	return name, department


def _sender_signature_html():
	"""Whoever is actually generating/sending this letter - frappe.session.
	user, both when previewing (they're the one about to click Send) and
	when send_appointment_letter() itself runs - signs as "Authorized
	Signatory", the same User.custom_signature field every onboarding form
	already reads (see employee_data.py's _hr_signature_html and
	signature_gate.js). Blank (not a placeholder image) if they haven't
	drawn one yet - employee.js's Send Mail button gates on
	ensureSenderSignature() before ever calling send_appointment_letter(),
	so in practice this only stays blank in the preview, before they've
	had the chance to add one."""
	if frappe.session.user == "Administrator":
		return ""
	signature = get_user_signature(frappe.session.user)
	if not signature:
		return ""
	sig = _flatten_signature_on_white(signature)
	return f'<img src="{sig}" style="max-height:60px;max-width:220px;display:block;margin-bottom:4px;">'


def _ctc_from_salary_slip(emp_doc):
	"""Nothing in this codebase ever writes Employee.custom_ctcannum - it's
	only ever what HR happened to type in by hand, so it's usually blank.
	Once payroll has actually run for this employee at least once, their
	earliest submitted Salary Slip's own "ctc" field (HRMS's own computed
	Cost To Company for the salary structure that slip was generated
	against) is a real, system-computed number - the earliest, not the
	latest, since an appointment letter is dated near joining and should
	reflect what the CTC actually was then, not a since-revised figure."""
	return frappe.db.get_value(
		"Salary Slip",
		{"employee": emp_doc.name, "docstatus": 1},
		"ctc",
		order_by="start_date asc",
	)


def _annual_ctc_text(emp_doc):
	ctc = emp_doc.custom_ctcannum or emp_doc.ctc or _ctc_from_salary_slip(emp_doc)
	if not ctc:
		return "________________"
	# The letter already says "Rs. ...", so no currency symbol here (fmt_money
	# with currency="INR" added a second "₹").
	return fmt_money(ctc, precision=2)


def _reference_no(emp_doc):
	code = COMPANY_SHORT_CODE.get(emp_doc.company, "HR")
	return f"HRD/{code}/{emp_doc.name}"


def _form_code_line(emp_doc):
	code = COMPANY_FORM_CODE.get(emp_doc.company)
	return f'<div class="form-code">{esc(code)}</div>' if code else ""


def _default_body_html(emp_doc):
	"""Everything inside <body> except the letterhead header/footer images
	(those aren't part of the editable region - see the module docstring).
	This, or whatever's saved in Employee.custom_appointment_letter_html
	instead, is what _build_html() wraps with the letterhead/style shell."""
	salutation, relation = _salutation_and_relation(emp_doc)
	full_name = f"{salutation} {emp_doc.employee_name}".strip()
	father_line = (
		f"{relation} Sh. {esc(emp_doc.custom_father_name)}" if emp_doc.custom_father_name and relation else ""
	)
	office_label = (emp_doc.branch or "").split(" - ", 1)[-1].strip() or "Corporate Office"
	doj = frappe.utils.format_date(emp_doc.date_of_joining, "dd-MM-yyyy") if emp_doc.date_of_joining else "________"
	dated = frappe.utils.format_date(frappe.utils.today(), "dd-MM-yyyy")

	company = esc(emp_doc.company)
	designation = esc(emp_doc.designation) or "________________"
	article = _article_for(emp_doc.designation)
	name_esc = esc(full_name)
	ctc = _annual_ctc_text(emp_doc)
	signature_html = _sender_signature_html()

	return f"""
	{_form_code_line(emp_doc)}
	<div class="ref-block">
		<div><b>Ref:</b> {esc(_reference_no(emp_doc))}</div>
		<div><b>Dated:</b> {dated}</div>
		<div>{name_esc}</div>
		<div>{father_line}</div>
	</div>
	<div class="subject">Subject: Appointment Letter</div>
	<div class="salute">Dear {name_esc},</div>
	<p>On behalf of <b>{company}</b>, we are pleased to appoint you as {article} <b>{designation}</b> w.e.f
	<b>{doj}</b> at our <b>{office_label}</b> on the following terms and conditions.</p>
	<ol>
		<li>Your annual CTC will be <b>Rs. {ctc}/-</b> only, including all the components of the salary
		&amp; subject to Income Tax as applicable.</li>
		<li>You will be on probation for a period of six months from the date of your joining. During
		the probationary period your services can be terminated by either side without assigning any
		reasons, and one week's notice or payment in lieu of notice is required.</li>
		<li>After confirmation the management reserves the right to terminate your services at its
		absolute discretion after giving one month's notice or one month's salary in lieu of notice.
		Similarly, you shall be at liberty to resign after giving one month's notice or depositing one
		month's salary with the company in lieu of the notice period.</li>
		<li>At all times you will abide by and/or be governed by the rules and regulations of the
		company as amended or framed from time to time.</li>
		<li>You are liable to be transferred to any operation managed by {company} or its associate
		companies, to a place of business either existing or acquired later, including any place
		outside Delhi, and upon such transfer the rules, regulations, and terms of service applicable
		at the place of transfer shall automatically become applicable to you.</li>
		<li>Your hours of attendance shall be regularized to suit the duties entrusted to you.</li>
	</ol>
	<div class="sign-block">
		<table class="sign-row"><tr>
			<td>{signature_html}(Authorized Signatory)<br>HRD</td>
		</tr></table>
	</div>
	<div class="cont">Cont. to Page-2</div>

	<div class="page-break"></div>
	{_form_code_line(emp_doc)}
	<div class="ref-block">
		<div><b>Ref:</b> {esc(_reference_no(emp_doc))}</div>
		<div>Page - 2</div>
	</div>
	<ol start="7">
		<li>You will work under the supervision of such officers as may be decided by the company from
		time to time.</li>
		<li>You will diligently and satisfactorily carry out instructions given to you in connection
		with the work assigned, and perform your duties to the best of your ability and in the best
		interest of the company. You will not, at any time and without the company's consent, disclose,
		divulge, or make public any of the company's policies or processes that may become known to you
		in the course of your service.</li>
		<li>As per rules, you may be retained in service up to the age of 58 years at the option of the
		company.</li>
		<li>While in the company's service, you will be a whole-time employee and will not directly or
		indirectly engage in any other employment, business, trade or profession, and shall not leave
		your station of posting without prior intimation.</li>
		<li>While in the service of the company, you will not engage in studies or professional courses
		without prior permission, granted at the sole discretion of the company.</li>
		<li>Any communication sent by prepaid registered post to the address intimated by you shall be
		deemed to have been received by you within three days of dispatch, irrespective of actual
		receipt. Any change of address must be furnished by you in writing.</li>
		<li>All payments under this letter of appointment shall be due and payable at Delhi, and all
		disputes of any kind shall be litigated in the courts at Delhi only. If the terms and conditions
		enumerated above are acceptable to you, please sign the duplicate copy of this letter on all
		pages as a token of your acceptance and return it to us.</li>
	</ol>
	"""


def _closing_html(emp_doc):
	"""The final signature block - "Thanking you / For <company> / signature /
	(Authorized Signatory)" on the left, "Received by (<employee>)" on the
	right. Kept out of the editable body and always appended by _build_html:
	the rich-text editor can't hold this two-column layout and flattened it
	into one squashed row when HR edited the letter."""
	company = esc(emp_doc.company)
	salutation, _relation = _salutation_and_relation(emp_doc)
	name_esc = esc(f"{salutation} {emp_doc.employee_name}".strip())
	return f"""
	<div class="sign-block">
		<table class="sign-row"><tr>
			<td>Thanking you,<br><b>For {company}</b><br>{_sender_signature_html()}(Authorized Signatory)<br>HRD</td>
			<td style="text-align:right;">Received by<br><br><br>({name_esc})</td>
		</tr></table>
	</div>
	"""


def _strip_closing(body):
	"""Drop a closing signature block an older saved edit still carries (the
	editor's flattened table, or the original sign-block), so it isn't printed
	twice now that _closing_html() is always appended."""
	body = re.sub(r"<table\b(?:(?!</table>).)*Received by(?:(?!</table>).)*</table>", "", body, flags=re.S | re.I)
	return re.sub(
		r'<div class="sign-block">(?:(?!</div>).)*Received by(?:(?!</div>).)*</table>\s*</div>', "", body, flags=re.S | re.I
	)


LETTERHEAD_DIR = ("olscpl_hrms", "public", "files", "letterheads")


@functools.lru_cache(maxsize=16)
def _letterhead_layout(artwork_path, _mtime):
	"""Header/footer crops cut from a company's full-page A4 letterhead
	artwork (<prefix>_letterhead.jpg) plus its left frame line, if it has one.

	The separate <prefix>_header.jpg crop doesn't match this letter's margins
	(it got clipped, cutting the frame's top curve off) and the frame line
	running down the page between the curves isn't in either crop. So: crop
	header/footer from the full artwork at exactly the margins used, and draw
	the side line as a fixed element, which wkhtmltopdf repeats on every page.
	_mtime only busts the cache when the artwork file changes."""
	img = Image.open(artwork_path).convert("RGB")
	width, height = img.size
	px_per_mm = width / 210.0

	def is_dark(x, y):
		return sum(img.getpixel((x, y))) / 3 < 215

	line = None
	mid = height // 2
	start = None
	for x in range(int(5 * px_per_mm), int(width * 0.3)):  # skip scan-edge artefacts
		if is_dark(x, mid) and start is None:
			start = x
		elif not is_dark(x, mid) and start is not None:
			if (x - start) >= 0.5 * px_per_mm:
				line = (start, x - 1)
			break
	top_mm, bottom_mm = 48.0, 38.0
	side = None
	if line:
		cx = (line[0] + line[1]) // 2
		y0 = y1 = mid
		while y0 > 0 and is_dark(cx, y0 - 1):
			y0 -= 1
		while y1 < height - 1 and is_dark(cx, y1 + 1):
			y1 += 1
		top_mm = round(y0 / px_per_mm, 1)
		bottom_mm = round((height - y1) / px_per_mm, 1)
		r, g, b = img.getpixel((cx, mid))
		side = {
			"left_mm": round(line[0] / px_per_mm, 2),
			"width_mm": round((line[1] - line[0] + 1) / px_per_mm, 2),
			"height_mm": round((y1 - y0) / px_per_mm, 1),
			"color": f"#{r:02x}{g:02x}{b:02x}",
		}

	def crop_uri(y_from, y_to):
		buf = io.BytesIO()
		img.crop((0, int(y_from), width, int(y_to))).save(buf, format="JPEG", quality=90)
		return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

	return {
		"top_mm": top_mm,
		"bottom_mm": bottom_mm,
		"header": crop_uri(0, top_mm * px_per_mm),
		"footer": crop_uri(height - bottom_mm * px_per_mm, height),
		"side": side,
	}


def _pixel_uri(hex_color):
	"""1x1 PNG of a colour, as a data URI (for a repeat-y background strip)."""
	buf = io.BytesIO()
	Image.new("RGB", (1, 1), hex_color).save(buf, format="PNG")
	return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def _full_page_layout(company):
	"""_letterhead_layout() for this company's artwork, or None if it has none."""
	header_url, _footer_url = company_letterhead_urls(company)
	if not header_url:
		return None
	prefix = header_url.rsplit("/", 1)[-1].replace("_header.jpg", "")
	path = frappe.get_app_path(*LETTERHEAD_DIR, f"{prefix}_letterhead.jpg")
	if not os.path.exists(path):
		return None
	try:
		return _letterhead_layout(path, os.path.getmtime(path))
	except Exception:
		frappe.log_error(title=f"Letterhead layout failed for {company}")
		return None


def _pdf_options(emp_doc):
	"""PAGE_OPTIONS, with margins matching the full-page letterhead crops when
	there is one (side margins move into the body's own padding, so the
	header/footer crops span the full page width like the real letterhead)."""
	layout = _full_page_layout(emp_doc.company)
	if not layout:
		return PAGE_OPTIONS
	return dict(
		PAGE_OPTIONS,
		**{
			"margin-top": f"{layout['top_mm']}mm",
			"margin-bottom": f"{layout['bottom_mm']}mm",
			"margin-left": "0mm",
			"margin-right": "0mm",
		},
	)


def _render_pdf(emp_doc):
	"""The letter as PDF bytes. With a full-page frame, renders twice: the
	side line is a root-background strip, which only reaches as far down as
	the document does - on the last page it stopped where the text ended. The
	second pass stretches the document to fill exactly the pages the first
	one produced, so the line runs into the footer curve on every page."""
	html, options = _build_html(emp_doc), _pdf_options(emp_doc)
	pdf = get_pdf(html, options=options)
	layout = _full_page_layout(emp_doc.company)
	if not (layout and layout["side"]):
		return pdf
	pages = len(PdfReader(io.BytesIO(pdf)).pages)
	page_mm = 297 - layout["top_mm"] - layout["bottom_mm"]
	filled = html.replace("</style>", f" html {{ min-height: {pages * page_mm - 1:.1f}mm; }}</style>", 1)
	pdf2 = get_pdf(filled, options=options)
	return pdf2 if len(PdfReader(io.BytesIO(pdf2)).pages) == pages else pdf


def _build_html(emp_doc, body=None):
	"""body: the editable region's HTML - defaults to a saved edit
	(Employee.custom_appointment_letter_html) if the caller doesn't pass
	one, falling back to _default_body_html() if there's no saved edit
	either. Callers that already have emp_doc loaded and want the
	auto-filled version specifically (e.g. get_editable_body resetting
	the editor) should pass _default_body_html(emp_doc) explicitly rather
	than relying on this default, to avoid a second, redundant DB read."""
	if body is None:
		body = emp_doc.get("custom_appointment_letter_html") or _default_body_html(emp_doc)
	body = _strip_closing(body) + _closing_html(emp_doc)

	layout = _full_page_layout(emp_doc.company)
	extra_css = side_html = ""
	header_size = footer_size = "width:100%;"
	if layout:
		# Exact mm sizes: wkhtmltopdf scales the separate header/footer pages
		# differently from the body, which squashed the artwork ~10% and left
		# its frame curve short of the side line.
		header_size = f"width:210mm; height:{layout['top_mm']}mm;"
		footer_size = f"width:210mm; height:{layout['bottom_mm']}mm;"
		header_url, footer_url = layout["header"], layout["footer"]
		# Padding on the letter's own wrapper, not <body> - Frappe copies these
		# styles into the header/footer pages, where it would inset the artwork.
		extra_css = "body { margin: 0; } .al-body { padding: 0 20mm; }"
		if layout["side"]:
			# The frame line between the header and footer curves, as a vertical
			# strip in the root background - wkhtmltopdf paints that on every
			# page's content area (a position:fixed element only showed on page 1).
			side = layout["side"]
			extra_css += (
				f" html {{ background-image: url({_pixel_uri(side['color'])}); background-repeat: repeat-y;"
				f" background-position: {side['left_mm']}mm 0; background-size: {side['width_mm']}mm 297mm; }}"
			)
	else:
		header_url, footer_url = company_letterhead_urls(emp_doc.company)
	# letter-head / letter-head-footer: Frappe's header/footer page template
	# pads its body 15mm from the top and only cancels it for these classes -
	# without them the artwork sat 15mm low and got clipped.
	header_html = (
		f'<div id="header-html"><div class="letter-head"><img src="{header_url}" style="display:block; {header_size}"></div></div>'
		if header_url
		else ""
	)
	footer_html = (
		f'<div id="footer-html"><div class="letter-head-footer"><img src="{footer_url}" style="display:block; {footer_size}"></div></div>'
		if footer_url
		else ""
	)

	return f"""
	<html><head><meta charset="utf-8">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
	<style>
		body {{ font-family: 'Poppins', Arial, Helvetica, sans-serif; color: #1a1a1a; font-size: 12.5px; line-height: 1.5; }}
		.form-code {{ margin-bottom: 2px; }}
		.ref-block {{ margin-bottom: 18px; }}
		.ref-block div {{ margin-bottom: 2px; }}
		.subject {{ text-align: center; text-decoration: underline; font-weight: 700; margin: 18px 0; }}
		.salute {{ margin-bottom: 12px; }}
		ol {{ padding-left: 22px; margin: 0; }}
		ol li {{ margin-bottom: 12px; text-align: justify; }}
		.sign-block {{ margin-top: 60px; }}
		.sign-row {{ width: 100%; margin-top: 40px; }}
		/* Explicit 50/50 split (not left to auto/content-width column
		   sizing, which left the "Received by" cell sitting right next to
		   "For company..." instead of over at the page's right margin)
		   so there's real, reliable space between the two signature
		   blocks regardless of how short/long either side's text is. */
		.sign-row td {{ vertical-align: top; width: 50%; }}
		.page-break {{ page-break-before: always; }}
		.cont {{ text-align: right; font-size: 11px; color: #555; margin-top: 30px; }}
		{extra_css}
	</style>
	</head><body>
		{header_html}
		{footer_html}
		{side_html}
		<div class="al-body">{body}</div>
	</body></html>
	"""


def _get_employee(employee):
	doc = frappe.get_doc("Employee", employee)
	doc.check_permission("read")
	return doc


@frappe.whitelist()
def get_preview_pdf(employee):
	"""Served inline (Content-Disposition: inline, same as frappe.utils.
	print_format.download_pdf), not as an attachment - this is what the
	Appointment Letter dialog's iframe points at directly."""
	emp_doc = _get_employee(employee)
	pdf_content = _render_pdf(emp_doc)

	frappe.local.response.filename = f"{emp_doc.name}-appointment-letter.pdf"
	frappe.local.response.filecontent = pdf_content
	frappe.local.response.type = "pdf"


@frappe.whitelist()
def get_editable_body(employee):
	"""What employee.js's "Edit Letter" rich-text editor loads: the saved
	edit if HR has already made one for this employee, otherwise the
	freshly auto-filled version (same content get_preview_pdf would render
	right now) as the starting point to edit from."""
	emp_doc = _get_employee(employee)
	return {"body": emp_doc.get("custom_appointment_letter_html") or _default_body_html(emp_doc)}


@frappe.whitelist()
def save_appointment_letter_body(employee, body):
	"""Same permission bar as actually sending - this is what gets emailed
	next, not a personal draft, so anyone who could edit it could also
	just send whatever they typed unreviewed."""
	_require_manager()
	emp_doc = _get_employee(employee)
	emp_doc.check_permission("write")
	frappe.db.set_value("Employee", emp_doc.name, "custom_appointment_letter_html", body, update_modified=False)
	frappe.db.commit()
	return {"saved": True}


@frappe.whitelist()
def reset_appointment_letter_body(employee):
	"""Discards a saved edit, reverting to the always-fresh auto-filled
	version (which stays up to date with the employee's own data - a
	saved edit deliberately does NOT, once one exists, exactly because
	it's meant to hold HR's own wording instead of the template)."""
	_require_manager()
	emp_doc = _get_employee(employee)
	emp_doc.check_permission("write")
	frappe.db.set_value("Employee", emp_doc.name, "custom_appointment_letter_html", None, update_modified=False)
	frappe.db.commit()
	return {"body": _default_body_html(emp_doc)}


@frappe.whitelist()
def send_appointment_letter(employee):
	_require_manager()
	emp_doc = _get_employee(employee)

	recipient = _employee_email(emp_doc)
	if not recipient:
		frappe.throw(_("This employee has no email address on file (Personal Email/Company Email)."))
	# The letter prints the sender's signature as Authorised Signatory -
	# employee.js asks for an upload first; this catches any other route.
	# Administrator is exempt, same as _sender_signature_html() never prints one.
	if frappe.session.user != "Administrator" and not get_user_signature(frappe.session.user):
		frappe.throw(
			_("Upload your signature on your User profile before sending - it's printed as the Authorised Signatory on the appointment letter."),
			title=_("Signature Required"),
		)

	pdf_content = _render_pdf(emp_doc)

	# CC whoever actually clicked Send - same reasoning as the onboarding
	# link email (events/employee_onboarding.py): so the sending HR user
	# has a copy in their own inbox, not just a record on the Employee
	# timeline. Guards out "Administrator" (not a real email address).
	cc = [frappe.session.user] if "@" in frappe.session.user else None
	sender_name, sender_department = _sender_name_and_department()

	frappe.sendmail(
		recipients=[recipient],
		cc=cc,
		subject=_("Appointment Letter - {0}").format(emp_doc.company),
		message=company_email(emp_doc.company, _("Appointment Letter"), frappe.render_template(
			(
				"<p>Dear {{ name }},</p>"
				"<p>We are pleased to share your Appointment Letter for the position of "
				"<b>{{ designation }}</b> with our organization ({{ company }}).</p>"
				"<p>Please find the appointment letter attached for your reference. You are requested "
				"to go through the terms and conditions mentioned in the letter and confirm your "
				"acceptance.</p>"
				"<p>We look forward to having you as a part of our organization and wish you a "
				"successful and rewarding journey with us.</p>"
				"<p>Regards,<br>{{ sender_name }}{% if sender_department %}<br>{{ sender_department }}{% endif %}</p>"
			),
			{
				"name": emp_doc.employee_name,
				"designation": emp_doc.designation or "",
				"company": emp_doc.company,
				"sender_name": sender_name,
				"sender_department": sender_department,
			},
		)),
		attachments=[{"fname": f"{emp_doc.name}-appointment-letter.pdf", "fcontent": pdf_content}],
		now=True,
	)

	sent_on = frappe.utils.now_datetime()
	frappe.db.set_value(
		"Employee", emp_doc.name,
		{"custom_appointment_letter_sent_on": sent_on, "custom_appointment_letter_sent_by": frappe.session.user},
		update_modified=False,
	)
	frappe.db.commit()

	return {"sent_to": recipient, "sent_on": sent_on, "sent_by": frappe.session.user}


@frappe.whitelist()
def get_send_status(employee):
	"""Read fresh from the DB (not trusting frm.doc, which can be stale if
	the form was opened before a previous send, or in another tab/by
	another user) - called each time the Appointment Letter dialog opens,
	so "already sent" reflects reality rather than whatever the form
	happened to have loaded."""
	doc = _get_employee(employee)
	if not doc.custom_appointment_letter_sent_on:
		return {"sent": False}
	return {
		"sent": True,
		"sent_on": doc.custom_appointment_letter_sent_on,
		"sent_by": doc.custom_appointment_letter_sent_by,
	}
