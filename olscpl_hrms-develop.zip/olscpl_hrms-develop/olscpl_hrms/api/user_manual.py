# olscpl_hrms/api/user_manual.py
#
# The "User Manual" card grid linked from the navbar's user dropdown
# (Navbar Settings > Settings Dropdown > User Manual). Anyone signed in can
# browse/watch/download; only HR Manager/System Manager can upload or
# remove entries - same shape as social_feed.py: the "User Manual" doctype
# itself only grants System Manager access at the DocType level, so this
# module (ignore_permissions=True + its own role checks) is the only
# sanctioned way in.

import re

import frappe

MANAGER_ROLES = {"System Manager", "HR Manager"}
MAX_TITLE_LEN = 140
MAX_CATEGORY_LEN = 60

# Matches the video id out of every common YouTube URL shape:
# watch?v=ID, youtu.be/ID, embed/ID, shorts/ID - with or without extra
# query params/trailing slash after the id.
_YOUTUBE_ID_RE = re.compile(
	r"(?:youtube(?:-nocookie)?\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{11})"
)


def _is_manager():
	if frappe.session.user == "Administrator":
		return True
	return bool(set(frappe.get_roles(frappe.session.user)) & MANAGER_ROLES)


def _require_manager():
	if not _is_manager():
		frappe.throw(frappe._("Only HR Manager/System Manager can manage the User Manual."), frappe.PermissionError)


def _youtube_id(url):
	match = _YOUTUBE_ID_RE.search(url or "")
	return match.group(1) if match else None


def _serialize(row):
	out = {
		"name": row.name,
		"title": row.title,
		"category": row.category,
		"resourceType": row.resource_type,
		"owner": row.owner,
		"creation": str(row.creation),
	}
	if row.resource_type == "Video":
		vid = _youtube_id(row.youtube_url)
		out["youtubeUrl"] = ("https://www.youtube.com/watch?v=" + vid) if vid else row.youtube_url
		out["thumbnailUrl"] = ("https://img.youtube.com/vi/" + vid + "/hqdefault.jpg") if vid else None
	else:
		out["fileUrl"] = row.file_url
		out["fileName"] = row.file_name
		out["fileSize"] = row.file_size
	return out


@frappe.whitelist()
def get_list():
	rows = frappe.get_all(
		"User Manual",
		fields=["name", "title", "category", "resource_type", "youtube_url", "file_url", "file_name", "file_size", "owner", "creation"],
		order_by="creation desc",
	)
	manuals = [_serialize(r) for r in rows]
	return {
		"manuals": manuals,
		# Distinct labels already in use, for the search page's filter
		# chips - de-duplicated case-insensitively but keeping the first
		# casing seen, and sorted for a stable chip order.
		"categories": sorted({m["category"] for m in manuals if m.get("category")}, key=str.lower),
		"canManage": _is_manager(),
	}


@frappe.whitelist()
def create_entry(title, category, resource_type, youtube_url=None, file_url=None, file_name=None, file_size=None):
	_require_manager()

	title = (title or "").strip()
	if not title:
		frappe.throw(frappe._("Title is required."))
	if len(title) > MAX_TITLE_LEN:
		frappe.throw(frappe._("Title is too long (max {0} characters).").format(MAX_TITLE_LEN))

	category = (category or "").strip()
	if not category:
		frappe.throw(frappe._("Label is required."))
	if len(category) > MAX_CATEGORY_LEN:
		frappe.throw(frappe._("Label is too long (max {0} characters).").format(MAX_CATEGORY_LEN))

	if resource_type not in ("Video", "Document"):
		frappe.throw(frappe._("Invalid type."))

	doc = frappe.get_doc({"doctype": "User Manual", "title": title, "category": category, "resource_type": resource_type})

	if resource_type == "Video":
		if not _youtube_id(youtube_url):
			frappe.throw(frappe._("Enter a valid YouTube link."))
		doc.youtube_url = youtube_url.strip()
	else:
		if not file_url:
			frappe.throw(frappe._("Upload a file first."))
		doc.file_url = file_url
		doc.file_name = (file_name or file_url.rsplit("/", 1)[-1])[:200]
		try:
			doc.file_size = int(file_size) if file_size is not None else None
		except (TypeError, ValueError):
			doc.file_size = None

	doc.insert(ignore_permissions=True)
	frappe.db.commit()
	return _serialize(doc)


@frappe.whitelist()
def delete_entry(name):
	_require_manager()
	if not frappe.db.exists("User Manual", name):
		frappe.throw(frappe._("Not found."), frappe.DoesNotExistError)
	frappe.delete_doc("User Manual", name, ignore_permissions=True, force=True)
	frappe.db.commit()
