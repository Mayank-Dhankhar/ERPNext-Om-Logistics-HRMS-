# olscpl_hrms/api/org_chart.py
#
# Backend for the Org Chart desk page (/app/org-chart): the reporting tree
# (Employee.reports_to), the "No manager" tray, and the two edits the page
# makes - change someone's manager, and set a branch's HR people
# (Branch.custom_branch_hrs). Reads are for HR/System Manager; edits are
# System Manager only. Employee saves go through the normal document save,
# so Employee's own validation (including NestedSet loop checks) applies.
import frappe
from frappe import _

VIEW_ROLES = ("System Manager", "HR Manager", "HR User")
FIELDS = ["name", "employee_name", "designation", "department", "branch", "custom_state", "image", "reports_to"]
PAGE = 40

# "Has no active direct report" as an anti-join against ONE grouped pass over
# Employee. The old per-row `exists (select ... where c.reports_to = e.name)`
# subquery timed out (504) on prod's ~10k employees.
MANAGERS_JOIN = """left join (
		select distinct reports_to from `tabEmployee`
		where status='Active' and ifnull(reports_to,'')!='' and reports_to != name
	) m on m.reports_to = e.name"""


def _check_view():
	frappe.only_for(VIEW_ROLES)


def _check_edit():
	frappe.only_for(("System Manager",))


def _decorate(rows):
	"""Adds report counts and Branch HR assignments to employee rows."""
	if not rows:
		return rows
	names = [r.name for r in rows]
	counts = dict(
		frappe.db.sql(
			"""select reports_to, count(*) from `tabEmployee`
			where status='Active' and reports_to in %s and name != reports_to group by reports_to""",
			(names,),
		)
	)
	hr_of = {}
	for employee, branch in frappe.db.sql(
		"""select employee, parent from `tabBranch HR`
		where parenttype='Branch' and employee in %s""",
		(names,),
	):
		hr_of.setdefault(employee, []).append(branch)
	for r in rows:
		r["reports"] = counts.get(r.name, 0)
		r["hr_for"] = hr_of.get(r.name, [])
	return rows


@frappe.whitelist()
def get_meta():
	_check_view()
	active = {"status": "Active"}
	return {
		"can_edit": "System Manager" in frappe.get_roles(),
		"total": frappe.db.count("Employee", active),
		"unassigned": _unassigned_count(),
		"branches": frappe.get_all("Branch", pluck="name", order_by="name"),
		"departments": frappe.get_all("Department", pluck="name", order_by="name"),
	}


@frappe.whitelist()
def get_children(parent=None, start=0):
	"""Direct reports of `parent`, PAGE at a time (managers first). With no
	parent: the top of the tree - active people with no manager who manage
	someone."""
	_check_view()
	start = frappe.utils.cint(start)
	if parent:
		rows = frappe.db.sql(
			f"""select {", ".join(FIELDS)},
				(select count(*) from `tabEmployee` c where c.reports_to = e.name and c.name != e.name and c.status='Active') as n
			from `tabEmployee` e
			where status='Active' and reports_to=%s and name != reports_to
			order by n desc, employee_name asc limit %s offset %s""",
			(parent, PAGE, start),
			as_dict=True,
		)
		total = frappe.db.count("Employee", {"status": "Active", "reports_to": parent, "name": ["!=", parent]})
	else:
		rows = frappe.db.sql(
			f"""select {", ".join("e." + f for f in FIELDS)} from `tabEmployee` e
			{MANAGERS_JOIN}
			where e.status='Active' and (ifnull(e.reports_to,'')='' or e.reports_to=e.name)
			and m.reports_to is not null
			order by e.employee_name""",
			as_dict=True,
		)
		total = len(rows)
	for r in rows:
		r.pop("n", None)
	return {"rows": _decorate(rows), "total": total}


def _unassigned_count():
	return frappe.db.sql(
		f"""select count(*) from `tabEmployee` e {MANAGERS_JOIN}
		where e.status='Active' and (ifnull(e.reports_to,'')='' or e.reports_to=e.name)
		and m.reports_to is null"""
	)[0][0]


def _unassigned_names():
	return frappe.db.sql_list(
		f"""select e.name from `tabEmployee` e {MANAGERS_JOIN}
		where e.status='Active' and (ifnull(e.reports_to,'')='' or e.reports_to=e.name)
		and m.reports_to is null"""
	)


@frappe.whitelist()
def get_unassigned(txt=None, branch=None, department=None, state=None, start=0):
	"""People with no manager and no reports - the tray."""
	_check_view()
	cond, args = ["e.status='Active'", "(ifnull(e.reports_to,'')='' or e.reports_to=e.name)",
		"m.reports_to is null"], []
	if txt:
		cond.append("(e.employee_name like %s or e.name like %s or e.designation like %s)")
		args += [f"%{txt}%"] * 3
	for field, value in (("branch", branch), ("department", department), ("custom_state", state)):
		if value:
			cond.append(f"e.{field}=%s")
			args.append(value)
	where = " and ".join(cond)
	rows = frappe.db.sql(
		f"""select {", ".join("e." + f for f in FIELDS)} from `tabEmployee` e {MANAGERS_JOIN}
		where {where}
		order by e.employee_name limit %s offset %s""",
		(*args, PAGE, frappe.utils.cint(start)),
		as_dict=True,
	)
	total = frappe.db.sql(f"select count(*) from `tabEmployee` e {MANAGERS_JOIN} where {where}", args)[0][0]
	return {"rows": _decorate(rows), "total": total}


@frappe.whitelist()
def search(txt):
	"""Up to 15 matches anywhere, each with its manager chain (top first) so
	the page can expand down to it."""
	_check_view()
	rows = frappe.get_all(
		"Employee",
		filters={"status": "Active"},
		or_filters={"employee_name": ["like", f"%{txt}%"], "name": ["like", f"%{txt}%"]},
		fields=["name", "employee_name", "designation", "branch"],
		limit=15,
	)
	for r in rows:
		chain, cur, seen = [], frappe.db.get_value("Employee", r.name, "reports_to"), {r.name}
		while cur and cur not in seen:
			seen.add(cur)
			chain.insert(0, cur)
			nxt = frappe.db.get_value("Employee", cur, "reports_to")
			cur = None if nxt == cur else nxt  # a head who reports to themselves is the top
		r["path"] = chain
	return rows


@frappe.whitelist()
def get_employee(name):
	_check_view()
	row = frappe.db.get_value("Employee", name, FIELDS + ["company", "date_of_joining", "user_id"], as_dict=True)
	if not row:
		frappe.throw(_("Employee {0} not found").format(name))
	row["self_reporting"] = row.reports_to == row.name
	row["manager_name"] = (
		_("Self (approves own requests)") if row["self_reporting"]
		else row.reports_to and frappe.db.get_value("Employee", row.reports_to, "employee_name")
	)
	return _decorate([row])[0]


@frappe.whitelist(methods=["POST"])
def set_manager(employee, manager=None):
	"""Change Reports To. manager=None removes it (back to the tray)."""
	_check_edit()
	manager = manager or None
	if manager == employee:
		frappe.throw(_("Someone can't report to themselves"))
	if manager:
		# would `manager` end up under `employee`? walk manager's chain upward
		cur, seen = manager, set()
		while cur and cur not in seen:
			if cur == employee:
				frappe.throw(_("{0} can't report to someone in their own team").format(
					frappe.db.get_value("Employee", employee, "employee_name")))
			seen.add(cur)
			nxt = frappe.db.get_value("Employee", cur, "reports_to")
			cur = None if nxt == cur else nxt
	doc = frappe.get_doc("Employee", employee)
	old = doc.reports_to
	doc.reports_to = manager
	doc.save()
	return {"old": old, "new": manager}


@frappe.whitelist(methods=["POST"])
def set_branch_hr(employee, branches):
	"""Make `employee` the HR for exactly these branches (removes them from others)."""
	_check_edit()
	branches = set(frappe.parse_json(branches) or [])
	current = set(frappe.get_all("Branch HR", {"parenttype": "Branch", "employee": employee}, pluck="parent"))
	for branch in current - branches:
		doc = frappe.get_doc("Branch", branch)
		doc.set("custom_branch_hrs", [r for r in doc.custom_branch_hrs if r.employee != employee])
		doc.save()
	for branch in branches - current:
		doc = frappe.get_doc("Branch", branch)
		doc.append("custom_branch_hrs", {"employee": employee})
		doc.save()
	return sorted(branches)
