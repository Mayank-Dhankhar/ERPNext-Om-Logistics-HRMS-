# olscpl_hrms/api/letter_of_intent.py
#
# Generates a Letter of Intent PDF matching the company's standard paper
# LOI format (ref/date line, centered "Sub. : Letter Of Intent" heading,
# the same six body paragraphs - offer, reporting deadline, transfer
# clause, training-investment/reimbursement clause, notice-period clause,
# guarantee-form/acceptance clause - closing line, then a blank signature
# block), filled in per candidate from their Employee Onboarding record.
# Sent alongside the onboarding portal link email (see
# events/employee_onboarding.py's generate_portal_link()) and also
# available as a standalone download for HR.
import io
import os
import re

import frappe
from frappe.utils import format_date, get_url, now_datetime
from frappe.utils.pdf import get_pdf

STYLE = """
	body { font-family: Calibri, Arial, Helvetica, sans-serif; color: #000; margin: 0; font-size: 12.5px; }
	.content { padding: 30px 55px; }
	.header { text-align: center; }
	.company-logo { display: block; margin: 0 auto 6px; max-height: 70px; max-width: 320px; }
	.company-name { font-size: 19px; font-weight: bold; letter-spacing: .3px; }
	.header-rule { border: none; border-top: 1.5px solid #000; margin: 6px 0; }
	.contact-line { font-size: 10.5px; font-weight: bold; text-align: center; line-height: 1.5; margin: 4px 0; }
	.ref-row { width: 100%; margin: 22px 0 18px; font-size: 12.5px; }
	.ref-row td.date { text-align: right; }
	.subject { text-align: center; font-weight: bold; text-decoration: underline; margin-bottom: 18px; font-size: 13px; }
	.salutation { font-weight: bold; margin-bottom: 14px; }
	p.body-para { text-align: justify; line-height: 1.5; margin: 0 0 14px; }
	p.body-para.emphasis { font-weight: bold; }
	.sign-block { margin-top: 34px; }
	.sign-block .for-line { font-weight: bold; }
	/* left-aligned, directly above "(Authorised Signatory)" - not centred on
	   the "For <company>" line, which a long company name pushes far right */
	.sign-block .sig-space { height: 66px; margin-top: 14px; }
	.sign-block .sig-space img { max-height: 64px; max-width: 220px; display: block; }
	.sign-block .role { font-weight: bold; }

	/* Some Letter Heads' own <img> (Transafe's, at least) have no usable
	   width/height - a blank height="" plus an invalid "height: px;" style
	   the field editor wrote, both no-ops - so with nothing here to cap it,
	   the browser/wkhtmltopdf falls back to the file's native pixel size.
	   width:100% alone isn't enough, though: Transafe's file turns out to
	   be a full A4-page mockup (1131x1600, portrait) with its header text
	   in roughly the top quarter and the rest genuinely blank paper, not
	   just a header strip - the three Letter Heads with proper full-page
	   handling (see _full_page_letterhead_url) are recognisable by name and
	   use a completely different rendering path for exactly this reason.
	   Scaled to the page width, that blank three-quarters became a wall of
	   real empty space pushing the whole letter down a page. A max-height
	   well above any legitimate header crop (OLSCPL/SANJVIK/Telecom's own
	   header images all render under 170px at this width) but well under a
	   full page, plus object-fit so the crop is a clean crop and not a
	   squash, papers over any Letter Head image built the same oversized
	   way without needing to special-case it by name like the full-page
	   ones. Footer crops from the bottom instead of the top - a footer's
	   own content, if any, sits at the bottom of its image, not the top. */
	.letter-head img, .letter-head-footer img { display: block; width: 100%; height: auto; max-width: 100%; max-height: 260px; object-fit: cover; }
	.letter-head img { object-position: top; }
	.letter-head-footer img { object-position: bottom; }

	/* ss-page-break, not the bare "page-break" this used to be - Frappe's
	   own templates/styles/standard.css is ALWAYS injected ahead of a
	   print format's own CSS for every single print/PDF (get_print_style()
	   -> frappe.get_template("templates/styles/standard.css"), unrelated
	   to which Print Format or Print Style is chosen) and it defines its
	   OWN ".page-break { page-break-after: always; }" for its own,
	   different purpose. Same class name, so both applied to our div at
	   once - ours (page-break-before) put the Salary Structure page where
	   intended, but their page-break-after fired too, on that same div,
	   which is the LAST thing in the document - forcing a trailing blank
	   page after it every single time. Renamed to stop colliding, the
	   same fix as .ss-label below for the same underlying reason. */
	.ss-page-break { page-break-before: always; padding-top: 14px !important; padding-bottom: 10px !important; }
	.ss-title { text-align: center; font-weight: bold; font-size: 14px; text-decoration: underline; margin: 0 0 10px; }
	table.ss-header { width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 11.5px; }
	/* !important: that same always-injected standard.css also carries
	   ".print-format td, .print-format th { padding: 6px !important; }" -
	   !important beats a plain declaration regardless of selector
	   specificity, so every cell in every table below was silently
	   getting a uniform 6px pad on all sides no matter what we set here,
	   fattening the label column (and everything else) well past the
	   compact spacing this was actually designed for, and eating into
	   the salary table's row height enough on longer breakups to push it
	   onto a second page. Matching their own !important is the only way
	   to actually win this fight, not a specificity bump. */
	table.ss-header td { padding: 2px 0 !important; }
	/* ss-label, not the bare "label" this used to be - scoped like every
	   sibling class here (.ss-title, .ss-salary, ...) instead of a name
	   generic enough to risk colliding with something else, the same
	   reason .ss-page-break above was renamed. */
	table.ss-header td.ss-label { width: 150px; font-weight: bold; }
	table.ss-salary { width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 10px; }
	table.ss-salary th, table.ss-salary td { border: 1px solid #000 !important; padding: 3px 6px !important; }
	table.ss-salary th { text-align: left; background: #d9d9d9; font-weight: bold; }
	table.ss-salary th.amt, table.ss-salary td.amt { text-align: right; }
	table.ss-salary td.side-label { writing-mode: vertical-rl; transform: rotate(180deg); text-align: center;
		font-weight: bold; width: 20px; background: #f2f2f2; }
	table.ss-salary td.letter { text-align: center; font-weight: bold; width: 18px; }
	table.ss-salary tr.total td { font-weight: bold; background: #f2f2f2; }
	table.ss-salary tr.grand td { font-weight: bold; background: #d9d9d9; }
	table.ss-benefits { width: 100%; border-collapse: collapse; margin: 6px 0 10px; font-size: 10.5px; }
	table.ss-benefits th, table.ss-benefits td { border: 1px solid #000 !important; padding: 3px 6px !important; }
	table.ss-benefits th { background: #d9d9d9; text-align: left; }
	table.ss-benefits td.amt { text-align: right; }
	.ss-notes { font-size: 9px; color: #333; line-height: 1.3; margin-top: 6px; }
	.ss-notes .title { font-weight: bold; text-decoration: underline; }
	table.ss-accept { width: 100%; margin-top: 10px; font-size: 11.5px; }
	table.ss-accept td.right { text-align: right; }
	/* The Benefits table, the Notes paragraph and the acceptance line used to
	   have nothing stopping the PDF engine (wkhtmltopdf, WebKit-based) from
	   cutting a page break in the middle of the Benefits table's borders -
	   which it renders as a stray curved/rounded grey line bleeding into
	   whatever follows instead of a clean straight border. Keeping the whole
	   tail together (it is short) avoids any mid-table break; the row- and
	   table-level avoid rules are extra insurance in case the block itself
	   still doesn't fit whole on the remaining page. */
	.ss-tail { page-break-inside: avoid; }
	table.ss-benefits, table.ss-benefits tr { page-break-inside: avoid; }
"""


def _company_logo_html(company):
	logo_url = frappe.db.get_value("Company", company, "company_logo")
	if not logo_url:
		return ""
	try:
		file_doc = frappe.get_doc("File", {"file_url": logo_url, "attached_to_doctype": "Company", "attached_to_name": company})
	except Exception:
		try:
			file_doc = frappe.get_doc("File", {"file_url": logo_url})
		except Exception:
			return ""
	try:
		import base64

		content = file_doc.get_content()
	except Exception:
		return ""
	ext = (logo_url.rsplit(".", 1)[-1] or "png").lower()
	mime = {"jpg": "jpeg"}.get(ext, ext)
	if mime not in ("png", "jpeg", "gif", "webp"):
		mime = "png"
	b64 = base64.b64encode(content).decode()
	return f'<img src="data:image/{mime};base64,{b64}" class="company-logo">'


def _company_contact_line(company):
	"""Registered address / phone / email / website, whatever's actually on
	file for this company - never fabricated (a wrong CIN or address on an
	offer letter is a real liability, not a cosmetic detail)."""
	address_name = frappe.db.get_value(
		"Dynamic Link", {"link_doctype": "Company", "link_name": company, "parenttype": "Address"}, "parent"
	)
	address_bits = []
	phone = None
	email = frappe.db.get_value("Company", company, "email")
	if address_name:
		addr = frappe.db.get_value(
			"Address", address_name,
			["address_line1", "address_line2", "city", "state", "pincode", "phone", "email_id"],
			as_dict=True,
		)
		if addr:
			address_bits = [addr.address_line1, addr.address_line2, addr.city, addr.state, addr.pincode]
			address_bits = [b for b in address_bits if b]
			phone = addr.phone
			email = addr.email_id or email
	website = frappe.db.get_value("Company", company, "website")

	lines = []
	if address_bits:
		lines.append(f"Registered Address: {frappe.utils.escape_html(', '.join(address_bits))}")
	contact_bits = []
	if phone:
		contact_bits.append(f"Phone: {frappe.utils.escape_html(phone)}")
	if email:
		contact_bits.append(f"Email: {frappe.utils.escape_html(email)}")
	if website:
		contact_bits.append(f"Website: {frappe.utils.escape_html(website)}")
	if contact_bits:
		lines.append(" &nbsp;|&nbsp; ".join(contact_bits))

	if not lines:
		return ""
	return "<div class='contact-line'>" + "<br>".join(lines) + "</div>"


def _report_location(onboarding_doc):
	"""Where the letter tells the candidate to report: the Job Offer's Sitting
	Branch, without its code ("4905 - CHENNAI" -> "CHENNAI"), else
	"Corporate Office" as before."""
	branch = getattr(onboarding_doc, "branch", None)
	job_offer = getattr(onboarding_doc, "job_offer", None)
	if not branch and job_offer:
		branch = frappe.db.get_value("Job Offer", job_offer, "custom_sitting_branch")
	return re.sub(r"^\d+\s*-\s*", "", branch or "") or "Corporate Office"


# companies whose Letter of Intent carries a fixed document reference instead
# of the generated <abbr>/LOI/<year>
FIXED_REF = {
	"OM TELECOM LOGISTICS PVT LTD": "OTLPL/HR/7.0/F29/RN02",
}


def _ref_number(company, on_date):
	if company in FIXED_REF:
		return FIXED_REF[company]
	abbr = frappe.db.get_value("Company", company, "abbr") or "".join(w[0] for w in company.split())[:6].upper()
	return f"{abbr}/LOI/{on_date.year}"


def _money(value):
	return frappe.utils.fmt_money(value or 0, currency="INR").replace("₹", "").strip() if value else "0.00"


def _article_for(text):
	""""a" or "an" before a designation, matching its actual first letter -
	"an Executive Warehouse", not "a Executive Warehouse" (this used to be
	hardcoded "a" regardless of what the designation was). Vowel-letter
	heuristic (first alphabetic character is A/E/I/O/U) rather than true
	pronunciation - the same approximation almost every such generator
	uses; a job designation isn't likely to hit the sound-based exceptions
	("an hour", "a university") true prose sometimes needs."""
	words = (text or "").split()
	first_word = words[0] if words else ""
	# A short all-caps abbreviation in mixed-case text ("HR Assistant",
	# "MIS Executive") is read letter by letter - the article follows how the
	# first letter is *said* ("an HR", "an MIS", "a CA"). Not applied when the
	# whole designation is in capitals ("MANAGER"), where it's just a word.
	if first_word.isalpha() and first_word.isupper() and len(first_word) <= 4 and not (text or "").isupper():
		return "an" if first_word[0] in "AEFHILMNORSX" else "a"
	first = next((c for c in (text or "") if c.isalpha()), "")
	return "an" if first.upper() in "AEIOU" else "a"


def _ss_rows(rows, amount_field="per_month", annum_field="per_annum"):
	return [(r.particulars, _money(r.get(amount_field)), _money(r.get(annum_field))) for r in rows]


def _ss_section(label, letter, rows, total_month, total_annum):
	"""One salary-structure section: a vertical rotated label spanning every
	row (including its own Total row), then the data rows, then a shaded
	Total row carrying the section's letter (A/B/C/D) - matches the
	reference "SALARY STRUCTURE" sheet's layout exactly."""
	row_count = max(len(rows), 1) + 1  # +1 for the Total row
	html = "<tr>"
	html += f"<td rowspan='{row_count}' class='side-label'>{frappe.utils.escape_html(label)}</td>"
	if rows:
		particulars, per_month, per_annum = rows[0]
		html += f"<td></td><td>{frappe.utils.escape_html(particulars)}</td><td class='amt'>{per_month}</td><td class='amt'>{per_annum}</td></tr>"
		for particulars, per_month, per_annum in rows[1:]:
			html += f"<tr><td></td><td>{frappe.utils.escape_html(particulars)}</td><td class='amt'>{per_month}</td><td class='amt'>{per_annum}</td></tr>"
	else:
		html += "<td></td><td>&nbsp;</td><td class='amt'>&nbsp;</td><td class='amt'>&nbsp;</td></tr>"
	html += (
		f"<tr class='total'><td class='letter'>{letter}</td><td>Total</td>"
		f"<td class='amt'>{_money(total_month)}</td><td class='amt'>{_money(total_annum)}</td></tr>"
	)
	return html


def _has_salary_data(job_offer):
	"""Whether HR has actually filled in anything on the Job Offer's LOI
	Salary Structure fields yet - skip the whole salary structure page
	rather than send a candidate a sheet of ₹0.00 rows if nobody's
	populated it (HR fills this in on the Job Offer before sending the
	onboarding link; it's simply not always done yet)."""
	if job_offer.custom_ctcannum or job_offer.custom_gross_salaryannum:
		return True
	for fieldname in ("custom_salary_breakup", "custom_allowances", "custom_deductions", "custom_other_benefits", "custom_benefits"):
		if job_offer.get(fieldname):
			return True
	return False


def _salary_structure_row_count(job_offer):
	"""Total number of line items HR has added across the four Salary
	Structure child tables plus the flat Benefits box - the thing that
	actually varies the sheet's printed height (everything else on the
	page is fixed-height boilerplate: title, header block, notes,
	acceptance line)."""
	return sum(
		len(job_offer.get(fieldname) or [])
		for fieldname in ("custom_salary_breakup", "custom_allowances", "custom_deductions", "custom_other_benefits", "custom_benefits")
	)

# Past this many total line items, the sheet no longer fits inside the
# letterhead artwork's printable frame (see FULL_PAGE_STYLE) and its last
# lines - the Notes paragraph - start printing on top of the footer graphic
# baked into that artwork instead of stopping above it, since neither
# wkhtmltopdf's automatic pagination nor .lh-page's overflow:hidden catches
# an absolutely-positioned block (.lh-body) overflowing past the visible
# frame short of the full 296mm page edge. Confirmed empirically: 13 rows
# renders with clear margin below the frame, 25 rows overlaps it by a few
# mm. 18 sits with comfortable room on both sides of that gap.
_SALARY_STRUCTURE_SPLIT_THRESHOLD = 18


# (Job Offer tick-box, note) - the notes under the salary structure; HR
# unticks the ones a candidate's letter shouldn't show
# (patches/v1_1/setup_offer_letter_note_fields.py adds the tick-boxes)
OFFER_NOTES = [
	("custom_note_pli", "@PLI (if any) is paid on a quarterly basis based on performance."),
	("custom_note_symbols", "*As per Act; **subject to leave balance; ***subject to income tax; #as per company policy."),
	("custom_note_not_in_ctc", "Mobile/Laptop/Uniform/Stitching/Vehicle/Driver are not included in CTC if applicable, as per company policy."),
	("custom_note_other_benefits", "All other benefits are as per company policy."),
	("custom_note_accommodation", "If using company accommodation, an amount as per company policy will be deducted from the Gross Salary."),
]


def _offer_notes_html(job_offer, esc):
	# a tick-box missing (patch not run yet) counts as ticked
	notes = [text for fieldname, text in OFFER_NOTES if job_offer.get(fieldname) in (None, 1)]
	if not notes:
		return ""
	return '<div class="ss-notes"><div class="title">Note:-</div>' + "".join(
		f"<div>{esc(n)}</div>" for n in notes
	) + "</div>"


def _salary_structure_html(job_offer, onboarding_doc):
	"""Page 2 (and, once the sheet has enough line items to risk overflowing
	the printable frame - see _SALARY_STRUCTURE_SPLIT_THRESHOLD - page 3) of
	the LOI: the same "SALARY STRUCTURE" sheet as the reference format -
	Salary Break / Allowances / Gross / Deductions / Other Benefits / CTC /
	Net Salary, then the flat Benefits box (Mediclaim/GPA/GTL). Pulled from
	the linked Job Offer's LOI Salary Structure fields (custom_salary_breakup
	etc.) - HR fills those in on the Job Offer before sending the onboarding
	link; whatever's there is what goes out, nothing here is guessed or
	defaulted to a number.

	Returns (page_html, extra_page_html) - extra_page_html is "" for the
	common case (everything fits on one page); the caller (build_letter_of_
	intent_html) adds it as its own page only when non-empty, so nothing
	about the normal one-page layout changes for a typical, short sheet."""
	esc = frappe.utils.escape_html
	report_by = format_date(onboarding_doc.date_of_joining, "d MMMM yyyy") if onboarding_doc.date_of_joining else ""

	rows_html = ""
	rows_html += _ss_section("Salary Break", "A", _ss_rows(job_offer.custom_salary_breakup),
		job_offer.custom_total_breakupmonth, job_offer.custom_total_breakupannum)
	rows_html += _ss_section("Allowances", "B", _ss_rows(job_offer.custom_allowances),
		job_offer.custom_total_allowmonth, job_offer.custom_total_allowannum)
	rows_html += (
		"<tr class='grand'><td></td><td colspan='2'>(A+B) Gross Salary</td>"
		f"<td class='amt'>{_money(job_offer.custom_gross_salarymonth)}</td>"
		f"<td class='amt'>{_money(job_offer.custom_gross_salaryannum)}</td></tr>"
	)
	rows_html += _ss_section("Deductions", "C", _ss_rows(job_offer.custom_deductions),
		job_offer.custom_total_deductmonth, job_offer.custom_total_deductannum)
	rows_html += _ss_section("Other benefits", "D", _ss_rows(job_offer.custom_other_benefits),
		job_offer.custom_total_benefitmonth, job_offer.custom_total_benefitannum)
	rows_html += (
		"<tr class='grand'><td></td><td colspan='2'>(A+B)+D &nbsp;CTC</td>"
		f"<td class='amt'>{_money(job_offer.custom_ctcmonth)}</td>"
		f"<td class='amt'>{_money(job_offer.custom_ctcannum)}</td></tr>"
	)
	rows_html += (
		"<tr class='grand'><td></td><td colspan='2'>(A+B)-C &nbsp;Net Salary***</td>"
		f"<td class='amt'>{_money(job_offer.custom_net_salarymonth)}</td>"
		f"<td class='amt'>{_money(job_offer.custom_net_salaryannum)}</td></tr>"
	)

	benefit_rows = job_offer.custom_benefits or []
	benefits_html = ""
	if benefit_rows:
		benefits_html = "<table class='ss-benefits'><tr><th>Benefits</th><th class='amt'>Amount</th></tr>"
		for r in benefit_rows:
			benefits_html += f"<tr><td>{esc(r.particulars)}</td><td class='amt'>{_money(r.amount)}</td></tr>"
		benefits_html += "</table>"

	tail_html = f"""
		<div class="ss-tail">
			{benefits_html}
			{_offer_notes_html(job_offer, esc)}
			<table class="ss-accept"><tr>
				<td>&nbsp;</td>
				<td class="right">( Signature )<br>Accepted by</td>
			</tr></table>
		</div>
	"""

	overflow_risk = _salary_structure_row_count(job_offer) > _SALARY_STRUCTURE_SPLIT_THRESHOLD
	page_html = f"""
	<div class="ss-page-break content">
		<div class="ss-title">SALARY STRUCTURE</div>
		<table class="ss-header">
			<tr><td class="ss-label">NAME</td><td>{esc(onboarding_doc.employee_name or "")}</td></tr>
			<tr><td class="ss-label">DESIGNATION</td><td>{esc(onboarding_doc.designation or "")}</td></tr>
			<tr><td class="ss-label">DATE OF JOINING</td><td>{esc(report_by)}</td></tr>
			<tr><td class="ss-label">LOCATION</td><td>{esc(_report_location(onboarding_doc))}</td></tr>
		</table>
		<table class="ss-salary">
			<tr><th></th><th></th><th>PARTICULARS</th><th class="amt">PER MONTH</th><th class="amt">PER ANNUM</th></tr>
			{rows_html}
		</table>
		{"" if overflow_risk else tail_html}
	</div>
	"""
	extra_page_html = f'<div class="ss-page-break content">{tail_html}</div>' if overflow_risk else ""
	return page_html, extra_page_html


def _body_paragraphs_html(report_location, report_by, is_senior, esc):
	"""The middle five paragraphs of the letter (join-by-date, transfer
	clause, training/confidentiality clause, notice-period clause,
	guarantee-form clause) - two full variants, not templated differences,
	since the senior-role wording (from the company's actual senior-role
	LOI paper format) differs in substance, not just a phrase or two: a
	legal-action confidentiality clause instead of a reimbursement clause,
	and an "at its absolute discretion" termination clause instead of the
	standard one. Selected per Job Offer via the "Senior Role" checkbox
	(custom_senior_role) - see build_letter_of_intent_html below."""
	if is_senior:
		return f"""
		<p class="body-para">In the event of acceptance of the above, you are welcome to join our services
		and hereby directed to report at our <b>{esc(report_location)}</b> on or before
		<b>{esc(report_by)}</b> failing which, this letter will automatically stand cancelled.</p>

		<p class="body-para">The Company shall be entitled, at any time during the course of your
		employment with us, to transfer you to any of our branches and you shall comply with all
		directions and instructions on that behalf.</p>

		<p class="body-para emphasis">Our Company have to incurred a lot of expenses in your training
		&amp; development program. So, if you leave this company &amp; join any other company &amp; found
		that you are sharing confidential details of the company then company has the right to take
		legal action against you.</p>

		<p class="body-para">The management reserves the right to terminate your services at its absolute
		discretion only after giving One month notice or One month salary in lieu of notice period.
		Similarly, you shall be at liberty to resign from services after giving One month notice or
		deposit One month salary with the company in lieu of the notice period.</p>

		<p class="body-para">Kindly sign the duplicate of this letter and return it to the H.R. Deptt.,
		as a token of your acceptance. Your services will be governed by company's rules and regulations
		which will be communicated to you from time to time. You will also be required to furnish all
		the documents as mention in <b>Guarantee Form</b> at the time of joining.</p>
		"""
	return f"""
	<p class="body-para">In the event of acceptance of the above, you are welcome to join our services
	and hereby directed to report at our <b>{esc(report_location)}</b> on or before
	<b>{esc(report_by)}</b> failing which, this letter will automatically stand canceled.</p>

	<p class="body-para">The Company shall be entitled, at any time during the course of your
	employment with us, to transfer you to any of our branches and you shall comply with all
	directions and instructions on that behalf.</p>

	<p class="body-para emphasis">The Company will be investing significantly in your training and
	development. Therefore, in the event that you join a competitor or a similar industry within
	One year of your separation from the Company, you will be required to reimburse an amount
	equivalent to up to six months of your salary at the time of departure.</p>

	<p class="body-para">The Company reserves the right to terminate your employment by providing
	One months&rsquo; prior written notice or salary in lieu thereof. Similarly, you may resign from
	your position by serving One months&rsquo; prior written notice or by paying an amount equivalent
	to One months&rsquo; salary in lieu of the notice period.</p>

	<p class="body-para">Kindly sign the duplicate of this letter and return it to the H.R. Deptt.,
	as a token of your acceptance. Your services will be governed by company's rules and regulations
	which will be communicated to you from time to time. You will also be required to furnish all
	the documents as mentioned in the <b>Guarantee Form</b> at the time of joining.</p>
	"""


LETTERHEAD_ASSET_DIR = "/assets/olscpl_hrms/files/letterheads"

# Full-page letterheads not shipped as this app's own asset pair (see
# FULL_PAGE_OFFSET_OVERRIDES below for those) - kept empty for now, but
# left in place as the fallback for any future one-off Letter Head image
# uploaded ad hoc rather than added to public/files/letterheads/. Keyed by
# the image URL exactly as it appears in the Letter Head's own HTML.
KNOWN_FULL_PAGE_LETTERHEADS = {}

# Per-company override for the auto-detected <name>_header.jpg /
# <name>_letterhead.jpg pairing below - the (54, 28, 16) default is
# calibrated to OLSCPL/SANJVIK/Telecom's own artwork (logo block to
# ~46mm, inset frame at ~28mm). Offsets measured the same way as the
# FULL_PAGE_STYLE comment below describes.
#
# rapidshyp: logo sits much higher/smaller on its page (~15% of page
# height), no inset frame.
#
# transafe: was previously an ad-hoc Letter Head image upload (site
# /files/, not this app's assets - that's why it broke on production but
# not locally: an uploaded file never travels with a code deploy) rather
# than this app's own header/letterhead pairing; migrated to match the
# other three. No inset decorative frame like OLSCPL/SANJVIK/Telecom (its
# border sits right at the page edge), so its margins are plain round
# numbers, not measured off a frame line - and its header block runs to
# about 70mm, so 75mm clears it with a small gap.
FULL_PAGE_OFFSET_OVERRIDES = {
	"rapidshyp": (50, 20, 20),
	"transafe": (75, 20, 20),
}

# Layout for the full-page-artwork mode. Measured off the artwork itself
# (A4 at 1414x2000 -> 1px = 0.1485mm): the grey frame's left line sits at
# ~16-18mm, its top edge at ~46mm and its bottom edge at ~268mm, so body
# text starts inside the frame (28mm from the left, 54mm from the top) and
# each page's content must stay within ~208mm of height. Margins are forced
# to 0 through a `.print-format` rule, which Frappe's PDF step reads back
# out of the HTML (frappe.utils.pdf.read_options_from_html), so the artwork
# can bleed to the paper edge. Page height is a hair under 297mm so the
# fixed-size block never spills a blank extra page. top_mm/left_mm/right_mm
# are per-letterhead (see KNOWN_FULL_PAGE_LETTERHEADS above) - the values
# below are OLSCPL/SANJVIK/Telecom's own.
def _full_page_style(top_mm=54, left_mm=28, right_mm=16):
	return f"""
	.print-format {{ margin-top: 0mm; margin-bottom: 0mm; margin-left: 0mm; margin-right: 0mm; }}
	body {{ margin: 0; }}
	.lh-page {{ position: relative; width: 210mm; height: 296mm; page-break-after: always; overflow: hidden; }}
	.lh-page:last-child {{ page-break-after: auto; }}
	.lh-bg {{ position: absolute; top: 0; left: 0; width: 210mm; height: 296mm; }}
	.lh-body {{ position: absolute; top: {top_mm}mm; left: {left_mm}mm; right: {right_mm}mm; }}
	.lh-body .content {{ padding: 0 !important; }}
	.lh-body .ss-page-break {{ page-break-before: auto !important; padding: 0 !important; }}
	/* Frappe's on-screen print preview pads .print-format by 0.75in (a
	   screen-only rule in templates/styles/standard.css), which shifted the
	   full-bleed page right and clipped it. Inside @media screen so it is
	   ignored by the PDF step's margin read-out (that only reads top-level
	   .print-format rules) and by print media. */
	@media screen {{ .print-format {{ padding: 0 !important; }} }}
"""


# Kept for any external caller - returns just the URL half of
# _full_page_letterhead_info().
def _full_page_letterhead_url(letter_head_html):
	info = _full_page_letterhead_info(letter_head_html)
	return info[0] if info else None


def _full_page_letterhead_info(letter_head_html):
	"""The company letterheads (OLSCPL / SANJVIK / OM Telecom) each ship a
	full A4 artwork next to their header/footer crops, named
	<company>_letterhead.jpg beside <company>_header.jpg (see
	public/files/letterheads/README.md); KNOWN_FULL_PAGE_LETTERHEADS above
	covers ones that are already one whole-page image on their own. Given
	the rendered Letter Head HTML, returns (image_url, top_mm, left_mm,
	right_mm) for whichever of those it matches, else None (any other
	letterhead keeps the normal header-then-body-then-footer behaviour)."""
	m = re.search(rf"{re.escape(LETTERHEAD_ASSET_DIR)}/(\w+)_header\.jpg", letter_head_html or "")
	if m:
		name = m.group(1)
		path = frappe.get_app_path("olscpl_hrms", "public", "files", "letterheads", f"{name}_letterhead.jpg")
		if os.path.exists(path):
			top_mm, left_mm, right_mm = FULL_PAGE_OFFSET_OVERRIDES.get(name, (54, 28, 16))
			# ?v=<file time>: a replaced letterhead image isn't served from browser cache
			url = f"{LETTERHEAD_ASSET_DIR}/{name}_letterhead.jpg?v={int(os.path.getmtime(path))}"
			return (url, top_mm, left_mm, right_mm)
	for url, offsets in KNOWN_FULL_PAGE_LETTERHEADS.items():
		if url in (letter_head_html or ""):
			return (url, *offsets)
	return None


def _sender_signature_html(onboarding_doc):
	"""The authorised signatory's signature - whoever sent the candidate
	their onboarding link (Employee Onboarding.portal_link_sent_by, set in
	generate_portal_link() just before this PDF is built), else whoever is
	looking at the letter right now (a Job Offer preview, before any link
	has been sent, where they are the one about to send it). Read from
	their own User.custom_signature, the same field every onboarding form
	and the appointment letter already use. Blank if they haven't drawn one
	yet - the sign block just keeps its empty gap to sign on by hand."""
	from olscpl_hrms.api.employee_data import _flatten_signature_on_white, get_user_signature

	sender = (onboarding_doc.get("portal_link_sent_by") if onboarding_doc else None) or frappe.session.user
	signature = get_user_signature(sender)
	if not signature:
		return ""
	return f'<img src="{_flatten_signature_on_white(signature)}">'


def _additional_terms_page(onboarding_doc, company, candidate_name, esc):
	"""Last page: the Job Offer's Additional Terms & Commitments (asked for in the
	Submit Offer dialog), one point per line, with both signature lines. "" if none."""
	job_offer = getattr(onboarding_doc, "job_offer", None)
	text = (frappe.db.get_value("Job Offer", job_offer, "custom_additional_terms") or "").strip() if job_offer else ""
	if not text:
		return ""
	points = [p.strip().lstrip("-•*").strip() for p in text.splitlines() if p.strip()]
	items = "".join(f"<li>{esc(p)}</li>" for p in points)
	# same sender signature as the letter's own sign block, in the gap above "(Authorised Signatory)"
	signature = _sender_signature_html(onboarding_doc).replace("<img ", '<img style="max-height:64px;max-width:220px;display:block" ', 1)
	return f"""
	<div class="ss-page-break content">
		<div class="subject">Additional Terms &amp; Commitments</div>
		<p class="body-para">In addition to the terms set out in this letter, the following have been agreed between
		{esc(company)} and {esc(candidate_name)} and form part of this offer:</p>
		<ol class="body-para" style="padding-left:18px">{items}</ol>
		<table style="width:100%;margin-top:60px">
			<tr><td style="width:55%;vertical-align:top">For {esc(company)}</td>
				<td style="width:45%;vertical-align:top;text-align:right">Accepted by</td></tr>
			<tr><td style="vertical-align:bottom"><div style="height:66px;margin-top:14px">{signature}</div>(Authorised Signatory)</td>
				<td style="vertical-align:bottom;text-align:right">{esc(candidate_name)}</td></tr>
		</table>
	</div>
	"""


def build_letter_of_intent_html(onboarding_doc, use_letterhead=False, page_bg_url=None, page_bg_offsets=None) -> str:
	"""onboarding_doc: an Employee Onboarding doc (or anything with
	.employee_name, .designation, .company, .date_of_joining). Returns the
	full self-contained HTML (with its own <style>) - shared by the PDF
	builder below (emailed with the onboarding link) and the "Letter of
	Intent" print format (so what HR previews/prints from the Job Offer or
	Employee Onboarding form is exactly what the candidate was emailed,
	not a second copy of this markup that can drift out of sync).

	use_letterhead: the print preview/PDF has a Frappe Letter Head applied,
	which already carries the logo/address/contact details - so the letter's
	own built-in header block is dropped instead of printing both. The
	emailed PDF (build_letter_of_intent_pdf) has no Letter Head, so it keeps
	the built-in header.

	page_bg_url: full-page A4 letterhead artwork (see
	_full_page_letterhead_info) - when given, every page is laid out as its
	own A4 block with that artwork behind it, instead of relying on Frappe's
	header/footer crops (which are drawn once, at the top of the first page
	and the bottom of the last, so the artwork's grey frame line - which
	runs the whole page height - was cut off in between)."""
	company = onboarding_doc.company
	today = now_datetime()
	ref = _ref_number(company, today)
	ref_date = format_date(today, "d MMMM yyyy")

	candidate_name = onboarding_doc.employee_name or ""
	designation = onboarding_doc.designation or ""
	report_by = format_date(onboarding_doc.date_of_joining, "dd-MM-yyyy") if onboarding_doc.date_of_joining else ""
	report_location = _report_location(onboarding_doc)

	esc = frappe.utils.escape_html

	salary_structure_html = ""
	salary_structure_extra_html = ""
	is_senior = False
	if getattr(onboarding_doc, "job_offer", None):
		try:
			job_offer = frappe.get_doc("Job Offer", onboarding_doc.job_offer)
			is_senior = bool(job_offer.get("custom_senior_role"))
			if _has_salary_data(job_offer):
				salary_structure_html, salary_structure_extra_html = _salary_structure_html(job_offer, onboarding_doc)
		except frappe.DoesNotExistError:
			pass

	body_paragraphs = _body_paragraphs_html(report_location, report_by, is_senior, esc)

	builtin_header_html = ""
	if not use_letterhead and not page_bg_url:
		builtin_header_html = f"""
			<div class="header">
				{_company_logo_html(company)}
				<div class="company-name">{esc(company)}</div>
			</div>
			<hr class="header-rule">
			{_company_contact_line(company)}
			<hr class="header-rule">
		"""

	letter_html = f"""
		<div class="content">
			{builtin_header_html}

			<table class="ref-row"><tr>
				<td>Ref: {esc(ref)}</td>
				<td class="date">{esc(ref_date)}</td>
			</tr></table>

			<div class="subject">Sub. : Letter Of Intent</div>

			<div class="salutation">Dear {esc(candidate_name)},</div>

			<p class="body-para">With reference to your recent interview with us, we are pleased to offer you
			an employment as {_article_for(designation)} &ldquo;<b>{esc(designation)}</b>&rdquo;.</p>

			{body_paragraphs}

			<p class="body-para">Looking forward and anticipating a mutual beneficial &amp; fruitful long
			lasting association with you!</p>

			<div class="sign-block">
				<div class="for-line">For {esc(company)}</div>
				<div class="sig-space">{_sender_signature_html(onboarding_doc)}</div>
				<div class="role">(Authorised Signatory)</div>
				<div>HRD</div>
			</div>
		</div>
	"""

	# RapidShyp has its own Letter Of Offer and salary sheet (api/rapidshyp.py),
	# laid out in the same three page slots; every other company is unchanged.
	from olscpl_hrms.api.rapidshyp import is_rapidshyp, offer_letter_parts

	if is_rapidshyp(company):
		letter_html, salary_structure_html, salary_structure_extra_html = offer_letter_parts(
			onboarding_doc, _sender_signature_html(onboarding_doc), builtin_header_html
		)

	additional_terms_html = _additional_terms_page(onboarding_doc, company, candidate_name, esc)

	if page_bg_url:
		def page(inner):
			return (
				f'<div class="lh-page"><img class="lh-bg" src="{page_bg_url}">'
				f'<div class="lh-body">{inner}</div></div>'
			)

		pages = (
			page(letter_html)
			+ (page(salary_structure_html) if salary_structure_html else "")
			+ (page(salary_structure_extra_html) if salary_structure_extra_html else "")
			+ (page(additional_terms_html) if additional_terms_html else "")
		)
		full_page_style = _full_page_style(*page_bg_offsets) if page_bg_offsets else _full_page_style()
		return f"""
	<html><head><meta charset="utf-8"><style>{STYLE}{full_page_style}</style></head><body>
		{pages}
	</body></html>
	"""

	return f"""
	<html><head><meta charset="utf-8"><style>{STYLE}</style></head><body>
		{letter_html}
		{salary_structure_html}
		{salary_structure_extra_html}
		{additional_terms_html}
	</body></html>
	"""


def build_letter_of_intent_pdf(onboarding_doc) -> bytes:
	"""Emailed PDF (offer letter on submit, onboarding link) - on the
	company's default Letter Head, same as the print view shows, instead of
	the bare built-in header."""
	letter_head = footer = None
	lh_name = frappe.db.get_value("Company", onboarding_doc.company, "default_letter_head") if onboarding_doc.company else None
	if lh_name:
		letter_head, footer = frappe.db.get_value("Letter Head", lh_name, ["content", "footer"])
	return get_pdf(_letter_html_with_letterhead(onboarding_doc, letter_head, footer))


@frappe.whitelist()
def download_letter_of_intent(employee_onboarding: str):
	doc = frappe.get_doc("Employee Onboarding", employee_onboarding)
	doc.check_permission("read")

	pdf_bytes = build_letter_of_intent_pdf(doc)

	frappe.local.response.filename = f"{doc.name}-letter-of-intent.pdf"
	frappe.local.response.filecontent = pdf_bytes
	frappe.local.response.type = "download"


def _onboarding_doc_for_print(doctype, docname):
	"""Resolves whichever doc the "Letter of Intent" print format is being
	viewed from (Employee Onboarding directly, or a Job Offer - looked up
	via its linked Employee Onboarding) down to the Employee Onboarding
	doc build_letter_of_intent_html() actually needs."""
	if doctype == "Employee Onboarding":
		return frappe.get_doc("Employee Onboarding", docname)
	if doctype == "Job Offer":
		onboarding_name = frappe.db.get_value("Employee Onboarding", {"job_offer": docname})
		if onboarding_name:
			return frappe.get_doc("Employee Onboarding", onboarding_name)

		# HR previews the Letter of Intent on the Job Offer *before* sending
		# the onboarding link (that is what creates the Employee Onboarding
		# record), so a missing onboarding must not block the preview. The
		# letter only reads name/designation/company/joining date/branch
		# from it - all of it lives on the Job Offer itself, including the
		# joining date (offer_date, labelled "Date of Joining"), which the
		# onboarding record later copies and stays synced to - so the preview
		# matches what the candidate is later emailed.
		offer = frappe.get_doc("Job Offer", docname)
		# the designation HR sets on the offer wins; the applicant's (from the
		# job opening) is only a fallback when the offer has none
		applicant_designation = (
			frappe.db.get_value("Job Applicant", offer.job_applicant, "designation")
			if offer.job_applicant and not offer.designation
			else None
		)
		return frappe._dict(
			employee_name=offer.applicant_name,
			designation=offer.designation or applicant_designation,
			company=offer.company,
			# offer_date is the Job Offer's (mandatory) "Date of Joining"
			date_of_joining=offer.offer_date,
			job_offer=offer.name,
		)
	return None


def get_letter_of_intent_print_html(doctype, docname, letter_head=None, footer=None):
	"""Jinja method (see hooks.py `jinja.methods`) backing the "Letter of
	Intent" print format on both Job Offer and Employee Onboarding - so
	the print/preview toolbar shows the same letter+salary-structure PDF
	that generate_portal_link() emails, instead of only being available as
	an email attachment."""
	onboarding_doc = _onboarding_doc_for_print(doctype, docname)
	if not onboarding_doc:
		return (
			"<div style='padding:40px;text-align:center;color:#666;font-family:sans-serif'>"
			"No Employee Onboarding record is linked to this Job Offer yet - "
			"use \"Send Onboarding Link\" first, then reopen this print format."
			"</div>"
		)
	return _letter_html_with_letterhead(onboarding_doc, letter_head, footer)


def _letter_html_with_letterhead(onboarding_doc, letter_head=None, footer=None):
	"""The letter laid out on a given Letter Head's rendered header/footer
	HTML - shared by the print view and the emailed PDF, so both look the
	same."""
	full_page = _full_page_letterhead_info(letter_head)
	if full_page:
		bg, top_mm, left_mm, right_mm = full_page
		return build_letter_of_intent_html(onboarding_doc, page_bg_url=bg, page_bg_offsets=(top_mm, left_mm, right_mm))
	if letter_head:
		# Letter Head with no full-page artwork: Frappe's own header (top of
		# the letter) and footer (bottom), and the letter's built-in logo/
		# address header dropped so the two don't double up.
		return (
			f'<div class="letter-head">{letter_head}</div>'
			+ build_letter_of_intent_html(onboarding_doc, use_letterhead=True)
			+ (f'<div class="letter-head-footer">{footer}</div>' if footer else "")
		)
	return build_letter_of_intent_html(onboarding_doc)

