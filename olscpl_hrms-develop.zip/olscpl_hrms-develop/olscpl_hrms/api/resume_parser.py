# olscpl_hrms/api/resume_parser.py
#
# "Parse Resume" (Recruitment workspace / Job Applicant list): HR uploads a
# candidate's resume (PDF or DOCX), the applicant's name, email and phone are
# read from it, HR checks/edits them, and a Job Applicant is created with the
# resume attached.
#
# Runs entirely on this server - no third-party parsing service (the free
# ones are trials of paid APIs that would receive every candidate's resume).
# Text comes from pypdf (a Frappe dependency) or the .docx's own XML; email
# and phone are pattern matches, the name a heading/label heuristic.
# ponytail: scanned (image-only) PDFs have no text - HR types those in; add
# OCR if that turns out to be common.
import html
import io
import logging
import re
import zipfile

import frappe
from frappe import _

logging.getLogger("pypdf").setLevel(logging.ERROR)  # malformed-PDF warnings, harmless

# common endings first, so "x@gmail.comContact" (no space in the PDF's text) stops at .com
EMAIL_RE = re.compile(
	r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*?\.(?:co\.in|ac\.in|com|in|org|net|edu|gov|io|co|info|me)(?![A-Za-z0-9.-]*@)"
	r"|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"
)
# Indian mobile, optionally +91/91/0-prefixed, digits possibly split by spaces/dashes
PHONE_RE = re.compile(r"(?<!\d)(?:\+?91[\s-]*|0)?([6-9](?:[\s-]?\d){9})(?!\d)")
NAME_LABEL_RE = re.compile(r"^\s*(?:full\s+)?name\s*[:\-–]\s*(.+)$", re.I)
NOT_A_NAME = re.compile(
	r"resume|curriculum|vitae|\bcv\b|bio-?data|profile|objective|summary|address|contact|e-?mail|phone|mobile"
	r"|@|www\.|http|linkedin|\d"
	# section headings and job words that sit above the name on many resumes
	r"|experience|history|education|qualification|skill|project|certific|achievement|personal|detail"
	r"|declaration|reference|language|hobb|career|professional|work|employment|training|strength|competenc"
	r"|manager|engineer|executive|developer|analyst|consultant|officer|operations|accountant|intern"
	r"|assistant|associate|specialist|coordinator|supervisor|lead\b|head\b|director|\bhr\b",
	re.I,
)


def _unspace(line):
	"""'B H U M I K A  B H R I G U' (letter-spaced heading, as pypdf reads many
	designed resumes) -> 'BHUMIKA BHRIGU'."""
	tokens = line.split(" ")
	letters = [t for t in tokens if t]
	if len(letters) >= 4 and sum(len(t) == 1 for t in letters) / len(letters) > 0.8:
		return " ".join(word.replace(" ", "") for word in re.split(r" {2,}", line.strip()))
	return line


def extract_text(content: bytes, filename: str) -> str:
	name = (filename or "").lower()
	if name.endswith(".pdf"):
		from pypdf import PdfReader

		reader = PdfReader(io.BytesIO(content))
		return "\n".join((page.extract_text() or "") for page in reader.pages[:4])
	if name.endswith(".docx"):
		with zipfile.ZipFile(io.BytesIO(content)) as z:
			xml = z.read("word/document.xml").decode("utf8", "ignore")
		xml = re.sub(r"</w:p>|<w:br/>|<w:tab/>", "\n", xml)
		return html.unescape(re.sub(r"<[^>]+>", "", xml))
	frappe.throw(_("Upload the resume as a PDF or Word (.docx) file"))


def _name_words(line):
	return line.replace(".", ". ").split()


def _looks_like_name(line, first_line=False):
	words = _name_words(line)
	return (
		(1 < len(words) <= 4 or (first_line and len(words) == 1 and len(line) >= 3))
		and len(line) <= 40
		and not NOT_A_NAME.search(line)
		and all(re.fullmatch(r"[A-Za-z][A-Za-z.'-]*", w) for w in words)
	)


def parse(text: str) -> dict:
	lines = [re.sub(r"\s+", " ", _unspace(ln)).strip(" |•·-–") for ln in text.splitlines()]
	# "NILADRI JANAIndustrial Operations" (name glued to the headline) -> "NILADRI JANA Industrial ..."
	lines = [re.sub(r"([A-Z]{2,})(?=[A-Z][a-z])", r"\1 ", ln) for ln in lines if ln]
	flat = "\n".join(lines)

	email = next(iter(EMAIL_RE.findall(flat)), None)
	phone_match = PHONE_RE.search(flat)
	phone = re.sub(r"\D", "", phone_match.group(1)) if phone_match else None

	name = None
	for ln in lines[:40]:  # an explicit "Name: ..." label wins
		m = NAME_LABEL_RE.match(ln)
		if m and not NOT_A_NAME.search(m.group(1)):
			name = m.group(1)
			break
	if not name:
		# the first name-like line above (or just by) the contact details
		contact = next((i for i, ln in enumerate(lines[:20]) if EMAIL_RE.search(ln) or PHONE_RE.search(ln)), None)
		limit = min(15, contact + 1) if contact is not None else 15
		name = next((ln for i, ln in enumerate(lines[:limit]) if _looks_like_name(ln, first_line=i == 0)), None)
	if not name:
		# else a run of capitalised words opening the first lines ("HARSH TICKOO MBA - ...")
		for ln in lines[:2]:
			m = re.match(r"^([A-Z][A-Z.'-]+(?: [A-Z][A-Z.'-]+){1,2})\b", ln)
			if m and not NOT_A_NAME.search(m.group(1)):
				name = m.group(1)
				break
	if name:
		name = " ".join(w.capitalize() if w.isupper() or w.islower() else w for w in _name_words(name.strip(" .,")))

	return {"applicant_name": name, "email_id": email.lower() if email else None, "phone_number": phone}


@frappe.whitelist()
def parse_resume(file_url: str, job_title: str = None):
	"""Read an uploaded resume and return the applicant fields found in it."""
	frappe.has_permission("Job Applicant", "create", throw=True)
	file_doc = frappe.get_doc("File", {"file_url": file_url})
	text = extract_text(file_doc.get_content(), file_doc.file_name)
	result = parse(text)
	result["has_text"] = bool(text.strip())
	result["existing"] = existing_application(result["email_id"], job_title)
	return result


@frappe.whitelist()
def existing_application(email_id: str = None, job_title: str = None):
	"""This candidate's earlier application to the same opening, if any -
	applying to a different opening is normal and not flagged."""
	if not email_id or not job_title:
		return None
	return frappe.db.get_value("Job Applicant", {"email_id": email_id, "job_title": job_title}, ["name", "job_title"], as_dict=True)


@frappe.whitelist()
def create_applicant(file_url: str, applicant_name: str, email_id: str, job_title: str = None, phone_number: str = None):
	"""Create the Job Applicant from the checked fields, with the resume attached.
	Refused if this email has already applied to the same opening."""
	frappe.has_permission("Job Applicant", "create", throw=True)
	existing = existing_application((email_id or "").strip().lower(), job_title)
	if existing:
		frappe.throw(_("{0} has already applied to this opening ({1}) - not created again").format(email_id, existing.name))
	applicant = frappe.get_doc({
		"doctype": "Job Applicant",
		"applicant_name": applicant_name,
		"email_id": email_id,
		"phone_number": phone_number,
		"job_title": job_title or None,
		"resume_attachment": file_url,
		"status": "Open",
	}).insert()
	file_name = frappe.db.get_value("File", {"file_url": file_url, "attached_to_name": ["is", "not set"]})
	if file_name:
		frappe.db.set_value("File", file_name, {
			"attached_to_doctype": "Job Applicant",
			"attached_to_name": applicant.name,
			"attached_to_field": "resume_attachment",
		})
	return applicant.name


@frappe.whitelist()
def create_applicants(rows: str, job_title: str = None):
	"""Bulk upload: create a Job Applicant per checked row; one row failing
	(e.g. no email) doesn't stop the rest. Returns what happened per row."""
	frappe.has_permission("Job Applicant", "create", throw=True)
	results = []
	for row in frappe.parse_json(rows):
		frappe.db.savepoint("resume_row")
		try:
			name = create_applicant(
				row.get("file_url"), row.get("applicant_name"), row.get("email_id"),
				job_title=job_title, phone_number=row.get("phone_number"),
			)
			results.append({"file_url": row.get("file_url"), "name": name})
		except Exception as e:
			frappe.db.rollback(save_point="resume_row")
			frappe.clear_messages()
			results.append({"file_url": row.get("file_url"), "error": frappe.utils.strip_html(str(e)) or "Could not create"})
	return results
