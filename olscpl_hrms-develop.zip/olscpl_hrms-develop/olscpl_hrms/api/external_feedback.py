# olscpl_hrms/api/external_feedback.py
#
# No-login Interview Feedback for external interviewers
# (www/interview-feedback-form, invited from events/interview.py). The link
# carries the Interview and that interviewer's private key; the feedback is
# saved as a normal Interview Feedback against their website user, so stock
# HRMS rules and our hooks (Interview status, summary, Previous Rounds) apply.
import frappe
from frappe import _
from frappe.rate_limiter import rate_limit
from frappe.utils import cint, flt, getdate, nowdate

from olscpl_hrms.patches.v1_1.add_interview_feedback_candidate_details import CARRIED, FIELDS


def get_invite(interview, key):
	"""(interview doc, external interviewer row) for a valid link, else (None, None)."""
	if not interview or not key or len(key) < 20:
		return None, None
	row = frappe.db.get_value("Interview External Interviewer", {"parent": interview, "parenttype": "Interview",
		"feedback_key": key}, ["name", "interviewer_name", "email", "user", "feedback"], as_dict=True)
	if not row:
		return None, None
	iv = frappe.get_doc("Interview", interview)
	return (iv, row) if iv.docstatus < 2 else (None, None)


def form_context(interview, key):
	iv, row = get_invite(interview, key)
	if not iv:
		return {"valid": False}
	from hrms.hr.doctype.interview.interview import get_expected_skill_set
	applicant = frappe.db.get_value("Job Applicant", iv.job_applicant, ["applicant_name", "resume_attachment",
		"custom_job_opening_title"], as_dict=True) or {}
	submitted = row.feedback and frappe.db.get_value("Interview Feedback", row.feedback, "docstatus") == 1
	from olscpl_hrms.api.rapidshyp import is_rapidshyp
	from olscpl_hrms.events.interview import _company, _stars, external_previous_rounds
	from olscpl_hrms.events.interview_feedback import _previous_details

	return {
		"valid": True, "interview": iv, "row": row, "submitted": bool(submitted),
		"rapidshyp": is_rapidshyp(_company(iv)),  # RapidShyp opening: RapidShyp header
		"candidate": applicant.get("applicant_name") or iv.job_applicant, "resume": applicant.get("resume_attachment"),
		"opening": applicant.get("custom_job_opening_title") or iv.job_opening,
		"too_early": getdate(nowdate()) < getdate(iv.scheduled_on),
		"skills": [s.get("skill") for s in get_expected_skill_set(iv.interview_round) or []],
		"detail_fields": [f for f in FIELDS if f["fieldtype"] not in ("Section Break", "Column Break")],
		"detail_sections": FIELDS,
		# pre-filled with what earlier rounds already noted (latest value per
		# field), like the desk form (events/interview_feedback.copy_previous_details)
		"previous": _previous_details(iv.job_applicant, exclude=row.feedback),
		# earlier rounds' results / ratings / comments (no candidate details)
		"previous_rounds": external_previous_rounds(iv.name),
		"stars": _stars,
	}


@frappe.whitelist(allow_guest=True, methods=["POST"])
@rate_limit(limit=20, seconds=60 * 60)
def submit(interview, key, data):
	iv, row = get_invite(interview, key)
	if not iv:
		frappe.throw(_("This feedback link is invalid."), frappe.PermissionError)
	if row.feedback and frappe.db.get_value("Interview Feedback", row.feedback, "docstatus") == 1:
		frappe.throw(_("Your feedback for this interview has already been submitted."))
	if getdate(nowdate()) < getdate(iv.scheduled_on):
		frappe.throw(_("Feedback can be submitted from the interview date ({0}).").format(frappe.utils.format_date(iv.scheduled_on)))
	data = frappe.parse_json(data) if isinstance(data, str) else data
	if data.get("result") not in ("Cleared", "Under Review", "Rejected"):
		frappe.throw(_("Please choose a result."))
	skills = [{"skill": s, "rating": max(0.0, min(1.0, flt(r) / 5))} for s, r in (data.get("skills") or {}).items()
		if s and frappe.db.exists("Skill", s)]
	if not skills:
		frappe.throw(_("Please rate the skills."))

	fb = frappe.get_doc({
		"doctype": "Interview Feedback", "interview": iv.name, "interviewer": row.user, "job_applicant": iv.job_applicant,
		"result": data["result"], "feedback": (data.get("feedback") or "").strip()[:5000], "skill_assessment": skills,
		**{f: (cint(data.get(f)) if f == "custom_married" else (str(data.get(f) or "").strip()[:500] or None)) for f in CARRIED},
	})
	# key checked above; runs as Administrator for the stock + our feedback hooks, then back to Guest
	user = frappe.session.user
	frappe.set_user("Administrator")
	try:
		fb.flags.ignore_permissions = True
		fb.insert()
		fb.submit()
		frappe.db.set_value("Interview External Interviewer", row.name, "feedback", fb.name)
		frappe.db.commit()
	finally:
		frappe.set_user(user)
	return {"feedback": fb.name}
