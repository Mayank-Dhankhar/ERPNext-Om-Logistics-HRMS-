# olscpl_hrms/api/fbp.py
#
# Form helper for FBP Declaration (RapidShyp / OSBS only): given the employee's
# Salary Structure Assignment, returns the annual cap of every component so the
# form can fill its rows and warn at entry time. The server re-checks
# everything on save (doctype/fbp_declaration/fbp_declaration.py).
import frappe
from frappe import _
from frappe.utils import flt

from olscpl_hrms.utils.fbp_slabs import (
	COMPONENT_FIELD_MAP,
	FLEXI_SALARY_STRUCTURE,
	get_fbp_entitlements,
	get_fbp_bucket,
)


@frappe.whitelist()
def get_entitlements(salary_structure_assignment):
	frappe.has_permission(
		"Salary Structure Assignment", "read", doc=salary_structure_assignment, throw=True
	)
	ssa = frappe.db.get_value(
		"Salary Structure Assignment",
		salary_structure_assignment,
		["base", "salary_structure"],
		as_dict=True,
	)
	if not ssa:
		frappe.throw(_("Salary Structure Assignment {0} not found.").format(salary_structure_assignment))
	if ssa.salary_structure != FLEXI_SALARY_STRUCTURE:
		frappe.throw(
			_("This assignment is on {0}, not {1}.").format(ssa.salary_structure, FLEXI_SALARY_STRUCTURE)
		)

	gross = flt(ssa.base)
	entitlements = get_fbp_entitlements(gross)
	return {
		"gross": gross,
		"fbp_total": get_fbp_bucket(gross),
		"entitlements": [
			{"component": component, "entitlement": entitlements[component]}
			for component in COMPONENT_FIELD_MAP
		],
	}
