"""
olscpl_hrms/api/bulk_attendance.py

Custom whitelisted bulk endpoint for historical attendance backfill.
Add this file to your existing custom app (olscpl_hrms) and register the
whitelisted method (see bottom of file / hooks.py note).

WHY THIS EXISTS
----------------
The old Airflow DAG called Employee Checkin (x2) + Attendance-exists-check
(GET) + mark_bulk_attendance (POST) SEPARATELY for every single
(employee, date) pair. For 5,000 employees x 30 days that is ~150k-600k
blocking HTTP round trips, each paying full HTTP + Frappe request-boot +
ORM + hook overhead. That overhead, not Oracle and not the ORM itself, is
what was taking 30-40 minutes per day.

This endpoint accepts a BATCH (e.g. 500-1000 employee-date combinations)
in a single HTTP call and loops over them SERVER-SIDE, inside one Frappe
request/transaction, so you pay the per-call HTTP overhead once per batch
instead of once per record. All existing business logic (violation
calculation, late-coming counters, monthly tracker update via your
server scripts / doc_events) still fires normally, because we still go
through frappe.get_doc(...).insert() / the standard Attendance flow -
we are only removing REDUNDANT NETWORK ROUND TRIPS, not your validation.

EMAIL SUPPRESSION (Sep 28, 2026)
---------------------------------
A single insert()/submit() can fire Notification-doctype email alerts and
Workflow email alerts (e.g. any alert configured against Attendance). At
bulk-migration volume -- thousands of records in one call -- that means
thousands of individual emails, which is neither useful nor safe to send
(mail relay rate limits, inbox flooding). frappe.flags.mute_emails is
Frappe's own switch to suppress outbound mail (frappe.sendmail() and the
Notification/Workflow email-alert machinery both check it) -- set True
for the life of this call and always restored in a finally block so nothing
else on the site (interactive Desk usage, other whitelisted calls in the
same worker process) is left muted afterward.

USAGE FROM AIRFLOW
-------------------
POST {site}/api/method/olscpl_hrms.api.bulk_attendance.bulk_backfill_attendance
Body (JSON):
{
  "records": [
      {
        "employee": "HR-EMP-00123",       # ERPNext employee id (already resolved)
        "date": "2026-01-22",
        "punch_in": "2026-01-22 09:58:00",   # optional
        "punch_out": "2026-01-22 18:42:00",  # optional
        "status": "Present",               # "Present" or "Absent"
        "shift": "Head Office Common Shift"  # optional
      },
      ...
  ],
  "skip_existing": true   # if true, checks tabAttendance in bulk first and skips dupes
}

Returns:
{
  "created_checkins": <int>,
  "created_attendance": <int>,
  "skipped_existing": <int>,
  "skipped_inactive": <int>,                 # records for employees ERPNext marks Inactive
  "skipped_inactive_employees": [<emp>, ...],  # distinct ids, for the report
  "errors": [ {employee, date, stage, error}, ... ]
}

INACTIVE EMPLOYEES (Oct 19, 2026)
----------------------------------
HRMS core refuses to create any transaction (Employee Checkin, Attendance)
for an Employee whose status is "Inactive" ("Transactions cannot be created
for an Inactive Employee"). Oracle can still list such a person as active,
so the Airflow run sent them anyway and each record came back as an error
(651 errors on 2026-10-18). Inactive employees are now detected in ONE bulk
query and skipped up front - reported under skipped_inactive instead of
errors. Only status == "Inactive" is skipped, which is exactly what HRMS
blocks; "Left" employees with a future relieving date are untouched.
"""

import frappe
from frappe.utils import get_datetime


@frappe.whitelist()
def bulk_backfill_attendance(records, skip_existing=True):
    """
    records: list[dict] OR JSON string of that list (Frappe auto-parses
             JSON body fields passed as strings, but accept both).
    """
    import json

    if isinstance(records, str):
        records = json.loads(records)
    if isinstance(skip_existing, str):
        skip_existing = skip_existing.lower() == "true"

    if not records:
        return {
            "created_checkins": 0,
            "created_attendance": 0,
            "skipped_existing": 0,
            "skipped_inactive": 0,
            "skipped_inactive_employees": [],
            "errors": [],
        }

    result = {
        "created_checkins": 0,
        "created_attendance": 0,
        "skipped_existing": 0,
        "skipped_inactive": 0,
        "skipped_inactive_employees": [],
        "errors": [],
    }

    # ------------------------------------------------------------------
    # 1. ONE bulk lookup for existing Attendance rows covering every
    #    (employee, date) pair in this batch — replaces N GET calls with
    #    a single SQL query.
    # ------------------------------------------------------------------
    existing_pairs = set()
    if skip_existing:
        employees = list({r["employee"] for r in records})
        dates = [r["date"] for r in records]
        min_date, max_date = min(dates), max(dates)

        existing_rows = frappe.get_all(
            "Attendance",
            filters={
                "employee": ["in", employees],
                "attendance_date": ["between", [min_date, max_date]],
                "docstatus": ["!=", 2],
            },
            fields=["employee", "attendance_date"],
        )
        existing_pairs = {
            (row.employee, str(row.attendance_date)) for row in existing_rows
        }

    # ------------------------------------------------------------------
    # 1b. ONE bulk lookup for employees ERPNext marks Inactive - HRMS core
    #     refuses to create transactions for them, so skip them up front
    #     instead of letting every record fail as an error.
    # ------------------------------------------------------------------
    inactive_employees = set(
        frappe.get_all(
            "Employee",
            filters={
                "name": ["in", list({r["employee"] for r in records})],
                "status": "Inactive",
            },
            pluck="name",
        )
    )
    result["skipped_inactive_employees"] = sorted(inactive_employees)

    commit_every = 200
    processed_since_commit = 0

    # Bulk call: suppress Notification/Workflow email alerts for the whole
    # batch (see module docstring, "EMAIL SUPPRESSION"). Always restored,
    # even on an exception mid-batch, so this worker process never stays
    # muted for unrelated requests afterward.
    previous_mute = frappe.flags.mute_emails
    frappe.flags.mute_emails = True
    try:
        for idx, rec in enumerate(records):
            employee = rec["employee"]
            date_str = rec["date"]
            status = rec.get("status", "Present")

            if (employee, date_str) in existing_pairs:
                result["skipped_existing"] += 1
                continue

            if employee in inactive_employees:
                result["skipped_inactive"] += 1
                continue

            # A savepoint scopes the rollback below to JUST this record's
            # uncommitted work. Without it, frappe.db.rollback() rolls back
            # the WHOLE uncommitted transaction -- wiping out every earlier
            # record in this batch that succeeded but hasn't been committed
            # yet (commit only happens every `commit_every` records). That
            # was silently discarding good inserts whenever a later record
            # in the same batch failed (e.g. a broken Department link on one
            # employee erasing another employee's already-"successful"
            # Checkin/Attendance rows before they were ever committed).
            savepoint = f"bulk_att_{idx}"
            frappe.db.savepoint(savepoint)

            try:
                # --- Employee Checkin(s), only if a real punch exists ---
                # _insert_checkin returns False (instead of raising) when the
                # checkin already exists with the same timestamp -- that is
                # NOT a failure, it just means Airflow re-sent a punch we
                # already have. We must not let it abort the Attendance
                # insert below (the old DAG treated this as a soft-success
                # too; see module docstring history).
                if rec.get("punch_in"):
                    if _insert_checkin(employee, rec["punch_in"], "IN", rec.get("shift")):
                        result["created_checkins"] += 1
                if rec.get("punch_out"):
                    if _insert_checkin(employee, rec["punch_out"], "OUT", rec.get("shift")):
                        result["created_checkins"] += 1

                # --- Attendance record ---
                att = frappe.get_doc(
                    {
                        "doctype": "Attendance",
                        "employee": employee,
                        "attendance_date": date_str,
                        "status": status,
                    }
                )
                att.insert(ignore_permissions=True)
                att.submit()
                result["created_attendance"] += 1

            except Exception as e:
                result["errors"].append(
                    {
                        "employee": employee,
                        "date": date_str,
                        "stage": "insert",
                        "error": str(e)[:300],
                    }
                )
                # Roll back ONLY this record's changes (including any
                # checkin(s) already inserted above before the Attendance
                # insert failed) -- everything before this savepoint in the
                # current transaction is left untouched.
                frappe.db.rollback(save_point=savepoint)
                continue

            processed_since_commit += 1
            if processed_since_commit >= commit_every:
                frappe.db.commit()
                processed_since_commit = 0

        frappe.db.commit()
    finally:
        frappe.flags.mute_emails = previous_mute

    return result


def _insert_checkin(employee, time_str, log_type, shift=None):
    """
    Returns True if a new Employee Checkin was created, False if it was
    skipped because an identical (employee, time) checkin already exists
    (HRMS core's own duplicate-timestamp validation) -- that case is
    tolerated, not treated as an error, so the caller's Attendance insert
    still goes through. Any other validation/db error is re-raised so the
    caller's savepoint rollback still protects against real failures.
    """
    doc = frappe.get_doc(
        {
            "doctype": "Employee Checkin",
            "employee": employee,
            "time": get_datetime(time_str),
            "log_type": log_type,
            "device_id": "ORACLE_COVID19_ATT",
            "custom_custom_geo_validation": "Valid",
        }
    )
    if shift:
        doc.shift = shift

    try:
        doc.insert(ignore_permissions=True)
        return True
    except frappe.exceptions.ValidationError as e:
        msg = str(e).lower()
        if "same timestamp" in msg or "duplicate" in msg:
            return False
        raise


@frappe.whitelist()
def bulk_resolve_employee_ids(employee_numbers):
    """
    ONE call to map Oracle employee codes -> ERPNext employee ids,
    instead of the old DAG's one-GET-per-employee loop.

    employee_numbers: list[str] or JSON-encoded list.
    Returns: { "34625": "HR-EMP-00123", ... }  (unmatched codes omitted)
    """
    import json

    if isinstance(employee_numbers, str):
        employee_numbers = json.loads(employee_numbers)

    rows = frappe.get_all(
        "Employee",
        filters={"employee_number": ["in", employee_numbers]},
        fields=["name", "employee_number"],
    )
    return {row.employee_number: row.name for row in rows}
