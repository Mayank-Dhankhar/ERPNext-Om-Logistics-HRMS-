# olscpl_hrms/api/social_feed.py
#
# Company-wide Twitter-style social feed. Anyone can post; HR Manager /
# System Manager posts go live immediately, everyone else's needs one of
# those two roles to approve it first. Every entry point below does its
# own role/ownership check and reads/writes with ignore_permissions=True -
# the "Social Post*" doctypes themselves only grant System Manager access,
# so this module is the only sanctioned way in (same pattern as the rest
# of this app's whitelisted APIs).

import json

import frappe
from frappe.utils import cint, cstr

APPROVER_ROLES = {"System Manager", "HR Manager"}
MAX_CONTENT_LEN = 2000
MAX_COMMENT_LEN = 1000
MAX_IMAGES_PER_POST = 6
MAX_ATTACHMENTS_PER_POST = 6
FEED_PAGE_SIZE = 15


def _parse_images(raw):
	"""images is stored as a JSON array of file URLs (Long Text column) -
	a plain list field would need its own child doctype for what's really
	just an ordered list of strings, so JSON is the simpler fit here."""
	if not raw:
		return []
	try:
		parsed = json.loads(raw)
	except (TypeError, ValueError):
		return []
	return [u for u in parsed if isinstance(u, str) and u.strip()][:MAX_IMAGES_PER_POST]


def _parse_attachments(raw):
	"""attachments is a JSON array of {url, filename, size} for non-image
	files (PDF, Excel, Word, ...) - kept separate from images since those
	render as a thumbnail grid while these render as a clickable file chip."""
	if not raw:
		return []
	try:
		parsed = json.loads(raw)
	except (TypeError, ValueError):
		return []
	out = []
	for a in parsed:
		if isinstance(a, dict) and a.get("url"):
			out.append({
				"url": a["url"],
				"filename": (a.get("filename") or a["url"].rsplit("/", 1)[-1])[:200],
				"size": a.get("size") if isinstance(a.get("size"), (int, float)) else None,
			})
	return out[:MAX_ATTACHMENTS_PER_POST]


def _is_approver():
	if frappe.session.user == "Administrator":
		return True
	return bool(set(frappe.get_roles(frappe.session.user)) & APPROVER_ROLES)


def _author_info(user):
	info = frappe.db.get_value(
		"Employee",
		{"user_id": user},
		["employee_name", "designation", "department", "image"],
		as_dict=True,
	)
	# Employee.image is HR-managed (often set once, from an old ID-card
	# photo or a bulk import, and rarely touched again - one such import
	# left it pointing at a private file with no actual File record behind
	# it, 403ing for everyone); User.user_image is the person's own "My
	# Profile" picture, which they can update themselves and so is more
	# likely to actually be current. Prefer it, falling back to Employee.
	# image only when the user has never set one.
	user_image = frappe.db.get_value("User", user, "user_image")
	if info:
		return {
			"name": info.employee_name,
			"designation": info.designation,
			"image": user_image or info.image,
			"user": user,
		}
	full_name = frappe.db.get_value("User", user, "full_name") or user
	return {"name": full_name, "designation": None, "image": user_image, "user": user}


def _serialize_post(row, current_user):
	author = _author_info(row.owner)
	like_count = frappe.db.count("Social Post Like", {"post": row.name})
	comment_count = frappe.db.count("Social Post Comment", {"post": row.name})
	liked_by_me = bool(frappe.db.exists("Social Post Like", {"post": row.name, "owner": current_user}))

	return {
		"name": row.name,
		"content": row.content,
		"subtopic": row.subtopic,
		"isAnnouncement": bool(row.is_announcement),
		"images": _parse_images(row.images),
		"attachments": _parse_attachments(row.attachments),
		"status": row.status,
		"rejectionReason": row.rejection_reason,
		"author": author,
		"authorUser": row.owner,
		"isMine": row.owner == current_user,
		"postedOn": str(row.creation),
		"likeCount": like_count,
		"commentCount": comment_count,
		"likedByMe": liked_by_me,
	}


@frappe.whitelist()
def get_feed(before=None, limit=None):
	"""Approved posts, everyone's; plus the current user's own
	Pending/Rejected posts mixed in (so an author can see their own
	awaiting-approval or rejected post inline, badge-marked) - never
	another user's non-approved post. Cursor-paginated on creation."""
	user = frappe.session.user
	limit = min(cint(limit) or FEED_PAGE_SIZE, 50)

	conditions = ["(status = 'Approved' OR owner = %(user)s)"]
	values = {"user": user, "limit": limit}
	if before:
		conditions.append("creation < %(before)s")
		values["before"] = before

	rows = frappe.db.sql(
		f"""
		SELECT name, content, subtopic, is_announcement, images, attachments, status, rejection_reason, owner, creation
		FROM `tabSocial Post`
		WHERE {" AND ".join(conditions)}
		ORDER BY creation DESC
		LIMIT %(limit)s
		""",
		values,
		as_dict=True,
	)

	posts = [_serialize_post(r, user) for r in rows]
	return {
		"posts": posts,
		"hasMore": len(rows) == limit,
		"nextBefore": str(rows[-1].creation) if rows else None,
		"canApprove": _is_approver(),
		"me": _author_info(user),
	}


@frappe.whitelist()
def get_pending_posts():
	"""Moderation queue - HR Manager / System Manager only."""
	if not _is_approver():
		frappe.throw(frappe._("Only HR Manager or System Manager can view pending posts."), frappe.PermissionError)

	rows = frappe.db.sql(
		"""
		SELECT name, content, subtopic, is_announcement, images, attachments, status, rejection_reason, owner, creation
		FROM `tabSocial Post`
		WHERE status = 'Pending'
		ORDER BY creation ASC
		""",
		as_dict=True,
	)
	return [_serialize_post(r, frappe.session.user) for r in rows]


@frappe.whitelist()
def create_post(content=None, images=None, attachments=None, subtopic=None, is_announcement=None):
	content = (content or "").strip()
	# images/attachments arrive as JSON-encoded arrays of already-uploaded
	# file URLs (the browser uploads each file separately via
	# /api/method/upload_file first, then sends the results here) - a
	# plain list posted as form data would arrive as a single comma-joined
	# string, so the frontend JSON-encodes it and we decode the same way.
	image_list = _parse_images(images)
	attachment_list = _parse_attachments(attachments)

	# content is now rich HTML from a Text Editor control (see doctype's
	# "content" fieldtype) - an empty editor still serializes to something
	# like "<p><br></p>", which isn't an empty string, so the "did they
	# actually write anything" check has to look at the stripped text
	# instead of the raw HTML. The HTML itself is what gets stored/shown
	# (formatting preserved); doc.insert() auto-sanitizes it since Text
	# Editor fields go through frappe's sanitize_html on save.
	plain_text = frappe.utils.strip_html_tags(content).strip()
	if not plain_text and not image_list and not attachment_list:
		frappe.throw(frappe._("Write something or attach a file before posting."))
	if len(plain_text) > MAX_CONTENT_LEN:
		frappe.throw(frappe._("Post is too long (max {0} characters).").format(MAX_CONTENT_LEN))

	subtopic = cstr(subtopic).strip()[:80] or None

	approver = _is_approver()
	doc = frappe.get_doc({
		"doctype": "Social Post",
		"content": content,
		"subtopic": subtopic,
		"is_announcement": 1 if cint(is_announcement) else 0,
		"images": json.dumps(image_list) if image_list else None,
		"attachments": json.dumps(attachment_list) if attachment_list else None,
		"status": "Approved" if approver else "Pending",
	})
	if approver:
		doc.approved_by = frappe.session.user
		doc.approved_on = frappe.utils.now_datetime()
	doc.insert(ignore_permissions=True)
	frappe.db.commit()
	if approver and doc.is_announcement:
		_queue_announcement_notice(doc.name)

	row = frappe.db.get_value(
		"Social Post",
		doc.name,
		["name", "content", "subtopic", "is_announcement", "images", "attachments", "status", "rejection_reason", "owner", "creation"],
		as_dict=True,
	)
	return _serialize_post(row, frappe.session.user)


def _get_post_owner(post):
	owner = frappe.db.get_value("Social Post", post, "owner")
	if not owner:
		frappe.throw(frappe._("Post not found."), frappe.DoesNotExistError)
	return owner


@frappe.whitelist()
def delete_post(post):
	owner = _get_post_owner(post)
	if owner != frappe.session.user and not _is_approver():
		frappe.throw(frappe._("You can only delete your own posts."), frappe.PermissionError)
	frappe.delete_doc("Social Post", post, ignore_permissions=True, force=True)
	frappe.db.commit()


@frappe.whitelist()
def approve_post(post):
	if not _is_approver():
		frappe.throw(frappe._("Only HR Manager or System Manager can approve posts."), frappe.PermissionError)
	was_approved = frappe.db.get_value("Social Post", post, "status") == "Approved"
	frappe.db.set_value("Social Post", post, {
		"status": "Approved",
		"approved_by": frappe.session.user,
		"approved_on": frappe.utils.now_datetime(),
	}, update_modified=False)
	frappe.db.commit()
	if not was_approved and frappe.db.get_value("Social Post", post, "is_announcement"):
		_queue_announcement_notice(post)


@frappe.whitelist()
def reject_post(post, reason=None):
	if not _is_approver():
		frappe.throw(frappe._("Only HR Manager or System Manager can reject posts."), frappe.PermissionError)
	frappe.db.set_value("Social Post", post, {
		"status": "Rejected",
		"approved_by": frappe.session.user,
		"approved_on": frappe.utils.now_datetime(),
		"rejection_reason": cstr(reason)[:200] if reason else None,
	}, update_modified=False)
	frappe.db.commit()


@frappe.whitelist()
def toggle_like(post):
	if not frappe.db.exists("Social Post", post):
		frappe.throw(frappe._("Post not found."), frappe.DoesNotExistError)

	user = frappe.session.user
	existing = frappe.db.get_value("Social Post Like", {"post": post, "owner": user})
	if existing:
		frappe.delete_doc("Social Post Like", existing, ignore_permissions=True, force=True)
		liked = False
	else:
		frappe.get_doc({"doctype": "Social Post Like", "post": post}).insert(ignore_permissions=True)
		liked = True
	frappe.db.commit()

	return {"liked": liked, "likeCount": frappe.db.count("Social Post Like", {"post": post})}


@frappe.whitelist()
def get_comments(post):
	rows = frappe.get_all(
		"Social Post Comment",
		filters={"post": post},
		fields=["name", "comment", "owner", "creation"],
		order_by="creation asc",
	)
	return [
		{
			"name": r.name,
			"comment": r.comment,
			"author": _author_info(r.owner),
			"authorUser": r.owner,
			"postedOn": str(r.creation),
		}
		for r in rows
	]


@frappe.whitelist()
def add_comment(post, comment):
	if not frappe.db.exists("Social Post", post):
		frappe.throw(frappe._("Post not found."), frappe.DoesNotExistError)

	comment = (comment or "").strip()
	if not comment:
		frappe.throw(frappe._("Comment cannot be empty."))
	if len(comment) > MAX_COMMENT_LEN:
		frappe.throw(frappe._("Comment is too long (max {0} characters).").format(MAX_COMMENT_LEN))

	doc = frappe.get_doc({"doctype": "Social Post Comment", "post": post, "comment": comment})
	doc.insert(ignore_permissions=True)
	frappe.db.commit()

	return {
		"name": doc.name,
		"comment": doc.comment,
		"author": _author_info(doc.owner),
		"authorUser": doc.owner,
		"postedOn": str(doc.creation),
		"commentCount": frappe.db.count("Social Post Comment", {"post": post}),
	}


@frappe.whitelist()
def delete_comment(name):
	owner = frappe.db.get_value("Social Post Comment", name, "owner")
	if not owner:
		frappe.throw(frappe._("Comment not found."), frappe.DoesNotExistError)
	if owner != frappe.session.user and not _is_approver():
		frappe.throw(frappe._("You can only delete your own comments."), frappe.PermissionError)
	frappe.delete_doc("Social Post Comment", name, ignore_permissions=True, force=True)
	frappe.db.commit()


# ---------------------------------------------------------------------------
# Announcement -> app notification for every active employee
# ---------------------------------------------------------------------------
def _queue_announcement_notice(post):
	# ~10k recipients: never inside the approver's request
	frappe.enqueue(
		"olscpl_hrms.api.social_feed.send_announcement_notice",
		queue="long",
		post=post,
		enqueue_after_commit=True,
		job_id=f"social_announcement::{post}",
		deduplicate=True,
	)


def send_announcement_notice(post):
	"""One app (PWA) notification per active employee login, written in a
	single bulk insert - one-by-one inserts would be ~20k writes plus a push
	attempt each. The app's bell refreshes via one site-wide realtime event."""
	row = frappe.db.get_value("Social Post", post, ["owner", "content", "status", "is_announcement"], as_dict=True)
	if not row or row.status != "Approved" or not row.is_announcement:
		return
	if frappe.db.exists("PWA Notification", {"reference_document_type": "Social Post", "reference_document_name": post}):
		return  # already sent (e.g. re-approved)

	author = frappe.db.get_value("User", row.owner, "full_name") or row.owner
	text = frappe.utils.strip_html_tags(row.content or "").strip()
	if len(text) > 90:
		text = text[:87].rstrip() + "..."
	message = f"📢 <b>{frappe.utils.escape_html(author)}</b> posted an announcement" + (
		f": {frappe.utils.escape_html(text)}" if text else ""
	)

	users = frappe.db.sql_list(
		"""select distinct e.user_id from `tabEmployee` e
		join `tabUser` u on u.name = e.user_id and u.enabled = 1
		where e.status = 'Active' and ifnull(e.user_id, '') != '' and e.user_id != %s""",
		(row.owner,),
	)
	if not users:
		return
	# PWA Notification is autoincrement: its ids come from a sequence, not the
	# table. Draw all of them in one query (MariaDB's seq_1_to_N table).
	# ponytail: MariaDB-only, fine for this bench; Postgres would need generate_series.
	ids = frappe.db.sql_list(f"select nextval(`pwa_notification_id_seq`) from seq_1_to_{len(users)}")
	now = frappe.utils.now()
	fields = ["name", "creation", "modified", "owner", "modified_by", "docstatus", "from_user", "to_user", "message",
		"read", "reference_document_type", "reference_document_name"]
	values = [(i, now, now, row.owner, row.owner, 0, row.owner, u, message, 0, "Social Post", post) for i, u in zip(ids, users)]
	frappe.db.bulk_insert("PWA Notification", fields, values, chunk_size=2000)
	frappe.db.commit()
	# every open app re-reads its bell (hrms:refetch_resource, see hrms.refetch_resource)
	for key in ("hrms:notifications", "hrms:unread_notifications_count"):
		frappe.publish_realtime("hrms:refetch_resource", {"cache_key": key})
