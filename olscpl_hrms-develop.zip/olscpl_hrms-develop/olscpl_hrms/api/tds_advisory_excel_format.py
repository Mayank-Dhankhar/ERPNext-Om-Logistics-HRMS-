"""
OLSCPL-HRMS-TDS-001 (v9) : Excel-format TDS Advisory
------------------------------------------------------------------
App file: olscpl_hrms/api/tds_advisory_excel_format.py

v9 fixes two bugs found in v8:

1. Component row order was arbitrary (first-seen insertion order),
   not the expected Basic / HRA / Conveyance / Child Education /
   Uniform / ... sequence. Fixed with a canonical ordering list,
   with any other components appended after in first-seen order.

2. A component that starts recurring partway through the year (e.g.
   CCA effective from July via a recurring Additional Salary record)
   was incorrectly backfilled into EARLIER months that already have
   a submitted slip and genuinely don't have that component -- the
   per-component monthly fallback didn't distinguish "no slip this
   month yet, project forward" from "slip exists, component just
   wasn't on it that month". Fixed by only falling back to the
   recurring projection for months with NO submitted slip at all;
   months with a submitted slip always show their actual value
   (0 if the component wasn't present that month).

v8 (still included): queries Additional Salary directly for
component detection instead of trusting Salary Detail's
additional_salary link field (unreliable for already-submitted
slips, since the "ZZ Salary Slip Fixed Component" script wipes it
during rebuild).

v7 (still included): cumulative true-up projection method --
actual per-component earnings for months with a submitted slip,
recurring (one-time-stripped) component breakdown from the latest
submitted slip projected forward for months without one.

ALLOWED_EARNINGS_FOR_SLIP is imported from tds_advisory.py;
ONE_TIME_COMPONENTS is imported from payroll_constants.py.
"""

import frappe
from frappe.utils import flt, getdate
from frappe.utils.xlsxutils import make_xlsx
from olscpl_hrms.utils.payroll_constants import ONE_TIME_COMPONENTS

MONTH_LABELS = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]

# Canonical display order for the core recurring components. Any
# other component encountered on a slip (CCA, Education Scholarship,
# Leave Encashment, Performance Bonus, etc.) is appended after these,
# in the order first encountered across the FY's slips.
CANONICAL_COMPONENT_ORDER = [
    "Basic",
    "House Rent Allowance",
    "Conveyance",
    "Child Education Allowance",
    "Uniform Allowance",
]


def _get_additional_salary_components(employee, period_start, period_end):
    """
    Components with an Additional Salary record covering this period
    (recurring, or a one-off payroll_date within it). Used instead of
    Salary Detail's additional_salary link field -- see module
    docstring for why that field can't be trusted here.
    """
    rows = frappe.db.sql("""
        SELECT DISTINCT salary_component
        FROM `tabAdditional Salary`
        WHERE employee = %s
          AND docstatus = 1
          AND disabled = 0
          AND (
                (is_recurring = 1 AND from_date <= %s AND to_date >= %s)
                OR (payroll_date BETWEEN %s AND %s)
          )
    """, (employee, period_end, period_start, period_start, period_end), as_dict=True)
    return set(r.salary_component for r in rows)


def _build_advisory(employee, fiscal_year):
    from olscpl_hrms.api.tds_advisory import (
        _resolve_employee, _get_active_ssa, _get_payroll_period, _get_regime_slab, _slab_tax,
        _apply_87a_rebate, _apply_surcharge, CESS_RATE,
        ALLOWED_EARNINGS_FOR_SLIP,
    )

    employee = _resolve_employee(employee)
    if not employee:
        return {"error": "No Employee record found for this user."}

    employee_name = frappe.db.get_value("Employee", employee, "employee_name") or employee

    fiscal_year = int(fiscal_year or getdate().year)

    approx_fy_end = "%s-03-31" % (fiscal_year + 1)
    ssa = _get_active_ssa(employee, approx_fy_end)
    if not ssa:
        return {"error": "No active Salary Structure Assignment found for %s." % employee}
    company = ssa.company

    pp_name, pp_start, pp_end = _get_payroll_period(company, fiscal_year)
    if not pp_name:
        return {"error": "No Payroll Period found for company %s covering %s." % (company, fiscal_year)}

    # ============================================================
    # STEP: PULL SUBMITTED SLIPS FOR THIS FY, MAP TO FY MONTH INDEX
    # (0=Apr ... 11=Mar), by end_date.
    # ============================================================
    slips = frappe.get_all(
        "Salary Slip",
        filters={
            "employee": employee, "docstatus": 1,
            "end_date": [">=", pp_start],
            "start_date": ["<=", pp_end],
        },
        fields=["name", "start_date", "end_date", "payment_days", "total_working_days"],
        order_by="end_date",
    )
    slip_by_month_idx = {}
    slip_attendance_by_month_idx = {}
    for s in slips:
        d = getdate(s.end_date)
        month_idx = (d.month - 4) % 12
        slip_by_month_idx[month_idx] = s.name
        slip_attendance_by_month_idx[month_idx] = {
            "payment_days": flt(s.payment_days),
            "total_working_days": flt(s.total_working_days),
        }

    # ============================================================
    # STEP: PER-COMPONENT ACTUAL EARNINGS FOR PROCESSED MONTHS.
    # The "ZZ Salary Slip Fixed Component" script has already
    # filtered doc.earnings down to only genuine, visible components
    # by the time a slip is submitted -- so for already-submitted
    # slips we trust Salary Detail as-is.
    # ============================================================
    monthly_earnings = {}   # component -> {month_idx: amount}
    seen_components = []    # first-seen order, used for the "other" tail

    for month_idx, slip_name in slip_by_month_idx.items():
        rows = frappe.db.sql(
            """SELECT salary_component, amount
               FROM `tabSalary Detail`
               WHERE parent=%s AND parentfield='earnings'""",
            (slip_name,), as_dict=True,
        )
        for r in rows:
            comp = str(r.salary_component or "").strip()
            if not comp:
                continue
            if comp not in seen_components:
                seen_components.append(comp)
            monthly_earnings.setdefault(comp, {})[month_idx] = flt(r.amount)

    slips_processed = len(slip_by_month_idx)
    months_left = max(12 - slips_processed, 0)
    latest_month_idx = max(slip_by_month_idx.keys()) if slip_by_month_idx else None

    # ============================================================
    # STEP: LOP-AWARE PROJECTION BASELINE (mirrors apply_tds_validation
    # STEP 5h). If the latest processed month had LOP, don't project
    # future months off its reduced gross -- walk backward to the most
    # recent FULL-ATTENDANCE month instead. If none exists this FY,
    # fall back to the latest month's own reduced gross, unscaled.
    # ============================================================
    recurring_source_month_idx = latest_month_idx
    if latest_month_idx is not None:
        latest_att = slip_attendance_by_month_idx.get(latest_month_idx, {})
        latest_payment_days = latest_att.get("payment_days") or 0
        latest_total_working_days = latest_att.get("total_working_days") or 0
        latest_had_lop = (
            latest_total_working_days > 0
            and latest_payment_days > 0
            and latest_payment_days < latest_total_working_days
        )
        if latest_had_lop:
            full_attendance_month_idx = None
            for m_idx in sorted(slip_by_month_idx.keys(), reverse=True):
                att = slip_attendance_by_month_idx.get(m_idx, {})
                p = att.get("payment_days") or 0
                t = att.get("total_working_days") or 0
                if t > 0 and p >= t:
                    full_attendance_month_idx = m_idx
                    break
            if full_attendance_month_idx is not None:
                recurring_source_month_idx = full_attendance_month_idx
            # else: keep latest_month_idx -- no-scaling fallback

    # ============================================================
    # STEP: RECURRING PER-COMPONENT GROSS FOR PROJECTING FUTURE
    # MONTHS -- from the LOP-aware baseline month above, one-time
    # components stripped out.
    # ============================================================
    recurring_by_component = {}
    if recurring_source_month_idx is not None:
        for comp, vals in monthly_earnings.items():
            if recurring_source_month_idx in vals and comp not in ONE_TIME_COMPONENTS:
                recurring_by_component[comp] = vals[recurring_source_month_idx]
    else:
        # No slips submitted yet this FY -- best-effort fallback from
        # the Salary Structure Assignment's base + template earnings.
        recurring_by_component["Basic"] = flt(ssa.base)
        struct_rows = frappe.db.sql(
            """SELECT salary_component, amount FROM `tabSalary Detail`
               WHERE parent=%s AND parentfield='earnings'""",
            (ssa.salary_structure,), as_dict=True,
        )
        for r in struct_rows:
            comp = str(r.salary_component or "").strip()
            if comp in ALLOWED_EARNINGS_FOR_SLIP and comp != "Basic" and comp not in ONE_TIME_COMPONENTS:
                recurring_by_component[comp] = flt(r.amount)
        for comp in recurring_by_component:
            if comp not in seen_components:
                seen_components.append(comp)

    recurring_monthly_gross = sum(recurring_by_component.values())

    # ============================================================
    # STEP: CANONICAL COMPONENT ORDER -- fixed order for the core
    # components, then any others (CCA, Education Scholarship,
    # Leave Encashment, Performance Bonus, etc.) appended in the
    # order first encountered.
    # ============================================================
    component_order = [c for c in CANONICAL_COMPONENT_ORDER if c in seen_components]
    component_order += [c for c in seen_components if c not in component_order]

    # ============================================================
    # STEP: MONTH-WISE TOTAL GROSS -- actual for processed months,
    # recurring projection for the rest.
    # ============================================================
    gross_monthly = {}
    for i in range(12):
        if i in slip_by_month_idx:
            gross_monthly[i] = sum(v.get(i, 0) for v in monthly_earnings.values())
        else:
            gross_monthly[i] = recurring_monthly_gross

    actual_gross_total = sum(gross_monthly[i] for i in slip_by_month_idx.keys())
    annual_gross = actual_gross_total + recurring_monthly_gross * months_left

    # ============================================================
    # STEP: PER-COMPONENT MONTHLY DISPLAY + ANNUAL TOTAL.
    # For months WITH a submitted slip: show the actual value for
    # that component, 0 if it genuinely wasn't on that slip -- never
    # backfilled from a later month's recurring projection.
    # For months WITHOUT a submitted slip (future, unprocessed):
    # project forward using the recurring breakdown from the latest
    # submitted slip.
    # ============================================================
    component_monthly_display = {}
    annual_by_component = {}
    for c in component_order:
        vals = monthly_earnings.get(c, {})
        display = {}
        total = 0
        for i in range(12):
            if i in slip_by_month_idx:
                v = vals.get(i, 0)
            else:
                v = recurring_by_component.get(c, 0)
            display[i] = v
            total += v
        component_monthly_display[c] = display
        annual_by_component[c] = total

    # ============================================================
    # STEP: TDS & PF ACTUALS (unchanged)
    # ============================================================
    tds_by_month = {}
    pf_monthly_known = {}
    for month_idx, slip_name in slip_by_month_idx.items():
        ded_rows = frappe.db.sql(
            """SELECT salary_component, amount FROM `tabSalary Detail`
               WHERE parent=%s AND parentfield='deductions'""",
            (slip_name,), as_dict=True,
        )
        pf_this_month = 0.0
        for r in ded_rows:
            if r.salary_component in ("Provident Fund", "VPF"):
                pf_this_month += flt(r.amount)
            if r.salary_component == "TDS":
                tds_by_month[month_idx] = flt(r.amount)
        pf_monthly_known[month_idx] = pf_this_month

    tds_ytd = sum(tds_by_month.values())

    pf_fill_value = pf_monthly_known.get(latest_month_idx, 0) if latest_month_idx is not None else 0
    pf_annual_projected = sum(pf_monthly_known.get(m, pf_fill_value) for m in range(12))
    pf_monthly_row = {m: pf_monthly_known.get(m, pf_fill_value) for m in range(12)}

    # ============================================================
    # STEP: DECLARATIONS (unchanged)
    # ============================================================
    declaration = frappe.get_all(
        "Employee Tax Exemption Declaration",
        filters={"employee": employee, "payroll_period": pp_name},
        fields=["name", "annual_hra_exemption", "monthly_house_rent", "rented_in_metro_city"],
        limit_page_length=1,
    )
    hra_exemption_declared = 0.0
    hra_exemption = 0.0
    monthly_rent = 0
    is_metro = 0
    declared_by_category = {}
    if declaration:
        hra_exemption_declared = flt(declaration[0].annual_hra_exemption)
        monthly_rent = flt(declaration[0].monthly_house_rent)
        is_metro = declaration[0].rented_in_metro_city or 0
        cat_rows = frappe.db.sql(
            """SELECT exemption_category, amount FROM `tabEmployee Tax Exemption Declaration Category`
               WHERE parent=%s""",
            (declaration[0].name,), as_dict=True,
        )
        for r in cat_rows:
            declared_by_category[r.exemption_category] = declared_by_category.get(r.exemption_category, 0) + flt(r.amount)

    categories = {}
    for c in frappe.get_all("Employee Tax Exemption Category", fields=["name", "max_amount"]):
        categories[c.name] = flt(c.max_amount)

    decl_80c = min(declared_by_category.get("80C", 0) + pf_annual_projected, categories.get("80C", 150000))
    decl_80d = min(declared_by_category.get("80D", 0), categories.get("80D", 50000))
    decl_24b = min(declared_by_category.get("24(b)", 0), categories.get("24(b)", 200000))
    decl_nps = declared_by_category.get("80CCD(1B)", declared_by_category.get("NPS", 0))

    rows = []

    def add_row(label, old_val, new_val, monthly=None):
        row = {"particular": label, "old_regime": old_val, "new_regime": new_val}
        for i, m in enumerate(MONTH_LABELS):
            row[m] = (monthly.get(i) if monthly else None)
        rows.append(row)

    for c in component_order:
        add_row(c.upper(), annual_by_component[c], annual_by_component[c], component_monthly_display[c])

    add_row("GROSS SALARY", annual_gross, annual_gross, gross_monthly)

    add_row("PERQUISITE CAR", 0, 0)
    add_row("OTHER-INCOME", 0, 0)
    add_row("INT-HL U/S24(b)", -decl_24b, 0)

    gross_income_old = annual_gross - decl_24b
    gross_income_new = annual_gross
    add_row("GROSSINCOME", gross_income_old, gross_income_new)

    #24-08-2026 (moved up: must be defined before first use below)
    def _compute_monthly_hra_exemption(basic_amt, hra_amt, rent, metro):
        cap_pct = 0.5 if metro else 0.4
        rent_limit = rent - (basic_amt * 0.10)
        if rent_limit < 0:
            rent_limit = 0
        return min(cap_pct * basic_amt, hra_amt, rent_limit)
    
    hra_exemption = hra_exemption_declared

    if monthly_rent > 0:
        basic_vals = monthly_earnings.get("Basic", {})
        hra_vals = monthly_earnings.get("House Rent Allowance", {})
        proj_basic = recurring_by_component.get("Basic", 0)
        proj_hra = recurring_by_component.get("House Rent Allowance", 0)

        hra_exemption_recomputed = 0
        for i in range(12):
            b = basic_vals.get(i, proj_basic) if i in slip_by_month_idx else proj_basic
            h = hra_vals.get(i, proj_hra) if i in slip_by_month_idx else proj_hra
            hra_exemption_recomputed += _compute_monthly_hra_exemption(b, h, monthly_rent, is_metro)

        hra_exemption = hra_exemption_recomputed

    hra_monthly = {}
    if monthly_rent > 0:
        basic_vals = monthly_earnings.get("Basic", {})
        hra_vals = monthly_earnings.get("House Rent Allowance", {})
        proj_basic = recurring_by_component.get("Basic", 0)
        proj_hra = recurring_by_component.get("House Rent Allowance", 0)
        for i in range(12):
            b = basic_vals.get(i, proj_basic) if i in slip_by_month_idx else proj_basic
            h = hra_vals.get(i, proj_hra) if i in slip_by_month_idx else proj_hra
            hra_monthly[i] = _compute_monthly_hra_exemption(b, h, monthly_rent, is_metro)
    else:
        hra_monthly = {i: (hra_exemption / 12) if hra_exemption else None for i in range(12)}

    add_row("HRA ALL.U/S10(13A)", hra_exemption, 0, hra_monthly)

    old_slab = _get_regime_slab(company, True)
    new_slab = _get_regime_slab(company, False)
    std_ded_old = flt(old_slab.standard_tax_exemption_amount) if old_slab else 50000
    std_ded_new = flt(new_slab.standard_tax_exemption_amount) if new_slab else 75000

    uniform_allowance_annual = annual_by_component.get("Uniform Allowance", 0)
    add_row("UNIFORM All.", uniform_allowance_annual, 0)

    #24-08-2026
    # def _compute_monthly_hra_exemption(basic_amt, hra_amt, rent, metro):
    #     cap_pct = 0.5 if metro else 0.4
    #     rent_limit = rent - (basic_amt * 0.10)
    #     if rent_limit < 0:
    #         rent_limit = 0
    #     return min(cap_pct * basic_amt, hra_amt, rent_limit)

    # hra_exemption = hra_exemption_declared

    # if monthly_rent > 0:
    #     basic_vals = monthly_earnings.get("Basic", {})
    #     hra_vals = monthly_earnings.get("House Rent Allowance", {})
    #     proj_basic = recurring_by_component.get("Basic", 0)
    #     proj_hra = recurring_by_component.get("House Rent Allowance", 0)

    #     hra_exemption_recomputed = 0
    #     for i in range(12):
    #         b = basic_vals.get(i, proj_basic) if i in slip_by_month_idx else proj_basic
    #         h = hra_vals.get(i, proj_hra) if i in slip_by_month_idx else proj_hra
    #         hra_exemption_recomputed += _compute_monthly_hra_exemption(b, h, monthly_rent, is_metro)

    #     hra_exemption = hra_exemption_recomputed

    add_row("STANDARD DED. 17(2)", std_ded_old, std_ded_new)
    add_row("PF", pf_annual_projected, 0, pf_monthly_row)

    add_row("80C AS PER DEC.", declared_by_category.get("80C", 0), 0)
    add_row("TOTAL DED.U/S80(C)", decl_80c, 0)
    add_row("MEDICAL(80D)", decl_80d, 0)
    add_row("NPS", decl_nps, 0)

    total_exemption_old = std_ded_old + hra_exemption + uniform_allowance_annual + decl_80c + decl_80d + decl_nps
    total_exemption_new = std_ded_new
    add_row("TOTAT-EXEMPTION", total_exemption_old, total_exemption_new)

    taxable_old = max(gross_income_old - total_exemption_old, 0)
    taxable_new = max(gross_income_new - total_exemption_new, 0)
    add_row("TAXABLE INCOME", taxable_old, taxable_new)

    tax_old = _slab_tax(taxable_old, old_slab.slabs) if old_slab else 0
    tax_new = _slab_tax(taxable_new, new_slab.slabs) if new_slab else 0

    tax_old_pre_rebate = tax_old
    tax_new_pre_rebate = tax_new
    tax_old = _apply_87a_rebate(tax_old, taxable_old, True)
    tax_new = _apply_87a_rebate(tax_new, taxable_new, False)

    add_row("TAX", tax_old_pre_rebate, tax_new_pre_rebate)
    add_row("U/S87(A)", tax_old_pre_rebate - tax_old, tax_new_pre_rebate - tax_new)

    tax_old_net = tax_old          # after 87A rebate, before surcharge
    tax_new_net = tax_new

    tax_old, surcharge_old = _apply_surcharge(tax_old, taxable_old, True, old_slab.slabs)
    tax_new, surcharge_new = _apply_surcharge(tax_new, taxable_new, False, new_slab.slabs)

    add_row("NET-TAX", tax_old_net, tax_new_net)
    add_row("SER. CHG.", surcharge_old, surcharge_new)

    cess_old = tax_old * CESS_RATE
    cess_new = tax_new * CESS_RATE
    add_row("EDU CESS", cess_old, cess_new)

    total_tax_old = tax_old + cess_old
    total_tax_new = tax_new + cess_new
    add_row("TOTAL_TAX", total_tax_old, total_tax_new)

    add_row("DEDUCTED TDS", tds_ytd, tds_ytd, tds_by_month)
    add_row("BALANCE TDS", total_tax_old - tds_ytd, total_tax_new - tds_ytd)

    return {
        "employee": employee,
        "employee_name": employee_name,
        "company": company,
        "fiscal_year": fiscal_year,
        "payroll_period": pp_name,
        "months": MONTH_LABELS,
        "rows": rows,
        "recommended_regime": "New Regime" if total_tax_new <= total_tax_old else "Old Regime",
        "recurring_monthly_gross": round(recurring_monthly_gross, 2),
        "slips_processed": slips_processed,
        "months_left": months_left,
    }


@frappe.whitelist()
def get_employee_tds_advisory_excel(employee=None, fiscal_year=None):
    return _build_advisory(employee, fiscal_year)


@frappe.whitelist()
def get_employee_tds_advisory_excel_for_hr(employee, fiscal_year=None):
    if not frappe.has_permission("Employee", "read", user=frappe.session.user):
        frappe.throw("Not permitted")
    allowed_roles = {"HR Manager", "HR User", "Payroll Manager", "System Manager"}
    if not (allowed_roles & set(frappe.get_roles())):
        frappe.throw("Only HR/Payroll roles can look up another employee's TDS advisory.")
    return _build_advisory(employee, fiscal_year)


@frappe.whitelist(allow_guest=False)
def download_tds_advisory_excel(employee=None, fiscal_year=None):
    caller = frappe.session.user
    requested_employee = employee
    if requested_employee:
        from olscpl_hrms.api.tds_advisory import _resolve_employee
        own_employee = _resolve_employee(None)
        if requested_employee != own_employee:
            allowed_roles = {"HR Manager", "HR User", "Payroll Manager", "System Manager"}
            if not (allowed_roles & set(frappe.get_roles())):
                frappe.throw("Only HR/Payroll roles can download another employee's TDS advisory.")

    data = _build_advisory(requested_employee, fiscal_year)
    if data.get("error"):
        frappe.throw(data["error"])

    xlsx_data = [["PARTICULAR", "Old Regime", "New Regime"] + data["months"]]
    for row in data["rows"]:
        line = [row["particular"], row.get("old_regime"), row.get("new_regime")]
        for m in data["months"]:
            line.append(row.get(m))
        xlsx_data.append(line)

    xlsx_file = make_xlsx(xlsx_data, "TDS Advisory")

    filename = "TDS_Advisory_%s_%s.xlsx" % (data["employee"], data["fiscal_year"])
    frappe.response["filename"] = filename
    frappe.response["filecontent"] = xlsx_file.getvalue()
    frappe.response["type"] = "binary"