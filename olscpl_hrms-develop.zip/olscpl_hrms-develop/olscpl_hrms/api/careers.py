# olscpl_hrms/api/careers.py
#
# Public, guest-facing read API for the company's external career page
# (a separate site/team, not this HRMS) to pull published job openings
# from. Mirrors exactly what hrms's own public www/jobs/index.py already
# shows anonymous visitors (status=Open, publish=1) - nothing here exposes
# anything that isn't already visible on /jobs today.
#
# Reads are public. Applying has two options: link candidates to each
# job's apply_url (our own hosted /job_application/new), or let the
# external site run its own form and POST it to submit_job_application()
# server-to-server with the shared careers_api_key. See
# docs/careers_api.md for the integration write-up meant for that team.
import io
import os
import secrets

import frappe
import qrcode
from frappe.rate_limiter import rate_limit
from frappe.utils import cstr, get_url, validate_email_address


def _job_payload(jo):
	base_url = get_url()
	salary_range = None
	if jo.get("publish_salary_range") and (jo.get("lower_range") or jo.get("upper_range")):
		salary_range = {
			"currency": jo.get("currency"),
			"lower": jo.get("lower_range"),
			"upper": jo.get("upper_range"),
			"per": jo.get("salary_per"),
		}

	return {
		"id": jo.name,
		"title": jo.job_title,
		"company": jo.company,
		"department": jo.department,
		"location": jo.location,
		"employment_type": jo.employment_type,
		"description": jo.description,
		"posted_on": jo.posted_on,
		"closes_on": jo.closes_on,
		"salary_range": salary_range,
		"applications_received": (
			frappe.db.count("Job Applicant", {"job_title": jo.name})
			if jo.get("publish_applications_received")
			else None
		),
		"detail_url": f"{base_url}/{jo.route}" if jo.get("route") else None,
		"apply_url": f"{base_url}/{jo.get('job_application_route') or 'job_application'}/new?job_title={jo.name}",
	}


@frappe.whitelist(allow_guest=True)
def get_jobs(company: str | None = None):
	"""All published, open job openings - same filter hrms's own /jobs
	listing page uses. Optional ?company= narrows to one entity in the
	group; omit it to get every published opening across all companies."""
	filters = {"status": "Open", "publish": 1}
	# the General Application is for every company - kept in a company's list
	or_filters = {"company": company, "custom_is_general": 1} if company else None

	jobs = frappe.get_all(
		"Job Opening",
		filters=filters,
		or_filters=or_filters,
		fields=[
			"name", "job_title", "company", "department", "location", "employment_type",
			"description", "posted_on", "closes_on", "route", "job_application_route",
			"publish_salary_range", "currency", "lower_range", "upper_range", "salary_per",
			"publish_applications_received",
		],
		order_by="posted_on desc",
	)
	return {"jobs": [_job_payload(jo) for jo in jobs]}


@frappe.whitelist(allow_guest=True)
def get_job(job_opening: str):
	"""Single job by id (the same id returned as "id" from get_jobs), for
	an external page that wants to render its own detail view instead of
	linking to detail_url. Only returns it if still published and open -
	a closed/unpublished opening 404s here exactly like it would on /jobs."""
	jo = frappe.db.get_value(
		"Job Opening",
		{"name": job_opening, "status": "Open", "publish": 1},
		[
			"name", "job_title", "company", "department", "location", "employment_type",
			"description", "posted_on", "closes_on", "route", "job_application_route",
			"publish_salary_range", "currency", "lower_range", "upper_range", "salary_per",
			"publish_applications_received",
		],
		as_dict=True,
	)
	if not jo:
		frappe.throw("Job opening not found or no longer published", frappe.DoesNotExistError)
	return _job_payload(jo)


@frappe.whitelist(allow_guest=True)
def download_qr_code(job_opening: str):
	"""PNG QR code for one job's public page (the exact same link get_job()
	returns as detail_url, and the /jobs listing card itself opens on
	click) - for HR to grab from the Job Opening form and print/share on
	a poster, WhatsApp, social post etc., or for anyone to pull directly
	off the public /jobs listing. A guest only gets it for a published,
	open job - same visibility get_job() already allows; a logged-in
	user with read access to the doctype can also grab it ahead of
	publishing, to prep material before the role goes live."""
	if frappe.session.user == "Guest":
		if not frappe.db.exists("Job Opening", {"name": job_opening, "status": "Open", "publish": 1}):
			frappe.throw("Job opening not found or no longer published", frappe.DoesNotExistError)
		jo = frappe.get_doc("Job Opening", job_opening)
	else:
		jo = frappe.get_doc("Job Opening", job_opening)
		jo.check_permission("read")

	if not jo.route:
		frappe.throw("This job opening has no public page yet - publish it first")

	# ?via=qr: the application form records it came through the QR code
	# (Job Applicant > Application Channel, source Walk In)
	apply_url = get_url("/" + jo.route) + "?via=qr"

	img = qrcode.make(apply_url, box_size=10, border=2)
	buf = io.BytesIO()
	img.save(buf, format="PNG")

	frappe.local.response.filename = f"{frappe.scrub(jo.job_title)}-qr.png"
	frappe.local.response.filecontent = buf.getvalue()
	frappe.local.response.type = "download"


RESUME_EXTENSIONS = {".pdf", ".doc", ".docx"}
RESUME_MAX_BYTES = 5 * 1024 * 1024
APPLICANT_SOURCE = "Company Websites"


# ponytail: one shared IP (their server) sends every applicant, so this caps
# total volume, not per-candidate abuse - their form should rate-limit/captcha
# its own visitors.
@frappe.whitelist(allow_guest=True, methods=["POST"])
@rate_limit(limit=300, seconds=60 * 60)
def submit_job_application(
	job_opening: str,
	applicant_name: str,
	email: str,
	phone: str | None = None,
	cover_letter: str | None = None,
	resume_link: str | None = None,
	country: str | None = None,
):
	"""Server-to-server: the external career site's backend posts its own
	"Apply" form here (multipart/form-data, resume file in the "resume"
	part) and a Job Applicant is created against the opening. Guarded by
	the shared careers_api_key (site config) in the X-Careers-Api-Key
	header - it must never be called straight from a browser, or the key
	would be public and anyone could create applicants."""
	expected_key = frappe.conf.get("careers_api_key")
	given_key = frappe.get_request_header("X-Careers-Api-Key") or ""
	if not expected_key or not secrets.compare_digest(given_key, expected_key):
		frappe.throw("Invalid API key", frappe.AuthenticationError)

	if not frappe.db.exists("Job Opening", {"name": job_opening, "status": "Open", "publish": 1}):
		frappe.throw("Job opening not found or no longer published", frappe.DoesNotExistError)

	applicant_name = cstr(applicant_name).strip()[:140]
	email = cstr(email).strip().lower()
	if not applicant_name:
		frappe.throw("applicant_name is required")
	if not validate_email_address(email):
		frappe.throw("A valid email is required")

	if frappe.db.exists("Job Applicant", {"email_id": email, "job_title": job_opening}):
		frappe.throw("You have already applied for this job", frappe.DuplicateEntryError)

	resume = frappe.request.files.get("resume") if frappe.request.files else None
	resume_content = None
	if resume and resume.filename:
		ext = os.path.splitext(resume.filename)[1].lower()
		if ext not in RESUME_EXTENSIONS:
			frappe.throw("Resume must be a PDF, DOC or DOCX file")
		resume_content = resume.stream.read(RESUME_MAX_BYTES + 1)
		if len(resume_content) > RESUME_MAX_BYTES:
			frappe.throw("Resume must be 5 MB or smaller")
	resume_link = cstr(resume_link).strip()[:500] or None
	if not resume_content and not resume_link:
		frappe.throw("Attach a resume file or provide resume_link")

	applicant = frappe.get_doc({
		"doctype": "Job Applicant",
		"applicant_name": applicant_name,
		"email_id": email,
		"phone_number": cstr(phone).strip()[:30] or None,
		"job_title": job_opening,
		"cover_letter": cstr(cover_letter).strip()[:5000] or None,
		"resume_link": resume_link,
		"country": country if country and frappe.db.exists("Country", country) else None,
		"source": APPLICANT_SOURCE if frappe.db.exists("Job Applicant Source", APPLICANT_SOURCE) else None,
		"status": "Open",
	})
	applicant.insert(ignore_permissions=True)

	if resume_content:
		# Public, like the hosted form's resume (make_resume_attachment_public
		# patch) - recruiters open it from shared views without a login.
		try:
			file_doc = frappe.get_doc({
				"doctype": "File",
				"file_name": resume.filename,
				"content": resume_content,
				"is_private": 0,
				"attached_to_doctype": "Job Applicant",
				"attached_to_name": applicant.name,
				"attached_to_field": "resume_attachment",
			}).insert(ignore_permissions=True)
		except Exception:
			# e.g. a corrupt PDF (File validates PDFs on insert); the request
			# rolls back, so the applicant above isn't kept either
			frappe.throw("Resume file is damaged or unreadable - please upload it again")
		applicant.resume_attachment = file_doc.file_url
		applicant.save(ignore_permissions=True)  # on_update renames it to Resume_<name>

	frappe.db.commit()
	return {"application_id": applicant.name, "status": applicant.status}
