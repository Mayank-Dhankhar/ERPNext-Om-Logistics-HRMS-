# olscpl_hrms/api/work_from_home.py
#
# Mobile-app facing APIs for the "Work From Home Request" DocType. Same
# server-to-server model as api/regularization.py (see that file's
# module-level note) - every function takes a trusted `caller_employee`
# and is gated to the shared Administrator credential.
#
# FIELDS mirror the OMSTAFF Android app's existing WFH submission
# (activity/WfmAct.kt + model/wfm/{Main,Detail}.kt) exactly, since that's
# the payload shape the app already builds and POSTs today - just to a
# separate legacy endpoint (other/work-from-home on
# omapp.omlogistics.co.in) instead of this one:
#   Main.EmpCode        -> employee (here: caller_employee/employee)
#   Main.today_date      -> date
#   Main.rPerson         -> reporting_person
#   Main.lat / lng       -> latitude / longitude
#   Main.locations       -> location
#   Main.FIN_YR          -> financial_year
#   Detail[].DESCRIPTION -> work_details child table rows (Detail is a
#                           list in the app's own model, hence a table
#                           here rather than a single field)
# create_and_submit_work_from_home_request()'s `work_details` argument
# therefore takes the exact same shape as the app's own `Detail` list:
# [{"description": "..."}, ...].
#
# WORKFLOW ("Work From Home Workflow", fixtures/workflow.json) - same
# shape as Attendance Regularization Workflow:
#   States:      Draft(docstatus 0) -> Pending(0) -> Approved(1) / Rejected(0)
#   Transitions: Draft --Submit--> Pending (allowed: Employee)
#                Pending --Approve--> Approved (allowed: Manager + reports_to/HR condition)
#                Pending --Reject--> Rejected (allowed: Manager + reports_to/HR condition)
#   NOTE: only "Approve" actually submits the document (docstatus 0 -> 1),
#   which is what triggers events/work_from_home_request.on_update() to
#   mark the employee's Attendance for that date as "Work From Home".
#   workflow_state is set directly here rather than via apply_workflow(),
#   which checks the Workflow's own role/condition against
#   frappe.session.user - meaningless when every caller is the shared
#   Administrator account (see api/regularization.py's note).
import frappe
from frappe import _
from frappe.utils import getdate

from olscpl_hrms.utils.reporting_person import omstaff_can_approve, omstaff_team_filters

DOCTYPE = "Work From Home Request"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _is_trusted_caller():
	return frappe.session.user == "Administrator"


def _response(success, payload=None, message=""):
	frappe.response["http_status_code"] = 200 if success else 400
	# See api/regularization.py's _response() for why message_log is cleared.
	frappe.local.message_log = []
	return {"success": success, "payload": payload, "message": message}


def _is_hr_manager_employee(employee):
	user = frappe.db.get_value("Employee", employee, "user_id")
	if not user:
		return False
	return "HR Manager" in frappe.get_roles(user)


def _is_direct_manager(employee, caller_employee):
	manager_employee = frappe.db.get_value("Employee", employee, "reports_to")
	return bool(manager_employee) and manager_employee == caller_employee


def _serialize(doc):
	return {
		"name": doc.name,
		"employee": doc.employee,
		"employee_name": doc.employee_name,
		"date": doc.date,
		"reporting_person": doc.reporting_person,
		"latitude": doc.latitude,
		"longitude": doc.longitude,
		"location": doc.location,
		"financial_year": doc.financial_year,
		"work_details": [{"description": r.description} for r in doc.work_details],
		"workflow_state": doc.workflow_state,
		"docstatus": doc.docstatus,
		"creation": doc.creation,
		"modified": doc.modified,
	}


# ---------------------------------------------------------------------------
# 1. CREATE + SUBMIT (single call for the mobile app)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def create_and_submit_work_from_home_request(
	caller_employee,
	date,
	reporting_person,
	work_details,
	latitude=None,
	longitude=None,
	location=None,
	financial_year=None,
	employee=None,
):
	"""
	Creates a Work From Home Request (Draft) and immediately moves it to
	Pending in the employee's reporting person's queue. Called by: the OM
	Staff App backend, server-to-server, using the Administrator
	credential (see module-level note above). `caller_employee` is the
	Employee ID of whoever the app has already authenticated - it is
	trusted completely, which is why access is gated to Administrator only.
	`work_details` is a list of {"description": "..."} dicts (a JSON
	string is also accepted, matching how the app's own Retrofit client
	serializes its Detail list).
	"""
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		if isinstance(work_details, str):
			work_details = frappe.parse_json(work_details)
		if not work_details:
			return _response(False, None, _("Work Details is mandatory"))
		employee = employee or caller_employee
		if not frappe.db.exists("Employee", reporting_person):
			return _response(False, None, _("Unknown reporting_person"))
		if employee == reporting_person:
			return _response(False, None, _("Employee cannot be their own Reporting Person"))
		# Employees may only raise requests for themselves. Managers may
		# raise on behalf of others only if they are HR, or the specific
		# employee's own reports_to manager - see api/regularization.py's
		# create_and_submit_regularization() for the same rule.
		if employee != caller_employee and not (
			_is_hr_manager_employee(caller_employee) or _is_direct_manager(employee, caller_employee)
		):
			return _response(False, None, _("You can only raise a request for yourself, or for your direct reports"))
		existing = frappe.db.exists(
			DOCTYPE,
			{
				"employee": employee,
				"date": getdate(date),
				"workflow_state": ["in", ["Pending", "Approved"]],
			},
		)
		if existing:
			return _response(
				False, None,
				_("A Work From Home request already exists for this employee and date ({0})").format(existing),
			)
		doc = frappe.new_doc(DOCTYPE)
		doc.flags.ignore_permissions = True
		doc.employee = employee
		doc.date = getdate(date)
		doc.reporting_person = reporting_person
		doc.latitude = latitude
		doc.longitude = longitude
		doc.location = location
		doc.financial_year = financial_year
		for row in work_details:
			doc.append("work_details", {"description": row.get("description") if isinstance(row, dict) else row})
		doc.insert()
		doc.workflow_state = "Pending"
		doc.save()
		doc.reload()
		frappe.db.commit()  # noqa: frappe.db.commit is intentional at API boundary
		return _response(True, _serialize(doc), _("Work From Home request submitted successfully"))
	except frappe.ValidationError as e:
		frappe.db.rollback()
		return _response(False, None, str(e))
	except Exception:
		frappe.db.rollback()
		frappe.log_error(frappe.get_traceback(), "Work From Home Request: create_and_submit failed")
		return _response(False, None, _("Something went wrong while submitting your request"))


# ---------------------------------------------------------------------------
# 2. MANAGER ACTION — approve / reject
# ---------------------------------------------------------------------------
@frappe.whitelist()
def action_work_from_home_request(caller_employee, name, action, remarks=None):
	"""
	action: "Approve" or "Reject". Restricted to HR Manager, or the
	specific employee's own reports_to manager. `caller_employee` is
	trusted (see module-level note above) as the Employee ID of whoever
	the app's backend has already authenticated as the acting
	manager/HR user.
	"""
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		if action not in ("Approve", "Reject"):
			return _response(False, None, _("Invalid action. Use 'Approve' or 'Reject'"))
		doc = frappe.get_doc(DOCTYPE, name)
		doc.flags.ignore_permissions = True
		if not omstaff_can_approve(doc, caller_employee):
			return _response(False, None, _("Not permitted to action this request"))
		if doc.workflow_state != "Pending":
			return _response(False, None, _("Request is not pending approval"))
		caller_name = frappe.db.get_value("Employee", caller_employee, "employee_name")
		comment_text = f"{action} by {caller_name} ({caller_employee})"
		if remarks:
			comment_text += f": {remarks}"
		doc.add_comment("Comment", comment_text)
		if action == "Approve":
			doc.workflow_state = "Approved"
			doc.submit()
		else:
			doc.workflow_state = "Rejected"
			doc.save()
		doc.reload()
		frappe.db.commit()  # noqa
		msg = _("Request approved successfully") if action == "Approve" else _("Request rejected")
		return _response(True, _serialize(doc), msg)
	except frappe.DoesNotExistError:
		return _response(False, None, _("Work From Home request not found"))
	except frappe.ValidationError as e:
		frappe.db.rollback()
		return _response(False, None, str(e))
	except Exception:
		frappe.db.rollback()
		frappe.log_error(frappe.get_traceback(), "Work From Home Request: action failed")
		return _response(False, None, _("Something went wrong while processing this action"))


# ---------------------------------------------------------------------------
# 3a. VIEW — employee's own records
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_my_work_from_home_requests(caller_employee, from_date=None, to_date=None, workflow_state=None, limit=50, start=0):
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		filters = {"employee": caller_employee}
		if workflow_state:
			filters["workflow_state"] = workflow_state
		if from_date and to_date:
			filters["date"] = ["between", [getdate(from_date), getdate(to_date)]]
		rows = frappe.get_all(
			DOCTYPE,
			filters=filters,
			fields=[
				"name", "employee", "employee_name", "date", "reporting_person",
				"latitude", "longitude", "location", "financial_year",
				"workflow_state", "docstatus", "creation", "modified",
			],
			order_by="creation desc",
			limit_page_length=int(limit),
			limit_start=int(start),
		)
		return _response(True, rows, _("Records fetched successfully"))
	except Exception:
		frappe.log_error(frappe.get_traceback(), "Work From Home Request: get_my failed")
		return _response(False, None, _("Something went wrong while fetching your records"))


# ---------------------------------------------------------------------------
# 3b. VIEW — manager's queue (pending + actioned by them)
# ---------------------------------------------------------------------------
@frappe.whitelist()
def get_team_work_from_home_requests(
	caller_employee, workflow_state=None, employee=None, from_date=None, to_date=None, limit=50, start=0
):
	"""
	Manager view. `caller_employee` is the trusted (see module-level note
	above) Employee ID of whoever the app has authenticated as the acting
	manager/HR user. HR Manager sees the whole company; anyone else sees
	only their own direct reports (Employee.reports_to).
	"""
	try:
		if not _is_trusted_caller():
			return _response(False, None, _("Not permitted"))
		if not frappe.db.exists("Employee", caller_employee):
			return _response(False, None, _("Unknown caller_employee"))
		filters = omstaff_team_filters(DOCTYPE, caller_employee, employee)
		if workflow_state:
			filters["workflow_state"] = workflow_state
		if from_date and to_date:
			filters["date"] = ["between", [getdate(from_date), getdate(to_date)]]
		rows = frappe.get_all(
			DOCTYPE,
			filters=filters,
			fields=[
				"name", "employee", "employee_name", "date", "reporting_person",
				"latitude", "longitude", "location", "financial_year",
				"workflow_state", "docstatus", "creation", "modified",
			],
			order_by="creation desc",
			limit_page_length=int(limit),
			limit_start=int(start),
		)
		return _response(True, rows, _("Records fetched successfully"))
	except Exception:
		frappe.log_error(frappe.get_traceback(), "Work From Home Request: get_team failed")
		return _response(False, None, _("Something went wrong while fetching team records"))
