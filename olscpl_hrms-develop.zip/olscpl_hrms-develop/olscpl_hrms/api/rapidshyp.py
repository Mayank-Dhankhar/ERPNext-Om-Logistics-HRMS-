# olscpl_hrms/api/rapidshyp.py
#
# RapidShyp (company OPEN SOURCE BUSINESS SOLUTIONS PVT LTD) only:
#   - salary: picking the "OSBS Base-Salary-Based Structure" Salary Structure
#     (patches/v1_1/setup_rapidshyp_salary_structure.py) as a Job Offer's LOI
#     Salary Structure fills its salary tables from HR's "Salary
#     Structure.xlsx" (sheet RapidShyp) - calculate() is that sheet's formulas,
#     cell for cell, with its own rows and labels. "Base Salary" is the sheet's
#     Gross Salary, "PF Applicable" its PF (Yes = 12% of Basic, No, Ceiling).
#     The shared LOI engine (api/loi_salary.py) is not used for it.
#   - letter: a "Letter Of Offer" in RapidShyp's own wording instead of the
#     Letter of Intent (offer_letter_parts(), picked in
#     letter_of_intent.build_letter_of_intent_html)
# Nothing here runs for any other structure or company.
from decimal import ROUND_HALF_UP, Decimal

import frappe
from frappe.utils import flt, fmt_money, format_date
from olscpl_hrms.utils.payroll_constants import (
	OSBS_MIN_BASIC_AMOUNT,
	OSBS_BASIC_RATE,
	OSBS_HRA_RATE,
	OSBS_CONVEYANCE_RATE,
	OSBS_PF_RATE,
)
from olscpl_hrms.utils.payroll_changeable_component_utils import get_component_value

COMPANY = "OPEN SOURCE BUSINESS SOLUTIONS PVT LTD"
STRUCTURE = "OSBS Base-Salary-Based Structure"
BRAND = "RapidShyp"

# (Job Offer tick-box, line) - the Benefits under the salary sheet, as on HR's
# RapidShyp salary sheet; only the ticked ones print, like the other companies'
# notes (patches/v1_1/setup_offer_letter_note_fields.py adds the tick-boxes)
BENEFITS = [
	("custom_rs_benefit_gmc", "GMC – Group Mediclaim: Self + up to 5 dependents, subject to company policy and applicable eligibility, where ESI is not applicable."),
	("custom_rs_benefit_gpa", "GPA – Group Personal Accident: Employee coverage, subject to company policy, where ESI is not applicable."),
	("custom_rs_benefit_gtl", "GTL – Group Term Life: Company's internal policy providing employee coverage; cost is not included in CTC."),
]
# always printed after the Benefits - they explain the sheet's * and ** marks
NOTES = [
	"* PF, ESI, LWF, Professional Tax (PT), Gratuity and other statutory components shall be governed by the applicable laws and rules in force from time to time.",
	"** In-Hand Salary: Subject to Income Tax/TDS and attendance.",
]
DOCUMENTS = [
	"All Educational certificates (photocopies).",
	"Relieving Letter from the last company.",
	"Salary Certificate/ Salary slips/ Bank Statement x last 3 months.",
	"Experience certificate(s) of the last 3 companies.",
	"Passport size photographs x 2 copies",
	"Documents of proof of residence (Permanent &amp; Current)",
	"Pan Card Copy.",
	"Form 16 (Income Tax) from the previous employer.",
	"Adhar Card(Self)",
	"Adhar Card(Parents, Spouse, Kids)",
]


def is_rapidshyp(company):
	return company == COMPANY


def _round(value):
	"""Excel ROUND(x, 0): halves away from zero, not Python's to-even."""
	return float(Decimal(str(value)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def calculate_lwf(custom_state, gross):
	lwf_amount = 0

	lwf_doc_name = frappe.db.get_value(
		"LWF Configuration",
		{"state": custom_state, "is_active": 1},
		"name"
	)

	if lwf_doc_name:
		lwf_doc = frappe.get_doc("LWF Configuration", lwf_doc_name)

		if lwf_doc.employee_type == "Fixed":
			lwf_amount = flt(lwf_doc.employee_amount or 0)

		elif lwf_doc.employee_type == "Percentage":
			percentage = flt(lwf_doc.employee_percentage or 0)
			lwf_amount = _round(gross * (percentage / 100))

			max_cap = flt(lwf_doc.employee_max_cap or 0)
			if max_cap > 0 and lwf_amount > max_cap:
				lwf_amount = max_cap

	return flt(lwf_amount)


def calculate(gross, pf="Ceiling", custom_state="", as_on_date=None):
	"""Salary Structure.xlsx, sheet RapidShyp: H5 = gross (monthly)."""

	g = flt(gross)

	as_on_date = frappe.utils.getdate(
		as_on_date or frappe.utils.today()
	)

	pf_ceiling = flt(
		get_component_value("PF Ceiling Amount", as_on_date) or 15000
	)

	basic = max(g * OSBS_BASIC_RATE, OSBS_MIN_BASIC_AMOUNT)

	if g * OSBS_BASIC_RATE <= OSBS_MIN_BASIC_AMOUNT:
		hra = g - basic if (g - basic) <= g * OSBS_HRA_RATE else g * OSBS_HRA_RATE  # D6
		conveyance = g - basic - hra  # D7
	else:
		hra = g * OSBS_HRA_RATE
		conveyance = g * OSBS_CONVEYANCE_RATE

	if pf == "No":
		employer_pf = 0
	elif pf == "Ceiling":
		employer_pf = _round(min(basic, pf_ceiling) * OSBS_PF_RATE)
	else:
		employer_pf = _round(basic * OSBS_PF_RATE)
	employer_esi = _round(0 if g > 21000 else g * 0.0075)  # D10
	insurance = 2500 if g >= 100000 else 1500 if g >= 50000 else 1000 if g > 35000 else 0  # D11
	gratuity = _round(basic / 26 * 15 / 12)  # D12

	employee_pf = employer_pf  # D14
	employee_esi = _round(0 if g > 21000 else g * 0.0325)  # D15
	lwf = calculate_lwf(custom_state, g)

	earnings = [
		("Basic", basic, _round(basic * 12)),
		("HRA", hra, _round(hra * 12)),
		("Conveyance Allowance", conveyance, _round(conveyance * 12)),
	]
	employer = [
		("Employer PF *", employer_pf, employer_pf * 12),
		("Employer ESI *", employer_esi, employer_esi * 12),
		("Insurance Benefits - GMC / GPA", insurance, insurance * 12),
		("Gratuity*", gratuity, _round(basic * 15 / 26)),  # E12 - not D12 x 12
	]
	deductions = [
		("Employee PF *", employee_pf, employee_pf * 12),
		("Employee ESI *", employee_esi, employee_esi * 12),
		("LWF*", lwf, lwf * 12),
	]
	total_deductions = employee_pf + employee_esi + lwf  # D17
	return frappe._dict(
		earnings=earnings,
		employer=employer,
		deductions=deductions,
		gross=g,
		gross_annum=g * 12,  # E8
		employer_total=sum(r[1] for r in employer),
		employer_total_annum=sum(r[2] for r in employer),
		ctc=_round(g + sum(r[1] for r in employer)),  # D13
		ctc_annum=g * 12 + sum(r[2] for r in employer),  # E13 = SUM(E8:E12)
		total_deductions=total_deductions,
		total_deductions_annum=total_deductions * 12,
		in_hand=g - total_deductions,  # D18
		in_hand_annum=(g - total_deductions) * 12,
	)
def _rows(rows):
	return [{"particulars": p, "per_month": flt(m, 2), "per_annum": flt(a, 2)} for p, m, a in rows]


def _pf(pf_applicable):
	return pf_applicable if pf_applicable in ("No", "Ceiling") else "Basic"



@frappe.whitelist()
def get_salary(gross, pf_applicable=None, custom_state=None, as_on_date=None):
    """For the Job Offer form's live salary calculation."""
    s = calculate(
		gross,
		_pf(pf_applicable),
		custom_state=custom_state,
		as_on_date=as_on_date
	)
    return {
        **s,
        "earnings": _rows(s.earnings),
        "employer": _rows(s.employer),
        "deductions": _rows(s.deductions)
    }


def set_job_offer_salary(doc, method=None):
	"""Job Offer validate: an offer on the RapidShyp structure gets its salary
	tables and totals from the sheet, from Base Salary (its Gross Salary) and
	PF Applicable."""
	if doc.custom_loi_salary_structure != STRUCTURE or not flt(doc.custom_base_salary):
		return
	s = calculate(
		doc.custom_base_salary,
		_pf(doc.custom_pf_applicable),
		custom_state=doc.get("custom_state") or "",
		as_on_date=doc.get("offer_date") or frappe.utils.today()
	)
	doc.set("custom_salary_breakup", _rows(s.earnings))
	doc.set("custom_allowances", [])
	doc.set("custom_other_benefits", _rows(s.employer))
	doc.set("custom_deductions", _rows(s.deductions))
	doc.set("custom_benefits", [])
	doc.update({
		"custom_total_breakupmonth": s.gross, "custom_total_breakupannum": s.gross_annum,
		"custom_total_allowmonth": 0, "custom_total_allowannum": 0,
		"custom_gross_salarymonth": s.gross, "custom_gross_salaryannum": s.gross_annum,
		"custom_total_benefitmonth": s.employer_total, "custom_total_benefitannum": s.employer_total_annum,
		"custom_total_deductmonth": s.total_deductions, "custom_total_deductannum": s.total_deductions_annum,
		"custom_ctcmonth": s.ctc, "custom_ctcannum": s.ctc_annum,
		"custom_net_salarymonth": s.in_hand, "custom_net_salaryannum": s.in_hand_annum,
	})


# ---- letter ----

STYLE = """
	.rs p, .rs li { font-family: Cambria, Georgia, 'Times New Roman', serif; font-size: 13px; line-height: 1.55; }
	.rs .subject { font-family: Arial, Helvetica, sans-serif; text-align: center; font-weight: bold; text-decoration: none; margin: 0 0 22px; font-size: 13px; }
	.rs p { margin: 0 0 12px; text-align: justify; }
	.rs .detail { margin: 0 0 8px; }
	.rs .detail b { font-family: Arial, Helvetica, sans-serif; }
	.rs ol { margin: 6px 0 0 30px; padding: 0; }
	.rs ol li { margin: 0; line-height: 1.45; }
	.rs table.rs-sign { width: 100%; margin-top: 18px; font-family: Arial, Helvetica, sans-serif; font-size: 13px; }
	.rs table.rs-sign td { vertical-align: top; width: 50%; }
	.rs .rs-sig { height: 84px; margin: 8px 0 6px; }
	.rs .rs-sig img { max-height: 80px; max-width: 260px; display: block; }
	/* Frappe's print view stretches every image in a table cell to the cell's
	   full width (templates/styles/standard.css "mozilla hack":
	   .print-format td img { width: 100% !important }) - keep the signature's
	   own shape; this selector outranks that one. */
	.rs table.rs-sign td .rs-sig img { width: auto !important; height: auto; }
	.rs table.rs-ss { width: 100%; border-collapse: collapse; font-family: Arial, Helvetica, sans-serif; font-size: 11px; }
	.rs table.rs-ss td, .rs table.rs-ss th { border: 1px solid #000 !important; padding: 4px 6px !important; }
	.rs table.rs-ss th { font-weight: bold; text-decoration: underline; text-align: left; }
	.rs table.rs-ss .amt { text-align: right; }
	.rs table.rs-ss .group { text-align: center; font-weight: bold; vertical-align: middle; }
	.rs table.rs-ss tr.total td { font-weight: bold; background: #e7e7e7; }
	.rs table.rs-ss .title { text-align: center; font-weight: bold; text-decoration: underline; font-size: 12px; }
	.rs table.rs-benefits { margin-top: 14px; }
	.rs table.rs-ss .notes-title { font-weight: bold; text-decoration: underline; font-size: 10px; }
	.rs .rs-small { font-family: Arial, Helvetica, sans-serif; font-size: 10px; }
"""


def _money(value):
	return f"{flt(value):.2f}"


def _lpa(value):
	return fmt_money(_round(value), precision=0, format="#,##,###")


def _salary_page(job_offer, esc):
	def group(label, rows, letter, total):
		html = ""
		for i, r in enumerate(rows):
			html += "<tr>"
			if i == 0:
				html += f'<td class="group" rowspan="{len(rows)}">{esc(label)}</td>'
			html += (f'<td>{esc(r.particulars)}</td><td class="amt">{_money(r.per_month)}</td>'
				f'<td class="amt">{_money(r.per_annum)}</td></tr>')
		return html + (f'<tr class="total"><td class="group">{letter}</td><td>{total[0]}</td>'
			f'<td class="amt">{_money(total[1])}</td><td class="amt">{_money(total[2])}</td></tr>')

	o = job_offer
	rows = (
		group("Earnings", o.custom_salary_breakup or [], "A",
			("Gross Salary", o.custom_gross_salarymonth, o.custom_gross_salaryannum))
		+ group("Employer Contribution & Benefits (B)", o.custom_other_benefits or [], "A+B",
			("CTC (Fixed)", o.custom_ctcmonth, o.custom_ctcannum))
		+ group("Employee Deductions", o.custom_deductions or [], "D",
			("Total Deductions", o.custom_total_deductmonth, o.custom_total_deductannum))
		+ f'<tr class="total"><td class="group">A-D</td><td>Estimated In Hand Salary**</td>'
		f'<td class="amt">{_money(o.custom_net_salarymonth)}</td><td class="amt">{_money(o.custom_net_salaryannum)}</td></tr>'
	)
	def ticked(title, lines):
		# a tick-box missing (patch not run yet) counts as ticked
		lines = [text for fieldname, text in lines if job_offer.get(fieldname) in (None, 1)]
		return (title + "".join(f'<tr><td colspan="4" class="rs-small">{esc(t)}</td></tr>' for t in lines)) if lines else ""

	benefits = ticked('<tr><td colspan="4" class="title">Benefits</td></tr>', BENEFITS)
	notes = '<tr><td colspan="4" class="rs-small notes-title">Notes:-</td></tr>' + "".join(
		f'<tr><td colspan="4" class="rs-small">{esc(t)}</td></tr>' for t in NOTES)
	return f"""
		<table class="rs-ss">
			<tr><td colspan="4" class="title">SALARY STRUCTURE</td></tr>
			<tr><td></td><th>PARTICULARS</th><th class="amt">PER MONTH</th><th class="amt">PER ANNUM</th></tr>
			{rows}
		</table>
		<table class="rs-ss rs-benefits">
			{benefits}
			{notes}
		</table>
	"""


def _signatory(onboarding_doc):
	user = (onboarding_doc.get("portal_link_sent_by") if onboarding_doc else None) or frappe.session.user
	emp = frappe.db.get_value("Employee", {"user_id": user}, ["employee_name", "designation"], as_dict=True)
	if emp:
		return emp.employee_name, emp.designation
	return frappe.utils.get_fullname(user), None


def offer_letter_parts(onboarding_doc, signature_html, header_html=""):
	"""(page 1, page 2, salary page) of the RapidShyp Letter Of Offer, in the
	same three slots build_letter_of_intent_html() lays the LOI out in."""
	esc = frappe.utils.escape_html
	job_offer = frappe.get_doc("Job Offer", onboarding_doc.job_offer) if onboarding_doc.get("job_offer") else None
	name = onboarding_doc.employee_name or ""
	address = onboarding_doc.get("present_address") or onboarding_doc.get("permanent_address")
	start = format_date(onboarding_doc.date_of_joining, "dd - MMMM - yyyy") if onboarding_doc.date_of_joining else ""
	ctc = _lpa(job_offer.custom_ctcannum) if job_offer and job_offer.custom_ctcannum else ""
	signatory, signatory_role = _signatory(onboarding_doc)

	page1 = f"""
	<style>{STYLE}</style>
	<div class="content rs">
		{header_html}
		<div class="subject">Sub.: Letter Of Offer</div>
		<p>Dear {esc(name)},</p>
		{f'<p>Address: {esc(address)}</p>' if address else ''}
		<p>We believe your passion align well with our mission. As a member of our team, you will play
		an integral role in shaping the future of {BRAND}. Please find below the offer details.</p>
		<p class="detail">Position Details: <b>{esc(onboarding_doc.designation or '')}</b></p>
		<p class="detail">Start Date: <b>{esc(start)}</b></p>
		{f'<p class="detail">CTC: <b>{esc(ctc)} LPA</b></p>' if ctc else ''}
		<p>The Company shall be entitled, at any time during the course of your employment with us, to
		transfer you to any of our branches.</p>
		<p>The management reserves the right to terminate your services at its absolute discretion only
		after giving one month(s) notice or one-month salary in lieu of notice period. Similarly, you
		shall be at liberty to resign from services after giving one months’ notice or deposit one -month
		salary with the company in lieu of the notice period.</p>
		<p style="margin-top:18px">You are requested to carry the below-mentioned documents at the time of joining:</p>
		<ol>{''.join(f'<li>{d}</li>' for d in DOCUMENTS)}</ol>
	</div>
	"""
	page2 = f"""
	<div class="ss-page-break content rs">
		<p>Thank you for considering this opportunity to be part of {BRAND}. We hope you are as
		enthusiastic about your future with us as we are with you!</p>
		<p>Please note this offer is conditional to successful completion of third-party BGV (Background
		Verification) failing which the offer shall stand cancelled.</p>
		<p>The formal letter of appointment containing details of the terms and conditions of the
		employment will be issued to you within a week of your joining with us.</p>
		<table class="rs-sign"><tr>
			<td>
				<b>For {BRAND}</b>
				<div class="rs-sig">{signature_html}</div>
				<b>(Authorized Signatory)</b><br><br>
				<b>{esc(signatory or '')}</b><br>
				{f'<b>{esc(signatory_role)}</b>' if signatory_role else ''}
			</td>
			<td><b>Candidate Signature</b></td>
		</tr></table>
	</div>
	"""
	has_salary = job_offer and job_offer.custom_ctcannum
	page3 = f'<div class="ss-page-break content rs">{_salary_page(job_offer, esc)}</div>' if has_salary else ""
	return page1, page2, page3


# ── emails (no attachments - the offer letter is handed over on joining) ──────
# Signed by the HR user sending them, in utils/email_layout.rapidshyp_email
# (RapidShyp branding) - not branded_email, which carries OM One ATLAS / OM Logistics.
def signoff_html(onboarding_doc=None):
	from frappe.utils import escape_html

	sender, sender_designation = _signatory(onboarding_doc)
	return (f"<p>Thanks &amp; Regards<br><br>{escape_html(sender or '')}"
		+ (f"<br>{escape_html(sender_designation)}" if sender_designation else "") + "</p>")


ONBOARDING_DOCUMENTS = [
	"Aadhaar Card",
	"Aadhaar Card (Father and Mother)",
	"PAN Card",
	"10th Marksheet",
	"12th Marksheet",
	"Graduation Marksheets and Degree Certificate",
	"Post-Graduation Marksheets and Degree Certificate (if applicable)",
	"Offer Letter and Appointment Letter from your previous employer",
	"Payslips and/or Bank Statements",
	"Appraisal Letters (if any)",
	"Form 16 / Form 26AS / Income Tax Statement",
]


def onboarding_email(doc, portal_url):
	"""events/employee_onboarding.generate_portal_link, first send: (subject, html)."""
	from frappe.utils import escape_html, format_date

	documents = "".join(f"<li>{escape_html(d)}</li>" for d in ONBOARDING_DOCUMENTS)
	html = (
		f"<p>Hello {escape_html((doc.employee_name or '').strip())}</p>"
		"<p>Congratulations!</p>"
		f"<p>We are delighted to offer you the position of <b>{escape_html(doc.designation or '')}</b> at {BRAND},"
		f" with your joining date scheduled for <b>{format_date(doc.date_of_joining, 'd MMMM yyyy')}</b>.</p>"
		"<p>Additionally, we request you to complete the joining formalities and upload the following documents"
		" using the link provided below before your joining date.</p>"
		f"<p>Document Upload Link: <a href='{portal_url}' target='_blank'>{portal_url}</a></p>"
		f"<ul>{documents}</ul>"
		f"<p>We look forward to welcoming you to the {BRAND} team.<br>"
		"Please note, your official Offer Letter will be handed over to you on the day of joining.</p>"
		+ signoff_html(doc)
	)
	return f"Onboarding Documentation Required - {BRAND}", html


def offer_email_intro(doc):
	"""events/job_offer.send_offer_letter: the lines above the Accept / Decline buttons."""
	from frappe.utils import escape_html, format_date

	return (
		f"<p>Dear {escape_html((doc.applicant_name or '').strip())},</p>"
		"<p>Congratulations!</p>"
		f"<p>We are delighted to offer you the position of <b>{escape_html(doc.designation or '')}</b> at {BRAND},"
		f" with your joining date scheduled for <b>{format_date(doc.offer_date, 'd MMMM yyyy')}</b>.</p>"
		"<p>Please let us know your decision below. Your official Offer Letter will be handed over to you"
		" on the day of joining.</p>"
	)
