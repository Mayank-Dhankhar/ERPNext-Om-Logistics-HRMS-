# olscpl_hrms/overrides/employee_onboarding.py
#
# Overrides hrms's own "Create Employee" mapper (Employee Onboarding ->
# Employee) via hooks.py's override_whitelisted_methods, rather than
# editing apps/hrms directly. Stock hrms only carries across
# first_name/employee_grade + email/status (see
# hrms/hr/doctype/employee_onboarding/employee_onboarding.py:70-93) -
# everything the candidate filled in on the self-service portal
# (olscpl_hrms's own addition) was being dropped on the floor otherwise.
import frappe
from hrms.hr.doctype.employee_onboarding.employee_onboarding import (
	make_employee as _stock_make_employee,
)

# Employee Onboarding KYC row type -> target Employee field(s).
KYC_FIELD_MAP = {
	"Aadhaar Number": "custom_aadhaar_number",
	"Permanent Account Number (PAN)": "pan_number",
	"ESIC Number": "custom_esic_number",
	"UAN Number": "custom_uan",
}


def _guard_against_duplicate_employee(source_name):
	"""Stock make_employee() only checks docstatus/task-completion
	(validate_employee_creation) - it never checks whether an Employee was
	already created from this onboarding, so clicking Create > Employee
	twice (or twice in quick succession before the first save lands)
	silently produces a second Employee record for the same person. The
	Employee Onboarding doc's own `employee` field is meant to catch this
	(set_employee() populates it from job_applicant on save) but only if
	the doc has been saved/reloaded since - so it's checked here too as a
	fallback, straight off the Employee table."""
	source = frappe.db.get_value(
		"Employee Onboarding", source_name, ["employee", "job_applicant"], as_dict=True
	)
	existing = source.employee or frappe.db.get_value(
		"Employee", {"job_applicant": source.job_applicant}, "name"
	)
	if existing:
		frappe.throw(
			frappe._("An Employee record already exists for this onboarding: {0}").format(
				frappe.utils.get_link_to_form("Employee", existing)
			),
			title=frappe._("Employee Already Created"),
		)


@frappe.whitelist()
def make_employee(source_name, target_doc=None):
	_guard_against_duplicate_employee(source_name)

	doc = _stock_make_employee(source_name, target_doc)
	source = frappe.get_doc("Employee Onboarding", source_name)

	full_name = (source.employee_name or "").split()
	if full_name:
		doc.first_name = full_name[0]
	if len(full_name) > 2:
		doc.middle_name = " ".join(full_name[1:-1])
	if len(full_name) > 1:
		doc.last_name = full_name[-1]

	field_map = {
		"gender": "gender",
		"candidate_dob": "date_of_birth",
		"marital_status": "marital_status",
		"candidate_phone": "cell_number",
		"candidate_email": "personal_email",
		"present_address": "current_address",
		"permanent_address": "permanent_address",
		"father_name": "custom_father_name",
	}
	for source_field, target_field in field_map.items():
		value = source.get(source_field)
		if value:
			doc.set(target_field, value)

	remarks = []
	for row in source.get("kyc_details") or []:
		target_field = KYC_FIELD_MAP.get(row.kyc_type)
		if target_field and row.number:
			doc.set(target_field, row.number)
		elif row.kyc_type == "Bank Account":
			if row.number:
				doc.bank_ac_no = row.number
			if row.remarks:
				remarks.append(f"Bank: {row.remarks}")
	if remarks:
		existing = doc.get("custom_remarks") or ""
		doc.custom_remarks = (existing + " | " if existing else "") + "; ".join(remarks)

	return doc
