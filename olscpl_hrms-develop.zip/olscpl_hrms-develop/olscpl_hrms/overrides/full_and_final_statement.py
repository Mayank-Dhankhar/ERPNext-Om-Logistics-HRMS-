# olscpl_hrms/overrides/full_and_final_statement.py
#
# HRMS core's Full and Final Statement only tracks generic payables/
# receivables tables. The company's legacy "Statement of Full & Final
# Settlement" print format (see fixtures/print_format for
# "Full and Final Settlement (Legacy)") needs a fixed set of
# salary-breakup/deduction columns that core doesn't have - added as
# Custom Fields by patches.v1_1.add_full_and_final_statement_fields.
# This override wires those fields: auto-fills the relation prefix
# (S/o Do/ Wo) from the employee's gender, pulls Gratuity/Leave
# Encashment/Bonus amounts from the core payables table when present,
# and keeps the legacy totals in sync.
import frappe
from frappe.utils import flt, get_first_day, get_last_day, getdate, money_in_words
from olscpl_hrms.utils.payroll_constants import (
	BASE_BASIC_RATE,
	BASE_HRA_RATE,
	is_manual_salary_structure,
)

from hrms.hr.doctype.full_and_final_statement.full_and_final_statement import (
	FullandFinalStatement,
	get_account_and_amount,
)

# Basic/HRA are a fixed split of the Salary Structure Assignment's own base
# (not read off the structure/a payslip at all - see fetch_salary_breakup).
# Salary Component abbreviation -> Rate of Pay fieldname, for every ROP
# component OTHER than Basic/HRA - these come from the employee's active
# recurring Additional Salary records, not the Salary Structure. Components
# with no matching abbr in this company's Salary Component list (Edu.
# Allowance, Tea Allowance) are simply left for manual entry.
OTHER_ROP_ABBR_MAP = {
	"CONV": "custom_rop_conv",
	"UNIFORM": "custom_rop_uniform",
	"MOBILE": "custom_rop_mobile",
	"LAPTOP": "custom_rop_laptop",
	"CCA": "custom_rop_cca",
	"ARREAR": "custom_rop_arrears",
	"OTHERALL": "custom_rop_other",
}

ROP_FIELDS = [
	"custom_rop_basic",
	"custom_rop_hra",
	"custom_advance_bonus",
	"custom_rop_conv",
	"custom_rop_uniform",
	"custom_rop_edu_allow",
	"custom_rop_mobile",
	"custom_rop_laptop",
	"custom_rop_tea_allow",
	"custom_rop_cca",
	"custom_rop_arrears",
	"custom_rop_other",
]

DUES_FIELDS = [
	"custom_dues_basic",
	"custom_dues_hra",
	"custom_dues_conv",
	"custom_dues_uniform",
	"custom_dues_edu_allow",
	"custom_dues_mobile",
	"custom_dues_incentive",
	"custom_dues_advance_bonus",
	"custom_dues_cca_mess_washing",
	"custom_dues_arrear_other",
]

DEDUCTION_FIELDS = [
	"custom_ded_epf",
	"custom_ded_esi",
	"custom_ded_tds",
	"custom_ded_lwf_pf_tax",
	"custom_ded_loan_advance",
	"custom_ded_notice",
	"custom_ded_excess_leave_amount",
	"custom_ded_deduction_from_ac",
	"custom_ded_spl1_drf_cab_food_accm",
	"custom_ded_other",
]

OTHER_DUES_FIELDS = [
	"custom_encashment_last_yr_amount",
	"custom_encashment_current_yr_amount",
	"custom_bonus_exgratia_last_yr",
	"custom_bonus_exgratia_current_yr",
	"custom_gratuity_amount",
	"custom_notice_pay_amount",
	"custom_service_compensation",
	"custom_misc",
]

GENDER_RELATION_MAP = {
	"Male": "S/o",
	"Female": "D/o",
	"Other": "S/o",
}

# Payables component (see hrms full_and_final_statement.get_payable_component)
# -> the legacy field it should pre-fill, only when that field is still empty.
PAYABLE_COMPONENT_AUTOFILL = {
	"Gratuity": "custom_gratuity_amount",
	"Leave Encashment": "custom_encashment_current_yr_amount",
	"Bonus": "custom_bonus_exgratia_current_yr",
}

# Salary Components that count as a one-off settlement "Bonus" payable, for
# get_outstanding_statements()'s Additional Salary lookup below - NOT
# "Advance Bonus" (ADVBON), which is a recurring monthly earning already
# covered by custom_dues_advance_bonus in the Last Month Earnings section,
# not something that belongs on the Payables table as a one-time payout.
BONUS_SALARY_COMPONENTS = ["Bonus", "Performance Bonus"]

# Salary Component abbreviation(s) -> last-month Dues fieldname, for
# fetch_last_month_details(). A list sums multiple components into one
# legacy field (the paper form groups some components together). Edu.
# Allowance has no reliable abbr in this company's Salary Component list
# (same gap as SALARY_COMPONENT_ABBR_MAP above) - stays manual.
LAST_MONTH_DUES_ABBR_MAP = {
	"custom_dues_basic": ["BASIC"],
	"custom_dues_hra": ["HRA"],
	"custom_dues_conv": ["CONV"],
	"custom_dues_uniform": ["UNIFORM"],
	"custom_dues_mobile": ["MOBILE"],
	"custom_dues_incentive": ["INCENT"],
	"custom_dues_advance_bonus": ["ADVBON"],
	"custom_dues_cca_mess_washing": ["CCA", "WASH"],
	"custom_dues_arrear_other": ["ARREAR", "OTHERALL"],
}

# Salary Component abbreviation -> last-month Deductions fieldname. Only
# the three with an unambiguous, always-present statutory component are
# automated; LWF/P.F. Tax, Notice, Deduction from A/C,
# SPL1/DRF/CAB/FOOD/ACCM and Other stay manual - one-off HR calls with no
# single clean source.
LAST_MONTH_DEDUCTION_ABBR_MAP = {
	"custom_ded_epf": ["PF"],
	"custom_ded_esi": ["ESI"],
	"custom_ded_tds": ["TDS"],
}


class CustomFullandFinalStatement(FullandFinalStatement):
	def validate(self):
		super().validate()
		self.set_default_letter_head()
		self.set_relation_prefix()
		self.autofill_from_payables()
		self.compute_legacy_totals()

	def set_default_letter_head(self):
		# Same intent as erpnext.controllers.accounts_controller
		# .set_default_letter_head() - this doctype doesn't extend that
		# class, so it doesn't get it for free - but that pattern's own
		# "only if not already set" guard doesn't actually work here:
		# frappe.model.create_new.get_new_doc() pre-fills ANY field named
		# "letter_head" from whichever Letter Head has is_default=1
		# (frappe.defaults, a sitewide default keyed purely by fieldname)
		# before this validate() ever runs - so self.letter_head is
		# already non-empty on a brand new doc, just wrong. Force the
		# company's own letterhead on insert; respect a manual change on
		# later saves.
		if not self.company:
			return
		company_letter_head = frappe.db.get_value("Company", self.company, "default_letter_head")
		if company_letter_head and (self.is_new() or not self.get("letter_head")):
			self.letter_head = company_letter_head

	def set_relation_prefix(self):
		if self.custom_relation_prefix or not self.employee:
			return
		gender = frappe.db.get_value("Employee", self.employee, "gender")
		self.custom_relation_prefix = GENDER_RELATION_MAP.get(gender, "S/o")

	def autofill_from_payables(self):
		for row in self.payables:
			fieldname = PAYABLE_COMPONENT_AUTOFILL.get(row.component)
			if fieldname and not flt(self.get(fieldname)):
				self.set(fieldname, row.amount)

	def compute_legacy_totals(self):
		precision = self.precision("total_payable_amount")

		self.custom_rop_total = flt(sum(flt(self.get(f)) for f in ROP_FIELDS), precision)
		self.custom_dues_total = flt(sum(flt(self.get(f)) for f in DUES_FIELDS), precision)
		self.custom_ded_total = flt(sum(flt(self.get(f)) for f in DEDUCTION_FIELDS), precision)
		self.custom_other_dues_total = flt(sum(flt(self.get(f)) for f in OTHER_DUES_FIELDS), precision)

		self.custom_total_dues = flt(self.custom_dues_total + self.custom_other_dues_total, precision)
		self.custom_total_deductions = flt(self.custom_ded_total, precision)
		self.custom_grand_total = self.custom_total_dues
		self.custom_amount_payable_recoverable = flt(
			self.custom_total_dues - self.custom_total_deductions, precision
		)

		currency = frappe.get_cached_value("Company", self.company, "default_currency") if self.company else None
		self.custom_amount_in_words = money_in_words(self.custom_amount_payable_recoverable, currency)

	@frappe.whitelist()
	def get_outstanding_statements(self):
		"""Core (hrms.full_and_final_statement.create_component_row) only
		ever adds a blank placeholder row per payable/receivable component
		type - Gratuity, Expense Claim, Bonus, Leave Encashment, Employee
		Advance - it never checks whether the employee actually HAS one of
		those, so every row's mandatory Reference Document is left for HR
		to fill in by hand, blocking Save even for components that don't
		apply to this employee at all.

		Runs automatically on Employee select (core's own JS trigger calls
		this same whitelisted method, unchanged) - replace each placeholder
		with the real outstanding document(s) if any exist for this
		employee (one fully-filled row per document - reference, account,
		amount), or drop the row entirely if none do, so an irrelevant
		component never blocks Save."""
		super().get_outstanding_statements()

		self._replace_placeholder_rows(
			"payables", "Gratuity", "Gratuity", self._find_gratuities()
		)
		self._replace_placeholder_rows(
			"payables", "Expense Claim", "Expense Claim", self._find_expense_claims()
		)
		self._replace_placeholder_rows(
			"payables", "Bonus", "Additional Salary", self._find_bonus_additional_salaries(),
			resolver=self._bonus_account_and_amount,
		)
		self._replace_placeholder_rows(
			"payables", "Leave Encashment", "Leave Encashment", self._find_leave_encashments()
		)
		self._replace_placeholder_rows(
			"receivables", "Employee Advance", "Employee Advance", self._find_employee_advances()
		)

	def _replace_placeholder_rows(self, table_field, component, ref_doctype, matches, resolver=None):
		kept = [row for row in self.get(table_field) if row.component != component]
		self.set(table_field, kept)

		resolver = resolver or (
			lambda name: get_account_and_amount(ref_doctype, name, self.company) or (None, None)
		)
		for name in matches:
			account, amount = resolver(name)
			self.append(
				table_field,
				{
					"status": "Unsettled",
					"component": component,
					"reference_document_type": ref_doctype,
					"reference_document": name,
					"account": account,
					"amount": amount,
				},
			)

	def _find_gratuities(self):
		return frappe.get_all(
			"Gratuity",
			filters={"employee": self.employee, "docstatus": 1, "status": ["in", ["Unpaid", "Submitted"]]},
			pluck="name",
		)

	def _find_expense_claims(self):
		return frappe.get_all(
			"Expense Claim",
			filters={"employee": self.employee, "docstatus": 1, "status": ["in", ["Unpaid", "Submitted"]]},
			pluck="name",
		)

	def _find_leave_encashments(self):
		return frappe.get_all(
			"Leave Encashment",
			filters={"employee": self.employee, "docstatus": 1, "status": ["in", ["Unpaid", "Submitted"]]},
			pluck="name",
		)

	def _find_employee_advances(self):
		rows = frappe.get_all(
			"Employee Advance",
			filters={
				"employee": self.employee,
				"docstatus": 1,
				"status": ["in", ["Paid", "Partly Claimed and Returned"]],
			},
			fields=["name", "paid_amount", "claimed_amount", "return_amount"],
		)
		return [r.name for r in rows if flt(r.paid_amount) - flt(r.claimed_amount) - flt(r.return_amount) > 0]

	def _find_bonus_additional_salaries(self):
		return frappe.get_all(
			"Additional Salary",
			filters={
				"employee": self.employee,
				"docstatus": 1,
				"disabled": 0,
				"salary_component": ["in", BONUS_SALARY_COMPONENTS],
			},
			pluck="name",
		)

	def _bonus_account_and_amount(self, name):
		# get_account_and_amount() (hrms core) has no "Additional Salary"
		# branch - Bonus is the only FnF payables component core maps to
		# that doctype, and it's never actually wired up, even for manual
		# selection through the UI. Resolve it ourselves: amount is the
		# Additional Salary's own `amount`, account comes from its Salary
		# Component's own per-company account row (Salary Component
		# doesn't have a single fixed account - accounts are configured
		# per company).
		additional_salary = frappe.db.get_value(
			"Additional Salary", name, ["amount", "salary_component"], as_dict=True
		)
		account = frappe.db.get_value(
			"Salary Component Account",
			{"parent": additional_salary.salary_component, "company": self.company},
			"account",
		)
		return account, additional_salary.amount

	@frappe.whitelist()
	def fetch_salary_breakup(self):
		"""Fill the Rate of Pay section. Called from the "Fetch Salary
		Breakup" button - does not run automatically so it never silently
		overwrites a manually-corrected value.

		Two entirely different sourcing paths depending on structure type:

		BASE STRUCTURE: Basic/HRA/Advance Bonus come from the relieving
		month Salary Slip's minimum-wage entitlement fields
		(custom_mw_basic_entitlement etc.) when that override was active,
		else fall back to a flat 60%/40% split of the SSA's `base`. Every
		other component (Conveyance, Uniform, Mobile, Laptop, CCA,
		Arrears, Other) comes from the employee's active recurring
		Additional Salary records.

		MANUAL STRUCTURE: every component amount was typed in directly on
		the SSA's own Manual Salary Component rows at assignment time -
		THAT is the primary source for Basic/HRA and every other
		component alike (no 60/40 split, no minimum-wage concept - MW
		never applies to Manual, matching apply_pf_epf_eps_split's own
		is_base_structure-only gate). Additional Salary is only consulted
		as a fallback, for any component NOT present among that
		employee's Manual Salary Component rows at all.
		"""
		if not self.employee:
			frappe.throw(frappe._("Set Employee first"))
		if not self.relieving_date:
			frappe.throw(frappe._("Set Relieving Date first"))

		relieving_date = getdate(self.relieving_date)

		assignment = frappe.db.get_value(
			"Salary Structure Assignment",
			{"employee": self.employee, "docstatus": 1},
			["name", "salary_structure", "base"],
			order_by="from_date desc",
			as_dict=True,
		)
		if not assignment:
			frappe.throw(frappe._("No submitted Salary Structure Assignment found for {0}").format(self.employee))

		assignment_name = assignment.name
		base = flt(assignment.base)
		precision = self.precision("custom_rop_basic")
		is_manual_structure = is_manual_salary_structure(assignment.salary_structure)

		defined_components = set()   # NEW: components already sourced from Manual Salary Component,
		                              # so the Additional Salary fallback below skips them

		if is_manual_structure:
			# NEW: primary source for Manual structure -- the SSA's own
			# Manual Salary Component rows, exactly as typed in at
			# assignment time. No 60/40 split, no MW entitlement lookup.
			manual_rows = frappe.db.sql("""
				SELECT salary_component, amount, abbr
				FROM `tabManual Salary Component`
				WHERE parent = %s
				  AND parenttype = 'Salary Structure Assignment'
				  AND component_type = 'Earning'
			""", assignment_name, as_dict=True)

			for mrow in manual_rows:
				comp = (mrow.salary_component or "").strip()
				if not comp:
					continue
				defined_components.add(comp)

				if comp == "Basic":
					self.custom_rop_basic = flt(mrow.amount, precision)
				elif comp == "House Rent Allowance":
					self.custom_rop_hra = flt(mrow.amount, precision)
				elif comp == "Advance Bonus":
					self.custom_rop_advance_bonus = flt(mrow.amount, precision)
				else:
					abbr = mrow.abbr or frappe.db.get_value(
						"Salary Component", comp, "salary_component_abbr"
					)
					fieldname = OTHER_ROP_ABBR_MAP.get(abbr)
					if fieldname:
						self.set(fieldname, flt(mrow.amount, precision))

		else:
			# Base structure -- unchanged: MW entitlement override, else
			# flat 60/40 split.
			slip, is_temporary = self._get_or_build_relieving_month_salary_slip(relieving_date)
			try:
				mw_basic = flt(slip.get("custom_mw_basic_entitlement"))
				mw_hra = flt(slip.get("custom_mw_hra_entitlement"))
				mw_advance_bonus = flt(slip.get("custom_mw_advance_bonus_entitlement"))
			finally:
				if is_temporary:
					frappe.delete_doc("Salary Slip", slip.name, force=True, ignore_permissions=True)

			if mw_basic > 0:
				self.custom_rop_basic = flt(mw_basic, precision)
				self.custom_rop_hra = flt(mw_hra, precision)
			else:
				self.custom_rop_basic = flt(base * BASE_BASIC_RATE, precision)
				self.custom_rop_hra = flt(base * BASE_HRA_RATE, precision)

			if mw_advance_bonus > 0:
				self.custom_rop_advance_bonus = flt(mw_advance_bonus, precision)

		# Additional Salary -- fallback (Base structure: always consulted
		# for "other" components, as before. Manual structure: only for
		# components NOT already found in Manual Salary Component above.)
		additional_salaries = frappe.get_all(
			"Additional Salary",
			filters={
				"employee": self.employee,
				"docstatus": 1,
				"disabled": 0,
				"is_recurring": 1,
				"type": "Earning",
				"from_date": ["<=", relieving_date],
			},
			fields=["salary_component", "amount", "to_date"],
		)
		amounts_by_abbr = {}
		for row in additional_salaries:
			if row.to_date and getdate(row.to_date) < relieving_date:
				continue
			if is_manual_structure and row.salary_component in defined_components:
				continue   # NEW: already sourced from Manual Salary Component -- don't overwrite
			abbr = frappe.db.get_value("Salary Component", row.salary_component, "salary_component_abbr")
			if abbr:
				amounts_by_abbr[abbr] = amounts_by_abbr.get(abbr, 0) + flt(row.amount)

		for abbr, fieldname in OTHER_ROP_ABBR_MAP.items():
			if abbr in amounts_by_abbr:
				self.set(fieldname, amounts_by_abbr[abbr])

		self.compute_legacy_totals()
		self.save()
		return {
			"salary_structure_assignment": assignment_name,
			"base": base,
			"is_manual_structure": is_manual_structure,
			"minimum_wage_applied": (not is_manual_structure) and locals().get("mw_basic", 0) > 0,
		}

	@frappe.whitelist()
	def fetch_last_month_details(self):
		"""Auto-fill Days Worked, the last-month Dues fields that map to a
		real Salary Component, EPF/ESI/TDS under Deductions, Loan/Advance,
		and Excess Leave (Days + Amount) - the whole "Salary/Wages Payable
		for Last Month" + part of the Deductions section that used to be
		100% manual entry. Called from the "Fetch Last Month Details"
		button, so a manual correction afterwards is never silently
		clobbered.

		Source of truth for days worked / prorated amounts, in order:
		1. The employee's own submitted Salary Slip covering the relieving
		   date, if HR already ran payroll for their final month - real
		   numbers, nothing recomputed.
		2. Otherwise, a Salary Slip is created (never submitted, deleted
		   immediately after reading it) for month-start..relieving-date so
		   HRMS's own payroll engine computes payment days and prorated
		   earnings/deductions from actual Attendance - far more reliable
		   than reimplementing that logic here by hand.
		"""
		if not self.employee:
			frappe.throw(frappe._("Set Employee first"))
		if not self.relieving_date:
			frappe.throw(frappe._("Set Relieving Date first"))

		relieving_date = getdate(self.relieving_date)
		slip, is_temporary = self._get_or_build_relieving_month_salary_slip(relieving_date)
		try:
			self._apply_salary_slip_to_last_month_fields(slip)
		finally:
			if is_temporary:
				frappe.delete_doc("Salary Slip", slip.name, force=True, ignore_permissions=True)

		self.fetch_loan_advance_deduction()
		self.fetch_excess_leave_deduction(relieving_date)

		self.compute_legacy_totals()
		self.save()
		return {"salary_slip": slip.name if not is_temporary else None}

	def _get_or_build_relieving_month_salary_slip(self, relieving_date):
		existing = frappe.db.get_value(
			"Salary Slip",
			{
				"employee": self.employee,
				"docstatus": 1,
				"start_date": ("<=", relieving_date),
				"end_date": (">=", relieving_date),
			},
			"name",
		)
		if existing:
			return frappe.get_doc("Salary Slip", existing), False

		slip = frappe.new_doc("Salary Slip")
		slip.employee = self.employee
		slip.posting_date = relieving_date
		slip.start_date = get_first_day(relieving_date)
		slip.end_date = relieving_date
		slip.insert(ignore_permissions=True)
		return slip, True

	def _apply_salary_slip_to_last_month_fields(self, slip):
		"""Days Worked, plus TWO representations of the same slip data:
		custom_last_month_earnings/deductions are a 1:1 copy of every row on
		the slip exactly as computed there (what "fetch same data as it is"
		means - nothing summarised or dropped); the legacy custom_dues_*/
		custom_ded_* fields are additionally kept in sync from that same
		data, purely so the existing "Full and Final Settlement (Legacy)"
		print format (fixed named columns, matching the paper form) keeps
		working without its own redesign.
		"""
		self.custom_dues_days_worked = slip.payment_days
		self.set("custom_last_month_earnings", [])
		self.set("custom_last_month_deductions", [])

		earnings_by_abbr = {}
		for row in slip.earnings:
			self.append("custom_last_month_earnings", {"component": row.salary_component, "amount": row.amount})
			abbr = frappe.db.get_value("Salary Component", row.salary_component, "salary_component_abbr")
			if abbr:
				earnings_by_abbr[abbr] = earnings_by_abbr.get(abbr, 0) + flt(row.amount)

		for fieldname, abbrs in LAST_MONTH_DUES_ABBR_MAP.items():
			total = sum(earnings_by_abbr.get(abbr, 0) for abbr in abbrs)
			if any(abbr in earnings_by_abbr for abbr in abbrs):
				self.set(fieldname, total)

		deductions_by_abbr = {}
		for row in slip.deductions:
			self.append("custom_last_month_deductions", {"component": row.salary_component, "amount": row.amount})
			abbr = frappe.db.get_value("Salary Component", row.salary_component, "salary_component_abbr")
			if abbr:
				deductions_by_abbr[abbr] = deductions_by_abbr.get(abbr, 0) + flt(row.amount)

		for fieldname, abbrs in LAST_MONTH_DEDUCTION_ABBR_MAP.items():
			total = sum(deductions_by_abbr.get(abbr, 0) for abbr in abbrs)
			if any(abbr in deductions_by_abbr for abbr in abbrs):
				self.set(fieldname, total)

	def fetch_loan_advance_deduction(self):
		# The core Receivables row for "Employee Advance"/"Loan" is only a
		# placeholder (see hrms.full_and_final_statement.create_component_row)
		# - its amount/reference_document stay blank until someone picks the
		# specific document in the row's own edit dialog. Query the
		# employee's outstanding advances directly instead of relying on
		# that row ever being filled in.
		total = 0.0
		for advance in frappe.get_all(
			"Employee Advance",
			filters={"employee": self.employee, "docstatus": 1},
			fields=["name", "advance_account", "paid_amount", "claimed_amount", "return_amount"],
		):
			outstanding = flt(advance.paid_amount) - flt(advance.claimed_amount) - flt(advance.return_amount)
			if outstanding <= 0:
				continue
			total += outstanding
			# Populate the matching placeholder row too, same shape
			# get_account_and_amount() would produce via the manual UI flow -
			# so the core Receivables table isn't left blank either.
			for row in self.receivables:
				if row.component == "Employee Advance" and not row.reference_document:
					row.reference_document = advance.name
					row.account = advance.advance_account
					row.amount = outstanding
					break

		if total:
			self.custom_ded_loan_advance = total

	def fetch_excess_leave_deduction(self, relieving_date):
		from hrms.hr.doctype.leave_application.leave_application import get_leave_balance_on

		leave_types = frappe.get_all(
			"Leave Allocation",
			filters={"employee": self.employee, "docstatus": 1},
			pluck="leave_type",
			distinct=True,
		)

		excess_days = 0.0
		days_in_month = (get_last_day(relieving_date) - get_first_day(relieving_date)).days + 1
		for leave_type in set(leave_types):
			balance = flt(get_leave_balance_on(self.employee, leave_type, relieving_date))
			if balance < 0:
				excess_days += -balance

		if excess_days:
			self.custom_ded_excess_leave_days = excess_days
			per_day_rate = flt(self.custom_rop_total) / days_in_month if days_in_month else 0
			self.custom_ded_excess_leave_amount = flt(excess_days * per_day_rate, self.precision("custom_ded_excess_leave_amount"))
