# Leave Application: let the request's Reporting Person
# approve or reject it.
#
# `status` is a permlevel-1 field (HR User/HR Manager/Leave Approver only).
# For a plain-Employee approver Frappe silently reset it to "Open" on save,
# and the workflow then submitted the leave as the first submitted state -
# "Approved" - so Reject turned into Approve. Grant level 1 to exactly this
# document's approvers (get_permlevel_access).
#
# Approving or rejecting re-runs validate_balance_leaves, whose
# get_leave_balance_on -> validate_leave_access only lets through the
# employee, the approver on the *Employee record*, or someone who can read
# that Employee - so the Reporting Person (utils/reporting_person.py)
# got "Not permitted". We vouch for exactly that employee, for this one
# document's validation, and leave HRMS's check alone everywhere else.
import frappe
from hrms.hr.doctype.leave_application import leave_application as hrms_leave
from hrms.hr.doctype.leave_application.leave_application import LeaveApplication

from olscpl_hrms.utils.reporting_person import approver_users

_hrms_validate_leave_access = hrms_leave.validate_leave_access


def _validate_leave_access(employee):
	if frappe.flags.leave_access_for == employee:
		return
	_hrms_validate_leave_access(employee)


hrms_leave.validate_leave_access = _validate_leave_access


class CustomLeaveApplication(LeaveApplication):
	def validate_balance_leaves(self):
		if frappe.session.user not in approver_users(self):
			return super().validate_balance_leaves()
		frappe.flags.leave_access_for = self.employee
		try:
			super().validate_balance_leaves()
		finally:
			frappe.flags.leave_access_for = None

	def get_permlevel_access(self, permission_type="write"):
		levels = super().get_permlevel_access(permission_type)
		if 1 not in levels and frappe.session.user in approver_users(self):
			levels.append(1)
		return levels

	def create_or_update_attendance(self, attendance_name, date):
		"""Approving a Leave Application that overlaps a date already marked
		(e.g. Absent, by the daily attendance sync) updates that EXISTING
		Attendance record - core's create_or_update_attendance() only puts
		ignore_permissions=True on the "make a new one" branch just below it,
		not this one. The Reporting Person approving has no general
		permission on someone else's Attendance (this app's whole model is
		per-document DocShare, not role-based), so the update throws right
		there: "User X does not have access to this document: Attendance -
		Y". Same fix shape as validate_balance_leaves above - vouch for this
		one write, don't touch the permission system itself."""
		if not attendance_name:
			return super().create_or_update_attendance(attendance_name, date)
		doc = frappe.get_doc("Attendance", attendance_name)
		doc.flags.ignore_permissions = True
		status = "Half Day" if self.half_day_date and frappe.utils.getdate(date) == frappe.utils.getdate(self.half_day_date) else "On Leave"
		half_day_status = None if status == "On Leave" else "Present"
		modify_half_day_status = 1 if doc.status == "Absent" and status == "Half Day" else 0
		doc.db_set(
			{
				"status": status,
				"leave_type": self.leave_type,
				"leave_application": self.name,
				"half_day_status": half_day_status,
				"modify_half_day_status": modify_half_day_status,
			}
		)
