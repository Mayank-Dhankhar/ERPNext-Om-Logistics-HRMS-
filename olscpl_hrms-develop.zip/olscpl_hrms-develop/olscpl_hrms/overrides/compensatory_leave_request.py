# Overrides HRMS core CompensatoryLeaveRequest.validate() solely to make
# validate_attendance() (the "you must have actually worked - been marked
# Present/WFH/Half Day - on every day you're claiming as worked" check)
# skippable via custom_skip_attendance_validation, a System-Manager-only
# field (see patches/v1_1/add_compensatory_leave_bulk_upload_field.py -
# permlevel 1, no other role can even see it, let alone set it) - for bulk-
# importing old/historical compensatory leave records where no Attendance
# was ever recorded for those dates (or wasn't tracked in this system at
# the time) but the leave genuinely needs to exist. Every other check
# (active employee, dates, half day, overlap, is-it-actually-a-holiday,
# leave type required) is untouched - just re-calls the same inherited
# methods HRMS core already defines.
#
# Registered via hooks.py -> override_doctype_class

from frappe import _
from hrms.hr.doctype.compensatory_leave_request.compensatory_leave_request import (
	CompensatoryLeaveRequest as HRMSCompensatoryLeaveRequest,
)
from hrms.hr.utils import validate_active_employee, validate_dates, validate_overlap
from frappe.utils import date_diff, format_date, getdate
import frappe


class CustomCompensatoryLeaveRequest(HRMSCompensatoryLeaveRequest):
	def validate(self):
		validate_active_employee(self.employee)
		validate_dates(self, self.work_from_date, self.work_end_date)
		if self.half_day:
			if not self.half_day_date:
				frappe.throw(_("Half Day Date is mandatory"))
			if not getdate(self.work_from_date) <= getdate(self.half_day_date) <= getdate(self.work_end_date):
				frappe.throw(_("Half Day Date should be in between Work From Date and Work End Date"))
		validate_overlap(self, self.work_from_date, self.work_end_date)
		self.validate_holidays()
		if not self.custom_skip_attendance_validation:
			self.validate_attendance()
		if not self.leave_type:
			frappe.throw(_("Leave Type is mandatory"))

	def validate_attendance(self):
		# Same check as HRMS core, but a Visit (custom status) on the holiday
		# also counts as worked; a First/Second Half Visit counts as Half Day.
		records = frappe.get_all(
			"Attendance",
			filters={
				"attendance_date": ["between", (self.work_from_date, self.work_end_date)],
				"status": ("in", ["Present", "Work From Home", "Half Day", "Visit"]),
				"docstatus": 1,
				"employee": self.employee,
			},
			fields=["attendance_date", "status", "custom_visit_day_portion"],
		)

		half_days = [
			r.attendance_date for r in records
			if r.status == "Half Day"
			or (r.status == "Visit" and r.custom_visit_day_portion in ("First Half", "Second Half"))
		]
		if half_days and (not self.half_day or getdate(self.half_day_date) not in half_days):
			frappe.throw(
				_("You were only present for Half Day on {}. Cannot apply for a full day compensatory leave").format(
					", ".join(frappe.bold(format_date(d)) for d in half_days)
				)
			)

		if len(records) < date_diff(self.work_end_date, self.work_from_date) + 1:
			frappe.throw(_("You are not present all day(s) between compensatory leave request days"))
