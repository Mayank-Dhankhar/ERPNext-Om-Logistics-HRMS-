# olscpl_hrms/overrides/notification.py
#
# Notification (Settings > Notification) with "Use company email template"
# ticked: the message goes out inside the company's Email Branding
# (utils/email_layout.render_branded). The company is the one chosen on the
# Notification, else the document's own Company (or the Job Applicant's), else
# the Default branding. Unticked: unchanged.
import frappe
from frappe.email.doctype.notification.notification import Notification
from frappe.utils import escape_html, md_to_html


class CustomNotification(Notification):
	def send_an_email(self, doc, context):
		if not self.get("custom_use_company_template"):
			return super().send_an_email(doc, context)

		from olscpl_hrms.utils.email_layout import get_branding, render_branded

		body = frappe.render_template(self.message, context)
		if self.message_type == "Markdown":
			body = md_to_html(body)
		elif self.message_type == "Plain Text":
			body = escape_html(body).replace("\n", "<br>")
		label = self.get("custom_template_label") or frappe.render_template(self.subject or "", context)
		# the Company chosen on the Notification, else the document's own
		company = self.get("custom_template_company") or doc.get("company") or doc.get("custom_company")
		wrapped = render_branded(get_branding(company), label, body, signoff=bool(self.get("custom_template_signoff")))

		# the stock sender renders self.message again - hand it the finished HTML, then restore
		original = self.message
		self.message = "{% raw %}" + wrapped + "{% endraw %}"
		try:
			return super().send_an_email(doc, context)
		finally:
			self.message = original
