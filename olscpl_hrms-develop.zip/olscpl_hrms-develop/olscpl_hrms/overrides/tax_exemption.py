# olscpl_hrms/overrides/tax_exemption.py
import frappe
from frappe import _
from frappe.utils import flt, get_link_to_form

from hrms.hr.utils import get_salary_assignments
from hrms.regional.india.utils import (
    calculate_hra_exemption,
    get_component_pay,
    get_end_date_for_assignment,
    get_component_amt_from_salary_slip,
    has_hra_component,
)


def get_component_amt_from_manual_table(assignment_name, basic_component, hra_component):
    """
    Fallback for Manual Salary Structures: reads Basic/HRA amounts from the
    custom 'Manual Salary Component' child table on the Salary Structure
    Assignment, since these structures carry no Earning rows on the
    Salary Structure itself (has_hra_component() would return False).
    """
    rows = frappe.get_all(
        "Manual Salary Component",
        filters={
            "parent": assignment_name,
            "salary_component": ["in", [basic_component, hra_component]],
        },
        fields=["salary_component", "amount"],
    )

    basic_amt = hra_amt = 0
    for row in rows:
        if row.salary_component == basic_component:
            basic_amt = row.amount
        elif row.salary_component == hra_component:
            hra_amt = row.amount

    return basic_amt, hra_amt


def calculate_annual_eligible_hra_exemption(doc):
    basic_component, hra_component = frappe.db.get_value(
        "Company", doc.company, ["basic_component", "hra_component"]
    )

    if not (basic_component and hra_component):
        frappe.throw(
            _("Please set Basic and HRA component in Company {0}").format(
                get_link_to_form("Company", doc.company)
            )
        )

    annual_exemption = monthly_exemption = hra_amount = basic_amount = 0

    if hra_component and basic_component:
        assignments = get_salary_assignments(doc.employee, doc.payroll_period)

        if not assignments and doc.docstatus == 1:
            frappe.throw(_("Salary Structure must be submitted before submission of {0}").format(doc.doctype))

        period_start_date = frappe.db.get_value("Payroll Period", doc.payroll_period, "start_date")

        assignment_dates = []
        for assignment in assignments:
            assignment.from_date = max(assignment.from_date, period_start_date)
            assignment_dates.append(assignment.from_date)

        for idx, assignment in enumerate(assignments):
            if has_hra_component(assignment.salary_structure, hra_component):
                basic_salary_amt, hra_salary_amt = get_component_amt_from_salary_slip(
                    doc.employee,
                    assignment.salary_structure,
                    basic_component,
                    hra_component,
                    assignment.from_date,
                )
            else:
                # --- CHANGED: Manual Salary Structure fallback ---
                basic_salary_amt, hra_salary_amt = get_component_amt_from_manual_table(
                    assignment.name, basic_component, hra_component
                )
                # --------------------------------------------------

            to_date = get_end_date_for_assignment(assignment_dates, idx, doc.payroll_period)

            frequency = frappe.get_value(
                "Salary Structure", assignment.salary_structure, "payroll_frequency"
            )
            basic_amount += get_component_pay(frequency, basic_salary_amt, assignment.from_date, to_date)
            hra_amount += get_component_pay(frequency, hra_salary_amt, assignment.from_date, to_date)

        if hra_amount:
            if doc.monthly_house_rent:
                annual_exemption = calculate_hra_exemption(
                    assignment.salary_structure,
                    basic_amount,
                    hra_amount,
                    doc.monthly_house_rent,
                    doc.rented_in_metro_city,
                )
                if annual_exemption > 0:
                    monthly_exemption = annual_exemption / 12
                else:
                    annual_exemption = 0

    return frappe._dict(
        {
            "hra_amount": hra_amount,
            "annual_exemption": annual_exemption,
            "monthly_exemption": monthly_exemption,
        }
    )