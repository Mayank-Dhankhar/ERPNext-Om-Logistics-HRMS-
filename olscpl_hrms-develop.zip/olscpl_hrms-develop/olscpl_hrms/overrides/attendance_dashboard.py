# Attendance form -> Connections: everything tied to this day, so HR can jump
# to it (e.g. a pending regularization blocking a cancel/delete).
from frappe import _


def get_data(data=None):
	return {
		"fieldname": "attendance",
		"non_standard_fieldnames": {"Attendance Regularization": "attendance_link"},
		"internal_links": {
			"Leave Application": "leave_application",
			"Attendance Request": "attendance_request",
		},
		"transactions": [
			{"label": _("Punches"), "items": ["Employee Checkin"]},
			{"label": _("Requests"), "items": ["Attendance Regularization", "Attendance Request", "Leave Application"]},
		],
	}
