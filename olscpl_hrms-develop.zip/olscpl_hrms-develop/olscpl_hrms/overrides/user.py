# olscpl_hrms/overrides/user.py
#
# Impersonation without the "Security Alert: Your account is being
# impersonated" email (frappe.core.doctype.user.user.impersonate, hooked via
# override_whitelisted_methods) - turned off at the owner's request. The
# Activity Log and the in-app alert stay, so every session is still on record.
import frappe
from frappe import _


@frappe.whitelist(methods=["POST"])
def impersonate(user: str, reason: str):
	frappe.only_for("Administrator")

	impersonator = frappe.session.user
	frappe.get_doc(
		{
			"doctype": "Activity Log",
			"user": user,
			"status": "Success",
			"subject": _("User {0} impersonated as {1}").format(impersonator, user),
			"operation": "Impersonate",
		}
	).insert(ignore_permissions=True, ignore_links=True)

	notification = frappe.new_doc(
		"Notification Log",
		for_user=user,
		from_user=impersonator,
		subject=_("{0} just impersonated as you. They gave this reason: {1}").format(impersonator, reason),
	)
	notification.set("type", "Alert")
	notification.insert(ignore_permissions=True)

	frappe.local.login_manager.impersonate(user)
