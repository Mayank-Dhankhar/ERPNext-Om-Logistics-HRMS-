# Overrides HRMS core Attendance.validate() solely to extend the
# allowed status list with "Week Off". Every other check
# (duplicate record, overlapping shift, employee status, leave
# record) is untouched -- just re-calls the same inherited methods
# HRMS core already defines.
#
# Registered via hooks.py -> override_doctype_class

from hrms.hr.doctype.attendance.attendance import Attendance as HRMSAttendance
from hrms.hr.utils import validate_active_employee


class CustomAttendance(HRMSAttendance):
	def validate(self):
		from erpnext.controllers.status_updater import validate_status

		validate_status(
			self.status,
			["Present", "Absent", "On Leave", "Half Day", "Work From Home", "Week Off", "Holiday", "Visit"],
		)
		validate_active_employee(self.employee)
		self.validate_attendance_date()
		self.validate_duplicate_record()
		self.validate_overlapping_shift_attendance()
		self.validate_employee_status()
		self.check_leave_record()

