# olscpl_hrms/overrides/payroll_entry.py
#
# Create Salary Slips in parallel chunks with per-slip commits and progress
# (api/payroll_entry.start_slip_creation). Small runs (<= 30 employees) keep
# stock behaviour.
import frappe
from frappe import _
from hrms.payroll.doctype.payroll_entry.payroll_entry import PayrollEntry

from olscpl_hrms.api.payroll_entry import start_slip_creation


class CustomPayrollEntry(PayrollEntry):
	@frappe.whitelist()
	def create_salary_slips(self):
		employees = [emp.employee for emp in self.employees]
		if len(employees) <= 30 and not frappe.flags.enqueue_payroll_entry:
			return super().create_salary_slips()
		self.check_permission("write")
		args = frappe._dict(
			salary_slip_based_on_timesheet=self.salary_slip_based_on_timesheet,
			payroll_frequency=self.payroll_frequency,
			start_date=self.start_date,
			end_date=self.end_date,
			company=self.company,
			posting_date=self.posting_date,
			deduct_tax_for_unclaimed_employee_benefits=self.deduct_tax_for_unclaimed_employee_benefits,
			deduct_tax_for_unsubmitted_tax_exemption_proof=self.deduct_tax_for_unsubmitted_tax_exemption_proof,
			payroll_entry=self.name,
			exchange_rate=self.exchange_rate,
			currency=self.currency,
		)
		start_slip_creation(self, employees, args)

	@frappe.whitelist()
	def submit_salary_slips(self):
		"""Big runs: submitted by several processes with progress
		(api/payroll_entry.start_slip_submission). Also picks up a run whose
		slips went through but whose Journal Entry failed."""
		from olscpl_hrms.api.payroll_entry import _unaccounted_slips, start_slip_submission

		self.check_permission("write")
		slips = [s[0] for s in self.get_sal_slip_list(ss_status=0)]
		if len(slips) <= 30 and not _unaccounted_slips(self.name) and not frappe.flags.enqueue_payroll_entry:
			return super().submit_salary_slips()
		start_slip_submission(self, slips)
		frappe.publish_realtime("payroll_slip_submit_started", {"name": self.name},
			user=frappe.session.user, after_commit=True)

	def cancel(self):
		"""Stock cancel, plus the starting slip count for the cancel progress panel."""
		from olscpl_hrms.api.payroll_entry import note_cancel_start

		slips = len(self.get_linked_salary_slips())
		note_cancel_start(self.name, slips)
		if slips <= 50 and len(self.employees) > 50:
			# stock runs this in the request (behind a freeze) when few slips are
			# left, but the auto leaves of a big run still take minutes - queue it
			self.queue_action("cancel", timeout=3000)
			return
		return super().cancel()

	def on_cancel(self):
		super().on_cancel()
		self.cancel_auto_leaves()

	def cancel_auto_leaves(self):
		"""Cancel the "Auto LWP Adjustment" leaves that slip creation made for
		this run's half days (events/salary_slip_steps.py), so their balance
		comes back and a re-run gives the same result. The Half Day attendance
		stays: stock cancel would cancel it, so only its leave link is undone,
		and no cancellation mail goes out for a leave nobody applied for."""
		from olscpl_hrms.utils.payroll_constants import MONTH_MAP

		# same payroll month (26th -> 25th cycle) as salary_slip_steps uses
		start = frappe.utils.getdate(self.start_date)
		month = frappe.utils.add_months(start, 1) if start.day >= 26 else start
		# a join, not employee IN (...thousands...) - that list alone takes ~30s to build
		leaves = frappe.db.sql_list("""SELECT la.name FROM `tabLeave Application` la
			JOIN `tabPayroll Employee Detail` d ON d.parent = %s AND d.employee = la.employee
			WHERE la.description = %s AND la.docstatus = 1""",
			(self.name, f"Auto LWP Adjustment | Payroll: {MONTH_MAP[month.month]} {month.year}"))
		for name in leaves:
			leave = frappe.get_doc("Leave Application", name)
			# by (employee, date) - indexed; leave_application alone would scan every Attendance row
			frappe.db.sql("""UPDATE `tabAttendance` SET leave_type = NULL, leave_application = NULL,
				half_day_status = 'Absent', modify_half_day_status = 0
				WHERE employee = %s AND attendance_date = %s AND leave_application = %s AND status = 'Half Day'""",
				(leave.employee, leave.from_date, name))
			leave.cancel_attendance = leave.notify_employee = lambda: None
			leave.flags.ignore_permissions = True
			leave.cancel()

	def delete_linked_salary_slips(self):
		"""Stock steps for every slip: submitted slips cancelled then deleted
		(one by one, as stock); draft slips deleted with the stock delete_doc by
		several processes at once (api/payroll_entry.delete_draft_slips_parallel)."""
		from olscpl_hrms.api.payroll_entry import delete_draft_slips_parallel

		slips = self.get_linked_salary_slips()
		for slip in slips:
			if slip.docstatus == 1:
				frappe.get_doc("Salary Slip", slip.name).cancel()
				frappe.delete_doc("Salary Slip", slip.name)
		drafts = [s.name for s in slips if s.docstatus != 1]
		if len(drafts) <= 50:
			for name in drafts:
				frappe.delete_doc("Salary Slip", name)
			return
		failed = delete_draft_slips_parallel(self.name, drafts)
		if failed:
			lines = "<br>".join(f"{f['slip']}: {frappe.utils.escape_html(f['error'])}" for f in failed[:20])
			frappe.throw(_("{0} salary slip(s) could not be deleted, so the Payroll Entry was not cancelled. "
				"Fix them and cancel again - slips already removed stay removed:<br>{1}").format(len(failed), lines))
