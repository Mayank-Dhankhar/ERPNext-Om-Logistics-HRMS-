// OLSCPL-HRMS-TDS-001 (v3) : Employee Self-Service Page -- Excel-format table
// File: olscpl_hrms/olscpl_hrms/olscpl_hrms/page/tds_advisory/tds_advisory.js
// v3 adds: employee name display, "Download Excel" button.

frappe.pages['tds-advisory'].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'My TDS Advisory',
		single_column: true,
	});

	const fy_field = page.add_field({
		fieldtype: 'Select',
		fieldname: 'fiscal_year',
		label: 'Fiscal Year',
		options: [new Date().getFullYear() - 1, new Date().getFullYear(), new Date().getFullYear() + 1]
			.map(String).join('\n'),
		default: String(new Date().getFullYear()),
		change: () => render(),
	});

	let last_result = null;

	page.set_primary_action('Download Excel', () => {
		const fiscal_year = fy_field.get_value();
		const url = '/api/method/olscpl_hrms.api.tds_advisory_excel_format.download_tds_advisory_excel'
			+ '?fiscal_year=' + encodeURIComponent(fiscal_year);
		window.open(url, '_blank');
	}, 'download');

	const $body = $('<div class="tds-advisory-wrapper" style="margin-top:15px; overflow-x:auto;"></div>').appendTo(page.body);

	function render() {
		$body.html('<div class="text-muted">Loading...</div>');
		frappe.call({
			method: 'olscpl_hrms.api.tds_advisory_excel_format.get_employee_tds_advisory_excel',
			args: { fiscal_year: fy_field.get_value() },
			freeze: true,
			callback: (r) => {
				if (!r.message || r.message.error) {
					$body.html(`<div class="alert alert-warning">${(r.message && r.message.error) || 'No data found.'}</div>`);
					return;
				}
				last_result = r.message;
				draw(r.message);
			},
		});
	}

	function fmt(v) {
		if (v === null || v === undefined || v === '') return '';
		return frappe.format(v, { fieldtype: 'Currency' });
	}

	const BOLD_ROWS = new Set([
		'GROSS SALARY', 'GROSSINCOME', 'TAXABLE INCOME', 'TOTAT-EXEMPTION',
		'NET-TAX', 'TOTAL_TAX', 'BALANCE TDS',
	]);

	function draw(d) {
		const badge = `<span class="indicator-pill green">${d.recommended_regime}</span>`;
		let month_headers = d.months.map(m => `<th class="text-right">${m}</th>`).join('');

		let body_rows = d.rows.map(row => {
			const bold = BOLD_ROWS.has(row.particular) ? 'style="font-weight:600;"' : '';
			let month_cells = d.months.map(m => `<td class="text-right">${fmt(row[m])}</td>`).join('');
			return `
				<tr ${bold}>
					<td>${row.particular}</td>
					<td class="text-right">${fmt(row.old_regime)}</td>
					<td class="text-right">${fmt(row.new_regime)}</td>
					${month_cells}
				</tr>`;
		}).join('');

		$body.html(`
			<div style="margin-bottom:10px;">
				<strong>${d.employee} - ${d.employee_name}</strong> &nbsp;|&nbsp;
				<strong>Company:</strong> ${d.company} &nbsp;|&nbsp;
				<strong>Payroll Period:</strong> ${d.payroll_period} &nbsp;|&nbsp;
				Recommended: ${badge}
			</div>
			<table class="table table-bordered table-sm" style="font-size:12px; white-space:nowrap;">
				<thead>
					<tr>
						<th>PARTICULAR</th>
						<th class="text-right">Old Regime</th>
						<th class="text-right">New Regime</th>
						${month_headers}
					</tr>
				</thead>
				<tbody>
					${body_rows}
				</tbody>
			</table>
			<p class="text-muted small">
				Months with no submitted Salary Slip yet show blank. Use the
				"Download Excel" button above to save this table.
			</p>
		`);
	}

	render();
};