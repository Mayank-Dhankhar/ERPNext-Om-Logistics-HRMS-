// Org Chart (/app/org-chart)
//
// The reporting tree (Employee.reports_to) as a pan/zoom canvas. Click a
// card's team chip to open its team, drag a card onto another card to change
// who they report to (System Manager only), drag from the "No manager" tray
// to place someone, drop on the tray to remove their manager. The side panel
// sets a person as a branch's HR (Branch.custom_branch_hrs), which the
// approval flow uses. Backend: olscpl_hrms.api.org_chart.

const OC_API = "olscpl_hrms.api.org_chart.";
const CW = 228, CH = 76, HG = 28, VG = 72, LEAF_GAP = 14, PAD = 18, MAX_COLS = 4;

frappe.pages["org-chart"].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({ parent: wrapper, title: __("Org Chart"), single_column: true });
	wrapper.org_chart = new OrgChart(page, wrapper);
};

frappe.pages["org-chart"].on_page_show = function (wrapper) {
	wrapper.org_chart && wrapper.org_chart.fit(false);
};

class OrgChart {
	constructor(page, wrapper) {
		this.page = page;
		this.nodes = new Map(); // id -> {data, kids: [ids] | null, total, open}
		this.roots = [];
		this.view = { x: 0, y: 0, k: 1 };
		this.goal = { x: 0, y: 0, k: 1 };
		this.els = new Map();
		this.tray = { rows: [], total: 0, filters: {} };
		this.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.build($(wrapper).find(".layout-main-section"));
		this.init();
	}

	// ---------- setup ----------
	build($parent) {
		$parent.addClass("oc-host").html(`
			<div class="oc">
				<aside class="oc-tray" aria-label="${__("People with no manager")}">
					<div class="oc-tray-head">
						<div class="oc-tray-title">${__("No manager")} <span class="oc-count"></span></div>
						<input class="oc-input oc-tray-search" type="search" placeholder="${__("Search name, ID or designation")}">
						<div class="oc-filters">
							<select class="oc-input" data-f="branch"><option value="">${__("All branches")}</option></select>
							<select class="oc-input" data-f="department"><option value="">${__("All departments")}</option></select>
						</div>
						<p class="oc-hint oc-edit-only">${__("Drag someone onto a manager to set who they report to.")}</p>
					</div>
					<div class="oc-tray-list"></div>
				</aside>
				<div class="oc-stage" tabindex="0" aria-label="${__("Org chart canvas")}">
					<div class="oc-world">
						<svg class="oc-links"><g></g></svg>
						<div class="oc-nodes"></div>
					</div>
					<div class="oc-find">
						<input class="oc-input oc-find-input" type="search" placeholder="${__("Find anyone in the chart")}">
						<div class="oc-find-results"></div>
					</div>
					<div class="oc-zoom" role="toolbar">
						<button class="oc-btn" data-z="out" aria-label="${__("Zoom out")}">−</button>
						<span class="oc-zoom-val">100%</span>
						<button class="oc-btn" data-z="in" aria-label="${__("Zoom in")}">+</button>
						<button class="oc-btn oc-btn-text" data-z="fit">${__("Fit")}</button>
					</div>
				</div>
				<aside class="oc-panel" aria-live="polite"></aside>
			</div>`);
		this.$root = $parent.find(".oc");
		this.$stage = this.$root.find(".oc-stage");
		this.world = this.$root.find(".oc-world")[0];
		this.svg = this.$root.find(".oc-links g")[0];
		this.layer = this.$root.find(".oc-nodes")[0];
		this.$panel = this.$root.find(".oc-panel");
	}

	async init() {
		try {
			await this._init();
		} catch (e) {
			console.error("Org Chart failed to load", e);
			this.$root.find(".oc-tray-list").html(
				`<p class="oc-hint">${__("Could not load the org chart. Please refresh, or contact IT if it persists.")}</p>`
			);
		}
	}

	async _init() {
		this.meta = await this.call("get_meta");
		this.$root.toggleClass("oc-can-edit", !!this.meta.can_edit);
		this.$root.find(".oc-count").text(this.meta.unassigned.toLocaleString());
		const fill = (sel, list) => this.$root.find(`select[data-f="${sel}"]`).append(list.map((v) => `<option>${frappe.utils.escape_html(v)}</option>`));
		fill("branch", this.meta.branches);
		fill("department", this.meta.departments);
		this.bindCanvas();
		this.bindTray();
		this.bindFind();
		const top = await this.call("get_children", {});
		this.roots = top.rows.map((r) => this.remember(r).name);
		this.render();
		this.fit(false);
		this.loadTray(true);
		this.showPanel(null);
	}

	call(method, args = {}, post = false) {
		return new Promise((resolve, reject) =>
			frappe.call({ method: OC_API + method, args, type: post ? "POST" : "GET", callback: (r) => resolve(r.message), error: reject })
		);
	}

	remember(row) {
		const n = this.nodes.get(row.name);
		if (n) Object.assign(n.data, row);
		else this.nodes.set(row.name, { data: row, kids: null, total: row.reports, open: false });
		return row;
	}

	// ---------- tree data ----------
	async openNode(id, open = true) {
		const n = this.nodes.get(id);
		if (!n || !n.data.reports) return;
		if (open && !n.kids) {
			n.loading = true;
			this.render();
			const res = await this.call("get_children", { parent: id, start: 0 });
			n.kids = res.rows.map((r) => this.remember(r).name);
			n.total = res.total;
			n.loading = false;
		}
		n.open = open;
		this.render();
	}

	async loadMore(id) {
		const n = this.nodes.get(id);
		const res = await this.call("get_children", { parent: id, start: n.kids.length });
		n.kids.push(...res.rows.map((r) => this.remember(r).name).filter((k) => !n.kids.includes(k)));
		n.total = res.total;
		this.render();
	}

	async refreshTeam(id) {
		if (!id) {
			const top = await this.call("get_children", {});
			this.roots = top.rows.map((r) => this.remember(r).name);
			return;
		}
		const n = this.nodes.get(id);
		if (!n) return;
		const res = await this.call("get_children", { parent: id, start: 0 });
		n.kids = res.rows.map((r) => this.remember(r).name);
		n.total = res.total;
		n.data.reports = res.total;
	}

	// ---------- layout ----------
	measure(id) {
		const n = this.nodes.get(id);
		const box = { id, w: CW, h: CH, managers: [], leaves: [], more: 0 };
		if (n.open && n.kids) {
			for (const k of n.kids) (this.nodes.get(k).data.reports ? box.managers : box.leaves).push(k);
			box.more = Math.max(0, n.total - n.kids.length);
			const leafCount = box.leaves.length + (box.more ? 1 : 0);
			if (leafCount) {
				box.cols = Math.min(MAX_COLS, leafCount);
				box.rows = Math.ceil(leafCount / box.cols);
				box.leafW = box.cols * CW + (box.cols - 1) * LEAF_GAP + PAD * 2;
				box.leafH = box.rows * CH + (box.rows - 1) * LEAF_GAP + PAD * 2;
			}
			box.sub = box.managers.map((m) => this.measure(m));
			const parts = [...(leafCount ? [box.leafW] : []), ...box.sub.map((s) => s.w)];
			box.rowW = parts.reduce((a, b) => a + b, 0) + Math.max(0, parts.length - 1) * HG * 2;
			box.w = Math.max(CW, box.rowW);
			box.h = CH + VG + Math.max(box.leafH || 0, ...box.sub.map((s) => s.h));
		}
		return box;
	}

	place(box, left, top, out) {
		const n = this.nodes.get(box.id);
		const x = left + (box.w - CW) / 2;
		out.cards.push({ id: box.id, x, y: top });
		if (!(n.open && n.kids)) return;
		let cx = left + (box.w - box.rowW) / 2;
		const cy = top + CH + VG;
		const from = { x: x + CW / 2, y: top + CH };
		if (box.leafW) {
			out.trays.push({ id: box.id, x: cx, y: cy, w: box.leafW, h: box.leafH });
			out.links.push({ from, to: { x: cx + box.leafW / 2, y: cy } });
			box.leaves.forEach((k, i) => {
				const col = i % box.cols, row = Math.floor(i / box.cols);
				out.cards.push({ id: k, x: cx + PAD + col * (CW + LEAF_GAP), y: cy + PAD + row * (CH + LEAF_GAP), leaf: true });
			});
			if (box.more) {
				const i = box.leaves.length, col = i % box.cols, row = Math.floor(i / box.cols);
				out.cards.push({ id: `more:${box.id}`, more: box.more, parent: box.id, x: cx + PAD + col * (CW + LEAF_GAP), y: cy + PAD + row * (CH + LEAF_GAP) });
			}
			cx += box.leafW + HG * 2;
		}
		for (const s of box.sub) {
			out.links.push({ from, to: { x: cx + s.w / 2, y: cy } });
			this.place(s, cx, cy, out);
			cx += s.w + HG * 2;
		}
	}

	// ---------- render ----------
	render() {
		const out = { cards: [], trays: [], links: [] };
		let left = 0;
		for (const r of this.roots) {
			const box = this.measure(r);
			this.place(box, left, 0, out);
			left += box.w + HG * 3;
		}
		this.bounds = { w: Math.max(left - HG * 3, CW), h: Math.max(...out.cards.map((c) => c.y + CH), CH) };

		// connectors: curved "routes" with an arrowhead into the team. Each
		// gradient is in user space - a bounding-box gradient paints nothing
		// on a perfectly vertical line (zero-width box), which hid them all.
		const ARROW = 7;
		this.svg.innerHTML =
			`<defs><marker id="oc-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="${ARROW}" markerHeight="${ARROW}" orient="auto-start-reverse" markerUnits="userSpaceOnUse">
				<path d="M0,0 L10,5 L0,10 L3,5 z" class="oc-arrow-head"/></marker>
			${out.links.map(({ from, to }, i) => `<linearGradient id="oc-g${i}" gradientUnits="userSpaceOnUse" x1="${from.x}" y1="${from.y}" x2="${to.x}" y2="${to.y}">
				<stop offset="0" stop-color="#6e86ff"/><stop offset="1" stop-color="#5ad19a"/></linearGradient>`).join("")}</defs>` +
			out.links.map(({ from, to }, i) => {
				const end = to.y - 3; // stop short so the arrow tip touches the card/panel edge
				const my = (from.y + end) / 2;
				return `<circle cx="${from.x}" cy="${from.y}" r="3.5" class="oc-link-dot"/>
					<path d="M${from.x},${from.y} C${from.x},${my} ${to.x},${my} ${to.x},${end}" stroke="url(#oc-g${i})" marker-end="url(#oc-arrow)"/>`;
			}).join("");

		// card positions in world space - focusOn reads these (parsing them back
		// out of style.transform broke: Chrome writes translate(x, 0px) as translate(x))
		this.pos = new Map(out.cards.map((c) => [c.id, { x: c.x, y: c.y }]));

		const seen = new Set();
		for (const t of out.trays) this.upsert(`tray:${t.id}`, t, () => this.trayEl(), seen);
		for (const c of out.cards) this.upsert(c.id, c, () => (c.more ? this.moreEl(c) : this.cardEl(c.id)), seen);
		for (const [key, el] of this.els) {
			if (!seen.has(key)) {
				el.classList.add("oc-leaving");
				setTimeout(() => el.remove(), this.reduced ? 0 : 220);
				this.els.delete(key);
			}
		}
	}

	upsert(key, pos, make, seen) {
		seen.add(key);
		let el = this.els.get(key);
		const fresh = !el;
		if (fresh) {
			el = make();
			this.layer.appendChild(el);
			this.els.set(key, el);
		} else if (!key.startsWith("tray:")) {
			this.fillCard(el, key, pos);
		}
		if (pos.w) { el.style.width = pos.w + "px"; el.style.height = pos.h + "px"; }
		if (fresh && !this.reduced) {
			el.style.transform = `translate(${pos.x}px, ${pos.y - 10}px)`;
			el.style.opacity = "0";
			requestAnimationFrame(() => { el.style.transform = `translate(${pos.x}px, ${pos.y}px)`; el.style.opacity = ""; });
		} else {
			el.style.transform = `translate(${pos.x}px, ${pos.y}px)`;
		}
	}

	trayEl() {
		const el = document.createElement("div");
		el.className = "oc-team";
		return el;
	}

	moreEl(c) {
		const el = document.createElement("button");
		el.className = "oc-card oc-more";
		el.dataset.more = c.parent;
		el.textContent = __("Show {0} more", [Math.min(40, c.more)]) + (c.more > 40 ? ` (${c.more.toLocaleString()} ${__("left")})` : "");
		return el;
	}

	cardEl(id) {
		const el = document.createElement("div");
		el.className = "oc-card";
		el.dataset.id = id;
		el.tabIndex = 0;
		this.fillCard(el, id);
		return el;
	}

	fillCard(el, id, pos) {
		if (el.classList.contains("oc-more")) {
			if (pos) el.textContent = __("Show {0} more", [Math.min(40, pos.more)]) + (pos.more > 40 ? ` (${pos.more.toLocaleString()} ${__("left")})` : "");
			return;
		}
		const n = this.nodes.get(id);
		if (!n) return;
		const d = n.data, esc = frappe.utils.escape_html;
		const sig = [d.employee_name, d.designation, d.branch, d.reports, d.reports_to, n.open, n.loading, (d.hr_for || []).length, this.selected === id].join("|");
		if (el._sig === sig) return;
		el._sig = sig;
		el.classList.toggle("oc-selected", this.selected === id);
		const branchCode = (d.branch || "").split(" - ")[0];
		el.innerHTML = `
			${avatar(d)}
			<div class="oc-card-body">
				<div class="oc-name" title="${esc(d.employee_name || "")}">${esc(d.employee_name || d.name)}</div>
				<div class="oc-desig">${esc(d.designation || __("No designation"))}</div>
				<div class="oc-foot">
					${branchCode ? `<span class="oc-branch" title="${esc(d.branch)}">${esc(branchCode)}</span>` : ""}
					${d.reports_to && d.reports_to === d.name ? `<span class="oc-self" title="${__("Reports to themselves - approves their own requests")}">${__("Self")}</span>` : ""}
					${(d.hr_for || []).length ? `<span class="oc-hr" title="${esc(__("Branch HR for") + ":\n" + d.hr_for.join("\n"))}">${__("HR")}${d.hr_for.length > 1 ? ` ×${d.hr_for.length}` : ""}</span>` : ""}
				</div>
			</div>
			${d.reports ? `<button class="oc-team-chip ${n.open ? "is-open" : ""}" data-toggle="${esc(id)}" aria-expanded="${n.open}" aria-label="${__("Team of {0}", [esc(d.employee_name)])}">
				${n.loading ? `<span class="oc-spin"></span>` : `${d.reports.toLocaleString()}<svg viewBox="0 0 10 6"><path d="M1 1l4 4 4-4"/></svg>`}
			</button>` : ""}`;
	}

	// ---------- pan & zoom ----------
	bindCanvas() {
		const stage = this.$stage[0];
		const pointers = new Map();
		let pan = null, pinch = null;

		stage.addEventListener("wheel", (e) => {
			e.preventDefault();
			// The wheel always zooms around the cursor (drag the background to move).
			// deltaMode 1 = lines (some mice) -> roughly pixels.
			const dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
			this.zoomAt(e.clientX, e.clientY, Math.exp(-dy * (e.ctrlKey ? 0.012 : 0.0022)));
		}, { passive: false });

		stage.addEventListener("pointerdown", (e) => {
			if (e.target.closest(".oc-card, .oc-zoom, .oc-find, button, input, select")) return;
			pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
			stage.setPointerCapture(e.pointerId);
			if (pointers.size === 1) pan = { x: e.clientX, y: e.clientY, gx: this.goal.x, gy: this.goal.y };
			if (pointers.size === 2) {
				const [a, b] = [...pointers.values()];
				pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), k: this.goal.k };
				pan = null;
			}
			this.$stage.addClass("oc-grabbing");
		});
		stage.addEventListener("pointermove", (e) => {
			if (!pointers.has(e.pointerId)) return;
			pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
			if (pinch && pointers.size === 2) {
				const [a, b] = [...pointers.values()];
				const k = pinch.k * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d;
				this.zoomAt((a.x + b.x) / 2, (a.y + b.y) / 2, k / this.goal.k, true);
			} else if (pan) {
				this.goal.x = pan.gx + e.clientX - pan.x;
				this.goal.y = pan.gy + e.clientY - pan.y;
				this.view.x = this.goal.x; this.view.y = this.goal.y;
				this.apply();
			}
		});
		const end = (e) => {
			pointers.delete(e.pointerId);
			if (pointers.size < 2) pinch = null;
			if (!pointers.size) { pan = null; this.$stage.removeClass("oc-grabbing"); }
		};
		stage.addEventListener("pointerup", end);
		stage.addEventListener("pointercancel", end);

		this.$root.on("click", "[data-z]", (e) => {
			const z = e.currentTarget.dataset.z;
			if (z === "fit") return this.fit(true);
			const r = stage.getBoundingClientRect();
			this.zoomAt(r.left + r.width / 2, r.top + r.height / 2, z === "in" ? 1.25 : 0.8);
		});
		stage.addEventListener("keydown", (e) => {
			if (e.target !== stage) return;
			const r = stage.getBoundingClientRect();
			if (e.key === "+" || e.key === "=") this.zoomAt(r.left + r.width / 2, r.top + r.height / 2, 1.25);
			if (e.key === "-") this.zoomAt(r.left + r.width / 2, r.top + r.height / 2, 0.8);
			if (e.key === "0") this.fit(true);
		});

		// cards: open team / select / drag
		this.$root.on("click", "[data-toggle]", (e) => {
			e.stopPropagation();
			const id = e.currentTarget.dataset.toggle;
			const n = this.nodes.get(id);
			this.openNode(id, !n.open);
		});
		this.$root.on("click", ".oc-more", (e) => this.loadMore(e.currentTarget.dataset.more));
		this.$root.on("keydown", ".oc-card[data-id]", (e) => {
			if (e.key === "Enter") this.select(e.currentTarget.dataset.id);
		});
		this.bindDrag();
	}

	zoomAt(cx, cy, factor, instant = false) {
		const r = this.$stage[0].getBoundingClientRect();
		const k = Math.min(2, Math.max(0.12, this.goal.k * factor));
		const px = cx - r.left, py = cy - r.top;
		this.goal.x = px - ((px - this.goal.x) * k) / this.goal.k;
		this.goal.y = py - ((py - this.goal.y) * k) / this.goal.k;
		this.goal.k = k;
		if (instant) { Object.assign(this.view, this.goal); this.apply(); }
		else this.animate();
	}

	fit(smooth = true) {
		const r = this.$stage[0].getBoundingClientRect();
		if (!r.width || !this.bounds) return;
		const k = Math.min(1, Math.max(0.12, Math.min((r.width - 80) / this.bounds.w, (r.height - 120) / this.bounds.h)));
		this.goal = { k, x: (r.width - this.bounds.w * k) / 2, y: 70 };
		if (smooth) this.animate();
		else { Object.assign(this.view, this.goal); this.apply(); }
	}

	focusOn(id, k = 1.1) {
		const p = this.pos && this.pos.get(id);
		if (!p) return;
		const r = this.$stage[0].getBoundingClientRect();
		// centre the card at a readable zoom (110%)
		this.goal = { k, x: r.width / 2 - (p.x + CW / 2) * k, y: r.height / 2 - (p.y + CH / 2) * k };
		this.animate();
	}

	animate() {
		if (this.reduced) { Object.assign(this.view, this.goal); return this.apply(); }
		if (this.raf) return;
		const step = () => {
			const v = this.view, g = this.goal, t = 0.22;
			v.x += (g.x - v.x) * t; v.y += (g.y - v.y) * t; v.k += (g.k - v.k) * t;
			const done = Math.abs(g.x - v.x) < 0.3 && Math.abs(g.y - v.y) < 0.3 && Math.abs(g.k - v.k) < 0.0005;
			if (done) Object.assign(v, g);
			this.apply();
			this.raf = done ? null : requestAnimationFrame(step);
		};
		this.raf = requestAnimationFrame(step);
	}

	apply() {
		const { x, y, k } = this.view;
		this.world.style.transform = `translate(${x}px, ${y}px) scale(${k})`;
		this.$root.find(".oc-zoom-val").text(Math.round(k * 100) + "%");
		this.$stage.css("--oc-dot", `${Math.max(12, 24 * k)}px`).css("background-position", `${x}px ${y}px`);
	}

	// ---------- drag & drop ----------
	bindDrag() {
		let drag = null;
		const start = (e, id, fromTray) => {
			if (!this.meta.can_edit || e.button > 0) return;
			drag = { id, fromTray, x: e.clientX, y: e.clientY, live: false };
		};
		this.$root.on("pointerdown", ".oc-card[data-id]", (e) => {
			if (e.target.closest("[data-toggle]")) return;
			start(e.originalEvent, e.currentTarget.dataset.id, false);
			this.pendingSelect = e.currentTarget.dataset.id;
		});
		this.$root.on("pointerdown", ".oc-tray-item", (e) => start(e.originalEvent, e.currentTarget.dataset.id, true));
		this.$root.on("click", ".oc-card[data-id]", (e) => {
			if (e.target.closest("[data-toggle]") || this.justDragged) return;
			this.select(e.currentTarget.dataset.id);
		});
		this.$root.on("click", ".oc-tray-item", (e) => { if (!this.justDragged) this.select(e.currentTarget.dataset.id); });

		document.addEventListener("pointermove", (e) => {
			if (!drag) return;
			if (!drag.live) {
				if (Math.hypot(e.clientX - drag.x, e.clientY - drag.y) < 6) return;
				drag.live = true;
				const d = (this.nodes.get(drag.id) || this.trayRow(drag.id) || { data: {} });
				const data = d.data || d;
				drag.ghost = $(`<div class="oc-ghost">${avatar(data)}<span>${frappe.utils.escape_html(data.employee_name || drag.id)}</span></div>`).appendTo(document.body)[0];
				this.$root.addClass("oc-dragging");
				this.els.get(drag.id)?.classList.add("oc-lifted");
			}
			drag.ghost.style.transform = `translate(${e.clientX + 14}px, ${e.clientY + 10}px)`;
			const hit = document.elementFromPoint(e.clientX, e.clientY);
			const card = hit && hit.closest(".oc-card[data-id]");
			const tray = hit && hit.closest(".oc-tray");
			const target = card && card.dataset.id !== drag.id ? card : null;
			if (drag.target !== target) {
				drag.target?.classList.remove("oc-dock");
				target?.classList.add("oc-dock");
				drag.target = target;
			}
			this.$root.find(".oc-tray").toggleClass("oc-dock-tray", !!tray && !drag.fromTray);
			drag.toTray = !!tray && !drag.fromTray;
		});
		document.addEventListener("pointerup", () => {
			if (!drag) return;
			const d = drag;
			drag = null;
			if (!d.live) return;
			this.justDragged = true;
			setTimeout(() => (this.justDragged = false), 0);
			d.ghost.remove();
			d.target?.classList.remove("oc-dock");
			this.$root.removeClass("oc-dragging").find(".oc-tray").removeClass("oc-dock-tray");
			this.els.get(d.id)?.classList.remove("oc-lifted");
			if (d.target) this.confirmMove(d.id, d.target.dataset.id);
			else if (d.toTray) this.confirmMove(d.id, null);
		});
	}

	trayRow(id) {
		return this.tray.rows.find((r) => r.name === id);
	}

	nameOf(id) {
		return (this.nodes.get(id)?.data || this.trayRow(id) || {}).employee_name || id;
	}

	confirmMove(id, manager) {
		const who = frappe.utils.escape_html(this.nameOf(id));
		const msg = manager
			? __("Make {0} report to {1}?", [`<b>${who}</b>`, `<b>${frappe.utils.escape_html(this.nameOf(manager))}</b>`])
			: __("Remove {0}'s manager? They'll move to the No manager list.", [`<b>${who}</b>`]);
		frappe.confirm(msg, () => this.move(id, manager));
	}

	async move(id, manager) {
		let res;
		try {
			res = await this.call("set_manager", { employee: id, manager }, true);
		} catch (e) {
			return; // frappe already showed the server's message
		}
		frappe.show_alert({ message: manager ? __("Manager changed") : __("Manager removed"), indicator: "green" });
		const inTray = this.trayRow(id);
		if (inTray) {
			this.tray.rows = this.tray.rows.filter((r) => r.name !== id);
			this.remember(inTray);
			this.meta.unassigned -= 1;
		}
		await Promise.all([this.refreshTeam(res.old), this.refreshTeam(manager)]);
		if (res.old && this.nodes.get(res.old)) this.nodes.get(res.old).data.reports = this.nodes.get(res.old).total;
		if (manager) this.nodes.get(manager).open = true;
		if (!manager) { this.loadTray(true); this.meta.unassigned += 1; }
		this.$root.find(".oc-count").text(this.meta.unassigned.toLocaleString());
		this.renderTray();
		this.render();
		if (manager) setTimeout(() => this.focusOn(id), 260);
		if (this.selected === id) this.select(id);
	}

	// ---------- tray ----------
	bindTray() {
		const reload = frappe.utils.debounce(() => this.loadTray(true), 250);
		this.$root.find(".oc-tray-search").on("input", (e) => { this.tray.filters.txt = e.target.value; reload(); });
		this.$root.find(".oc-tray select").on("change", (e) => { this.tray.filters[e.target.dataset.f] = e.target.value; this.loadTray(true); });
		this.$root.on("click", ".oc-tray-more", () => this.loadTray(false));
	}

	async loadTray(reset) {
		const args = { ...this.tray.filters, start: reset ? 0 : this.tray.rows.length };
		const res = await this.call("get_unassigned", args);
		this.tray.rows = reset ? res.rows : this.tray.rows.concat(res.rows);
		this.tray.total = res.total;
		this.renderTray();
	}

	renderTray() {
		const esc = frappe.utils.escape_html;
		const $list = this.$root.find(".oc-tray-list");
		if (!this.tray.rows.length) {
			$list.html(`<p class="oc-empty">${this.tray.filters.txt || this.tray.filters.branch || this.tray.filters.department ? __("No one matches these filters.") : __("Everyone has a manager.")}</p>`);
			return;
		}
		$list.html(this.tray.rows.map((r) => `
			<div class="oc-tray-item ${this.selected === r.name ? "oc-selected" : ""}" data-id="${esc(r.name)}" tabindex="0">
				${avatar(r)}
				<div><div class="oc-name">${esc(r.employee_name)}</div><div class="oc-desig">${esc(r.designation || "")}${r.branch ? `, ${esc(r.branch.split(" - ").slice(1).join(" - ") || r.branch)}` : ""}</div></div>
			</div>`).join("") +
			(this.tray.rows.length < this.tray.total ? `<button class="oc-btn oc-btn-text oc-tray-more">${__("Show more ({0} left)", [(this.tray.total - this.tray.rows.length).toLocaleString()])}</button>` : ""));
	}

	// ---------- find ----------
	bindFind() {
		const $in = this.$root.find(".oc-find-input"), $res = this.$root.find(".oc-find-results");
		const run = frappe.utils.debounce(async () => {
			const txt = $in.val().trim();
			if (txt.length < 2) return $res.empty();
			const rows = await this.call("search", { txt });
			const esc = frappe.utils.escape_html;
			$res.html(rows.length ? rows.map((r) => `<button class="oc-find-row" data-id="${esc(r.name)}" data-path='${esc(JSON.stringify(r.path))}'>
				<b>${esc(r.employee_name)}</b><span>${esc(r.designation || "")}</span></button>`).join("") : `<p class="oc-empty">${__("No one found")}</p>`);
		}, 250);
		$in.on("input", run);
		$in.on("keydown", (e) => {
			if (e.key === "Enter") { e.preventDefault(); $res.find(".oc-find-row").first().trigger("click"); }
			if (e.key === "Escape") { $res.empty(); $in.val(""); }
		});
		$res.on("click", ".oc-find-row", async (e) => {
			const id = e.currentTarget.dataset.id, path = JSON.parse(e.currentTarget.dataset.path);
			$res.empty(); $in.val("");
			await this.reveal(id, path);
		});
	}

	async reveal(id, path) {
		// Someone with no manager and no team lives in the tray, not the chart.
		if (!path.length && !this.roots.includes(id)) {
			this.tray.filters = { txt: this.nameOf(id) === id ? id : this.nameOf(id) };
			this.$root.find(".oc-tray-search").val(this.tray.filters.txt);
			await this.loadTray(true);
			frappe.show_alert({ message: __("{0} has no manager or team yet, shown in the No manager list.", [this.nameOf(id)]), indicator: "blue" });
			return this.select(id);
		}
		// Open each manager down the chain, making sure the next person is on
		// the canvas even when they're beyond the first page of a big team.
		const chain = [...path, id];
		for (let i = 0; i < chain.length - 1; i++) {
			const mgr = chain[i], next = chain[i + 1];
			if (!this.nodes.has(mgr)) this.remember(await this.call("get_employee", { name: mgr }));
			await this.openNode(mgr, true);
			const n = this.nodes.get(mgr);
			if (n.kids && !n.kids.includes(next)) {
				n.kids.push(this.remember(await this.call("get_employee", { name: next })).name);
			}
		}
		this.render();
		await this.select(id);
		setTimeout(() => {
			this.focusOn(id);
			const el = this.els.get(id);
			if (el) { el.classList.remove("oc-found"); void el.offsetWidth; el.classList.add("oc-found"); }
		}, this.reduced ? 0 : 300);
	}

	// ---------- side panel ----------
	async select(id) {
		this.selected = id;
		this.render();
		this.renderTray();
		const d = await this.call("get_employee", { name: id });
		if (this.selected !== id) return;
		this.remember(d);
		this.showPanel(d);
	}

	showPanel(d) {
		const esc = frappe.utils.escape_html;
		if (!d) {
			this.$panel.html(`<div class="oc-panel-empty">
				<p>${__("Select someone to see their details.")}</p>
				<p class="oc-hint">${__("Scroll the mouse wheel or pinch to zoom, drag the background to move around.")}</p></div>`);
			return;
		}
		const row = (label, value) => value ? `<div class="oc-row"><span>${label}</span><b>${esc(String(value))}</b></div>` : "";
		this.$panel.html(`
			<div class="oc-panel-head">${avatar(d, true)}
				<div><h3>${esc(d.employee_name)}</h3><p>${esc(d.designation || __("No designation"))}</p></div>
				<button class="oc-close" aria-label="${__("Close")}">×</button>
			</div>
			<div class="oc-rows">
				${row(__("Employee ID"), d.name)}
				${row(__("Reports to"), d.manager_name || __("No manager"))}
				${row(__("Team size"), d.reports ? d.reports.toLocaleString() : "")}
				${row(__("Department"), d.department)}
				${row(__("Branch"), d.branch)}
				${row(__("State"), d.custom_state)}
			</div>
			<div class="oc-hr-block">
				<div class="oc-hr-title">${__("Branch HR for")}</div>
				${(d.hr_for || []).length ? `<div class="oc-pills">${d.hr_for.map((b) => `<span class="oc-pill">${esc(b)}</span>`).join("")}</div>` : `<p class="oc-hint">${__("Not HR for any branch.")}</p>`}
			</div>
			<div class="oc-actions">
				<button class="btn btn-default btn-sm oc-edit-only" data-act="manager">${__("Change manager")}</button>
				${d.reports_to ? `<button class="btn btn-default btn-sm oc-edit-only" data-act="remove">${__("Remove manager")}</button>` : ""}
				<button class="btn btn-default btn-sm oc-edit-only" data-act="hr">${__("Set branch HR")}</button>
				<a class="btn btn-default btn-sm" href="/app/employee/${encodeURIComponent(d.name)}" target="_blank">${__("Open employee")}</a>
			</div>`);
		this.$panel.find(".oc-close").on("click", () => { this.selected = null; this.render(); this.renderTray(); this.showPanel(null); });
		this.$panel.find("[data-act=remove]").on("click", () => this.confirmMove(d.name, null));
		this.$panel.find("[data-act=manager]").on("click", () => {
			const dlg = new frappe.ui.Dialog({
				title: __("Change manager of {0}", [d.employee_name]),
				fields: [{ fieldname: "manager", fieldtype: "Link", options: "Employee", label: __("Reports to"), reqd: 1,
					get_query: () => ({ filters: { status: "Active", name: ["!=", d.name] } }) }],
				primary_action_label: __("Change manager"),
				primary_action: ({ manager }) => { dlg.hide(); this.move(d.name, manager); },
			});
			dlg.show();
		});
		this.$panel.find("[data-act=hr]").on("click", () => this.branchHrDialog(d));
	}

	// Branch HR picker: chosen branches stay visible as removable chips (the
	// old MultiSelectList only said "3 values selected"), "+ Add branch"
	// opens a search over branches not yet chosen.
	branchHrDialog(d) {
		const esc = frappe.utils.escape_html;
		const chosen = new Set(d.hr_for || []);
		const split = (b) => {
			const i = b.indexOf(" - ");
			return i > 0 ? [b.slice(0, i), b.slice(i + 3)] : ["", b];
		};
		const dlg = new frappe.ui.Dialog({
			title: __("Branch HR: {0}", [d.employee_name]),
			size: "large",
			fields: [{ fieldname: "picker", fieldtype: "HTML" }],
			primary_action_label: __("Save"),
			primary_action: async () => {
				dlg.hide();
				const saved = await this.call("set_branch_hr", { employee: d.name, branches: JSON.stringify([...chosen]) }, true);
				frappe.show_alert({ message: saved.length ? __("Branch HR saved") : __("Removed from all branches"), indicator: "green" });
				this.select(d.name);
			},
		});
		const $w = $(`
			<div class="oc-hrsel">
				<p class="oc-hrsel-intro">${__("Requests from these branches can be seen and approved by {0}.", [`<b>${esc(d.employee_name)}</b>`])}</p>
				<div class="oc-hrsel-head">
					<span class="oc-hrsel-count"></span>
					<button type="button" class="oc-hrsel-clear">${__("Remove all")}</button>
				</div>
				<div class="oc-hrsel-chips"></div>
				<button type="button" class="oc-hrsel-add">
					<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3v10M3 8h10"/></svg>${__("Add branch")}
				</button>
				<div class="oc-hrsel-picker" hidden>
					<input type="search" class="oc-hrsel-search" placeholder="${__("Search by branch name or code")}" autocomplete="off">
					<div class="oc-hrsel-list" role="listbox"></div>
				</div>
			</div>`).appendTo(dlg.fields_dict.picker.$wrapper);
		const $picker = $w.find(".oc-hrsel-picker"), $search = $w.find(".oc-hrsel-search"), $list = $w.find(".oc-hrsel-list");

		const render = () => {
			const n = chosen.size;
			$w.find(".oc-hrsel-count").text(n ? __("{0} branches selected", [n]) : __("No branches yet"));
			$w.find(".oc-hrsel-clear").toggle(n > 1);
			$w.find(".oc-hrsel-chips").html(
				n
					? [...chosen].sort().map((b) => {
							const [code, label] = split(b);
							return `<span class="oc-hrsel-chip" title="${esc(b)}">${code ? `<b>${esc(code)}</b>` : ""}<span>${esc(label)}</span>
								<button type="button" data-remove="${esc(b)}" aria-label="${__("Remove {0}", [esc(b)])}">&times;</button></span>`;
						}).join("")
					: `<div class="oc-hrsel-empty">${__("Add the branches whose requests {0} should handle.", [esc(d.employee_name)])}</div>`
			);
			dlg.set_primary_action(n ? __("Save {0} branches", [n]) : __("Save (remove from all)"), dlg.primary_action);
			renderList();
		};
		const renderList = () => {
			const q = ($search.val() || "").trim().toLowerCase();
			const rows = this.meta.branches.filter((b) => !chosen.has(b) && (!q || b.toLowerCase().includes(q))).slice(0, 40);
			$list.html(
				rows.length
					? rows.map((b, i) => {
							const [code, label] = split(b);
							return `<button type="button" class="oc-hrsel-opt ${i === 0 ? "is-first" : ""}" data-add="${esc(b)}">${code ? `<b>${esc(code)}</b>` : ""}<span>${esc(label)}</span><i>+</i></button>`;
						}).join("")
					: `<div class="oc-hrsel-none">${q ? __("No branch matches “{0}”", [esc(q)]) : __("All branches are already added")}</div>`
			);
		};

		$w.on("click", "[data-remove]", (e) => { chosen.delete(e.currentTarget.dataset.remove); render(); });
		$w.on("click", "[data-add]", (e) => { chosen.add(e.currentTarget.dataset.add); render(); $search.trigger("focus"); });
		$w.find(".oc-hrsel-clear").on("click", () => { chosen.clear(); render(); });
		$w.find(".oc-hrsel-add").on("click", () => {
			$picker.prop("hidden", !$picker.prop("hidden"));
			if (!$picker.prop("hidden")) { $search.val(""); renderList(); $search.trigger("focus"); }
		});
		$search.on("input", renderList);
		$search.on("keydown", (e) => {
			if (e.key === "Enter") { e.preventDefault(); $list.find("[data-add]").first().trigger("click"); }
			if (e.key === "Escape") { e.stopPropagation(); $picker.prop("hidden", true); }
		});
		render();
		dlg.show();
	}
}

// Initials avatar (only 3 employees have photos) in a hue picked from the name.
function avatar(d, big) {
	const name = (d.employee_name || d.name || "?").trim();
	const initials = name.split(/\s+/).filter((w) => !/^(mr|ms|mrs|dr)\.?$/i.test(w)).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
	let h = 0;
	for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) % 360;
	const hue = 200 + (h % 70); // navy-blue-violet band
	const cls = big ? "oc-avatar oc-avatar-lg" : "oc-avatar";
	if (d.image) return `<span class="${cls}"><img src="${frappe.utils.escape_html(d.image)}" alt=""></span>`;
	return `<span class="${cls}" style="--h:${hue}" aria-hidden="true">${frappe.utils.escape_html(initials || "?")}</span>`;
}
