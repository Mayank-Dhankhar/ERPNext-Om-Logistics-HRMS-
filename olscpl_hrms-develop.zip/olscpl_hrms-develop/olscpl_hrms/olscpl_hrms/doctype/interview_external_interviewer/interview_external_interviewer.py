from frappe.model.document import Document


class InterviewExternalInterviewer(Document):
	pass
