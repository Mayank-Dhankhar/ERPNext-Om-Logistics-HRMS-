import frappe
from frappe.model.document import Document


class OnboardingEducationDetail(Document):
	pass
