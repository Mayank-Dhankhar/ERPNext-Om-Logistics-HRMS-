// olscpl_hrms/doctype/quick_bulk_update/quick_bulk_update.js
frappe.ui.form.on("Quick Bulk Update", {
	refresh(frm) {
		if (frm.doc.reference_doctype && !frm.is_new()) {
			frm.add_custom_button(__("Download Template"), () => download_template(frm));
		}

		if (frm.doc.import_file && frm.doc.reference_doctype && frm.doc.key_field && !frm.is_new()) {
			frm.add_custom_button(__("Validate File"), () => validate_file(frm));
			frm.add_custom_button(__("Run Import"), () => run_import(frm)).addClass(
				"btn-primary"
			);
		}

		if (["Success", "Partial Success", "Reverted"].includes(frm.doc.status)) {
			frm.add_custom_button(__("View Result"), () => view_result(frm));
		}
		if (["Success", "Partial Success"].includes(frm.doc.status)) {
			frm.add_custom_button(__("Revert Changes"), () => revert_changes(frm));
		}

		if (frm.doc.status === "Reverted") {
			frm.dashboard.set_headline_alert(
				"This update was reverted - see the Log section below for anything left as is.",
				"blue"
			);
		} else if (frm.doc.status === "Partial Success" || frm.doc.status === "Failed") {
			frm.dashboard.set_headline_alert(
				`${frm.doc.failed_rows} row(s) failed or were skipped - see the Log section below.`,
				"orange"
			);
		} else if (frm.doc.status === "Success") {
			frm.dashboard.set_headline_alert(
				`All ${frm.doc.updated_rows} row(s) updated successfully.`,
				"green"
			);
		}
	},
});

function download_template(frm) {
	// Reuse Data Import's own "Export Data" dialog/exporter verbatim (same
	// File Type / Export Type dropdowns, field picker, wording, and backend
	// template builder) instead of a hand-rolled clone - it works standalone
	// off just a doctype name, no actual Data Import record required. Its
	// downloaded headers ("ID" for name, each field's Label) are exactly
	// what run_import()/_resolve_header_to_fieldname() already expect.
	frappe.require("data_import_tools.bundle.js", () => {
		new frappe.data_import.DataExporter(frm.doc.reference_doctype, "Update Existing Records");
	});
}

function validate_file(frm) {
	frappe.dom.freeze(__("Checking file..."));
	frm.call("validate_file")
		.then((r) => {
			frappe.dom.unfreeze();
			if (!r.message) return;
			const d = r.message;

			let rows = [];
			if (!d.key_field_found) {
				rows.push(
					`<li class="text-danger">Key Field "<b>${frm.doc.key_field}</b>" was NOT found in the file's column headers.</li>`
				);
			} else {
				rows.push(`<li class="text-success">Key Field "<b>${frm.doc.key_field}</b>" found.</li>`);
			}
			d.matched_fields.forEach((f) => {
				rows.push(`<li class="text-success">"<b>${f}</b>" matches a real field on ${frm.doc.reference_doctype}.</li>`);
			});
			d.unmatched_fields.forEach((f) => {
				rows.push(
					`<li class="text-danger">"<b>${f}</b>" does NOT match any field on ${frm.doc.reference_doctype} - this column will be rejected if you run the import as-is.</li>`
				);
			});

			const all_ok = d.key_field_found && d.unmatched_fields.length === 0;
			frappe.msgprint({
				title: __("File Check"),
				indicator: all_ok ? "green" : "red",
				message: `<p>${d.total_data_rows} data row(s) found in the file.</p><ul>${rows.join("")}</ul>`,
			});
		})
		.catch(() => frappe.dom.unfreeze());
}

function run_import(frm) {
	frappe.confirm(
		__(
			"This will update {0} records directly using the settings above. If it goes wrong, use Revert Changes afterwards to put the previous values back. Continue?",
			[frm.doc.reference_doctype]
		),
		() => {
			frappe.dom.freeze(__("Running import..."));
			frm.call("run_import")
				.then((r) => {
					frappe.dom.unfreeze();
					if (!r.message) return;
					frm.reload_doc();
					frappe.msgprint({
						title: __("Import Finished"),
						indicator: r.message.failed_rows ? "orange" : "green",
						message: __(
							"Total rows: {0}<br>Matched existing records: {1}<br>Updated: {2}<br>Failed / skipped: {3}",
							[
								r.message.total_rows,
								r.message.matched_rows,
								r.message.updated_rows,
								r.message.failed_rows,
							]
						),
					});
				})
				.catch(() => frappe.dom.unfreeze());
		}
	);
}

function revert_changes(frm) {
	frappe.confirm(
		__(
			"This puts every {0} record this update changed back to its previous values. A record edited again since the update is left as is (listed in the Log). Continue?",
			[frm.doc.reference_doctype]
		),
		() => {
			frappe.dom.freeze(__("Reverting..."));
			frm.call("revert_changes")
				.then((r) => {
					frappe.dom.unfreeze();
					if (!r.message) return;
					frm.reload_doc();
					frappe.msgprint({
						title: __("Revert Finished"),
						indicator: r.message.skipped ? "orange" : "green",
						message: __("Reverted: {0}<br>Left as is: {1}", [r.message.reverted, r.message.skipped]),
					});
				})
				.catch(() => frappe.dom.unfreeze());
		}
	);
}

function view_result(frm) {
	frappe.dom.freeze(__("Loading changes..."));
	frm.call("get_changes")
		.then((r) => {
			frappe.dom.unfreeze();
			const { changes = [], title_label } = r.message || {};
			const esc = (v) => frappe.utils.escape_html(v === null || v === undefined || v === "" ? "-" : String(v));
			const was_reverted = frm.doc.status === "Reverted";
			const reverted = changes.filter((c) => c.reverted_to !== null && c.reverted_to !== undefined).length;
			const records = new Set(changes.map((c) => c.record)).size;

			const row = (c) => {
				const back = c.reverted_to !== null && c.reverted_to !== undefined;
				return `
				<tr data-search="${esc([c.record, c.title, c.field, c.old, c.new, back ? c.reverted_to : ""].join(" ").toLowerCase())}">
					<td>${esc(c.record)}</td>
					${title_label ? `<td>${esc(c.title)}</td>` : ""}
					<td>${esc(c.field)}</td>
					<td class="text-danger">${esc(c.old)}</td>
					<td class="text-success">${esc(c.new)}</td>
					${was_reverted ? `<td>${back ? `<span class="text-primary">${esc(c.reverted_to)}</span>` : `<span class="text-muted">${__("Not reverted")}</span>`}</td>` : ""}
				</tr>`;
			};

			const summary = __("{0} change(s) on {1} record(s)", [changes.length, records]) +
				(was_reverted ? ` · <b>${__("Reverted: {0} of {1}", [reverted, changes.length])}</b>` : "");

			const d = new frappe.ui.Dialog({
				title: __("Changes made by {0}", [frm.doc.name]),
				size: "extra-large",
				fields: [{ fieldtype: "HTML", fieldname: "result" }],
			});
			d.fields_dict.result.$wrapper.html(
				changes.length
					? `<p class="text-muted">${summary}</p>
					<input type="search" class="form-control mb-3 qbu-search" placeholder="${__("Search ID, name, field or value")}">
					<div style="max-height: 60vh; overflow: auto;">
						<table class="table table-bordered table-sm">
							<thead style="position: sticky; top: 0; background: var(--fg-color);"><tr>
								<th>${__("ID")}</th>
								${title_label ? `<th>${esc(__(title_label))}</th>` : ""}
								<th>${__("Field")}</th><th>${__("Old Value")}</th><th>${__("New Value")}</th>
								${was_reverted ? `<th>${__("Reverted To")}</th>` : ""}
							</tr></thead>
							<tbody>${changes.map(row).join("")}</tbody>
						</table>
					</div>`
					: `<p class="text-muted">${__("No recorded changes for this run.")}</p>`
			);
			d.$wrapper.find(".qbu-search").on("input", function () {
				const q = this.value.trim().toLowerCase();
				d.$wrapper.find("tbody tr").each(function () {
					$(this).toggle(!q || this.dataset.search.includes(q));
				});
			});
			d.show();
		})
		.catch(() => frappe.dom.unfreeze());
}
