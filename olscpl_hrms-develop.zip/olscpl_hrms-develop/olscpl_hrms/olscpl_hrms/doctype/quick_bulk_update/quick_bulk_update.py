# olscpl_hrms/doctype/quick_bulk_update/quick_bulk_update.py
#
# Fast alternative to the List View "Edit" bulk-edit feature (one HTTP
# request per record from the browser - ~40 min for ~7,000 Employees) and
# to Data Import (server-side, but still one full doc.save() - validate(),
# every doc_event hook, and a Version insert - per row).
#
# "Fast" mode instead runs one frappe.db.set_value() per matched row inside
# a single DB transaction, with a single commit at the end. That skips
# validate(), hooks (e.g. Employee's iam_sync/sync_username), and
# versioning entirely, which is what turns tens of minutes into single-digit
# seconds for a few thousand rows - it is only safe to use for fields that
# don't need those side effects to fire. "Safe" mode still exists for cases
# where the update DOES need validation/side effects: it goes through
# frappe.get_doc(...).save() per row, same as Data Import, just without the
# browser round-trip.
#
# Column headers in the file can be the raw fieldname (e.g. "custom_state"),
# the field's Label as shown in Desk (e.g. "State"), or "ID" for the record's
# own name - matching the exact headers Data Import's real "Export Data"
# dialog produces (frappe.data_import.DataExporter, reused as-is from
# quick_bulk_update.js instead of reimplemented), so a downloaded template
# always round-trips correctly.
import csv
import json

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils.xlsxutils import read_xlsx_file_from_attached_file


class QuickBulkUpdate(Document):
	@frappe.whitelist()
	def validate_file(self):
		"""Header-only check - reads the file and reports which column headers
		match real fields on reference_doctype and which don't, without
		writing anything. Lets the user catch a typo'd/renamed column before
		committing to Run Import."""
		frappe.only_for(("HR Manager", "System Manager"))
		self._check_common_setup()

		header, rows = self._read_and_resolve_header()

		key_field_found = any(resolved == self._resolved_key_field() for _i, _h, resolved in header)
		other_columns = [(h, resolved) for _i, h, resolved in header if resolved != self._resolved_key_field()]
		valid_fields = self._get_valid_fieldnames()
		matched = [h for h, resolved in other_columns if resolved in valid_fields]
		unmatched = [h for h, resolved in other_columns if resolved not in valid_fields]

		return {
			"key_field_found": key_field_found,
			"columns_in_file": [h for _i, h, _r in header],
			"matched_fields": matched,
			"unmatched_fields": unmatched,
			"total_data_rows": len(rows) - 1,
		}

	@frappe.whitelist()
	def run_import(self):
		frappe.only_for(("HR Manager", "System Manager"))
		self._check_common_setup()

		header, rows = self._read_and_resolve_header()
		resolved_key_field = self._resolved_key_field()

		key_matches = [(i, h) for i, h, resolved in header if resolved == resolved_key_field]
		if not key_matches:
			frappe.throw(
				_("Key Field '{0}' was not found in the file's column headers: {1}").format(
					self.key_field, ", ".join(h for _i, h, _r in header)
				)
			)
		key_idx = key_matches[0][0]

		update_field_idxs = [(i, resolved) for i, h, resolved in header if resolved != resolved_key_field]
		if not update_field_idxs:
			frappe.throw(_("File has a key column but no other columns to update"))

		valid_fields = self._get_valid_fieldnames()
		unmatched = [h for _i, h, resolved in header if resolved != resolved_key_field and resolved not in valid_fields]
		if unmatched:
			frappe.throw(
				_(
					"These column headers don't match any field (or Label) on {0}, so nothing was "
					"updated: {1}. Use the Download Template button to get exact column names, fix the "
					"file, and try again."
				).format(self.reference_doctype, ", ".join(unmatched))
			)

		updates = {}
		for row in rows[1:]:
			if not row or key_idx >= len(row) or row[key_idx] in (None, ""):
				continue
			key_val = str(row[key_idx]).strip()
			row_data = {}
			for i, fieldname in update_field_idxs:
				value = row[i] if i < len(row) else None
				row_data[fieldname] = "" if value is None else value
			updates[key_val] = row_data

		total_rows = len(updates)
		if not total_rows:
			frappe.throw(_("No usable rows found - every row was missing a value in the Key Field column"))

		update_fieldnames = [fieldname for _i, fieldname in update_field_idxs]
		fetch_fields = list(dict.fromkeys(["name", resolved_key_field, *update_fieldnames]))
		filters = {resolved_key_field: ["in", list(updates.keys())]}
		if self.match_field:  # e.g. Salary Component = Conveyance: only those records
			match_field = self._resolve_header_to_fieldname(self.match_field)
			if match_field not in self._get_valid_fieldnames():
				frappe.throw(_("'Only Where' field {0} is not a field of {1}").format(self.match_field, self.reference_doctype))
			match_value = self.match_value
			df = frappe.get_meta(self.reference_doctype).get_field(match_field)
			if df and df.fieldtype in ("Date", "Datetime") and match_value:
				# typed as shown in the app ("01-08-2026"); the database holds 2026-08-01
				day_first = (frappe.db.get_default("date_format") or "").startswith("dd") and not str(match_value)[:4].isdigit()
				match_value = frappe.utils.getdate(match_value, parse_day_first=day_first)
			filters[match_field] = match_value
		if frappe.get_meta(self.reference_doctype).is_submittable:
			filters["docstatus"] = ["<", 2]  # cancelled ones are never the record to update
		existing = frappe.get_all(self.reference_doctype, filters=filters, fields=fetch_fields)
		# a non-unique key (e.g. Employee on Salary Structure Assignment) can match
		# several records - refuse those rows rather than update an arbitrary one
		key_to_names = {}
		for row in existing:
			key_to_names.setdefault(
				row.name if resolved_key_field == "name" else str(row.get(resolved_key_field)), []
			).append(row.name)
		key_to_name = {k: v[0] for k, v in key_to_names.items() if len(v) == 1}
		old_values_by_name = {row.name: row for row in existing}

		updater_reference = {
			"doctype": self.doctype,
			"docname": self.name,
			"label": _("via Quick Bulk Update"),
		}

		errors = []
		updated = 0
		fast_mode = self.update_mode == "Fast (Direct Update)"

		for key_val, fields in updates.items():
			docname = key_to_name.get(key_val)
			if not docname and len(key_to_names.get(key_val, [])) > 1:
				errors.append({
					"key": key_val,
					"error": "Matches {0} records ({1}) - use a unique Key Field such as ID".format(
						len(key_to_names[key_val]), ", ".join(key_to_names[key_val][:5])
					),
				})
				continue
			if not docname:
				errors.append({"key": key_val, "error": "No matching record found"})
				continue
			try:
				if fast_mode:
					frappe.db.set_value(
						self.reference_doctype, docname, fields, update_modified=False
					)
					# frappe.db.set_value() bypasses doc.save() entirely, so it
					# never creates the Version record that powers the
					# Activity/timeline "You changed X from A to B" entries -
					# recreate that manually so Fast Mode still leaves an
					# audit trail, same as Safe Mode/Data Import would.
					self._record_version(
						docname, old_values_by_name.get(docname), fields, updater_reference
					)
				else:
					doc = frappe.get_doc(self.reference_doctype, docname)
					doc.flags.updater_reference = updater_reference
					doc.update(fields)
					doc.save()
				updated += 1
			except Exception as e:
				frappe.db.rollback()
				errors.append({"key": key_val, "error": str(e)})

		frappe.db.commit()

		self.total_rows = total_rows
		self.matched_rows = len(key_to_name)
		self.updated_rows = updated
		self.failed_rows = len(errors)
		self.result_log = json.dumps(errors, indent=2) if errors else ""
		if updated == total_rows:
			self.status = "Success"
		elif updated:
			self.status = "Partial Success"
		else:
			self.status = "Failed"
		self.save(ignore_permissions=True)

		return {
			"total_rows": self.total_rows,
			"matched_rows": self.matched_rows,
			"updated_rows": self.updated_rows,
			"failed_rows": self.failed_rows,
			"status": self.status,
		}

	@frappe.whitelist()
	def get_changes(self):
		"""Every field this run changed, from its Version entries: record,
		its title (e.g. employee name), field label, old and new value - and,
		once the run is reverted, the value the revert put back on that same
		row (reverted_to; None where the revert left the record as is)."""
		frappe.only_for(("HR Manager", "System Manager"))
		meta = frappe.get_meta(self.reference_doctype)
		versions = frappe.get_all(
			"Version",
			filters={"ref_doctype": self.reference_doctype, "data": ["like", f"%{self.name}%"]},
			fields=["docname", "data", "creation"],
			order_by="creation asc",
		)
		changes, by_key = [], {}
		for v in versions:
			data = json.loads(v.data)
			ref = data.get("updater_reference") or {}
			if ref.get("doctype") != self.doctype or ref.get("docname") != self.name:
				continue
			is_revert = ref.get("label") == _("Revert of Quick Bulk Update")
			for fieldname, old, new in data.get("changed") or []:
				key = (v.docname, fieldname)
				if is_revert:
					if key in by_key:
						by_key[key]["reverted_to"] = new
					continue
				if key in by_key:  # first entry per field is this run's own change
					continue
				by_key[key] = {"record": v.docname, "field": meta.get_label(fieldname), "old": old, "new": new, "reverted_to": None}
				changes.append(by_key[key])
		title_field = meta.title_field if meta.title_field and meta.title_field != "name" else None
		if title_field and changes:
			titles = dict(frappe.get_all(
				self.reference_doctype,
				filters={"name": ["in", list({c["record"] for c in changes})]},
				fields=["name", title_field],
				as_list=True,
			))
			for c in changes:
				c["title"] = titles.get(c["record"])
		return {"changes": changes, "title_label": meta.get_label(title_field) if title_field else None}

	@frappe.whitelist()
	def revert_changes(self):
		"""Undo this run: every record it changed gets the file's fields put
		back to the values they had before, read from the Version entries the
		run left (both modes tag them with this record as updater_reference).
		A record changed again since then is skipped and logged, not
		overwritten. Uses the run's own mode; leaves its own Version entries."""
		frappe.only_for(("HR Manager", "System Manager"))
		if self.status == "Reverted":
			frappe.throw(_("This update has already been reverted"))
		if self.status not in ("Success", "Partial Success"):
			frappe.throw(_("Only a run that updated records can be reverted"))

		versions = frappe.get_all(
			"Version",
			filters={"ref_doctype": self.reference_doctype, "data": ["like", f"%{self.name}%"]},
			fields=["docname", "data"],
			order_by="creation asc",
		)
		# only the file's own columns - a Safe save's Version can also list
		# fields its validate()/hooks changed on the side
		header, _rows = self._read_and_resolve_header()
		file_fields = {resolved for _i, _h, resolved in header if resolved != self._resolved_key_field()}

		restore = {}  # docname -> {fieldname: (old, new)}; first entry per field wins
		for v in versions:
			data = json.loads(v.data)
			ref = data.get("updater_reference") or {}
			if ref.get("doctype") != self.doctype or ref.get("docname") != self.name:
				continue
			for fieldname, old, new in data.get("changed") or []:
				if fieldname in file_fields:
					restore.setdefault(v.docname, {}).setdefault(fieldname, (old, new))
		if not restore:
			frappe.throw(_("No changes from this run were found to revert"))

		current = {
			row.name: row
			for row in frappe.get_all(
				self.reference_doctype,
				filters={"name": ["in", list(restore)]},
				fields=["name", *sorted({f for fields in restore.values() for f in fields})],
			)
		}
		updater_reference = {"doctype": self.doctype, "docname": self.name, "label": _("Revert of Quick Bulk Update")}
		fast_mode = self.update_mode == "Fast (Direct Update)"
		reverted, skipped = 0, []
		for docname, fields in restore.items():
			row = current.get(docname)
			if not row:
				skipped.append({"key": docname, "error": "Record no longer exists"})
				continue
			edited = [f for f, (_old, new) in fields.items() if str(row.get(f) or "") != str(new or "")]
			if edited:
				skipped.append({"key": docname, "error": f"Changed again since this run ({', '.join(edited)}) - left as is"})
				continue
			old_values = {f: old for f, (old, _new) in fields.items()}
			frappe.db.savepoint("qbu_revert")
			try:
				if fast_mode:
					frappe.db.set_value(self.reference_doctype, docname, old_values, update_modified=False)
					self._record_version(docname, row, old_values, updater_reference)
				else:
					doc = frappe.get_doc(self.reference_doctype, docname)
					doc.flags.updater_reference = updater_reference
					doc.update(old_values)
					doc.save()
				reverted += 1
			except Exception as e:
				frappe.db.rollback(save_point="qbu_revert")  # just this record
				skipped.append({"key": docname, "error": str(e)})

		frappe.db.commit()
		self.status = "Reverted"
		self.result_log = json.dumps({"reverted": reverted, "skipped": skipped}, indent=2)
		self.save(ignore_permissions=True)
		return {"reverted": reverted, "skipped": len(skipped)}

	def _record_version(self, docname, old_row, new_fields, updater_reference):
		"""Manually write the Version entry that a normal doc.save() would
		have produced, for a Fast Mode update. Only fields that actually
		changed value are recorded, matching Data Import's own
		change-detection - a no-op re-upload of the same values won't spam
		the Activity timeline with empty entries. Values are compared as
		strings since the file always supplies strings while the DB returns
		native types (dates, ints, etc.) - good enough for the plain text/
		select/link fields this tool is meant for."""
		changed = []
		for fieldname, new_value in new_fields.items():
			old_value = old_row.get(fieldname) if old_row else None
			if str(old_value or "") != str(new_value or ""):
				changed.append([fieldname, old_value, new_value])

		if not changed:
			return

		frappe.get_doc(
			{
				"doctype": "Version",
				"ref_doctype": self.reference_doctype,
				"docname": docname,
				"data": frappe.as_json(
					{
						"changed": changed,
						"added": [],
						"removed": [],
						"row_changed": [],
						"data_import": None,
						"updater_reference": updater_reference,
					},
					indent=None,
					separators=(",", ":"),
				),
			}
		).insert(ignore_permissions=True)

	def _check_common_setup(self):
		if not self.import_file:
			frappe.throw(_("Attach a file first"))
		if not self.reference_doctype:
			frappe.throw(_("Select the doctype to update"))
		if not self.key_field:
			frappe.throw(_("Set the Key Field"))
		if not frappe.has_permission(self.reference_doctype, "write"):
			frappe.throw(_("Not permitted to update {0}").format(self.reference_doctype), frappe.PermissionError)

	def _resolved_key_field(self):
		return self._resolve_header_to_fieldname(self.key_field)

	def _resolve_header_to_fieldname(self, header_value, meta=None):
		"""A column header may be the exact fieldname (power-user path,
		unchanged from before), the field's Label as shown in Desk and in a
		downloaded template (e.g. "State" -> custom_state), or "ID" for the
		record's own name - same three forms Data Import's own template
		export/import accepts."""
		if not header_value:
			return header_value
		value = header_value.strip()
		if value.lower() == "id":
			return "name"

		meta = meta or frappe.get_meta(self.reference_doctype)
		field = meta.get_field(value)
		if field:
			return field.fieldname

		for df in meta.fields:
			if (df.label or "").strip().lower() == value.lower():
				return df.fieldname

		return value

	def _get_valid_fieldnames(self):
		"""Fieldnames that are actually safe to set on reference_doctype:
		every DB column (meta.fields, skipping Table/child fields which
		aren't plain columns) plus the handful of standard Document fields
		that aren't in meta.fields but are still real columns (name itself,
		docstatus, owner, etc.)."""
		meta = frappe.get_meta(self.reference_doctype)
		fieldnames = {
			df.fieldname
			for df in meta.fields
			if df.fieldtype not in frappe.model.table_fields
		}
		fieldnames.update({"name", "owner", "docstatus"})
		return fieldnames

	def _read_and_resolve_header(self):
		"""Returns ([(index, raw_header_text, resolved_fieldname), ...], rows)
		for the file's header row (skipping blank columns) and the full parsed
		file, so callers don't need to read the file twice."""
		rows = self._read_file()
		if not rows or len(rows) < 2:
			frappe.throw(_("File has no data rows"))

		meta = frappe.get_meta(self.reference_doctype)
		header = []
		for i, h in enumerate(rows[0]):
			h = str(h).strip() if h is not None else ""
			if not h:
				continue
			header.append((i, h, self._resolve_header_to_fieldname(h, meta)))
		return header, rows

	def _read_file(self):
		file_doc = frappe.get_doc("File", {"file_url": self.import_file})
		path = file_doc.get_full_path()
		if path.lower().endswith(".csv"):
			with open(path, newline="", encoding="utf-8-sig") as f:
				return list(csv.reader(f))
		return read_xlsx_file_from_attached_file(file_url=self.import_file)
