# Copyright (c) 2026, OLSCPL and contributors
# Child table of Branch (custom_branch_hrs): the HR people responsible for a
# branch - set from the Org Chart page.
from frappe.model.document import Document


class BranchHR(Document):
	pass
