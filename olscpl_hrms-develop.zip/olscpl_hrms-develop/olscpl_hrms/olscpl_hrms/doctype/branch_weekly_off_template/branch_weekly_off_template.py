import frappe
from frappe.model.document import Document


class BranchWeeklyOffTemplate(Document):
	def validate(self):
		if not self.default_off_day:
			frappe.throw("Default Off Day is required")

		# Monday check -- keeps week_start_date consistent with
		# Shift Assignment's own Mon-Sun convention
		if frappe.utils.getdate(self.week_start_date).strftime("%A") != "Monday":
			frappe.throw("Week Start Date must be a Monday")


@frappe.whitelist()
def generate_employee_roster(template_name):
	template = frappe.get_doc("Branch Weekly Off Template", template_name)

	# Only pull employees who follow the branch's rotating pattern
	employees = frappe.get_all(
		"Employee",
		filters={
			"branch": template.branch,
			"status": "Active",
			"weekly_off_type": "Branch Rotational",
		},
		pluck="name",
	)

	updated = []
	skipped_no_shift = []

	for emp in employees:
		shift_name = frappe.db.get_value(
			"Shift Assignment",
			{
				"employee": emp,
				"start_date": template.week_start_date,
				"docstatus": ["!=", 2],
			},
			"name",
		)
		if shift_name:
			frappe.db.set_value(
				"Shift Assignment", shift_name, "weekly_off_day", template.default_off_day
			)
			updated.append(emp)
		else:
			skipped_no_shift.append(emp)

	if skipped_no_shift:
		frappe.log_error(
			title="Weekly Off Roster - Missing Shift Assignment",
			message=(
				f"Branch: {template.branch}, Week: {template.week_start_date}\n"
				f"Employees with no Shift Assignment for this week: {skipped_no_shift}"
			),
		)

	template.generated = 1
	template.save(ignore_permissions=True)
	frappe.db.commit()

	return {
		"updated_count": len(updated),
		"skipped_count": len(skipped_no_shift),
		"skipped_employees": skipped_no_shift,
	}