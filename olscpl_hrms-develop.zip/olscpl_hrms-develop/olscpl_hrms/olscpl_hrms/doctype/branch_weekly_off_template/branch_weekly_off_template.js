frappe.ui.form.on("Branch Weekly Off Template", {
	refresh(frm) {
		if (frm.doc.docstatus === 0 && !frm.is_new()) {
			frm.add_custom_button("Generate Employee Roster", () => {
				frappe.call({
					method: "olscpl_hrms.olscpl_hrms.doctype.branch_weekly_off_template.branch_weekly_off_template.generate_employee_roster",
					args: { template_name: frm.doc.name },
					freeze: true,
					freeze_message: "Generating roster...",
					callback: (r) => {
						if (r.message) {
							frappe.msgprint({
								title: "Roster Generated",
								message: `Updated: ${r.message.updated_count} employees.<br>
									Skipped (no Shift Assignment): ${r.message.skipped_count}`,
								indicator: r.message.skipped_count ? "orange" : "green",
							});
							frm.reload_doc();
						}
					},
				});
			});
		}
	},
});