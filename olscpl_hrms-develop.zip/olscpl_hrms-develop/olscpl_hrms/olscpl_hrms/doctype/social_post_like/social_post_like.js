// Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd. and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Social Post Like", {
// 	refresh(frm) {

// 	},
// });
