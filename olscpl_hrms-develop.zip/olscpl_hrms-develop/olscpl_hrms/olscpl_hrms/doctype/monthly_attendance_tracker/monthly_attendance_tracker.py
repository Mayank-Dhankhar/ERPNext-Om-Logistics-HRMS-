# Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd. and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class MonthlyAttendanceTracker(Document):
	pass
