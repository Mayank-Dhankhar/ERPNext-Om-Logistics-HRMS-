# Copyright (c) 2026, OM Logistics and contributors
# For license information, please see license.txt
import frappe
from frappe import _
from frappe.model.document import Document


class EmployeeSeparationClearance(Document):
	def validate(self):
		if self.status == "Cleared" and not self.cleared_on:
			self.cleared_on = frappe.utils.now_datetime()
		if self.status == "Pending":
			self.cleared_on = None

		self._enforce_approver_only_edit()

	def _enforce_approver_only_edit(self):
		"""has_permission (registered in hooks.py) already gates who can
		open/save this doc at all - this is a belt-and-suspenders check on
		the two fields that actually matter (status and the approver's own
		remarks), same defensive style as the rest of this app: don't rely
		solely on a permission hook running correctly to protect a real
		workflow action. In particular this is what stops the resigning
		employee themselves from clearing their own stage or editing an
		approver's remarks - has_permission only gates write at the whole
		-document level, not per field."""
		user = frappe.session.user
		if user == "Administrator":
			return
		if frappe.db.exists("Has Role", {"parent": user, "role": "HR Manager"}):
			return

		if self.is_new():
			return

		before = frappe.db.get_value(self.doctype, self.name, ["status", "remarks"], as_dict=True)
		if before.status == self.status and (before.remarks or "") == (self.remarks or ""):
			return

		approver_user = frappe.db.get_value("Employee", self.approver, "user_id")
		if user != approver_user:
			frappe.throw(
				_("Only the assigned approver ({0}) or HR can update this clearance stage.").format(
					self.approver
				),
				frappe.PermissionError,
			)
