import frappe
from frappe import _
from frappe.model.document import Document


class BackgroundVerification(Document):
	def on_submit(self):
		if self.status not in ("Cleared", "Flagged"):
			frappe.throw(_("Only a Background Verification marked Cleared or Flagged can be submitted."))
