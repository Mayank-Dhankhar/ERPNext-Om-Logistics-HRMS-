import frappe
from frappe.model.document import Document


class CompanyStateRegistration(Document):
	pass
