import frappe
from frappe.model.document import Document


class BulkSalaryStructureUploadItem(Document):
	pass
