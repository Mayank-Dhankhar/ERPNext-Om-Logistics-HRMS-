import frappe
from frappe.model.document import Document


class BulkSalaryStructureUpload(Document):
	pass
