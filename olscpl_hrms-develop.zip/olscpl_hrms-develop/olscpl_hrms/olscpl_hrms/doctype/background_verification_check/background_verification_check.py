import frappe
from frappe.model.document import Document


class BackgroundVerificationCheck(Document):
	pass
