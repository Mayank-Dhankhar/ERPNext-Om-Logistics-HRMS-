import frappe
from frappe.model.document import Document


class OnboardingEPFNominee(Document):
	pass
