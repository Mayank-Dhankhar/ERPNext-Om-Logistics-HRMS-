# Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd. and contributors
# For license information, please see license.txt
#
# FBP Declaration - an OSBS (RapidShyp) employee's yearly split of their Flexi
# Benefit bucket (the gross left after Basic and HRA). See utils/fbp_slabs.py for the slabs and
# patches/v1_1/setup_osbs_flexi_structure.py for how the split is paid.
#
# Submit copies the chosen amounts onto the employee's Salary Structure
# Assignment (fbp_* fields); cancel zeroes them again. The salary slip formulas
# read them from there.
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt

from olscpl_hrms.utils.fbp_slabs import (
	COMPONENT_FIELD_MAP,
	FLEXI_SALARY_STRUCTURE,
	MIN_FLEXI_GROSS,
	TOTAL_FIELD,
	get_fbp_bucket,
	get_fbp_entitlements,
	get_monthly_pool,
	monthly_amount,
)


class FBPDeclaration(Document):
	def before_validate(self):
		self.set_assignment_details()
		self.populate_items()

	def validate(self):
		self.validate_company_enabled()
		self.validate_duplicate()
		self.apply_entitlements_and_totals()
		self.validate_proof()

	def set_assignment_details(self):
		if not self.salary_structure_assignment:
			return
		ssa = frappe.db.get_value(
			"Salary Structure Assignment",
			self.salary_structure_assignment,
			["base", "employee", "company", "salary_structure", "docstatus"],
			as_dict=True,
		)
		if not ssa:
			frappe.throw(_("Salary Structure Assignment {0} not found.").format(self.salary_structure_assignment))
		if ssa.employee != self.employee:
			frappe.throw(_("The Salary Structure Assignment does not belong to this employee."))
		if ssa.docstatus != 1:
			frappe.throw(_("The Salary Structure Assignment must be submitted."))
		if ssa.salary_structure != FLEXI_SALARY_STRUCTURE:
			frappe.throw(
				_("The Salary Structure Assignment is on {0}; it must be on {1}.").format(
					ssa.salary_structure, FLEXI_SALARY_STRUCTURE
				)
			)
		if self.company and ssa.company != self.company:
			frappe.throw(_("The Salary Structure Assignment belongs to a different company."))
		if flt(ssa.base) < MIN_FLEXI_GROSS:
			frappe.throw(
				_("The Flexi Benefit Plan is only for a monthly gross of {0} or more.").format(MIN_FLEXI_GROSS)
			)
		self.gross = ssa.base

	def populate_items(self):
		present = {row.component for row in self.items}
		for component in COMPONENT_FIELD_MAP:
			if component not in present:
				self.append("items", {"component": component, "opted_amount": 0})

	def validate_company_enabled(self):
		if not frappe.db.get_value("Company", self.company, "enable_fbp"):
			frappe.throw(_("Flexi Benefit Plan is not enabled for {0}.").format(self.company))

	def validate_duplicate(self):
		existing = frappe.db.exists(
			"FBP Declaration",
			{
				"employee": self.employee,
				"fiscal_year": self.fiscal_year,
				"docstatus": ["<", 2],
				"name": ["!=", self.name or ""],
			},
		)
		if existing:
			frappe.throw(
				_("FBP Declaration {0} already exists for {1} in {2}. Cancel it first to make a new one.").format(
					existing, self.employee, self.fiscal_year
				)
			)

	def apply_entitlements_and_totals(self):
		entitlements = get_fbp_entitlements(self.gross)
		self.fbp_total = get_fbp_bucket(self.gross)

		seen = set()
		total = 0
		for row in self.items:
			if row.component not in entitlements:
				frappe.throw(_("Row {0}: {1} is not an FBP component.").format(row.idx, row.component))
			if row.component in seen:
				frappe.throw(_("Row {0}: {1} is listed twice.").format(row.idx, row.component))
			seen.add(row.component)

			row.entitlement = entitlements[row.component]
			opted = flt(row.opted_amount)
			if opted < 0 or opted > flt(row.entitlement):
				frappe.throw(
					_("Row {0}: {1} must be between 0 and {2}.").format(
						row.idx, row.component, frappe.format_value(row.entitlement, {"fieldtype": "Currency"})
					)
				)
			total += opted

		self.total_opted = total
		if total > flt(self.fbp_total):
			frappe.throw(
				_("Total chosen {0} is more than the FBP bucket {1} (gross less Basic and HRA, for the year).").format(
					frappe.format_value(total, {"fieldtype": "Currency"}),
					frappe.format_value(self.fbp_total, {"fieldtype": "Currency"}),
				)
			)

		# The slip pays each benefit as chosen / 12 to the rupee and Special
		# Allowance takes the rest - so the rounded monthly amounts must still
		# fit in the monthly pool, or Special Allowance would go negative.
		monthly_total = sum(monthly_amount(row.opted_amount) for row in self.items)
		monthly_pool = get_monthly_pool(self.gross)
		if monthly_total > monthly_pool:
			frappe.throw(
				_("Rounded to whole rupees a month, the chosen amounts come to {0}, more than the {1} left after Basic and HRA. Reduce one of them slightly.").format(
					frappe.format_value(monthly_total, {"fieldtype": "Currency"}),
					frappe.format_value(monthly_pool, {"fieldtype": "Currency"}),
				)
			)
		self.balance_taxable = flt(self.fbp_total) - total

	def validate_proof(self):
		"""Proof status is set by HR after submit (bills received). Only a
		Verified row carries an exempt amount, never more than was chosen."""
		for row in self.items:
			if row.proof_status == "Verified":
				if not flt(row.verified_amount):
					row.verified_amount = flt(row.opted_amount)
				if flt(row.verified_amount) > flt(row.opted_amount):
					frappe.throw(
						_("Row {0}: Verified Amount cannot be more than the chosen amount {1}.").format(
							row.idx, frappe.format_value(row.opted_amount, {"fieldtype": "Currency"})
						)
					)
			else:
				row.verified_amount = 0

	def on_submit(self):
		self.push_to_assignment(reset=False)

	def on_cancel(self):
		self.push_to_assignment(reset=True)

	def push_to_assignment(self, reset):
		values = {fieldname: 0 for fieldname in COMPONENT_FIELD_MAP.values()}
		values[TOTAL_FIELD] = 0
		if not reset:
			for row in self.items:
				values[COMPONENT_FIELD_MAP[row.component]] = flt(row.opted_amount)
			values[TOTAL_FIELD] = flt(self.total_opted)
		frappe.db.set_value(
			"Salary Structure Assignment",
			self.salary_structure_assignment,
			values,
			update_modified=False,
		)
