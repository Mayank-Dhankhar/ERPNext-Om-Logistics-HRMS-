// Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd. and contributors
// For license information, please see license.txt
//
// FBP Declaration form (RapidShyp / OSBS). Picking the employee picks their
// Salary Structure Assignment on the flexi structure; that fills the 9
// component rows with each one's yearly maximum (api/fbp.py). The server
// (fbp_declaration.py) re-checks every number on save - this only makes the
// form friendlier.

const FLEXI_STRUCTURE = "OSBS Flexi Benefit Structure"; // utils/fbp_slabs.py

frappe.ui.form.on("FBP Declaration", {
	setup(frm) {
		frm.set_query("salary_structure_assignment", () => ({
			filters: {
				employee: frm.doc.employee,
				salary_structure: FLEXI_STRUCTURE,
				docstatus: 1,
			},
		}));
	},

	refresh(frm) {
		if (frm.doc.docstatus === 0) {
			frm.set_intro(
				__("Enter the yearly amount for each benefit (up to its maximum). Whatever is not chosen is paid as Special Allowance (taxable)."),
				"blue"
			);
		}
	},

	async employee(frm) {
		if (!frm.doc.employee || frm.doc.docstatus !== 0) return;
		const rows = await frappe.db.get_list("Salary Structure Assignment", {
			filters: {
				employee: frm.doc.employee,
				salary_structure: FLEXI_STRUCTURE,
				docstatus: 1,
			},
			fields: ["name"],
			order_by: "from_date desc",
			limit: 1,
		});
		if (rows.length) {
			await frm.set_value("salary_structure_assignment", rows[0].name);
		} else {
			frm.set_value("salary_structure_assignment", null);
			frappe.msgprint(__("This employee has no submitted Salary Structure Assignment on {0}.", [FLEXI_STRUCTURE]));
		}
	},

	salary_structure_assignment(frm) {
		if (!frm.doc.salary_structure_assignment || frm.doc.docstatus !== 0) return;
		frappe.call({
			method: "olscpl_hrms.api.fbp.get_entitlements",
			args: { salary_structure_assignment: frm.doc.salary_structure_assignment },
			callback(r) {
				const d = r.message;
				if (!d) return;
				frm.set_value("gross", d.gross);
				frm.set_value("fbp_total", d.fbp_total);
				frm.clear_table("items");
				d.entitlements.forEach((e) => {
					const row = frm.add_child("items");
					row.component = e.component;
					row.entitlement = e.entitlement;
					row.opted_amount = 0;
				});
				frm.refresh_field("items");
				recalc_totals(frm);
			},
		});
	},
});

frappe.ui.form.on("FBP Declaration Item", {
	opted_amount(frm, cdt, cdn) {
		const row = locals[cdt][cdn];
		if (flt(row.opted_amount) > flt(row.entitlement)) {
			frappe.show_alert({
				message: __("{0}: maximum is {1}", [row.component, format_currency(row.entitlement)]),
				indicator: "orange",
			});
			frappe.model.set_value(cdt, cdn, "opted_amount", row.entitlement);
		}
		recalc_totals(frm);
	},
});

function recalc_totals(frm) {
	let total = 0;
	(frm.doc.items || []).forEach((r) => (total += flt(r.opted_amount)));
	frm.set_value("total_opted", total);
	frm.set_value("balance_taxable", flt(frm.doc.fbp_total) - total);
}
