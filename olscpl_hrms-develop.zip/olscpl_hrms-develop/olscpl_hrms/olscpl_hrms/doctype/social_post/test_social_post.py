# Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd. and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSocialPost(FrappeTestCase):
	pass
