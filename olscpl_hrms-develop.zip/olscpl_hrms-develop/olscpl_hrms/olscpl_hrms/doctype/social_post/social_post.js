// Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd. and contributors
// For license information, please see license.txt

frappe.ui.form.on("Social Post", {
	refresh(frm) {
		// The web composer (social-feed page) already has its own dedicated
		// image/attachment upload UI, so the Content field's built-in Quill
		// "image" button here in Desk would just be a second, redundant way
		// to embed images (and one that bypasses the composer's image/
		// attachment size limits). Drop it from the toolbar.
		//
		// Patching df.get_toolbar_options (the hook the control checks
		// before building its toolbar) doesn't work here: by the time any
		// client-script event fires, frm.fields already exist - the Quill
		// toolbar for this field was built from its own copy of the docfield
		// before any of our code runs. So instead we just remove the
		// already-rendered button from the DOM; harmless to call on every
		// refresh since a missing element is a no-op.
		var content_field = frm.get_field("content");
		if (content_field && content_field.$wrapper) {
			content_field.$wrapper.find(".ql-toolbar button.ql-image").remove();
		}
	},
});
