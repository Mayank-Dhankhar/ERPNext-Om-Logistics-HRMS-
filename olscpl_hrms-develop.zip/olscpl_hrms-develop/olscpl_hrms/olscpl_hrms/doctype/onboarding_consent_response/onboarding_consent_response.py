import frappe
from frappe.model.document import Document


class OnboardingConsentResponse(Document):
	pass
