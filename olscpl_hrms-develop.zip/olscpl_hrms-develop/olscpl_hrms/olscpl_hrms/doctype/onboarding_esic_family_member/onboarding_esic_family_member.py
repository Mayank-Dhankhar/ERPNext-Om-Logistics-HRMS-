import frappe
from frappe.model.document import Document


class OnboardingESICFamilyMember(Document):
	pass
