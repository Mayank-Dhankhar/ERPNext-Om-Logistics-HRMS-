import frappe
from frappe.model.document import Document


class OnboardingReference(Document):
	pass
