import frappe
from frappe.model.document import Document


class OnboardingEmploymentHistory(Document):
	pass
