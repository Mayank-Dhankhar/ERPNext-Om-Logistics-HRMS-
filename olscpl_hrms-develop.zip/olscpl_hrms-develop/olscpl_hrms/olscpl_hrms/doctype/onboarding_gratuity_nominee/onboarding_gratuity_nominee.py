import frappe
from frappe.model.document import Document


class OnboardingGratuityNominee(Document):
	pass
