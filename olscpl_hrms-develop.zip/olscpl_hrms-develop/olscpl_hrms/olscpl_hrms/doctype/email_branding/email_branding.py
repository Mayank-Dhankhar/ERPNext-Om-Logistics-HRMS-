# Email Branding - header / colours / sign-off / footer, per company, for
# Notifications made in the UI with "Use company email template"
# (utils/email_layout.render_branded). One Default for every company
# without its own. The built-in HR mails keep their own templates.
import frappe
from frappe import _
from frappe.model.document import Document


class EmailBranding(Document):
	def validate(self):
		if self.is_default:
			self.company = None
			other = frappe.db.get_value("Email Branding", {"is_default": 1, "name": ["!=", self.name]})
			if other:
				frappe.throw(_("{0} is already the Default branding. Untick it there first.").format(other))
		elif not self.company:
			frappe.throw(_("Choose a Company, or tick Default."))
		if self.header_style == "Banner Image" and not self.header_image:
			frappe.throw(_("Attach the Banner Image."))
		if self.header_style == "Logo on Colour" and not self.header_logo:
			frappe.throw(_("Attach the Logo."))

	def on_update(self):
		frappe.cache().delete_value("email_branding")

	def on_trash(self):
		frappe.cache().delete_value("email_branding")
