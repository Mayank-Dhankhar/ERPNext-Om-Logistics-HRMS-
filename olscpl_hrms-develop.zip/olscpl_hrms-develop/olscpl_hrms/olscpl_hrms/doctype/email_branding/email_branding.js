// Email Branding: a preview and the Notifications that use this branding
// ("Use company email template" - overrides/notification.py).
frappe.ui.form.on("Email Branding", {
	refresh(frm) {
		const wrap = frm.get_field("used_by_html").$wrapper;
		if (frm.is_new()) return wrap.html(`<p class="text-muted">${__("Save to see where this branding is used.")}</p>`);
		frappe.xcall("olscpl_hrms.utils.email_layout.branding_usage", { branding: frm.doc.name }).then((u) => {
				wrap.html(`
				<p class="text-muted">${frappe.utils.escape_html(u.scope)}</p>
				<div><b>${__("Notifications using it (Settings > Notification)")}</b>
				${u.notifications.length ? `<ul>${u.notifications.map((n) => `<li><a href="/app/notification/${encodeURIComponent(n)}">${frappe.utils.escape_html(n)}</a></li>`).join("")}</ul>`
					: `<p class="text-muted">${__("None yet. On any Notification, tick \"Use company email template\".")}</p>`}</div>`);
		});
		frm.add_custom_button(__("Preview"), () => {
			frappe.xcall("olscpl_hrms.utils.email_layout.preview_branding", { branding: frm.doc.name }).then((html) => {
				const d = new frappe.ui.Dialog({ title: __("Email preview"), size: "extra-large", fields: [{ fieldtype: "HTML", fieldname: "p" }] });
				d.fields_dict.p.$wrapper.html(`<iframe style="width:100%;height:70vh;border:0;background:#fff" srcdoc="${frappe.utils.escape_html(html)}"></iframe>`);
				d.show();
			});
		});
	},
});
