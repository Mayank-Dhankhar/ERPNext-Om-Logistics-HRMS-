import frappe
from frappe.model.document import Document


class PayrollChangeableComponent(Document):
	def before_save(self):
		if self.is_new():
			self._stamp_all_rows()
			return

		old_doc = self.get_doc_before_save()
		if not old_doc:
			self._stamp_all_rows()
			return

		old_rows = {r.component_name: r for r in old_doc.components}

		for new_row in self.components:
			old_row = old_rows.get(new_row.component_name)

			if not old_row:
				self._stamp_row(new_row)
				continue

			changed = (
				old_row.amount != new_row.amount
				or old_row.effective_date != new_row.effective_date
			)
			if not changed:
				continue

			frappe.get_doc({
				"doctype": "Payroll Changeable Component Audit",
				"payroll_changeable_component": self.name,
				"component_name": old_row.component_name,
				"amount": old_row.amount,
				"effective_date": old_row.effective_date,
				"changed_by": old_row.changed_by or old_doc.owner,
				"changed_on": old_row.changed_on or old_doc.creation,
			}).insert(ignore_permissions=True)

			self._stamp_row(new_row)

	def _stamp_all_rows(self):
		for row in self.components:
			self._stamp_row(row)

	def _stamp_row(self, row):
		row.changed_by = frappe.session.user
		row.changed_on = frappe.utils.now_datetime()