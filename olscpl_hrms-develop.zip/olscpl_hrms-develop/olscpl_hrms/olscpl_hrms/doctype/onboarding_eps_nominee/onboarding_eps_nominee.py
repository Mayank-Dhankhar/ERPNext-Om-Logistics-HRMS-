import frappe
from frappe.model.document import Document


class OnboardingEPSNominee(Document):
	pass
