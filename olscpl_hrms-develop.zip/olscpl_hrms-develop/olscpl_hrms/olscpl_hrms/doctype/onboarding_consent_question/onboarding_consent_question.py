import frappe
from frappe.model.document import Document


class OnboardingConsentQuestion(Document):
	pass
