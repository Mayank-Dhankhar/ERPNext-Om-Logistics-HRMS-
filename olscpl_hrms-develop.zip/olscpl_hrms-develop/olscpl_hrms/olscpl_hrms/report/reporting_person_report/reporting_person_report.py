# Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd.

import frappe


def execute(filters=None):
	filters = filters or {}
	return get_columns(), get_data(filters)


def get_columns():
	return [
		{"label": "Employee", "fieldname": "employee", "fieldtype": "Link", "options": "Employee", "width": 120},
		{"label": "Employee Name", "fieldname": "employee_name", "fieldtype": "Data", "width": 160},
		{"label": "Reports To", "fieldname": "reports_to", "fieldtype": "Link", "options": "Employee", "width": 120},
		{"label": "Reports To Name", "fieldname": "reports_to_name", "fieldtype": "Data", "width": 160},
	]


def get_data(filters):
	conditions = ["e.status = %(status)s"]
	values = {"status": filters.get("status") or "Active"}

	if filters.get("employee"):
		conditions.append("e.name = %(employee)s")
		values["employee"] = filters["employee"]

	if filters.get("company"):
		conditions.append("e.company = %(company)s")
		values["company"] = filters["company"]

	if filters.get("department"):
		conditions.append("e.department = %(department)s")
		values["department"] = filters["department"]

	reporting_person = filters.get("reporting_person")
	if reporting_person == "Set":
		conditions.append("e.reports_to IS NOT NULL AND e.reports_to != ''")
	elif reporting_person == "Not Set":
		conditions.append("(e.reports_to IS NULL OR e.reports_to = '')")

	return frappe.db.sql(
		"""
		SELECT
			e.name AS employee,
			e.employee_name,
			e.reports_to,
			m.employee_name AS reports_to_name
		FROM `tabEmployee` e
		LEFT JOIN `tabEmployee` m ON m.name = e.reports_to
		WHERE {conditions}
		ORDER BY e.employee_name ASC
		""".format(conditions=" AND ".join(conditions)),
		values,
		as_dict=1,
	)
