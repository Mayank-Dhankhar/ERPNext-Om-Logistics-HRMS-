// Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd.
// For license information, please see license.txt

frappe.query_reports["Reporting Person Report"] = {
	filters: [
		{
			fieldname: "employee",
			label: __("Employee"),
			fieldtype: "Link",
			options: "Employee",
		},
		{
			fieldname: "company",
			label: __("Company"),
			fieldtype: "Link",
			options: "Company",
		},
		{
			fieldname: "department",
			label: __("Department"),
			fieldtype: "Link",
			options: "Department",
			get_query: function () {
				const company = frappe.query_report.get_filter_value("company");
				return company ? { filters: { company } } : {};
			},
		},
		{
			fieldname: "status",
			label: __("Status"),
			fieldtype: "Select",
			options: ["Active", "Inactive", "Suspended", "Left"],
			default: "Active",
		},
		{
			fieldname: "reporting_person",
			label: __("Reporting Person"),
			fieldtype: "Select",
			options: ["", "Set", "Not Set"],
		},
	],

	formatter: function (value, row, column, data, default_formatter) {
		if (column.fieldname === "employee") {
			return value ? `<a href="/app/employee/${value}">${value}</a>` : "";
		}
		if (column.fieldname === "reports_to") {
			const link = value ? `<a href="/app/employee/${value}">${value}</a>` : "";
			return `${link} <a href="#" class="rp-edit-link" data-employee="${data.employee}" data-current="${
				data.reports_to || ""
			}" title="${__("Change Reporting Person")}">${frappe.utils.icon("edit", "sm")}</a>`;
		}
		return default_formatter(value, row, column, data);
	},

	onload: function (report) {
		// The datatable's sticky row-number header (.dt-cell--header) and a
		// filter's awesomplete dropdown both use z-index: 4 - on a tie the
		// later-painted datatable header wins and clips the dropdown's top
		// rows. Scoped to this report's own filter bar only.
		if (!document.getElementById("reporting-person-report-style")) {
			const style = document.createElement("style");
			style.id = "reporting-person-report-style";
			style.textContent = ".page-form .awesomplete ul { z-index: 20; }";
			document.head.appendChild(style);
		}

		report.page.wrapper.off("click", ".rp-edit-link").on("click", ".rp-edit-link", function (e) {
			e.preventDefault();
			const employee = $(this).attr("data-employee");
			const current = $(this).attr("data-current");
			frappe.prompt(
				{
					fieldname: "reports_to",
					label: __("Reports To"),
					fieldtype: "Link",
					options: "Employee",
					default: current,
					get_query: () => ({ filters: { name: ["!=", employee] } }),
				},
				(values) => {
					frappe.call({
						method: "frappe.client.set_value",
						args: {
							doctype: "Employee",
							name: employee,
							fieldname: "reports_to",
							value: values.reports_to || "",
						},
						freeze: true,
						callback: () => {
							frappe.show_alert({ message: __("Reporting Person updated"), indicator: "green" });
							report.refresh();
						},
					});
				},
				__("Change Reporting Person"),
				__("Update")
			);
		});
	},
};
