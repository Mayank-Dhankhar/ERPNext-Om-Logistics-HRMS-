// Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd.
// For license information, please see license.txt

frappe.query_reports["Salary Comparison Report"] = {

    filters: [

        {
            fieldname: "from_date",
            label: __("From Date"),
            fieldtype: "Date",
            reqd: 1,
            default: frappe.datetime.month_start(
                frappe.datetime.add_months(frappe.datetime.get_today(), -1)
            )
        },

        {
            fieldname: "to_date",
            label: __("To Date"),
            fieldtype: "Date",
            reqd: 1,
            default: frappe.datetime.month_start()
        },

        {
            fieldname: "company",
            label: __("Company"),
            fieldtype: "Link",
            options: "Company"
        },

        {
            fieldname: "branch",
            label: __("Branch"),
            fieldtype: "Link",
            options: "Branch"
        },

        {
            fieldname: "department",
            label: __("Department"),
            fieldtype: "Link",
            options: "Department"
        },

        {
            fieldname: "designation",
            label: __("Designation"),
            fieldtype: "Link",
            options: "Designation"
        },

        {
            fieldname: "employee",
            label: __("Employee"),
            fieldtype: "Link",
            options: "Employee"
        }

    ],

    onload: function(report) {

        inject_custom_styles();

        // Hero Title
        setTimeout(() => {

            const page = report.page;

            page.set_title("Salary Analytics Dashboard");

        }, 100);

    },

    formatter: function(value, row, column, data, default_formatter) {

        value = default_formatter(value, row, column, data);

        if (!data) {
            return value;
        }

        // --------------------------
        // Difference Columns
        // --------------------------

        if (column.fieldname.endsWith("_diff")) {

            let amount = flt(data[column.fieldname]);

            if (amount > 0) {

                return `
                    <div style="
                        color:#16A34A;
                        font-weight:700;
                        display:flex;
                        align-items:center;
                        gap:4px;
                    ">
                        ▲ ${format_currency(amount)}
                    </div>`;
            }

            if (amount < 0) {

                return `
                    <div style="
                        color:#DC2626;
                        font-weight:700;
                        display:flex;
                        align-items:center;
                        gap:4px;
                    ">
                        ▼ ${format_currency(Math.abs(amount))}
                    </div>`;
            }
        }

        // --------------------------
        // Gross Difference
        // --------------------------

        if (column.fieldname === "gross_difference") {

            let amount = flt(data.gross_difference);

            if (amount > 0) {

                return `
                    <div style="
                        background:#DCFCE7;
                        color:#166534;
                        border-radius:10px;
                        padding:6px 10px;
                        text-align:center;
                        font-weight:700;
                    ">
                        ▲ ${format_currency(amount)}
                    </div>`;
            }

            if (amount < 0) {

                return `
                    <div style="
                        background:#FEE2E2;
                        color:#991B1B;
                        border-radius:10px;
                        padding:6px 10px;
                        text-align:center;
                        font-weight:700;
                    ">
                        ▼ ${format_currency(Math.abs(amount))}
                    </div>`;
            }
        }

        // --------------------------
        // Reason Badges
        // --------------------------

        if (column.fieldname === "reason") {

            const reason = data.reason || "";

            let color = "#64748B";
            let bg = "#F1F5F9";

            if (reason.includes("Salary Revision")) {
                color="#166534";
                bg="#DCFCE7";
            }

            else if (reason.includes("Payment Days")) {
                color="#92400E";
                bg="#FEF3C7";
            }

            else if (reason.includes("Bonus")) {
                color="#1D4ED8";
                bg="#DBEAFE";
            }

            else if (reason.includes("Arrear")) {
                color="#7E22CE";
                bg="#F3E8FF";
            }

            return `
                <span style="
                    background:${bg};
                    color:${color};
                    padding:5px 10px;
                    border-radius:999px;
                    font-size:11px;
                    font-weight:600;
                    white-space:nowrap;
                ">
                    ${reason}
                </span>`;
        }

        // --------------------------
        // Changed Components
        // --------------------------

        if (column.fieldname === "changed_components") {

            if (!data.changed_components)
                return value;

            return data.changed_components
                .split(",")
                .map(component => `
                    <span style="
                        background:#EFF6FF;
                        color:#1E40AF;
                        padding:3px 8px;
                        border-radius:999px;
                        font-size:10px;
                        margin:2px;
                        display:inline-block;
                    ">
                        ${component.trim()}
                    </span>
                `)
                .join("");
        }

        return value;
    }
};

// ------------------------------------------------------
// Premium Dashboard Styling
// ------------------------------------------------------

function inject_custom_styles() {

    if ($("#salary-dashboard-style").length)
        return;

    $("head").append(`
        <style id="salary-dashboard-style">

        /* Page Background */

        .layout-main-section{

            background:#F8FAFC;
            border-radius:18px;
            padding:18px;
        }

        /* Filters */

        .page-form{

            background:white;
            border-radius:14px;
            padding:14px;
            box-shadow:0 4px 14px rgba(15,23,42,.05);
            margin-bottom:18px;
        }

        /* KPI Cards */

        .report-summary{

            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
            gap:16px;
            margin-bottom:20px;
        }

        .report-summary-item{

            background:white;
            border-radius:16px;
            box-shadow:0 8px 25px rgba(15,23,42,.06);
            padding:20px;
            transition:.25s;
        }

        .report-summary-item:hover{

            transform:translateY(-3px);
            box-shadow:0 12px 30px rgba(15,23,42,.12);
        }

        .report-summary-label{

            color:#64748B;
            font-size:12px;
            font-weight:600;
            text-transform:uppercase;
            letter-spacing:.5px;
        }

        .report-summary-value{

            font-size:30px;
            font-weight:700;
            margin-top:8px;
        }

        /* Chart */

        .chart-wrapper{

            background:white;
            border-radius:18px;
            padding:20px;
            margin-bottom:20px;
            box-shadow:0 8px 25px rgba(15,23,42,.06);
        }

        /* Table */

        .dt{

            border-radius:18px;
            overflow:hidden;
            background:white;
            box-shadow:0 8px 25px rgba(15,23,42,.06);
        }

        .dt-header{

            background:#0F172A;
        }

        .dt-cell__content{

            font-size:13px;
        }

        .dt-scrollable{

            max-height:650px;
        }

        .dt-row:hover{

            background:#F8FAFC;
        }

        /* Sticky Header */

        .dt-header{

            position:sticky;
            top:0;
            z-index:20;
        }

        /* First Columns */

        .dt-cell--col-0,
        .dt-cell--col-1,
        .dt-cell--col-2{

            position:sticky;
            left:0;
            background:white;
            z-index:15;
        }

        /* Nice Scrollbar */

        ::-webkit-scrollbar{

            height:8px;
            width:8px;
        }

        ::-webkit-scrollbar-thumb{

            background:#CBD5E1;
            border-radius:999px;
        }

        </style>
    `);
}