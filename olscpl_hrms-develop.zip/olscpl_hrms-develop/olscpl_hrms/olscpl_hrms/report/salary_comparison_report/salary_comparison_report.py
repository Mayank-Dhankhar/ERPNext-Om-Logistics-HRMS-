# Copyright (c) 2026, OM Logistics Supply Chain Pvt. Ltd.

import frappe
from collections import defaultdict, Counter


# -----------------------------
# Component Mapping
# -----------------------------

COMPONENT_MAP = {

    "Basic":"basic_diff",
    "HRA":"hra_diff",
    "House Rent Allowance":"hra_diff",

    "Conveyance":"conveyance_diff",
    "Conveyance Allowance":"conveyance_diff",

    "Uniform":"uniform_diff",
    "Uniform Allowance":"uniform_diff",

    "Child Education Allowance":"child_education_diff",

    "Special Allowance":"special_allowance_diff",

    "Other Allowance":"other_allowance_diff",

    "Mobile Allowance":"mobile_allowance_diff",

    "Education Scholarship":"education_scholarship_diff",

    "Performance Bonus":"performance_bonus_diff",

    "Washing Allowance":"washing_diff",

    "Bonus":"bonus_diff",

    "Incentive":"incentive_diff",
    "Monthly Incentive":"incentive_diff",

    "Leave Encashment":"leave_encashment_diff",

    "LTA":"lta_diff",

    "CCA":"cca_mess_diff",
    "Mess Allowance":"cca_mess_diff",

    "Arrear":"arrear_diff",

    # Deductions

    "PF":"pf_diff",
    "Provident Fund":"pf_diff",
    "Employee PF":"pf_diff",

    "ESI":"esi_diff",
    "Employee State Insurance":"esi_diff",

    "Professional Tax":"pt_diff",

    "TDS":"tds_diff",
    "Income Tax":"tds_diff",

    "Labour Welfare Fund":"lwf_diff",

    "Loan":"loan_diff",

    "Salary Advance":"salary_advance_diff",

    "Recovery":"recovery_diff"
}


# -----------------------------
# Main Report
# -----------------------------

def execute(filters=None):

    filters = filters or {}

    if not filters.get("from_date") or not filters.get("to_date"):
        frappe.throw("Please select From Date and To Date.")

    current = get_salary_slips(filters["to_date"], filters)
    previous = get_salary_slips(filters["from_date"], filters)

    current_map = {d.employee:d for d in current}
    previous_map = {d.employee:d for d in previous}

    current_comp = get_components([d.name for d in current])
    previous_comp = get_components([d.name for d in previous])

    employees = sorted(
        set(current_map.keys()) |
        set(previous_map.keys())
    )

    data = []

    component_counter = Counter()
    reason_counter = Counter()

    for emp in employees:

        curr = current_map.get(emp)
        prev = previous_map.get(emp)

        curr_vals = current_comp.get(curr.name,{}) if curr else {}
        prev_vals = previous_comp.get(prev.name,{}) if prev else {}

        row = {

            "employee":curr.employee if curr else prev.employee,
            "employee_name":curr.employee_name if curr else prev.employee_name,

            "company":curr.company if curr else prev.company,
            "branch":curr.branch if curr else prev.branch,
            "department":curr.department if curr else prev.department,
            "designation":curr.designation if curr else prev.designation,

            "current_month":filters["to_date"],
            "previous_month":filters["from_date"],

            "gross_difference":
                (curr.gross_pay if curr else 0)
                -
                (prev.gross_pay if prev else 0),

            "current_days":curr.payment_days if curr else 0,
            "previous_days":prev.payment_days if prev else 0,

            "reason":"",
            "changed_components":""
        }

        changed=False
        changed_components=[]
        reasons=[]

        # Initialize mapped fields

        for field in set(COMPONENT_MAP.values()):
            row[field]=0

        # Compare every component

        all_components = set(curr_vals.keys()) | set(prev_vals.keys())

        for component in all_components:

            diff = curr_vals.get(component,0)-prev_vals.get(component,0)

            field = COMPONENT_MAP.get(component)

            if field:

                row[field]+=diff

            if diff!=0:

                changed=True
                changed_components.append(component)

                component_counter[component]+=1

        # -----------------------
        # Reason Detection
        # -----------------------

        if row["current_days"]!=row["previous_days"]:

            reasons.append("Payment Days")

        if any(
            x in changed_components
            for x in ["Basic","HRA","House Rent Allowance"]
        ):
            reasons.append("Salary Revision")

        if "Bonus" in changed_components:
            reasons.append("Bonus Paid")

        if any(
            x in changed_components
            for x in ["Incentive","Monthly Incentive"]
        ):
            reasons.append("Incentive Added")

        if "Arrear" in changed_components:
            reasons.append("Arrear Paid")

        if "Leave Encashment" in changed_components:
            reasons.append("Leave Encashment")

        if row.get("pf_diff",0)!=0:
            reasons.append("PF Changed")

        if row.get("esi_diff",0)!=0:
            reasons.append("ESI Changed")

        if row.get("tds_diff",0)!=0:
            reasons.append("TDS Changed")

        if row.get("loan_diff",0)!=0:
            reasons.append("Loan Recovery")

        if not prev:
            reasons.append("New Joiner")

        if not curr:
            reasons.append("Exit Employee")

        row["reason"]=", ".join(dict.fromkeys(reasons))
        row["changed_components"]=", ".join(changed_components)

        for r in dict.fromkeys(reasons):
            reason_counter[r]+=1

        if changed or row["gross_difference"]!=0:
            data.append(row)

    columns=get_columns()

    report_summary=get_summary(data)

    chart=get_dashboard_chart(data)

    return columns,data,None,chart,report_summary


# -----------------------------
# Columns
# -----------------------------

def get_columns():

    columns=[

        {"label":"Employee","fieldname":"employee","fieldtype":"Link","options":"Employee","width":110},
        {"label":"Employee Name","fieldname":"employee_name","fieldtype":"Data","width":170},
        {"label":"Company","fieldname":"company","fieldtype":"Link","options":"Company","width":170},
        {"label":"Branch","fieldname":"branch","fieldtype":"Link","options":"Branch","width":130},
        {"label":"Department","fieldname":"department","fieldtype":"Link","options":"Department","width":140},
        {"label":"Designation","fieldname":"designation","fieldtype":"Link","options":"Designation","width":140},

        {"label":"Current Month","fieldname":"current_month","fieldtype":"Date","width":110},
        {"label":"Previous Month","fieldname":"previous_month","fieldtype":"Date","width":110}
    ]

    added=set()

    for _,field in COMPONENT_MAP.items():

        if field in added:
            continue

        added.add(field)

        columns.append({

            "label":field.replace("_"," ").title(),
            "fieldname":field,
            "fieldtype":"Currency",
            "width":130
        })

    columns.extend([

        {"label":"Gross Difference","fieldname":"gross_difference","fieldtype":"Currency","width":150},

        {"label":"Current Days","fieldname":"current_days","fieldtype":"Float","width":90},
        {"label":"Previous Days","fieldname":"previous_days","fieldtype":"Float","width":90},

        {"label":"Reason","fieldname":"reason","fieldtype":"Data","width":220},
        {"label":"Changed Components","fieldname":"changed_components","fieldtype":"Data","width":280}
    ])

    return columns


# -----------------------------
# Salary Slip Fetch
# -----------------------------

def get_salary_slips(compare_date,filters):

    conditions=""
    values=[compare_date,compare_date]

    if filters.get("company"):
        conditions+=" AND ss.company=%s"
        values.append(filters["company"])

    if filters.get("branch"):
        conditions+=" AND ss.branch=%s"
        values.append(filters["branch"])

    if filters.get("department"):
        conditions+=" AND emp.department=%s"
        values.append(filters["department"])

    if filters.get("designation"):
        conditions+=" AND emp.designation=%s"
        values.append(filters["designation"])

    if filters.get("employee"):
        conditions+=" AND ss.employee=%s"
        values.append(filters["employee"])

    return frappe.db.sql(f"""

        SELECT

            ss.name,
            ss.employee,
            ss.employee_name,
            ss.company,
            ss.branch,
            ss.payment_days,
            ss.gross_pay,

            emp.department,
            emp.designation

        FROM `tabSalary Slip` ss

        LEFT JOIN `tabEmployee` emp
            ON emp.name=ss.employee

        WHERE MONTH(ss.end_date)=MONTH(%s)
          AND YEAR(ss.end_date)=YEAR(%s)
          AND ss.docstatus=1

          {conditions}

        ORDER BY ss.employee

    """,tuple(values),as_dict=True)


# -----------------------------
# Salary Components
# -----------------------------

def get_components(slips):

    result=defaultdict(dict)

    if not slips:
        return result

    rows=frappe.get_all(

        "Salary Detail",

        filters={"parent":["in",slips]},

        fields=[
            "parent",
            "salary_component",
            "amount"
        ]
    )

    for row in rows:

        result[row.parent][row.salary_component]=row.amount

    return result


# -----------------------------
# KPI Cards
# -----------------------------

def get_summary(data):

    positive=sum(d["gross_difference"] for d in data if d["gross_difference"]>0)

    negative=sum(abs(d["gross_difference"]) for d in data if d["gross_difference"]<0)

    payment_cases=sum(1 for d in data if "Payment Days" in d["reason"])

    revision_cases=sum(1 for d in data if "Salary Revision" in d["reason"])

    return [

        {
            "value":len(data),
            "label":"Employees Changed",
            "indicator":"Blue"
        },

        {
            "value":positive,
            "label":"Net Increase",
            "indicator":"Green",
            "datatype":"Currency"
        },

        {
            "value":negative,
            "label":"Net Decrease",
            "indicator":"Red",
            "datatype":"Currency"
        },

        {
            "value":payment_cases,
            "label":"Payment Day Cases",
            "indicator":"Orange"
        },

        {
            "value":revision_cases,
            "label":"Salary Revisions",
            "indicator":"Purple"
        }
    ]


# -----------------------------
# Dashboard Chart
# -----------------------------

def get_dashboard_chart(data):

    positive=sum(d["gross_difference"] for d in data if d["gross_difference"]>0)

    negative=sum(abs(d["gross_difference"]) for d in data if d["gross_difference"]<0)

    return {

        "data":{

            "labels":[
                "Increase",
                "Decrease"
            ],

            "datasets":[
                {
                    "values":[positive,negative]
                }
            ]
        },

        "type":"donut",

        "colors":[
            "#16A34A",
            "#DC2626"
        ]
    }