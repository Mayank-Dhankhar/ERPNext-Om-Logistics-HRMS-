// ── Round to nearest integer ──────────────────────────────────────────────────
const r = v => Math.round(parseFloat(v) || 0);

// Shared by payroll through Frappe boot info; names are normalized to lowercase.
const ONE_TIME_ALLOWANCES = frappe.boot.one_time_components;
const isNoDeductionEmploymentType = type => (frappe.boot.no_deduction_employment_types || [])
    .includes((type || '').trim().toUpperCase());
const normalizeSalaryStructureName = name => (name || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
const isManualSalaryStructure = name => normalizeSalaryStructureName(name)
    .split(' ')
    .includes(frappe.boot.salary_structure_keywords.manual);
const isBaseSalaryStructure = name => normalizeSalaryStructureName(name)
    .includes(frappe.boot.salary_structure_keywords.base);

// ★ Manual overrides for Other Benefits rows (Meal Voucher, Medical Insurance,
// Ex-Gratia, Gratuity, Leave Encashment, ...). Keyed by lower-cased particulars.
// Re-applied after every server rebuild / client recalculation so a value the
// user typed is never replaced by a formula value or reset to 0.
const getOB = frm => (frm._ob_overrides = frm._ob_overrides || {});


// ── Form Events ───────────────────────────────────────────────────────────────
frappe.ui.form.on('Job Offer', {

  onload: function (frm) {
    frm.set_query('custom_loi_salary_structure', function () {
      return {
        filters: { docstatus: 1 }
      };
    });

    // Pull the real Bonus Ceiling Amount / Bonus Payable Percentage from
    // their doctypes as soon as the form loads, so recalcAllTotals() never
    // has to guess at these values.
    fetchBonusConfig(frm);

    // Only recalculate for drafts. recalcAllTotals() ends by rebuilding
    // custom_benefits from scratch (populateBenefits(): clear_table then
    // add_child for every row) - even when the resulting rows are
    // identical to what's already there, that's a fresh child table with
    // no `name` on its rows, which Frappe always treats as a real edit.
    // Running this unconditionally on every load was marking every Job
    // Offer "unsaved" the instant it was opened, submitted or not - and
    // on a submitted one, that dirtied custom_benefits (a field without
    // allow_on_submit) blocks *any* save on the whole document, including
    // fields that are allowed to change after submit (e.g. Senior Role).
    // A submitted offer's salary figures are meant to be frozen anyway,
    // so there's nothing to recalculate there in the first place.
    if (frm.doc.docstatus === 0) {

      // Keep a saved Meal Voucher from being reset to 0 by a later server rebuild
      (frm.doc.custom_other_benefits || []).forEach(row => {
        if ((row.particulars || '').toLowerCase() === 'meal voucher' && r(row.per_month) > 0) {
          getOB(frm)['meal voucher'] = r(row.per_month);
        }
      });

      recalcAllTotals(frm);
    }
  },
  refresh: function(frm) {
    toggle_base_field(frm);

    // Auto recalculate on any field change
    autoRecalculate(frm);
  },

  custom_loi_salary_structure: function(frm) {

    // ==============================
    // 🔴 STEP 1: RESET EVERYTHING
    // ==============================
    frm.set_value("custom_base_salary", 0);

    // Structure changed → manual Other Benefit overrides no longer apply
    frm._ob_overrides = {};

    frm.clear_table("custom_salary_breakup");
    frm.clear_table("custom_allowances");
    frm.clear_table("custom_deductions");
    frm.clear_table("custom_other_benefits");

    frm.refresh_field("custom_salary_breakup");
    frm.refresh_field("custom_allowances");
    frm.refresh_field("custom_deductions");
    frm.refresh_field("custom_other_benefits");

    frm.set_value("custom_total_breakupmonth", 0);
    frm.set_value("custom_total_allowmonth", 0);
    frm.set_value("custom_total_deductmonth", 0);
    frm.set_value("custom_total_benefitmonth", 0);
    frm.set_value("custom_gross_salarymonth", 0);
    frm.set_value("custom_net_salarymonth", 0);

    // Salary Structure changed → company driving Bonus Payable % may have
    // changed too. Clear the cached bonus values and re-fetch the real
    // ones from the doctypes — never assume a number here.
    frm._bonus_ceiling_amount = null;
    frm._bonus_payable_percentage = null;
    fetchBonusConfig(frm);

    toggle_base_field(frm);

    // ==============================
    // 🟡 STEP 2: MANUAL STRUCTURE
    // ==============================
    if (isManualSalaryStructure(frm.doc.custom_loi_salary_structure)) {
        frappe.show_alert({
            message: "Manual structure selected.",
            indicator: "orange"
        });

        // Call API to LOAD COMPONENTS (0 values)
        populateFromStructure(frm);

        return;
    }

    // ==============================
    // 🟢 STEP 3: DYNAMIC STRUCTURE
    // ==============================
    if (isBaseSalaryStructure(frm.doc.custom_loi_salary_structure)) {
        populateFromStructure(frm);
    }
  },


  custom_base_salary: function (frm) {

    if (!frm.doc.custom_loi_salary_structure) return;

    // ── Reset allowances to 0 whenever Base Salary changes ──
    reset_allowances_to_zero(frm);

    // ❌ Skip for Manual
    // Only dynamic structure recalculates
    if (!isBaseSalaryStructure(frm.doc.custom_loi_salary_structure)) {
        return;
    }

    setTimeout(() => { populateFromStructure(frm); }, 300);
  },
  
  // NEW: Employment Type changed → rebuild the annexure (Outsourced / Apprentice
  // switch to the flat 60/40 split, anything else goes back to the normal engine)
  custom_employment_type: function (frm) {
    if (!frm.doc.custom_loi_salary_structure) return;
    setTimeout(() => { populateFromStructure(frm); }, 300);
  },
  
  custom_state: function (frm) {

    // Manual structure → DON'T reload rows
    if (isManualSalaryStructure(frm.doc.custom_loi_salary_structure)) {
        recalcAllTotals(frm);
        return;
    }

    if (
        frm.doc.custom_loi_salary_structure &&
        frm.doc.custom_base_salary
    ) {
        setTimeout(() => {
            populateFromStructure(frm);
        }, 300);
    }
  },

  custom_pf_applicable: function (frm) {

    // Manual structure
    if (isManualSalaryStructure(frm.doc.custom_loi_salary_structure)) {

        setTimeout(() => {
            populateFromStructure(frm);
        }, 300);

        return;
    }

    // Base structure
    if (
        frm.doc.custom_loi_salary_structure &&
        frm.doc.custom_base_salary
    ) {

        setTimeout(() => {
            populateFromStructure(frm);
        }, 300);

    }
  },

  // ★ Company drives the Bonus Payable Percentage lookup (Ex-Gratia).
  // If the user changes Company after already selecting a structure,
  // refresh so Ex-Gratia picks up the right percentage for the new company.
  company: function (frm) {

    // Company changed → cached bonus values are stale until refetched.
    frm._bonus_ceiling_amount = null;
    frm._bonus_payable_percentage = null;
    fetchBonusConfig(frm);

    if (!frm.doc.custom_loi_salary_structure) return;

    const isManual = isManualSalaryStructure(frm.doc.custom_loi_salary_structure);
    if (isManual || frm.doc.custom_base_salary) {
        setTimeout(() => {
            populateFromStructure(frm);
        }, 300);
    }
  },

  validate: function (frm) {
    
    if (isNoDeductionEmploymentType(frm.doc.custom_employment_type)
        && isManualSalaryStructure(frm.doc.custom_loi_salary_structure)) {
      frappe.throw('Outsourced / Apprentice offers are a flat 60/40 split of Base Salary. Please choose a Base Salary-Based structure, not a Manual one.');
    }
    let recurring_allowance_total = 0;
    (frm.doc.custom_allowances || []).forEach(row => {
        let name = (row.particulars || '').toLowerCase();
        if (!ONE_TIME_ALLOWANCES.includes(name)) {
            recurring_allowance_total += parseFloat(row.per_month) || 0;
        }
    });

    let allowance_cap = (frm.doc.custom_base_salary || 0) * 0.20;

    if (allowance_cap > 0 && recurring_allowance_total > allowance_cap) {
        frappe.throw(
            `Recurring allowances (₹${Math.round(recurring_allowance_total)}) exceed 20% of Base Salary ` +
            `(₹${Math.round(allowance_cap)}). Please reduce allowance amounts before saving.`
        );
    }
  }

});


// ── Child Table Events ────────────────────────────────────────────────────────
['LOI Salary Breakup', 'LOI Allowance', 'LOI Deduction', 'LOI Other Benefit'].forEach(function (dt) {
  frappe.ui.form.on(dt, {

    per_month: function (frm, cdt, cdn) {

        let row = locals[cdt][cdn];
    
        frappe.model.set_value(
            cdt,
            cdn,
            'per_annum',
            r(row.per_month) * 12
        );

        // ★ Other Benefits edited manually → remember it and just recalc
        // totals locally. No server rebuild, otherwise the row would be
        // replaced by the formula / template value (0 for Meal Voucher).
        if (cdt === 'LOI Other Benefit') {
            getOB(frm)[(row.particulars || '').toLowerCase()] = r(row.per_month);
            recalcAllTotals(frm);
            frm.refresh_field("custom_other_benefits");
            return;   // no server rebuild for Other Benefits edits
        }
    
        recalcAllTotals(frm);
        frm.refresh_field("custom_salary_breakup");
        frm.refresh_field("custom_allowances");
    
        // Manual structure
        if (isManualSalaryStructure(frm.doc.custom_loi_salary_structure)) {
            // Only trigger server recalc when user edits salary breakup or allowances
            // NOT when server-set deduction/benefit rows fire this event
            if (
                cdt === 'LOI Salary Breakup' ||
                cdt === 'LOI Allowance'
            ) {
                recalcAllTotals(frm);
                setTimeout(() => {
                    populateFromStructure(frm);
                }, 300);
            }
            return;
        }
    
        // Dynamic structure
        setTimeout(() => {
            populateFromStructure(frm);
        }, 300);
    },

    per_annum: function (frm) { recalcAllTotals(frm); },
    amount:    function (frm) { recalcAllTotals(frm); }

  });
});


// ── Fetch real Bonus Ceiling Amount / Bonus Payable Percentage ───────────────
// Pulls straight from 'Payroll Changeable Component' and 'Bonus Payable' via
// a dedicated lightweight endpoint — no hardcoded numbers anywhere in this
// file. Once the values land, re-runs recalcAllTotals() so Ex-Gratia (which
// was skipped until now) gets calculated with the correct figures.
function fetchBonusConfig(frm) {

    frm._bonus_config_fetch_pending = true;

    frappe.call({
        method: 'olscpl_hrms.api.loi_salary.get_bonus_config',
        args: {
            company: frm.doc.company || '',
            salary_structure: frm.doc.custom_loi_salary_structure || '',
            // Job Offer has no Date of Joining field — Offer Date is the
            // "as of" date used for effective-dated ceiling lookups here.
            date_of_joining: frm.doc.offer_date || ''
        },
        callback: function (res) {
            frm._bonus_config_fetch_pending = false;

            if (!res.message) return;

            let d = res.message;

            frm._bonus_ceiling_amount = (d.bonus_ceiling_amount !== undefined && d.bonus_ceiling_amount !== null)
                ? parseFloat(d.bonus_ceiling_amount)
                : null;

            frm._bonus_payable_percentage = (d.bonus_payable_percentage !== undefined && d.bonus_payable_percentage !== null)
                ? parseFloat(d.bonus_payable_percentage)
                : null;

            if (!d.bonus_ceiling_amount) {
                frappe.show_alert({
                    message: 'No Payroll Changeable Component record found — Bonus Ceiling Amount is unavailable, Ex-Gratia will not be calculated.',
                    indicator: 'orange'
                });
            }
            if (!d.bonus_payable_percentage) {
                frappe.show_alert({
                    message: 'No Bonus Payable record found for this company — Ex-Gratia will not be calculated.',
                    indicator: 'orange'
                });
            }

            // Same guard as the onload call below - see the comment there.
            if (frm.doc.docstatus === 0) {
                recalcAllTotals(frm);
            }
        }
    });
}


// ── Populate from Salary Structure ───────────────────────────────────────────
function populateFromStructure(frm) {
  if (is_rapidshyp_structure(frm)) return rapidshyp_fill(frm);

  let special_allowance = 0;
  (frm.doc.custom_allowances || []).forEach(function (row) {
    if ((row.particulars || '').toLowerCase() === 'special allowance') {
      special_allowance = parseFloat(row.per_month) || 0;
    }
  });

  frappe.call({
    method: 'olscpl_hrms.api.loi_salary.get_loi_salary_data',
    args: {

        salary_structure:
            frm.doc.custom_loi_salary_structure,
    
        base:
            frm.doc.custom_base_salary || 0,
    
        custom_state:
            frm.doc.custom_state || '',
    
        custom_state_wage_category:
            frm.doc.custom_state_wage_category || '',
    
        special_allowance:
            special_allowance,
    
        custom_pf_applicable:
            frm.doc.custom_pf_applicable || "Yes",
    
        sitting_location:
            frm.doc.custom_sitting_location || '',

        // ★ Drives the company-specific Bonus Payable Percentage lookup
        // (used for the dynamic Ex-Gratia calculation).
        company:
            frm.doc.company || '',

        date_of_joining:
            frm.doc.offer_date || '',

        // NEW: drives the flat 60/40 / no-deduction path on the server
        employment_type:
            frm.doc.custom_employment_type || '',

        // MANUAL STRUCTURE DATA
        salary_breakup: JSON.stringify(
            frm.doc.custom_salary_breakup || []
        ),
        
        allowances: JSON.stringify(
            frm.doc.custom_allowances || []
        )
            },
    callback: function (res) {

      if (!res.message || res.message.error) {
        frappe.msgprint(res.message ? res.message.error : 'Error fetching data');
        return;
      }

      let d = res.message;

      // ★ Cache the dynamic (company-specific) Bonus Ceiling Amount and
      // Bonus Payable Percentage on the form, so any later purely-client-side
      // recalculation (recalcAllTotals) uses the correct values instead of
      // hardcoded ones. No fallback numbers here — if the server didn't send
      // a value, the cache is left as-is (or empty) and recalcAllTotals()
      // will simply skip the Ex-Gratia calc until fetchBonusConfig() succeeds.
      if (d.bonus_ceiling_amount !== undefined && d.bonus_ceiling_amount !== null) {
        frm._bonus_ceiling_amount = parseFloat(d.bonus_ceiling_amount);
      }
      if (d.bonus_payable_percentage !== undefined && d.bonus_payable_percentage !== null) {
        frm._bonus_payable_percentage = parseFloat(d.bonus_payable_percentage);
      }

      if (d.allowance_cap_exceeded) {
        frappe.msgprint({
          title:     'Validation Error',
          message:   `❌ Recurring allowances (₹${r(d.recurring_allowance_total)}) exceed 20% of Base Salary (₹${r(d.allowance_cap)}). Please reduce allowance amounts.`,
          indicator: 'red'
        });
      }

      function mergeIntoTable(tablefield, apiRows) {
            const existing = frm.doc[tablefield] || [];
        
            const existingMap = {};
            existing.forEach(row => {
                if (row.particulars) {
                    existingMap[row.particulars.toLowerCase()] = row;
                }
            });
        
            
            const PRESERVE_COMPONENTS = [
                'basic',
                'house rent allowance',
                'conveyance',
                'child education allowance',
                'uniform allowance',
                'cca',
                'education scholarship',
                'performance bonus',
                'special allowance'
            ];
        
            apiRows.forEach(item => {
                const key = (item.component || '').toLowerCase();
                const amt = r(item.per_month);
                const existingRow = existingMap[key];
        
                if (existingRow) {
                    const isManualStructure = isManualSalaryStructure(frm.doc.custom_loi_salary_structure);
                    const isPreservedComponent = PRESERVE_COMPONENTS.includes(key);
                    const hasExistingValue = (parseFloat(existingRow.per_month) || 0) > 0;
                
                    // Manual structure: preserve all listed components
                    if (isManualStructure && isPreservedComponent && hasExistingValue) return;
                
                    // Any structure: preserve allowances that user has manually entered
                    // (tablefield check: only apply to allowances, not salary breakup)
                    const isAdvanceBonus = key === 'advance bonus';
                    if (tablefield === 'custom_allowances' && hasExistingValue && !isAdvanceBonus) return;
                
                    frappe.model.set_value(existingRow.doctype, existingRow.name, 'per_month', amt);
                    frappe.model.set_value(existingRow.doctype, existingRow.name, 'per_annum', amt * 12);

                } else {
                    const row = frm.add_child(tablefield);
                    row.particulars = item.component;
                    row.per_month = amt;
                    row.per_annum = amt * 12;
                }
            });
        
            // Backfill per_annum for any rows where it's missing
            (frm.doc[tablefield] || []).forEach(row => {
                const hasMonthly = (parseFloat(row.per_month) || 0) > 0;
                const missingAnnual = (parseFloat(row.per_annum) || 0) === 0;
        
                if (hasMonthly && missingAnnual) {
                    frappe.model.set_value(row.doctype, row.name, 'per_annum', r(row.per_month) * 12);
                }
            });
        }

      // Salary Breakup
      if (isManualSalaryStructure(frm.doc.custom_loi_salary_structure)) {
        
            // First time load
            if (
                !frm.doc.custom_salary_breakup ||
                frm.doc.custom_salary_breakup.length === 0
            ) {
        
                frm.clear_table(
                    'custom_salary_breakup'
                );
        
                (d.earnings || []).forEach(e => {
        
                    let row = frm.add_child(
                        'custom_salary_breakup'
                    );
        
                    row.particulars =
                        e.component;
        
                    // Keep amount empty
                    row.per_month = 0;
                    row.per_annum = 0;
                });
        
            } else {
        
                // Preserve manual values
                mergeIntoTable(
                    'custom_salary_breakup',
                    d.earnings || []
                );
            }
        
       } else {
        
            frm.clear_table(
                'custom_salary_breakup'
            );
        
            (d.earnings || []).forEach(e => {
        
                let row = frm.add_child(
                    'custom_salary_breakup'
                );
        
                row.particulars =
                    e.component;
        
                row.per_month =
                    r(e.per_month);
        
                row.per_annum =
                    r(e.per_month) * 12;
            });
        }
              
      // NEW: no allowances for Outsourced / Apprentice. mergeIntoTable only
      // walks the server rows, so it would leave typed allowances in place.
    //   if (isNoDeductionEmploymentType(frm.doc.custom_employment_type)) {
    //     frm.clear_table('custom_allowances');
    //   }
      // Allowances — merge to preserve manual rows
      mergeIntoTable('custom_allowances', d.allowances || []);

      // Deductions
      frm.clear_table('custom_deductions');
      (d.deductions || []).forEach(dd => {
        let row         = frm.add_child('custom_deductions');
        row.particulars = dd.component;
        row.per_month   = r(dd.per_month);
        row.per_annum   = r(dd.per_month) * 12;
      });

      // Other Benefits — round each row here at the source.
      // ★ A manual override (if the user typed one) wins over the server value.
      frm.clear_table('custom_other_benefits');
      (d.other_benefits || []).forEach(ob => {
        let ov  = getOB(frm)[(ob.component || '').toLowerCase()];
        let val = (ov !== undefined) ? ov : r(ob.per_month);
        let row         = frm.add_child('custom_other_benefits');
        row.particulars = ob.component;
        row.per_month   = val;
        row.per_annum   = val * 12;
      });

      frm.refresh_fields();
      recalcAllTotals(frm);

      frappe.show_alert({ message: '✅ Salary calculated successfully', indicator: 'green' });
    }
  });
}


// ── Populate Benefits from LOI Benefit Rule ───────────────────────────────────
function populateBenefits(frm) {
  let gross           = frm.doc.custom_gross_salarymonth || 0;

  frappe.call({
    method: 'frappe.client.get_list',
    args: {
      doctype:  'LOI Benefit Rule',
      fields:   [
        'particulars',
        'slab1_max', 'slab1_amount',
        'slab2_max', 'slab2_amount',
        'slab3_max', 'slab3_amount',
        'slab4_max', 'slab4_amount',
        'default_amount'
      ],
      order_by: 'creation asc',
      limit:    50
    },
    callback: function (res) {
      if (!res.message || !res.message.length) return;

      frm.clear_table('custom_benefits');

      let row_index = 0;

      res.message.forEach(rule => {
        let amount = rule.default_amount || 0;

        let slabs = [
          { max: rule.slab1_max, amt: rule.slab1_amount },
          { max: rule.slab2_max, amt: rule.slab2_amount },
          { max: rule.slab3_max, amt: rule.slab3_amount },
          { max: rule.slab4_max, amt: rule.slab4_amount },
        ];

        for (let slab of slabs) {
          if (slab.max && gross <= slab.max) {
            amount = slab.amt;
            break;
          }
        }

        let row         = frm.add_child('custom_benefits');
        row.particulars = rule.particulars;
        row.amount      = r(amount);   // ✅ round benefit amounts too

        row_index++;
      });

      frm.refresh_field('custom_benefits');
    }
  });
}


// ── Reset allowances to zero (used on base salary / structure change) ────────
function reset_allowances_to_zero(frm) {
    (frm.doc.custom_allowances || []).forEach(row => {
        row.per_month = 0;
        row.per_annum = 0;
    });
    frm.refresh_field('custom_allowances');
    recalcAllTotals(frm);
}


// ── Recalculate Totals ────────────────────────────────────────────────────────
function recalcAllTotals(frm) {
  if (is_rapidshyp_structure(frm)) return;  // its totals come from its own sheet

  let breakup_total = sumTable(frm, 'custom_salary_breakup', 'per_month');

  // ── MANUAL COMPONENT CALCULATION ─────────────────────────────
  if (isManualSalaryStructure(frm.doc.custom_loi_salary_structure)) {

    let basic = 0;
    let advbon = 0;

    // Get BASIC
    (frm.doc.custom_salary_breakup || []).forEach(row => {
        if ((row.particulars || '').toLowerCase() === 'basic') {
            basic = parseFloat(row.per_month) || 0;
        }
    });

    // Get ADVANCE BONUS (if exists)
    (frm.doc.custom_salary_breakup || []).forEach(row => {
        if ((row.particulars || '').toLowerCase() === 'advance bonus') {
            advbon = parseFloat(row.per_month) || 0;
        }
    });

    // ── CALCULATIONS ──
    // 16/10/2026
    // let leave_encashment = (basic / 30) * (15 / 12);
    // let gratuity         = (basic / 26) * (15 / 12);

    // ★ Dynamic Ex-Gratia — Bonus Ceiling Amount and Bonus Payable
    // Percentage come from frm._bonus_ceiling_amount / frm._bonus_payable_percentage,
    // which are populated ONLY from the server (Payroll Changeable Component +
    // Bonus Payable, matched to Company) via fetchBonusConfig() / populateFromStructure().
    // There is no hardcoded fallback: if these haven't arrived yet, Ex-Gratia
    // is left untouched rather than computed with a guessed number — it will
    // be recalculated automatically the moment fetchBonusConfig() resolves.
    let bonus_ceiling_amount = frm._bonus_ceiling_amount;
    let bonus_payable_percentage = frm._bonus_payable_percentage;

    let haveBonusConfig =
        typeof bonus_ceiling_amount === 'number' && !isNaN(bonus_ceiling_amount) &&
        typeof bonus_payable_percentage === 'number' && !isNaN(bonus_payable_percentage);

    if (!haveBonusConfig && frm._bonus_ceiling_amount === undefined && !frm._bonus_config_fetch_pending) {
        // Never even attempted a fetch yet on this form instance — kick one off.
        fetchBonusConfig(frm);
    }

    if (haveBonusConfig) {
        let bonus_rate = bonus_payable_percentage / 100;
        let exgratia_ceiling_amt = bonus_ceiling_amount * bonus_rate;
        let exgratia = (basic < bonus_ceiling_amount ? (basic * bonus_rate) : exgratia_ceiling_amt) - advbon;

        (frm.doc.custom_other_benefits || []).forEach(row => {
            let name = (row.particulars || '').toLowerCase();
            if (name === 'ex-gratia' || name === 'ex gratia') {
                row.per_month = Math.round(exgratia);
                row.per_annum = Math.round(exgratia) * 12;
            }
        });
    }

    // ── WRITE VALUES (Leave Encashment / Gratuity — not company-dependent) ──
    (frm.doc.custom_other_benefits || []).forEach(row => {

        let name = (row.particulars || '').toLowerCase();

        if (name === 'leave encashment') {
            row.per_month = Math.round(leave_encashment);
            row.per_annum = Math.round(leave_encashment) * 12;
        }

        if (name === 'gratuity') {
            row.per_month = Math.round(gratuity);
            row.per_annum = Math.round(gratuity) * 12;
        }

    });
  }

  // ── ALLOWANCE CAP CHECK — runs BEFORE allowances are added to gross ──
  let base_salary = frm.doc.custom_base_salary || 0;
  let allowance_cap = base_salary * 0.20;

  let recurring_allowance_total = 0;
  (frm.doc.custom_allowances || []).forEach(row => {
    let name = (row.particulars || '').toLowerCase();
    if (!ONE_TIME_ALLOWANCES.includes(name)) {
      recurring_allowance_total += parseFloat(row.per_month) || 0;
    }
  });

  let allowance_cap_exceeded = base_salary > 0 && recurring_allowance_total > allowance_cap;

  if (allowance_cap_exceeded) {

    if (!frm._allowance_validation_shown) {
      frm._allowance_validation_shown = true;
      frappe.msgprint({
        title:     'Validation Error',
        message:   `❌ Recurring allowances (₹${r(recurring_allowance_total)}) exceed 20% of Base Salary (₹${r(allowance_cap)}). Allowances have been reset to 0.`,
        indicator: 'red'
      });
    }

    // Reset ALL allowance rows to 0 and keep them out of gross
    (frm.doc.custom_allowances || []).forEach(row => {
      row.per_month = 0;
      row.per_annum = 0;
    });
    frm.refresh_field('custom_allowances');

  } else {
    frm._allowance_validation_shown = false;
  }

  // Allowance total computed AFTER the reset above, so gross never
  // includes an over-limit allowance amount.
  let allowance_total = sumTable(frm, 'custom_allowances', 'per_month');
  let gross = r(breakup_total + allowance_total);

  // Medical Insurance: live gross, mirrors formula in salary structure.
  // Condition: only when ESIC is NOT applicable (gross > 21000).
  // Formula: 1500 if gross >= 100000 else 1000 if >= 50000 else 700 if > 21000 else 0
  let medical_insurance = 0;
  if (gross > 21000) {
    if      (gross >= 100000) medical_insurance = 1500;
    else if (gross >= 50000)  medical_insurance = 1000;
    else                      medical_insurance = 700;
  }

  // Write Medical Insurance into other_benefits rows synchronously
  (frm.doc.custom_other_benefits || []).forEach(function (row) {
    let name = (row.particulars || '').toLowerCase();
    if (name === 'medical insurance') {
      row.per_month = medical_insurance;
      row.per_annum = medical_insurance * 12;
    }
  });

  // ★ Re-apply manual overrides (wins over Medical Insurance / Ex-Gratia /
  // Gratuity / Leave Encashment formulas and over server template values)
  (frm.doc.custom_other_benefits || []).forEach(function (row) {
    let ov = getOB(frm)[(row.particulars || '').toLowerCase()];
    if (ov !== undefined) {
      row.per_month = ov;
      row.per_annum = ov * 12;
    }
  });

  // Sum AFTER all row mutations
  let benefit_total   = r(sumTable(frm, 'custom_other_benefits', 'per_month'));
  let deduction_total = r(sumTable(frm, 'custom_deductions',     'per_month'));

  let ctc = r(gross + benefit_total);
  let net = r(gross - deduction_total);

  frm.refresh_field('custom_deductions');
  frm.refresh_field('custom_other_benefits');

  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_breakupmonth', r(breakup_total));
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_breakupannum', r(breakup_total) * 12);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_allowmonth',   r(allowance_total));
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_allowannum',   r(allowance_total) * 12);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_deductmonth',  deduction_total);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_deductannum',  deduction_total * 12);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_benefitmonth', benefit_total);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_total_benefitannum', benefit_total * 12);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_gross_salarymonth',  gross);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_gross_salaryannum',  gross * 12);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_ctcmonth',           ctc);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_ctcannum',           ctc * 12);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_net_salarymonth',    net);
  frappe.model.set_value(frm.doctype, frm.docname, 'custom_net_salaryannum',    net * 12);


  // ── Other Validations (Basic / State Min Wage) ───────────────────────────

  // Get BASIC value
  let basic = 0;
  (frm.doc.custom_salary_breakup || []).forEach(row => {
    if ((row.particulars || '').toLowerCase() === 'basic') {
      basic = parseFloat(row.per_month) || 0;
    }
  });

  let structure    = (frm.doc.custom_loi_salary_structure || '').toUpperCase();
  let error_found  = false;

  // ✅ TASK 1 — Basic must be ≥ 15,000 for "12% of Basic" structures
  if (structure.includes('12% OF BASIC') || structure.includes('12%BASIC')) {
    if (basic < 15000) {
      error_found = true;
      if (!frm._validation_shown) {
        frm._validation_shown = true;
        frappe.msgprint({
          title:     'Validation Error',
          message:   '❌ Basic is less than 15,000. Please choose another structure.',
          indicator: 'red'
        });
      }
    }
  }

  // ✅ TASK 2 — Basic must be ≥ 50% of Gross Salary (excluding one-time allowances)
  let gross_for_validation = 0;

  ['custom_salary_breakup', 'custom_allowances'].forEach(tablefield => {
    (frm.doc[tablefield] || []).forEach(row => {
      let name   = (row.particulars || '').toLowerCase();
      let amount = parseFloat(row.per_month) || 0;

      if (!ONE_TIME_ALLOWANCES.includes(name)) {
        gross_for_validation += amount;
      }
    });
  });

  let minimum_basic = gross_for_validation * 0.50;

  if (basic < minimum_basic) {
    error_found = true;
    if (!frm._basic_validation_shown) {
      frm._basic_validation_shown = true;
      let one_time_allowances_label = ONE_TIME_ALLOWANCES
        .map(name => name.replace(/\b\w/g, character => character.toUpperCase()))
        .join(', ');
      frappe.msgprint({
        title:     'Validation Error',
        message:   `❌ Basic Salary (₹${r(basic)}) is less than 50% of Gross Salary ` +
                  `(₹${r(minimum_basic)}), excluding one-time allowances ` +
                  `(${one_time_allowances_label}).`,
        indicator: 'red'
      });
    }
  } else {
    frm._basic_validation_shown = false;
  }

  // ✅ TASK 3 — Base must be ≥ Basic for State Minimum Wage structures
  if (structure.includes('STATE MINIMUM WAGE')) {
    if (base_salary < basic) {
      error_found = true;
      if (!frm._validation_shown) {
        frm._validation_shown = true;
        frappe.msgprint({
          title:     'Validation Error',
          message:   '❌ Base amount is less than Basic (State Minimum Wage).',
          indicator: 'red'
        });
      }
    }
  }

  // ✅ Reset flag when no error
  if (!error_found) {
    frm._validation_shown = false;
  }

  populateBenefits(frm);
}


// ── Utility ───────────────────────────────────────────────────────────────────
function sumTable(frm, tablefield, valuefield) {
  let total = 0;
  (frm.doc[tablefield] || []).forEach(row => {
    total += (parseFloat(row[valuefield]) || 0);
  });
  return total;
}

function toggle_base_field(frm) {
    let is_manual = isManualSalaryStructure(frm.doc.custom_loi_salary_structure);
    frm.set_df_property('custom_base_salary', 'read_only', is_manual);
    if (is_manual) {
        frm.set_value('custom_base_salary', 0);
    }
}

function autoRecalculate(frm) {

    $(document).off(
        'change.job_offer_auto_calc'
    );

    $(document).on(
        'change.job_offer_auto_calc',
        'input, select',
        frappe.utils.debounce((e) => {

            // ★ Edits inside Other Benefits are fully handled by the child
            // table per_month event (override saved + local recalc). Skip the
            // server rebuild here, otherwise it wipes the manual value.
            if ($(e.target).closest('[data-fieldname="custom_other_benefits"]').length) {
                return;   // already handled by the child-table per_month event
            }

            // Same reasoning as the onload guard above - a submitted
            // offer's salary structure is frozen, and this listener is
            // bound to *any* input/select on the page, so without this it
            // fires (and re-dirties custom_benefits) even for an
            // unrelated field like the Senior Role checkbox.
            if (frm.doc.docstatus === 1) {
                return;
            }

            if (!frm.doc.custom_loi_salary_structure) {
                return;
            }

            // For manual structure, base salary is always 0 — that's OK
            const isManual = isManualSalaryStructure(frm.doc.custom_loi_salary_structure);

            if (!isManual && !frm.doc.custom_base_salary) {
                return;
            }

            // Field name
            let fieldname =
                $(e.target)
                .closest('[data-fieldname]')
                .attr('data-fieldname');

            // ----------------------------------
            // ONLY THESE FIELDS → API CALL
            // ----------------------------------
            let trigger_fields = [
                'custom_base_salary',
                'custom_state',
                'custom_state_wage_category',
                'custom_sitting_location',
                'custom_pf_applicable',
                'custom_loi_salary_structure',
                'company',
                'offer_date'
            ];

            if (
                trigger_fields.includes(
                    fieldname
                )
            ) {

                setTimeout(() => {
                    populateFromStructure(frm);
                }, 300);

                return;
            }

            // ----------------------------------
            // MANUAL STRUCTURE — any per_month edit
            // → always call server
            // ----------------------------------
            if (isManual && fieldname === 'per_month') {
                setTimeout(() => {
                    populateFromStructure(frm);
                }, 300);
                return;
            }

            // ----------------------------------
            // SPECIAL ALLOWANCE ONLY
            // ----------------------------------
            let special_row =
                (frm.doc.custom_allowances || [])
                .find(row =>
                    (row.particulars || '')
                    .toLowerCase() ===
                    'special allowance'
                );

            if (
                special_row &&
                fieldname === 'per_month'
            ) {

                setTimeout(() => {
                    populateFromStructure(frm);
                }, 300);

                return;
            }

            // Other component edits
            recalcAllTotals(frm);

        }, 300)
    );
}
// Submitting emails the candidate their offer letter with Accept/Decline
// buttons (olscpl_hrms.events.job_offer.send_offer_letter) - so the stock
// "Permanently Submit?" confirm is swapped, for this one submit, for a dialog
// that says a mail is about to go out. Cancel leaves the offer as a draft.
frappe.ui.form.on('Job Offer', {
    onload(frm) {
        frm.savesubmit = function (btn, callback, on_error) {
            const original_confirm = frappe.confirm;
            frappe.confirm = function (_message, on_yes, on_no) {
                frappe.confirm = original_confirm;
                // The offer letter prints the sender's signature as Authorised
                // Signatory - make sure one is uploaded first (signature_gate.js),
                // same as Send Onboarding Link. The server checks again.
                ensureSenderSignature(() => show_submit_offer_dialog(on_yes, on_no));
            };
            return frappe.ui.form.Form.prototype.savesubmit.call(this, btn, callback, on_error);
        };

        function show_submit_offer_dialog(on_yes, on_no) {
            let confirmed = false;
            const d = new frappe.ui.Dialog({
                title: __('Submit Offer and Send Offer Letter?'),
                fields: [{
                    fieldtype: 'HTML',
                    options: `<p>${__('Submitting will email the offer letter to {0} with Accept / Decline buttons.',
                        [`<b>${frappe.utils.escape_html(frm.doc.applicant_email || __('the applicant'))}</b>`])}</p>
                        <p class="text-muted">${__('Please check the Date of Joining and salary details first. Choose Cancel to keep editing.')}</p>`,
                }, {
                    // printed as the last page of the offer letter (api/letter_of_intent._additional_terms_page)
                    fieldname: 'additional_terms',
                    fieldtype: 'Small Text',
                    label: __('Any additional terms or commitments?'),
                    default: frm.doc.custom_additional_terms || '',
                    description: __('Anything agreed with the candidate that is not in the standard letter, including verbal promises '
                        + '(e.g. joining bonus, relocation support, laptop, notice-period buyout, planned leave). One point per line - '
                        + 'printed on the last page of the offer letter. Leave blank if none.'),
                }],
                primary_action_label: __('Submit & Send Mail'),
                primary_action(values) {
                    frm.doc.custom_additional_terms = (values.additional_terms || '').trim() || null;
                    confirmed = true;
                    d.hide();
                },
                secondary_action_label: __('Cancel'),
                secondary_action() { d.hide(); },
            });
            d.onhide = () => {
                if (!confirmed) return on_no && on_no();
                show_offer_send_loader(frm);
                on_yes();
            };
            d.show();
        }
    },
});

// Submitting builds the Letter of Intent PDF and emails it before the request
// returns (a few seconds) - show the standard loader with what's happening
// (public/js/om_loader.js) until Frappe's submit freeze lifts.
function show_offer_send_loader(frm) {
    om_loader.until_unfreeze(__('Generating the offer letter and emailing it to {0}…',
        [frm.doc.applicant_email || __('the applicant')]));
}



// ── RapidShyp: "OSBS Base-Salary-Based Structure" ──────────────────────────────────
// Filled from RapidShyp's own salary sheet (olscpl_hrms.api.rapidshyp, = HR's
// "Salary Structure.xlsx"), with its own rows, labels and annual figures -
// not the shared LOI engine above (populateFromStructure / recalcAllTotals
// hand over here). Base Salary = the sheet's monthly Gross Salary. Saving
// recalculates it server-side too. Every other structure is unchanged.
const RAPIDSHYP_STRUCTURE = 'OSBS Base-Salary-Based Structure';
const is_rapidshyp_structure = frm => frm.doc.custom_loi_salary_structure === RAPIDSHYP_STRUCTURE;

function rapidshyp_fill(frm) {
    if (!is_rapidshyp_structure(frm) || frm.doc.docstatus !== 0 || !frm.doc.custom_base_salary) return;
    frappe.call({
        method: 'olscpl_hrms.api.rapidshyp.get_salary',
        args: { gross: frm.doc.custom_base_salary, pf_applicable: frm.doc.custom_pf_applicable || '', custom_state: frm.doc.custom_state || '', as_on_date: frm.doc.offer_date || '' },
        callback: ({ message: s }) => {
            if (!s) return;
            [['custom_salary_breakup', s.earnings], ['custom_allowances', []], ['custom_other_benefits', s.employer],
             ['custom_deductions', s.deductions], ['custom_benefits', []]].forEach(([field, rows]) => {
                frm.clear_table(field);
                rows.forEach(row => Object.assign(frm.add_child(field), row));
                frm.refresh_field(field);
            });
            frm.set_value({
                custom_total_breakupmonth: s.gross, custom_total_breakupannum: s.gross_annum,
                custom_total_allowmonth: 0, custom_total_allowannum: 0,
                custom_gross_salarymonth: s.gross, custom_gross_salaryannum: s.gross_annum,
                custom_total_benefitmonth: s.employer_total, custom_total_benefitannum: s.employer_total_annum,
                custom_total_deductmonth: s.total_deductions, custom_total_deductannum: s.total_deductions_annum,
                custom_ctcmonth: s.ctc, custom_ctcannum: s.ctc_annum,
                custom_net_salarymonth: s.in_hand, custom_net_salaryannum: s.in_hand_annum,
            });
        },
    });
}

frappe.ui.form.on('Job Offer', {
    custom_loi_salary_structure: rapidshyp_fill,
    custom_base_salary: rapidshyp_fill,
    custom_pf_applicable: rapidshyp_fill,
});

// Company follows the Job Applicant's Company (a General Application applicant
// chose it on the form) - not the system default. Only on a new offer, so an
// offer HR already saved keeps its company.
frappe.ui.form.on('Job Offer', {
    onload(frm) {
        if (frm.is_new()) set_company_from_applicant(frm);
    },
    job_applicant(frm) {
        if (frm.is_new()) set_company_from_applicant(frm);
    },
});

function set_company_from_applicant(frm) {
    if (!frm.doc.job_applicant) return;
    frappe.db.get_value('Job Applicant', frm.doc.job_applicant, 'custom_company').then((r) => {
        const company = r.message && r.message.custom_company;
        if (company && company !== frm.doc.company) frm.set_value('company', company);
    });
}
