// olscpl_hrms/public/js/desk_scroll_fix.js
//
// Workspace pages (Hrms Home, HR, Complete Flow, ...) end up with TWO
// independently-scrollable containers at once: .app-content (arjun_theme's
// own layout choice - overflow: hidden auto) and, nested inside it,
// .layout-main-section-wrapper, which Frappe's workspace renderer gives a
// fixed height + its own overflow-y: auto so the top toolbar stays fixed
// while workspace content scrolls. Neither side knows about the other, so
// both show a scrollbar side by side.
//
// List views and form views do NOT have this problem - .layout-main-
// section-wrapper never becomes independently scrollable there, so
// .app-content's own scroll is the only (and correct) way to reach
// content below the fold on those page types. An earlier attempt at this
// fix hid .app-content's overflow unconditionally and broke scrolling on
// every form/list view - this version only suppresses the outer scroll
// when the inner pane has actually taken over, checked live on every
// route change rather than assumed from one page type.
(function () {
	function fixDoubleScroll() {
		var appContent = document.querySelector(".app-content");
		if (!appContent) return;

		var innerScrollable = false;
		var candidates = appContent.querySelectorAll(".layout-main-section-wrapper");
		for (var i = 0; i < candidates.length; i++) {
			var el = candidates[i];
			var style = getComputedStyle(el);
			if (
				(style.overflowY === "auto" || style.overflowY === "scroll") &&
				el.scrollHeight > el.clientHeight + 2
			) {
				innerScrollable = true;
				break;
			}
		}

		// Inline style beats any stylesheet on its own, no !important
		// war needed. Empty string clears the override and falls back
		// to arjun_theme's own default (overflow: hidden auto).
		appContent.style.overflowY = innerScrollable ? "hidden" : "";
	}

	// Route changes swap page content without a full reload, and the
	// inner wrapper's height is set asynchronously after render - a
	// light interval is simpler and more robust than chasing every
	// internal Frappe event that might fire around that timing.
	setInterval(fixDoubleScroll, 500);
	window.addEventListener("load", fixDoubleScroll);
})();
