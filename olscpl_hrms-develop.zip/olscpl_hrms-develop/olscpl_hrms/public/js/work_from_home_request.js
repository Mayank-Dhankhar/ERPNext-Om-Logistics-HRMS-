// was Client Script: "Work From Home Request Geolocation" - this file is
// a readable mirror of that DB record (same convention as attendance.js
// above), not itself loaded by hooks.py's doctype_js (that mechanism
// doesn't actually deliver per-doctype JS in this Frappe version - see
// Attendance/Employee/Job Offer's own doctype_js entries, which are
// dead for the same reason and rely on their own Client Script records
// instead).
//
// Fetches Latitude/Longitude the same way HRMS core's own Employee
// Checkin does on the ESS "Check In" page (frontend/src/components/
// CheckInPanel.vue's fetchLocation(), gated on the same "HR Settings.
// allow_geolocation_tracking" toggle): the browser's own
// navigator.geolocation API, not anything OMSTAFF-app specific - the
// OMSTAFF app supplies these fields itself when it calls
// api/work_from_home.py directly, this is only for whoever fills the
// form out in a browser instead.
frappe.ui.form.on('Work From Home Request', {
	onload: function (frm) {
		if (frm.is_new()) fetch_location(frm);
	},
});

function fetch_location(frm) {
	frappe.call({
		method: 'frappe.client.get_single_value',
		args: { doctype: 'HR Settings', field: 'allow_geolocation_tracking' },
		callback: function (r) {
			if (!r.message || !navigator.geolocation) return;
			navigator.geolocation.getCurrentPosition(
				function (position) {
					frm.set_value('latitude', position.coords.latitude);
					frm.set_value('longitude', position.coords.longitude);
					// Best-effort - api/geocode.py's reverse_geocode() never
					// raises, it just returns "" on failure, so there's
					// nothing to handle here beyond a missing message.
					frappe.call({
						method: 'olscpl_hrms.api.geocode.reverse_geocode',
						args: { latitude: position.coords.latitude, longitude: position.coords.longitude },
						callback: function (geo_r) {
							if (geo_r.message) frm.set_value('location', geo_r.message);
						},
					});
				},
				function () {
					frappe.show_alert({ message: __('Could not fetch your location'), indicator: 'orange' });
				}
			);
		},
	});
}
