// Every onboarding form prints "Signature of Employer/Authorised
// Signatory" using whoever actually sent that candidate their link's own
// uploaded signature (User.custom_signature_image - see
// patches/v1_1/convert_user_signature_to_upload.py, and
// employee_data.py's _hr_signature_html). If they've never drawn one,
// every one of those forms would just print blank for them, and they'd
// have no way of knowing that from the "Send Onboarding Link"/"Request
// Changes" button alone. ensureSenderSignature() is the one shared gate
// both of those buttons (Job Offer Onboarding Link Button and Employee
// Onboarding Request Changes Button - separate Client Scripts, so this
// lives globally instead of being duplicated in each) call before
// actually sending: if a signature is already on file, `callback` runs
// immediately; otherwise it offers to upload one right there and saves it
// before continuing, so nothing ever gets sent with a blank signatory.
function ensureSenderSignature(callback) {
	frappe.call({
		method: "frappe.client.get_value",
		args: {
			doctype: "User",
			filters: frappe.session.user,
			fieldname: "custom_signature_image",
		},
		callback: function (r) {
			if (r.message && r.message.custom_signature_image) {
				callback();
				return;
			}
			show_signature_gate_dialog(callback);
		},
	});
}

function show_signature_gate_dialog(on_done) {
	var d = new frappe.ui.Dialog({
		title: __("Sign before sending"),
		fields: [
			{
				fieldtype: "HTML",
				options:
					"<p>" +
					__(
						"You haven't saved a signature yet - it's what prints as the " +
							"\"Employer/Authorised Signatory\" signature on this candidate's " +
							"onboarding forms and letters. Upload an image of it once below " +
							"(dark ink on white paper works best) and it's reused every time after this."
					) +
					"</p>",
			},
			{
				fieldtype: "Attach Image",
				fieldname: "signature",
				label: __("Upload Your Signature"),
				reqd: 1,
			},
		],
		primary_action_label: __("Save & Continue"),
		primary_action: function (values) {
			frappe.call({
				method: "olscpl_hrms.events.employee_onboarding.save_my_signature",
				args: { signature: values.signature },
				freeze: true,
				callback: function () {
					d.hide();
					on_done();
				},
			});
		},
		secondary_action_label: __("Upload on my profile instead"),
		secondary_action: function () {
			d.hide();
			frappe.set_route("Form", "User", frappe.session.user);
		},
	});
	d.show();
}
