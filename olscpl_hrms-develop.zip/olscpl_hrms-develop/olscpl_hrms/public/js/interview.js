// First save of a new Interview emails the candidate and interviewers
// (olscpl_hrms.events.interview.after_insert), so confirm before it goes out -
// Cancel leaves the form unsaved for further edits. Later saves send nothing,
// so they aren't asked.
frappe.ui.form.on("Interview", {
	before_save(frm) {
		if (!frm.is_new()) return;

		return new Promise((resolve) => {
			let confirmed = false;
			const d = new frappe.ui.Dialog({
				title: __("Save Interview and Send Emails?"),
				fields: [
					{
						fieldtype: "HTML",
						options: `<p>${__(
							"Saving will email the interview details to the candidate and all interviewers."
						)}</p><p class="text-muted">${__(
							"Choose Cancel to keep editing first."
						)}</p>`,
					},
				],
				primary_action_label: __("Save & Send Mail"),
				primary_action() {
					confirmed = true;
					d.hide();
				},
				secondary_action_label: __("Cancel"),
				secondary_action() {
					d.hide();
				},
			});
			// on_hide also covers Esc / the X button - treated as Cancel
			d.onhide = () => {
				if (!confirmed) frappe.validated = false;
				resolve();
			};
			d.show();
		});
	},
});

// "Submit Feedback" opens the full Interview Feedback form instead of hrms's
// small dialog, which only has skills / result / feedback - the form also has
// the Candidate Details for the HR round (public/js/interview_feedback.js
// loads the skills and the candidate's previous details into it).
frappe.ui.form.on("Interview", {
	show_feedback_dialog(frm) {
		frappe.new_doc("Interview Feedback", {
			interview: frm.doc.name,
			interview_round: frm.doc.interview_round,
			job_applicant: frm.doc.job_applicant,
			interviewer: frappe.session.user,
		});
	},
});

// Next rounds: the candidate's earlier rounds for the same Job Opening, with
// every interviewer's complete feedback, in a box at the top of the form
// (olscpl_hrms.events.interview.previous_rounds). Styles: .prev-rounds-* in
// public/css/olscpl_theme.css.
frappe.ui.form.on("Interview", {
	refresh(frm) {
		if (frm.is_new() || !frm.doc.job_applicant) return;
		// refresh can fire twice in a row (e.g. right after the first save): only
		// the latest call draws, and it replaces any box already there
		const token = (frm.__prev_rounds_token = (frm.__prev_rounds_token || 0) + 1);
		frappe
			.xcall("olscpl_hrms.events.interview.previous_rounds", { interview: frm.doc.name })
			.then((rounds) => {
				if (token !== frm.__prev_rounds_token || frm.doc.name !== cur_frm?.doc?.name) return;
				$(frm.wrapper).find(".prev-rounds-section").remove();
				if (!rounds || !rounds.length) return;
				frm.dashboard.add_section(previous_rounds_html(rounds), __("Previous Rounds"), "custom prev-rounds-section");
				frm.dashboard.show();
			})
			.catch((e) => console.error("Previous Rounds:", e));
	},
});

function previous_rounds_html(rounds) {
	const esc = (v) => frappe.utils.escape_html(v == null ? "" : String(v));
	const stars = (r) => (r ? `${flt(r * 5, 1)}/5` : "-");
	// label: the interviewer's own Result ("Result: Rejected") - shown only when it
	// differs from the round's status, which already sits on the round heading
	const pill = (text, label) => {
		const cls = { Cleared: "green", Rejected: "red", "Under Review": "orange" }[text] || "gray";
		return text ? `<span class="indicator-pill ${cls}">${label ? esc(label) + ": " : ""}${esc(text)}</span>` : "";
	};
	return rounds
		.map((r) => {
			const feedback = r.feedback.length
				? r.feedback
						.map(
							(f) => `
				<div class="prev-rounds-feedback">
					<div class="prev-rounds-head">
						<b>${esc(f.interviewer || __("Interviewer"))}</b>
						${f.result !== r.status ? pill(f.result, __("Result")) : ""} ${f.draft ? `<span class="indicator-pill gray">${__("Draft")}</span>` : ""}
						<span class="text-muted">${__("Rating")} ${stars(f.average_rating)}</span>
						<a href="/app/interview-feedback/${encodeURIComponent(f.name)}" class="prev-rounds-link">${esc(f.name)}</a>
					</div>
					${f.skills.length ? `<div class="prev-rounds-skills">${f.skills
						.map((s) => `<span>${esc(s.skill)}: <b>${stars(s.rating)}</b></span>`)
						.join("")}</div>` : ""}
					${f.feedback ? `<div class="prev-rounds-text">${esc(f.feedback).replace(/\n/g, "<br>")}</div>` : ""}
					${f.details.length ? `<ul class="prev-rounds-details">${f.details.map((d) => `<li>${esc(d)}</li>`).join("")}</ul>` : ""}
				</div>`
						)
						.join("")
				: `<div class="text-muted">${__("No feedback submitted for this round.")}</div>`;
			return `
			<div class="prev-rounds-round">
				<div class="prev-rounds-title">
					<a href="/app/interview/${encodeURIComponent(r.name)}">${esc(r.interview_round || r.name)}</a>
					${pill(r.status)}
					<span class="text-muted">${r.scheduled_on ? frappe.datetime.str_to_user(r.scheduled_on) : ""}</span>
				</div>
				${feedback}
				${r.interview_summary ? `<div class="prev-rounds-text"><b>${__("Interview Summary")}:</b><br>${esc(r.interview_summary).replace(/\n/g, "<br>")}</div>` : ""}
			</div>`;
		})
		.join("");
}
