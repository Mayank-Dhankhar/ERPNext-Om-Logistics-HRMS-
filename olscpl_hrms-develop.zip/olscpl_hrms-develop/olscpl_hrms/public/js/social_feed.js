(function () {
	"use strict";

	var API = "/api/method/olscpl_hrms.api.social_feed.";
	var MAX_IMAGES = 6; // matches MAX_IMAGES_PER_POST in api/social_feed.py
	var MAX_ATTACHMENTS = 6; // matches MAX_ATTACHMENTS_PER_POST in api/social_feed.py

	function isImageFile(file) { return /^image\//.test(file.type); }

	function formatFileSize(bytes) {
		if (bytes == null) return "";
		if (bytes < 1024) return bytes + " B";
		if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
		return (bytes / (1024 * 1024)).toFixed(1) + " MB";
	}

	function fileIcon(filename) {
		var ext = (filename.split(".").pop() || "").toLowerCase();
		if (ext === "pdf") return "📄";
		if (["doc", "docx"].indexOf(ext) !== -1) return "📝";
		if (["xls", "xlsx", "csv"].indexOf(ext) !== -1) return "📊";
		if (["ppt", "pptx"].indexOf(ext) !== -1) return "📑";
		if (["zip", "rar", "7z"].indexOf(ext) !== -1) return "🗜️";
		return "📎";
	}

	var EMOJIS = [
		"😀", "😁", "😂", "🤣", "😊", "😍", "😘",
		"😎", "🤔", "😅", "😢", "😭", "😡", "🥳",
		"👍", "👎", "👏", "🙌", "🤝", "💪", "🙏",
		"❤️", "🔥", "🎉", "✨", "🌟", "💯", "⭐",
		"🚀", "📢", "📌", "✅", "❌", "⚡", "🎯",
		"😴", "🤗", "😇", "🥰", "🤩", "😜", "🤯",
		"🍕", "☕", "🎂", "🏆", "🎁", "🌈", "👋",
	];

	// ---- helpers ----

	function escapeHtml(s) {
		var div = document.createElement("div");
		div.textContent = s == null ? "" : String(s);
		return div.innerHTML;
	}

	// ---- custom dialogs (never window.alert/confirm/prompt) ----
	// Chrome (and other browsers) let a user tick "Prevent this page from
	// creating additional dialogs" on any native alert/confirm/prompt -
	// one misclick there and every alert/confirm/prompt call for the rest
	// of that page's life silently no-ops (confirm/prompt return false/
	// null with no dialog shown at all, not even an error). These replace
	// all three with plain in-page markup that can't be disabled that way.

	function showToast(message, type) {
		var el = document.createElement("div");
		el.className = "sf-toast" + (type === "error" ? " sf-toast-error" : "");
		el.textContent = message;
		document.body.appendChild(el);
		setTimeout(function () {
			el.classList.add("sf-toast-out");
			setTimeout(function () { el.remove(); }, 200);
		}, 4000);
	}

	function showConfirm(message, onConfirm) {
		var backdrop = document.createElement("div");
		backdrop.className = "sf-confirm-backdrop";
		backdrop.innerHTML =
			'<div class="sf-confirm-box">' +
			'<div class="sf-confirm-message">' + escapeHtml(message) + "</div>" +
			'<div class="sf-confirm-actions">' +
			'<button type="button" class="sf-confirm-cancel">Cancel</button>' +
			'<button type="button" class="sf-confirm-ok">Delete</button>' +
			"</div></div>";
		document.body.appendChild(backdrop);
		function close() { backdrop.remove(); }
		backdrop.addEventListener("click", function (e) { if (e.target === backdrop) close(); });
		backdrop.querySelector(".sf-confirm-cancel").addEventListener("click", close);
		backdrop.querySelector(".sf-confirm-ok").addEventListener("click", function () { close(); onConfirm(); });
	}

	function showPrompt(message, onSubmit) {
		var backdrop = document.createElement("div");
		backdrop.className = "sf-confirm-backdrop";
		backdrop.innerHTML =
			'<div class="sf-confirm-box">' +
			'<div class="sf-confirm-message">' + escapeHtml(message) + "</div>" +
			'<input type="text" class="sf-confirm-input" placeholder="Optional">' +
			'<div class="sf-confirm-actions">' +
			'<button type="button" class="sf-confirm-cancel">Cancel</button>' +
			'<button type="button" class="sf-confirm-ok">Reject</button>' +
			"</div></div>";
		document.body.appendChild(backdrop);
		var input = backdrop.querySelector(".sf-confirm-input");
		input.focus();
		function close() { backdrop.remove(); }
		backdrop.addEventListener("click", function (e) { if (e.target === backdrop) close(); });
		backdrop.querySelector(".sf-confirm-cancel").addEventListener("click", close);
		backdrop.querySelector(".sf-confirm-ok").addEventListener("click", function () { var v = input.value; close(); onSubmit(v); });
		input.addEventListener("keydown", function (e) { if (e.key === "Enter") { var v = input.value; close(); onSubmit(v); } });
	}

	function initials(name) {
		return (name || "").split(" ").filter(Boolean).slice(0, 2).map(function (p) { return p[0].toUpperCase(); }).join("");
	}

	function relativeTime(iso) {
		if (!iso) return "";
		var then = new Date(iso.replace(" ", "T"));
		if (isNaN(then.getTime())) return "";
		var diff = Math.max(0, (Date.now() - then.getTime()) / 1000);
		if (diff < 60) return "just now";
		if (diff < 3600) return Math.floor(diff / 60) + "m ago";
		if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
		if (diff < 604800) return Math.floor(diff / 86400) + "d ago";
		return then.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
	}

	function apiCall(method, data, useGet) {
		var url = API + method;
		if (useGet) {
			var qs = Object.keys(data || {})
				.filter(function (k) { return data[k] != null; })
				.map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(data[k]); })
				.join("&");
			if (qs) url += "?" + qs;
			return fetch(url, {
				method: "GET",
				credentials: "same-origin",
				headers: { "X-Frappe-CSRF-Token": window.csrf_token || "" },
			}).then(handleRes);
		}
		var body = new URLSearchParams();
		Object.keys(data || {}).forEach(function (k) {
			if (data[k] != null) body.append(k, data[k]);
		});
		return fetch(url, {
			method: "POST",
			credentials: "same-origin",
			headers: {
				"X-Frappe-CSRF-Token": window.csrf_token || "",
				"Content-Type": "application/x-www-form-urlencoded",
			},
			body: body.toString(),
		}).then(handleRes);
	}

	function handleRes(res) {
		return res.json().catch(function () { return {}; }).then(function (body) {
			if (!res.ok) {
				var msg = (body && body.exception) || (body && body._server_messages) || "Request failed (" + res.status + ")";
				try {
					var parsed = JSON.parse(msg);
					msg = Array.isArray(parsed) ? JSON.parse(parsed[0]).message : msg;
				} catch (e) { /* not JSON-wrapped, use as-is */ }
				throw new Error(msg);
			}
			return body.message;
		});
	}

	function uploadImage(file) {
		var fd = new FormData();
		fd.append("file", file);
		fd.append("is_private", "0");
		return fetch("/api/method/upload_file", {
			method: "POST",
			credentials: "same-origin",
			headers: { "X-Frappe-CSRF-Token": window.csrf_token || "" },
			body: fd,
		})
			.then(function (res) { return res.json(); })
			.then(function (body) {
				if (!body.message || !body.message.file_url) throw new Error("Image upload failed");
				return body.message.file_url;
			});
	}

	// ---- icons ----
	var ICONS = {
		home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 11.5 12 4l9 7.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 10v9a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1v-9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20.5s-7.5-4.6-10-9.3C0.3 7.8 2 4.5 5.3 4c2-.3 3.9.6 5 2.2.9-1.6 3-2.5 5-2.2 3.3.5 5 3.8 3.3 7.2-2.5 4.7-10 9.3-10 9.3Z" stroke-linejoin="round"/></svg>',
		comment: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16v12H8l-4 4V4Z" stroke-linejoin="round"/></svg>',
		image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="8.5" cy="9.5" r="1.5"/><path d="m4 17 5-5 3.5 3.5L17 11l3 3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		emoji: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M8.5 14s1.3 2 3.5 2 3.5-2 3.5-2" stroke-linecap="round"/><path d="M8.5 9.5h.01M15.5 9.5h.01" stroke-linecap="round" stroke-linewidth="2.5"/></svg>',
		close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 6l12 12M18 6 6 18" stroke-linecap="round"/></svg>',
		trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m2 0-.8 12.1a2 2 0 0 1-2 1.9H9.8a2 2 0 0 1-2-1.9L7 7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
	};

	// ---- state ----
	var state = {
		tab: "feed",
		feed: [],
		hasMore: false,
		nextBefore: null,
		canApprove: false,
		loadingMore: false,
		pending: [],
		me: { name: "", image: null },
		expanded: {},
		comments: {},
		commentDraft: {},
	};

	function root() { return document.getElementById("app"); }

	function renderError(message) {
		root().innerHTML = '<div class="sf-error"><h2>Couldn’t load the social feed</h2><p>' + escapeHtml(message) + "</p></div>";
	}

	function avatarHtml(author, size) {
		size = size || 40;
		if (author && author.image) {
			return '<img class="sf-avatar" style="width:' + size + "px;height:" + size + 'px" src="' + escapeHtml(author.image) + '" alt="">';
		}
		return '<div class="sf-avatar" style="width:' + size + "px;height:" + size + 'px">' + escapeHtml(initials(author ? author.name : "")) + "</div>";
	}

	// ---- renderers ----

	function renderHero() {
		return (
			'<div class="sf-hero">' +
			'<a href="/app/atlas-home" class="sf-home-btn" title="Back to Atlas Home">' + ICONS.home + "<span>Atlas Home</span></a>" +
			'<img src="/files/om_logo.svg" alt="OM One" class="sf-hero-logo">' +
			'<p class="sf-hero-title">Company Social Feed</p>' +
			"</div>"
		);
	}

	function renderTabs() {
		if (!state.canApprove) return "";
		return (
			'<div class="sf-tabs">' +
			'<button class="sf-tab ' + (state.tab === "feed" ? "active" : "") + '" data-tab="feed">Feed</button>' +
			'<button class="sf-tab ' + (state.tab === "pending" ? "active" : "") + '" data-tab="pending">Pending Approval' +
			(state.pending.length ? '<span class="sf-tab-badge">' + state.pending.length + "</span>" : "") +
			"</button>" +
			"</div>"
		);
	}

	function renderComposerAttachmentChip(a, idx) {
		return (
			'<div class="sf-attachment-chip"><span class="sf-attachment-icon">' + fileIcon(a.filename) + "</span>" +
			'<div class="sf-attachment-info"><div class="sf-attachment-name">' + escapeHtml(a.filename) + "</div>" +
			(a.size != null ? '<div class="sf-attachment-size">' + formatFileSize(a.size) + "</div>" : "") + "</div>" +
			'<button type="button" class="sf-composer-preview-remove sf-attachment-remove" data-remove-attachment="' + idx + '">' + ICONS.close + "</button></div>"
		);
	}

	// Pure trigger now, not an editable field - clicking it (or either tool
	// icon, or Post) opens the real compose dialog (openComposeDialog
	// below), same as the Hrms Home widget's composer.
	function renderComposer() {
		return (
			'<div class="sf-composer">' +
			'<div class="sf-composer-row">' +
			avatarHtml(state.me) +
			'<div class="sf-composer-main">' +
			'<div class="sf-composer-trigger" id="sf-composer-trigger">What’s on your mind ? </div>' +
			'<div class="sf-composer-footer">' +
			'<div class="sf-composer-tools">' +
			'<button type="button" class="sf-tool-btn" id="sf-emoji-btn" title="Emoji">' + ICONS.emoji + "</button>" +
			'<button type="button" class="sf-tool-btn" id="sf-image-btn" title="Attach files">' + ICONS.image + "</button>" +
			"</div>" +
			'<button type="button" class="sf-post-btn" id="sf-post-btn">Post</button>' +
			"</div></div></div></div>"
		);
	}

	function renderPostImages(images) {
		if (!images || !images.length) return "";
		return (
			'<div class="sf-post-images sf-post-images-' + Math.min(images.length, 4) + '">' +
			images.map(function (url) { return '<img src="' + escapeHtml(url) + '" alt="">'; }).join("") +
			"</div>"
		);
	}

	function renderPostAttachments(attachments) {
		if (!attachments || !attachments.length) return "";
		return (
			'<div class="sf-attachment-list">' + attachments.map(function (a) {
				return (
					'<a class="sf-attachment-chip sf-attachment-chip-link" href="' + escapeHtml(a.url) + '" target="_blank" rel="noopener" download="' + escapeHtml(a.filename) + '">' +
					'<span class="sf-attachment-icon">' + fileIcon(a.filename) + "</span>" +
					'<div class="sf-attachment-info"><div class="sf-attachment-name">' + escapeHtml(a.filename) + "</div>" +
					(a.size != null ? '<div class="sf-attachment-size">' + formatFileSize(a.size) + "</div>" : "") + "</div>" +
					'<span class="sf-attachment-open">Open</span>' +
					"</a>"
				);
			}).join("") + "</div>"
		);
	}

	function renderPost(p, mode) {
		var actions;
		if (mode === "pending") {
			actions =
				'<div class="sf-pending-actions">' +
				'<button type="button" class="sf-approve-btn" data-approve="' + p.name + '">Approve</button>' +
				'<button type="button" class="sf-reject-btn" data-reject="' + p.name + '">Reject</button>' +
				"</div>";
		} else {
			var expanded = !!state.expanded[p.name];
			actions =
				'<div class="sf-post-actions">' +
				'<button type="button" class="sf-action-btn ' + (p.likedByMe ? "liked" : "") + '" data-like="' + p.name + '">' +
				ICONS.heart + "<span>" + (p.likeCount || "") + " Like" + (p.likeCount === 1 ? "" : "s") + "</span></button>" +
				'<button type="button" class="sf-action-btn" data-toggle-comments="' + p.name + '">' +
				ICONS.comment + "<span>" + (p.commentCount || "") + " Comment" + (p.commentCount === 1 ? "" : "s") + "</span></button>" +
				"</div>" +
				(expanded ? renderComments(p) : "");
		}

		var badge = "";
		if (p.status === "Pending" && mode !== "pending") badge = '<span class="sf-post-badge pending">Pending approval</span>';
		if (p.status === "Rejected") badge = '<span class="sf-post-badge rejected">Rejected' + (p.rejectionReason ? ": " + escapeHtml(p.rejectionReason) : "") + "</span>";

		var deleteBtn = (mode !== "pending" && (p.isMine || state.canApprove))
			? '<button type="button" class="sf-post-menu-btn" data-delete="' + p.name + '" title="Delete post">' + ICONS.trash + "</button>"
			: "";

		var announcementBadge = p.isAnnouncement ? '<div class="sf-announcement-badge">📢 Announcement</div>' : "";
		var subtopicTag = p.subtopic ? '<div class="sf-subtopic-tag">' + escapeHtml(p.subtopic) + "</div>" : "";

		return (
			'<div class="sf-post' + (p.isAnnouncement ? " is-announcement" : "") + '" data-post="' + p.name + '">' +
			'<div class="sf-post-head">' +
			avatarHtml(p.author) +
			'<div class="sf-post-author">' +
			'<div class="sf-post-author-name">' + escapeHtml(p.author.name) + "</div>" +
			'<div class="sf-post-author-meta">' + (p.author.designation ? escapeHtml(p.author.designation) + " · " : "") + relativeTime(p.postedOn) + "</div>" +
			"</div>" + deleteBtn +
			"</div>" +
			announcementBadge + subtopicTag +
			// p.content is rich HTML from the Text Editor compose dialog
			// (sanitized server-side on save) - rendered as-is, not escaped,
			// so formatting (bold/lists/alignment/etc) survives here too.
			(p.content ? '<div class="sf-post-body">' + p.content + "</div>" : "") +
			renderPostImages(p.images) +
			renderPostAttachments(p.attachments) +
			badge +
			actions +
			"</div>"
		);
	}

	function renderComments(p) {
		var list = state.comments[p.name];
		var draft = state.commentDraft[p.name] || "";
		var listHtml = list == null
			? '<div class="sf-empty" style="padding:14px 0">Loading comments...</div>'
			: (list.length
				? list.map(function (c) {
					var canDelete = state.me && (c.authorUser === state.me.user || state.canApprove);
					var deleteBtn = canDelete
						? '<button type="button" class="sf-comment-delete" data-delete-comment="' + p.name + "|" + c.name + '" title="Delete comment">' + ICONS.close + "</button>"
						: "";
					return (
						'<div class="sf-comment">' + avatarHtml(c.author, 30) +
						'<div class="sf-comment-bubble"><div class="sf-comment-author">' + escapeHtml(c.author.name) + "</div>" +
						'<div class="sf-comment-text">' + escapeHtml(c.comment) + "</div>" +
						'<div class="sf-comment-time">' + relativeTime(c.postedOn) + "</div></div>" + deleteBtn + "</div>"
					);
				}).join("")
				: '<div class="sf-empty" style="padding:10px 0">No comments yet - be the first!</div>');

		return (
			'<div class="sf-comments">' + listHtml +
			'<div class="sf-comment-form">' +
			'<input type="text" class="sf-comment-input" data-comment-input="' + p.name + '" placeholder="Write a comment..." value="' + escapeHtml(draft) + '">' +
			'<button type="button" class="sf-comment-send" data-send-comment="' + p.name + '">Send</button>' +
			"</div></div>"
		);
	}

	function renderFeedTab() {
		var html = state.feed.length
			? state.feed.map(function (p) { return renderPost(p, "feed"); }).join("")
			: '<div class="sf-empty">No posts yet. Be the first to share something!</div>';
		if (state.hasMore) {
			html += '<button type="button" class="sf-load-more" id="sf-load-more">' + (state.loadingMore ? "Loading..." : "Load more") + "</button>";
		}
		return html;
	}

	function renderPendingTab() {
		return state.pending.length
			? state.pending.map(function (p) { return renderPost(p, "pending"); }).join("")
			: '<div class="sf-empty">Nothing waiting for approval 🎉</div>';
	}

	// render() only ever runs once, at boot - every action after that
	// patches just the specific DOM node that changed (a like button's
	// text, one post's comment thread, the composer region) instead of
	// tearing down and rebuilding the entire page. A full innerHTML
	// replacement on every click was forcing the browser to re-parse and
	// repaint everything - hero, composer, every other post - which is
	// what read as a full-screen "blink" on something as small as a like.
	function render() {
		root().innerHTML =
			'<div class="sf-shell">' + renderHero() +
			'<div class="sf-content-outer"><div class="sf-content">' +
			'<div id="sf-composer-region">' + renderComposer() + "</div>" +
			'<div id="sf-tabs-region">' + renderTabs() + "</div>" +
			'<div id="sf-list-region">' + (state.tab === "pending" ? renderPendingTab() : renderFeedTab()) + "</div>" +
			"</div></div></div>";
		bindEvents();
	}

	function tabsRegion() { return document.getElementById("sf-tabs-region"); }
	function listRegion() { return document.getElementById("sf-list-region"); }

	function findPost(name) {
		return state.feed.find(function (p) { return p.name === name; }) ||
			state.pending.find(function (p) { return p.name === name; });
	}


	function loadMoreHtml() {
		return '<button type="button" class="sf-load-more" id="sf-load-more">' + (state.loadingMore ? "Loading..." : "Load more") + "</button>";
	}

	// ---- targeted actions (no full render) ----

	function doLike(name) {
		apiCall("toggle_like", { post: name }).then(function (res) {
			var post = findPost(name);
			if (!post) return;
			post.likedByMe = res.liked;
			post.likeCount = res.likeCount;
			var btn = listRegion().querySelector('[data-like="' + name + '"]');
			if (btn) {
				btn.classList.toggle("liked", post.likedByMe);
				btn.innerHTML = ICONS.heart + "<span>" + (post.likeCount || "") + " Like" + (post.likeCount === 1 ? "" : "s") + "</span>";
			}
		}).catch(function (err) { showToast(err.message || "Couldn't like this post.", "error"); });
	}

	function patchComments(name) {
		var postEl = listRegion().querySelector('.sf-post[data-post="' + name + '"]');
		var post = findPost(name);
		if (!postEl || !post) return;
		var html = renderComments(post);
		var existing = postEl.querySelector(".sf-comments");
		if (existing) existing.outerHTML = html;
		else postEl.insertAdjacentHTML("beforeend", html);
	}

	function patchCommentCount(name) {
		var post = findPost(name);
		var btn = listRegion().querySelector('[data-toggle-comments="' + name + '"]');
		if (btn && post) btn.innerHTML = ICONS.comment + "<span>" + (post.commentCount || "") + " Comment" + (post.commentCount === 1 ? "" : "s") + "</span>";
	}

	function doToggleComments(name) {
		state.expanded[name] = !state.expanded[name];
		var postEl = listRegion().querySelector('.sf-post[data-post="' + name + '"]');
		if (!postEl) return;
		var existing = postEl.querySelector(".sf-comments");

		if (!state.expanded[name]) {
			if (existing) existing.remove();
			return;
		}

		if (!existing) patchComments(name); // shows the "Loading comments..." state immediately
		if (state.comments[name] == null) {
			apiCall("get_comments", { post: name }, true).then(function (list) {
				state.comments[name] = list;
				patchComments(name);
			});
		}
	}

	function sendComment(postName) {
		var text = (state.commentDraft[postName] || "").trim();
		if (!text) return;
		apiCall("add_comment", { post: postName, comment: text }).then(function (comment) {
			if (!state.comments[postName]) state.comments[postName] = [];
			state.comments[postName].push(comment);
			state.commentDraft[postName] = "";
			var post = findPost(postName);
			if (post) post.commentCount = comment.commentCount;
			patchComments(postName);
			patchCommentCount(postName);
		}).catch(function (err) { showToast(err.message || "Couldn't post comment.", "error"); });
	}

	function doDeleteComment(key) {
		var parts = key.split("|");
		var postName = parts[0], commentName = parts[1];
		showConfirm("Delete this comment?", function () {
			apiCall("delete_comment", { name: commentName }).then(function () {
				state.comments[postName] = (state.comments[postName] || []).filter(function (c) { return c.name !== commentName; });
				var post = findPost(postName);
				if (post) post.commentCount = Math.max(0, (post.commentCount || 1) - 1);
				patchComments(postName);
				patchCommentCount(postName);
			}).catch(function (err) { showToast(err.message || "Couldn't delete comment.", "error"); });
		});
	}

	// Shared by approve/reject/delete - all three just remove one post's
	// card from whichever list is currently showing.
	function removePostElementAndRefreshEmptyState() {
		var region = listRegion();
		if (region.querySelector(".sf-post")) return;
		var emptyText = state.tab === "pending" ? "Nothing waiting for approval 🎉" : "No posts yet. Be the first to share something!";
		region.innerHTML = '<div class="sf-empty">' + emptyText + "</div>" + (state.tab === "feed" && state.hasMore ? loadMoreHtml() : "");
	}

	function doApprove(name) {
		apiCall("approve_post", { post: name }).then(function () {
			state.pending = state.pending.filter(function (p) { return p.name !== name; });
			var el = listRegion().querySelector('.sf-post[data-post="' + name + '"]');
			if (el) el.remove();
			removePostElementAndRefreshEmptyState();
			tabsRegion().innerHTML = renderTabs();
		}).catch(function (err) { showToast(err.message || "Couldn't approve.", "error"); });
	}

	function doReject(name) {
		showPrompt("Reason for rejecting this post (optional):", function (reason) {
			apiCall("reject_post", { post: name, reason: reason || "" }).then(function () {
				state.pending = state.pending.filter(function (p) { return p.name !== name; });
				var el = listRegion().querySelector('.sf-post[data-post="' + name + '"]');
				if (el) el.remove();
				removePostElementAndRefreshEmptyState();
				tabsRegion().innerHTML = renderTabs();
			}).catch(function (err) { showToast(err.message || "Couldn't reject.", "error"); });
		});
	}

	function doDeletePost(name) {
		showConfirm("Delete this post? This can't be undone.", function () {
			apiCall("delete_post", { post: name }).then(function () {
				state.feed = state.feed.filter(function (p) { return p.name !== name; });
				state.pending = state.pending.filter(function (p) { return p.name !== name; });
				var el = listRegion().querySelector('.sf-post[data-post="' + name + '"]');
				if (el) el.remove();
				removePostElementAndRefreshEmptyState();
			}).catch(function (err) { showToast(err.message || "Couldn't delete.", "error"); });
		});
	}

	function switchTab(tab) {
		if (state.tab === tab) return;
		state.tab = tab;
		tabsRegion().innerHTML = renderTabs();
		listRegion().innerHTML = state.tab === "pending" ? renderPendingTab() : renderFeedTab();
	}

	function doLoadMore() {
		state.loadingMore = true;
		var btn = document.getElementById("sf-load-more");
		if (btn) btn.textContent = "Loading...";
		apiCall("get_feed", { before: state.nextBefore }, true).then(function (res) {
			state.feed = state.feed.concat(res.posts);
			state.hasMore = res.hasMore;
			state.nextBefore = res.nextBefore;
			state.loadingMore = false;
			var html = res.posts.map(function (p) { return renderPost(p, "feed"); }).join("");
			if (btn) {
				btn.insertAdjacentHTML("beforebegin", html);
				if (state.hasMore) btn.textContent = "Load more"; else btn.remove();
			}
		});
	}

	// ---- compose dialog (subtopic + announcement flag + rich text via
	// Quill + image/attachment uploads + emoji) ----
	// Same reasoning as the Hrms Home widget's dialog: the inline composer
	// above is just a trigger, all the actual writing happens here. cs is
	// a throwaway object scoped to one dialog open/close, not part of the
	// persistent page `state` - nothing here needs to survive past that.
	function openComposeDialog() {
		var cs = { images: [], attachments: [], uploading: 0, emojiOpen: false, quill: null };

		var backdrop = document.createElement("div");
		backdrop.className = "sf-compose-backdrop";
		backdrop.innerHTML =
			'<div class="sf-compose-modal">' +
			'<div class="sf-compose-header"><h3>Create Post</h3><button type="button" class="sf-compose-close" id="sf-compose-close">' + ICONS.close + "</button></div>" +
			'<div class="sf-compose-body">' +
			'<label class="sf-compose-label">Topic</label>' +
			'<input type="text" class="sf-compose-input" id="sf-compose-subtopic" placeholder="Optional - e.g. &quot;Policy Update&quot;, &quot;Team Outing&quot;">' +
			'<label class="sf-compose-checkbox"><input type="checkbox" id="sf-compose-announcement"> 📢 Mark as Announcement</label>' +
			'<div id="sf-compose-quill"></div>' +
			'<div id="sf-compose-upload-region"></div>' +
			"</div>" +
			'<div class="sf-compose-footer"><button type="button" class="sf-post-btn" id="sf-compose-post-btn">Post</button></div>' +
			"</div>";
		document.body.appendChild(backdrop);
		document.body.classList.add("sf-modal-open");

		cs.quill = new Quill(backdrop.querySelector("#sf-compose-quill"), {
			theme: "snow",
			placeholder: "What’s on your mind ?",
			modules: {
				toolbar: [
					[{ header: [1, 2, 3, false] }],
					["bold", "italic", "underline", "strike"],
					["blockquote"],
					[{ list: "ordered" }, { list: "bullet" }],
					[{ align: [] }],
					["link", "clean"],
				],
			},
		});

		renderComposeUploadRegion(backdrop, cs);
		bindComposeDialogEvents(backdrop, cs);
	}

	function closeComposeDialog(backdrop) {
		backdrop.remove();
		document.body.classList.remove("sf-modal-open");
	}

	function renderComposeUploadRegion(backdrop, cs) {
		var region = backdrop.querySelector("#sf-compose-upload-region");
		if (!region) return;

		var previewHtml = cs.images.length
			? '<div class="sf-composer-preview-grid">' + cs.images.map(function (url, i) {
				return (
					'<div class="sf-composer-preview"><img src="' + escapeHtml(url) + '">' +
					'<button type="button" class="sf-composer-preview-remove" data-remove-image="' + i + '">' + ICONS.close + "</button></div>"
				);
			}).join("") + "</div>"
			: "";
		var attachmentsHtml = cs.attachments.length
			? '<div class="sf-attachment-list">' + cs.attachments.map(renderComposerAttachmentChip).join("") + "</div>"
			: "";
		var canAddMore = cs.images.length < MAX_IMAGES || cs.attachments.length < MAX_ATTACHMENTS;

		region.innerHTML =
			previewHtml + attachmentsHtml +
			(cs.emojiOpen
				? '<div class="sf-emoji-pop" id="sf-compose-emoji-pop">' + EMOJIS.map(function (e) { return '<button type="button" data-emoji="' + e + '">' + e + "</button>"; }).join("") + "</div>"
				: "") +
			'<div class="sf-composer-footer">' +
			'<div class="sf-composer-tools">' +
			'<button type="button" class="sf-tool-btn" id="sf-compose-emoji-btn" title="Emoji">' + ICONS.emoji + "</button>" +
			'<button type="button" class="sf-tool-btn" id="sf-compose-image-btn" title="Attach files" ' + (canAddMore ? "" : "disabled") + ">" + ICONS.image + "</button>" +
			'<input type="file" multiple id="sf-compose-image-input" style="display:none">' +
			"</div>" +
			(cs.uploading ? '<div class="sf-composer-hint">Uploading file' + (cs.uploading > 1 ? "s" : "") + "...</div>" : "") +
			(!canAddMore ? '<div class="sf-composer-hint">Up to ' + MAX_IMAGES + " images and " + MAX_ATTACHMENTS + " other files per post</div>" : "") +
			"</div>";
	}

	function handleComposeImageInputChange(input, backdrop, cs) {
		var files = Array.prototype.slice.call(input.files || []);
		input.value = "";
		if (!files.length) return;

		var imageFiles = files.filter(isImageFile);
		var otherFiles = files.filter(function (f) { return !isImageFile(f); });

		var imageRoom = MAX_IMAGES - cs.images.length;
		var attachmentRoom = MAX_ATTACHMENTS - cs.attachments.length;
		var droppedMsgs = [];
		if (imageFiles.length > imageRoom) {
			droppedMsgs.push("up to " + MAX_IMAGES + " images");
			imageFiles = imageFiles.slice(0, imageRoom);
		}
		if (otherFiles.length > attachmentRoom) {
			droppedMsgs.push("up to " + MAX_ATTACHMENTS + " other files");
			otherFiles = otherFiles.slice(0, attachmentRoom);
		}
		if (droppedMsgs.length) showToast("You can attach " + droppedMsgs.join(" and ") + " per post - extra files were skipped.");

		var totalCount = imageFiles.length + otherFiles.length;
		if (!totalCount) return;
		cs.uploading = totalCount;
		renderComposeUploadRegion(backdrop, cs);

		Promise.all([
			Promise.all(imageFiles.map(function (f) { return uploadImage(f).catch(function () { return null; }); })),
			Promise.all(otherFiles.map(function (f) {
				return uploadImage(f)
					.then(function (url) { return url ? { url: url, filename: f.name, size: f.size } : null; })
					.catch(function () { return null; });
			})),
		]).then(function (results) {
			var imageUrls = results[0].filter(Boolean);
			var attachmentObjs = results[1].filter(Boolean);
			var failed = totalCount - imageUrls.length - attachmentObjs.length;
			cs.images = cs.images.concat(imageUrls);
			cs.attachments = cs.attachments.concat(attachmentObjs);
			cs.uploading = 0;
			if (failed) showToast(failed + " file(s) failed to upload.", "error");
			renderComposeUploadRegion(backdrop, cs);
		});
	}

	function submitComposeDialog(backdrop, cs) {
		var content = cs.quill.root.innerHTML;
		var plainText = cs.quill.getText().trim();
		if (!plainText && !cs.images.length && !cs.attachments.length) return;
		if (cs.uploading) return;

		var btn = backdrop.querySelector("#sf-compose-post-btn");
		btn.disabled = true;
		btn.textContent = "Posting...";

		apiCall("create_post", {
			content: content,
			subtopic: backdrop.querySelector("#sf-compose-subtopic").value || "",
			is_announcement: backdrop.querySelector("#sf-compose-announcement").checked ? 1 : 0,
			images: JSON.stringify(cs.images),
			attachments: JSON.stringify(cs.attachments),
		})
			.then(function (post) {
				closeComposeDialog(backdrop);
				state.feed.unshift(post);
				if (state.tab === "feed") {
					var region = listRegion();
					var emptyEl = region.querySelector(".sf-empty");
					if (emptyEl) emptyEl.remove();
					region.insertAdjacentHTML("afterbegin", renderPost(post, "feed"));
				}
				if (post.status !== "Approved") {
					showToast("Your post was submitted and is awaiting HR/System Manager approval. It'll show for everyone once approved.");
				}
			})
			.catch(function (err) {
				btn.disabled = false;
				btn.textContent = "Post";
				showToast(err.message || "Couldn't post. Please try again.", "error");
			});
	}

	function bindComposeDialogEvents(backdrop, cs) {
		backdrop.addEventListener("click", function (e) {
			if (e.target === backdrop) closeComposeDialog(backdrop);
		});
		backdrop.addEventListener("mousedown", function (e) {
			if (e.target.closest("[data-emoji]")) e.preventDefault();
		});
		backdrop.addEventListener("click", function (e) {
			var t = e.target;
			var el;

			if (t.closest("#sf-compose-close")) { closeComposeDialog(backdrop); return; }
			if ((el = t.closest("#sf-compose-emoji-btn"))) {
				e.stopPropagation();
				cs.emojiOpen = !cs.emojiOpen;
				renderComposeUploadRegion(backdrop, cs);
				return;
			}
			if ((el = t.closest("[data-emoji]"))) {
				var emoji = el.getAttribute("data-emoji");
				var range = cs.quill.getSelection(true) || { index: cs.quill.getLength() - 1 };
				cs.quill.insertText(range.index, emoji, "user");
				cs.quill.setSelection(range.index + emoji.length, 0);
				cs.emojiOpen = false;
				renderComposeUploadRegion(backdrop, cs);
				return;
			}
			if (t.closest("#sf-compose-image-btn")) {
				var input = backdrop.querySelector("#sf-compose-image-input");
				if (input) input.click();
				return;
			}
			if ((el = t.closest("[data-remove-image]"))) {
				cs.images.splice(parseInt(el.getAttribute("data-remove-image"), 10), 1);
				renderComposeUploadRegion(backdrop, cs);
				return;
			}
			if ((el = t.closest("[data-remove-attachment]"))) {
				cs.attachments.splice(parseInt(el.getAttribute("data-remove-attachment"), 10), 1);
				renderComposeUploadRegion(backdrop, cs);
				return;
			}
			if (t.closest("#sf-compose-post-btn")) { submitComposeDialog(backdrop, cs); return; }
		});
		backdrop.addEventListener("change", function (e) {
			if (e.target.id === "sf-compose-image-input") handleComposeImageInputChange(e.target, backdrop, cs);
		});
	}

	// ---- events (bound once - every action above patches the DOM itself) ----

	function bindEvents() {
		var app = root();

		app.addEventListener("input", function (e) {
			if (e.target.matches("[data-comment-input]")) {
				state.commentDraft[e.target.getAttribute("data-comment-input")] = e.target.value;
			}
		});
		app.addEventListener("keydown", function (e) {
			if (e.target.matches("[data-comment-input]") && e.key === "Enter") {
				sendComment(e.target.getAttribute("data-comment-input"));
			}
		});

		app.addEventListener("click", function (e) {
			var t = e.target;
			var el;

			if (t.closest("#sf-composer-trigger, #sf-emoji-btn, #sf-image-btn, #sf-post-btn")) { openComposeDialog(); return; }
			if ((el = t.closest("[data-tab]"))) { switchTab(el.getAttribute("data-tab")); return; }
			if ((el = t.closest("[data-like]"))) { doLike(el.getAttribute("data-like")); return; }
			if ((el = t.closest("[data-toggle-comments]"))) { doToggleComments(el.getAttribute("data-toggle-comments")); return; }
			if ((el = t.closest("[data-send-comment]"))) { sendComment(el.getAttribute("data-send-comment")); return; }
			if ((el = t.closest("[data-delete-comment]"))) { doDeleteComment(el.getAttribute("data-delete-comment")); return; }
			if ((el = t.closest("[data-approve]"))) { doApprove(el.getAttribute("data-approve")); return; }
			if ((el = t.closest("[data-reject]"))) { doReject(el.getAttribute("data-reject")); return; }
			if ((el = t.closest("[data-delete]"))) { doDeletePost(el.getAttribute("data-delete")); return; }
			if (t.closest("#sf-load-more")) { doLoadMore(); return; }
		});
	}

	// ---- deep-link: ?post=<name> (from the Hrms Home widget's "View on
	// Social Feed" links, or anyone sharing a direct link to one post) ----
	// scrolls to and briefly highlights that post once it's on the page.
	// The target is almost always on the very first get_feed page already
	// (both the widget and this page list newest-first), but if it isn't -
	// an older post someone linked to directly - keep paging in more of
	// the feed via the same cursor doLoadMore() uses, capped at 20 pages
	// so a bad/stale link can't page through the entire feed forever.
	function scrollToLinkedPost() {
		var target = new URLSearchParams(window.location.search).get("post");
		if (!target) return;
		findLinkedPost(target, 20);
	}

	function findLinkedPost(name, pagesLeft) {
		var el = listRegion() && listRegion().querySelector('.sf-post[data-post="' + name + '"]');
		if (el) {
			el.scrollIntoView({ behavior: "smooth", block: "center" });
			el.classList.add("sf-post-highlight");
			setTimeout(function () { el.classList.remove("sf-post-highlight"); }, 2500);
			return;
		}
		if (pagesLeft <= 0 || !state.hasMore || state.tab !== "feed") return;
		apiCall("get_feed", { before: state.nextBefore }, true).then(function (res) {
			state.feed = state.feed.concat(res.posts);
			state.hasMore = res.hasMore;
			state.nextBefore = res.nextBefore;
			listRegion().innerHTML = renderFeedTab();
			findLinkedPost(name, pagesLeft - 1);
		});
	}

	// ---- boot ----
	function boot() {
		apiCall("get_feed", {}, true)
			.then(function (res) {
				state.feed = res.posts;
				state.hasMore = res.hasMore;
				state.nextBefore = res.nextBefore;
				state.canApprove = res.canApprove;
				state.me = res.me;
				if (state.canApprove) {
					return apiCall("get_pending_posts", {}, true).then(function (pending) {
						state.pending = pending;
					});
				}
			})
			.then(function () {
				render();
				scrollToLinkedPost();
			})
			.catch(function (err) {
				renderError(err.message || "Something went wrong loading the feed. Please refresh.");
			});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}
})();
