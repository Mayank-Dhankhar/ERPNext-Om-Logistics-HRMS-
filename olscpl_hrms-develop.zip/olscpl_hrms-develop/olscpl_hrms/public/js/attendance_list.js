// Overrides frappe.listview_settings["Attendance"].onload from HRMS core
// solely to add "Week Off" to the Mark Attendance dialog's status options.
// Loads AFTER core's attendance_list.js via doctype_list_js hook, so this
// reassignment happens last and wins.

frappe.listview_settings["Attendance"].onload = function (list_view) {
	let me = this;

	list_view.page.add_inner_button(__("Mark Attendance"), function () {
		let first_day_of_month = moment().startOf("month");

		if (moment().toDate().getDate() === 1) {
			first_day_of_month = first_day_of_month.subtract(1, "month");
		}

		let dialog = new frappe.ui.Dialog({
			title: __("Mark Attendance"),
			fields: [
				{
					fieldname: "employee",
					label: __("For Employee"),
					fieldtype: "Link",
					options: "Employee",
					get_query: () => {
						return {
							query: "erpnext.controllers.queries.employee_query",
						};
					},
					reqd: 1,
					onchange: () => me.reset_dialog(dialog),
				},
				{
					fieldtype: "Section Break",
					fieldname: "time_period_section",
					hidden: 1,
				},
				{
					label: __("Start"),
					fieldtype: "Date",
					fieldname: "from_date",
					reqd: 1,
					default: first_day_of_month.toDate(),
					onchange: () => me.get_unmarked_days(dialog),
				},
				{
					fieldtype: "Column Break",
					fieldname: "time_period_column",
				},
				{
					label: __("End"),
					fieldtype: "Date",
					fieldname: "to_date",
					reqd: 1,
					default: moment().toDate(),
					onchange: () => me.get_unmarked_days(dialog),
				},
				{
					fieldtype: "Section Break",
					fieldname: "days_section",
					hidden: 1,
				},
				{
					label: __("Status"),
					fieldtype: "Select",
					fieldname: "status",
					// --- OLSCPL customization: added "Week Off" ---
					options: ["Present", "Absent", "Half Day", "Work From Home", "Week Off", "Holiday", "Visit"],
					reqd: 1,
				},
				{
					label: __("Exclude Holidays"),
					fieldtype: "Check",
					fieldname: "exclude_holidays",
					onchange: () => me.get_unmarked_days(dialog),
				},
				{
					label: __("Unmarked Attendance for days"),
					fieldname: "unmarked_days",
					fieldtype: "MultiCheck",
					options: [],
					columns: 2,
					select_all: true,
				},
			],
			primary_action(data) {
				if (cur_dialog.no_unmarked_days_left) {
					frappe.msgprint(
						__(
							"Attendance from {0} to {1} has already been marked for the Employee {2}",
							[data.from_date, data.to_date, data.employee],
						),
					);
				} else {
					frappe.confirm(
						__("Mark attendance as {0} for {1} on selected dates?", [
							data.status,
							data.employee,
						]),
						() => {
							frappe.call({
								method: "hrms.hr.doctype.attendance.attendance.mark_bulk_attendance",
								args: {
									data: data,
								},
							});
						},
					);
				}
				dialog.hide();
				list_view.refresh();
			},
			primary_action_label: __("Mark Attendance"),
		});
		dialog.show();
	});
};

frappe.listview_settings["Attendance"].get_indicator = function (doc) {
	if (["Present", "Work From Home", "Visit"].includes(doc.status)) {
		return [__(doc.status), "green", "status,=," + doc.status];
	} else if (["Absent", "On Leave"].includes(doc.status)) {
		return [__(doc.status), "red", "status,=," + doc.status];
	} else if (doc.status == "Half Day") {
		return [__(doc.status), "orange", "status,=," + doc.status];
	} else if (doc.status == "Week Off") {
		return [__(doc.status), "gray", "status,=," + doc.status];
	} else if (doc.status == "Holiday") {
		return [__(doc.status), "cyan", "status,=," + doc.status];
	}	
};
