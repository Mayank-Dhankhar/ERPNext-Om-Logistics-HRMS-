// The CSS hides body[data-path="login"] from first paint (a server-rendered
// attribute, so no JS timing is needed for the hide). This script reveals it
// again once the split layout is built. The `finally` guarantees the reveal
// runs even if something below returns early, so the page can't get stuck hidden.
function build_split_login() {
    if (document.body.getAttribute("data-path") !== "login") return;

    try {
        if (document.querySelector(".om-login-panel")) return;

        const panel = document.createElement("div");
        panel.className = "om-login-panel";
        panel.innerHTML = `
            <div class="om-login-ring"></div>
            <div class="om-login-brand">
                <img src="/assets/olscpl_hrms/images/om_logo.svg" alt="OM Logistics" />
                <span class="om-login-badge">OM LOGISTICS &middot; WORK HUB</span>
            </div>
            <div class="om-login-content">
                <h1 class="om-login-product">ATLAS</h1>
                <p class="om-login-tagline">HR, Payroll and Attendance for OM Logistics teams — one place for every employee.</p>
                <ul class="om-login-features">
                    <li>Attendance System</li>
                    <li>Talent management</li>
                    <li>Leave management</li>
                    <li>Performance appraisals</li>
                    <li>Salary &amp; payroll processing</li>
                </ul>
                <p class="om-login-closing">The people system that holds everything up.</p>
            </div>
            <div class="om-login-footer">&copy; OM Logistics &middot; OmOne ATLAS</div>
        `;
        document.body.appendChild(panel);
        document.body.classList.add("om-split-login");

        const loginSection = document.querySelector("section.for-login");
        if (!loginSection) return;

        const cardBody = loginSection.querySelector(".page-card-body");
        const cardActions = loginSection.querySelector(".page-card-actions");
        const forgotMessage = loginSection.querySelector(".forgot-password-message");

        if (cardBody && !loginSection.querySelector(".om-card-heading")) {
            const heading = document.createElement("div");
            heading.className = "om-card-heading-block";
            heading.innerHTML = `
                <h2 class="om-card-heading">Sign in to OmOne ATLAS</h2>
                <p class="om-card-subtitle">Access your HR, payroll and attendance details.</p>
            `;
            cardBody.parentElement.insertBefore(heading, cardBody);
        }

        const emailInput = loginSection.querySelector("#login_email");
        if (emailInput && emailInput.placeholder === "jane@example.com") {
            emailInput.placeholder = "name@example.com";
        }

        // Move "Forgot Password?" to appear below the Login button, centered.
        if (forgotMessage && cardActions) {
            cardActions.appendChild(forgotMessage);
        }

        if (cardActions && !loginSection.querySelector(".om-login-helper")) {
            const helper = document.createElement("div");
            helper.className = "om-login-helper";
            helper.innerHTML = `
                <p>Need access? Ask your HR team to invite you.</p>
                <p>Use your OM Logistics work email<br><span class="om-login-domains">(<strong>@omlogistics.co.in</strong> / <strong>@olsc.in</strong>).</span></p>
            `;
            cardActions.parentElement.insertBefore(helper, cardActions.nextSibling);
        }
        build_login_mascot(loginSection);
        build_login_form_feedback(loginSection);
        // Double rAF: the class must be added on a frame *after* the browser
        // has painted the pre-entrance state (see .om-login-ready in CSS),
        // or the transition has nothing to animate from and the card/mascot
        // just snap straight to their end state instead of settling in.
        requestAnimationFrame(() => requestAnimationFrame(() => {
            document.body.classList.add("om-login-ready");
        }));
    } finally {
        document.body.style.visibility = "visible";
    }
}

// Loading state on the Login button, and a re-triggerable shake on the
// input row when Frappe marks a failed attempt. Frappe's own login.js
// (see templates/includes/login/login.js) drives all of this through the
// submit button's text ("Login" -> "Verifying..." -> "Success" or the
// error message) and a ".page-card-body.invalid" class it adds and never
// removes - watched here via MutationObserver rather than changed, so a
// stock Frappe upgrade can't silently break this by touching that file.
function build_login_form_feedback(loginSection) {
    const btn = loginSection.querySelector(".btn-login");
    const body = loginSection.querySelector(".page-card-body");
    if (!btn || !body) return;

    let attempt = 0;
    let handledFailureFor = 0;
    const form = loginSection.querySelector(".form-login");
    if (form) form.addEventListener("submit", () => { attempt++; }, true);

    const sync = () => {
        const text = btn.textContent.trim();
        btn.classList.toggle("om-loading", text === "Verifying...");
        if (attempt > handledFailureFor && body.classList.contains("invalid") && text !== "Verifying..." && text !== "Success") {
            handledFailureFor = attempt;
            body.classList.remove("om-shake");
            void body.offsetWidth; // restart the animation on every failed attempt, not just the first
            body.classList.add("om-shake");
        }
    };
    new MutationObserver(sync).observe(loginSection, { attributes: true, childList: true, characterData: true, subtree: true });
}

// Animated character above the login card. Two are available, switched by
// OM_LOGIN_CHARACTER: "truck" (our own layered-SVG Om Logistics truck, the
// headlights are its eyes) and "face" (a static image, no eye/hand
// reactions - see om_face_driver). Both expose the same small API so the
// form wiring below is shared: checking(on), look(n), hands(on), success(),
// fail(). A third option, a Rive-animated bear, was tried and removed
// (unused) - the login-page mascot / bear commit history has it if this
// direction comes back.
const OM_LOGIN_CHARACTER = "truck";
const OM_FACE_IMG = "/assets/olscpl_hrms/images/om_truck_face.png";

const OM_TRUCK_SVG = `
<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="omBody" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#2f62f0"/><stop offset="1" stop-color="#1b3fb8"/>
    </linearGradient>
  </defs>
  <g class="om-t-truck">
    <rect x="46" y="166" width="24" height="22" rx="6" fill="#1a1d29"/>
    <rect x="130" y="166" width="24" height="22" rx="6" fill="#1a1d29"/>
    <rect x="30" y="72" width="12" height="22" rx="4" fill="#1a1d29"/>
    <rect x="158" y="72" width="12" height="22" rx="4" fill="#1a1d29"/>
    <rect x="38" y="42" width="124" height="126" rx="20" fill="url(#omBody)"/>
    <rect x="32" y="34" width="136" height="20" rx="9" fill="#173296"/>
    <text x="100" y="48.5" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-weight="800" font-size="12" fill="#fff" letter-spacing="3.5">ATLAS</text>
    <rect x="52" y="60" width="96" height="36" rx="9" fill="#d6e8ff"/>
    <path d="M52 78 L148 66" stroke="#fff" stroke-opacity=".55" stroke-width="5" stroke-linecap="round"/>
    <rect x="86" y="120" width="28" height="26" rx="5" fill="#0f1b3d"/>
    <path d="M91 127h18M91 133h18M91 139h18" stroke="#3b4f8f" stroke-width="2" stroke-linecap="round"/>
    <rect x="34" y="150" width="132" height="18" rx="8" fill="#1a1d29"/>
    <rect x="34" y="150" width="132" height="6" rx="3" fill="#ffc933"/>
    <path class="om-t-mouth" d="M88 161 Q100 168 112 161" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>
    <g class="om-t-eye" style="transform-origin:66px 134px"><circle cx="66" cy="134" r="17" fill="#fff" stroke="#0f1b3d" stroke-width="3"/><circle class="om-t-pupil" cx="66" cy="134" r="9.5" fill="#101828"/><circle class="om-t-glint" cx="63" cy="131" r="3" fill="#fff"/><circle class="om-t-lidfill" cx="66" cy="134" r="19" fill="#2650cf"/></g>
    <g class="om-t-eye" style="transform-origin:134px 134px"><circle cx="134" cy="134" r="17" fill="#fff" stroke="#0f1b3d" stroke-width="3"/><circle class="om-t-pupil" cx="134" cy="134" r="9.5" fill="#101828"/><circle class="om-t-glint" cx="131" cy="131" r="3" fill="#fff"/><circle class="om-t-lidfill" cx="134" cy="134" r="19" fill="#2650cf"/></g>
    <path class="om-t-brow om-t-brow-l" d="M50 111 Q65 103 82 110" fill="none" stroke="#0b1533" stroke-width="5.5" stroke-linecap="round"/>
    <path class="om-t-brow om-t-brow-r" d="M118 110 Q135 103 150 111" fill="none" stroke="#0b1533" stroke-width="5.5" stroke-linecap="round"/>
    <path class="om-t-lid" d="M50 135 Q66 145 82 135" fill="none" stroke="#0b1533" stroke-width="4" stroke-linecap="round"/>
    <path class="om-t-lid" d="M118 135 Q134 145 150 135" fill="none" stroke="#0b1533" stroke-width="4" stroke-linecap="round"/>
  </g>
</svg>`;

// Own SVG truck: pupils look along the email as it is typed, eyes close for
// the password. Motion is CSS (see olscpl_theme.css).
function om_truck_driver(wrap) {
    wrap.innerHTML = OM_TRUCK_SVG;
    const pupils = wrap.querySelectorAll(".om-t-pupil, .om-t-glint");
    const pulse = (cls, ms) => {
        wrap.classList.remove("om-t-ok", "om-t-bad");
        void wrap.offsetWidth;
        wrap.classList.add(cls);
        setTimeout(() => wrap.classList.remove(cls), ms);
    };
    const move = (dx, dy) => pupils.forEach((el) => { el.style.transform = `translate(${dx}px, ${dy}px)`; });

    // Eyes follow the cursor around the page (paused while hands() is up
    // for the password field). Offset is the angle from the truck's own
    // centre to the pointer, clamped to a small radius so the pupils stay
    // inside the headlight rather than actually reaching the cursor.
    let following = true;
    const lookAt = (mx, my) => {
        if (!following) return;
        const r = wrap.getBoundingClientRect();
        const cx = r.left + r.width / 2;
        const cy = r.top + r.height / 2;
        const dx = mx - cx;
        const dy = my - cy;
        const dist = Math.hypot(dx, dy) || 1;
        // Eye socket r=17, pupil r=9.5 (see OM_TRUCK_SVG) - 7 keeps the
        // pupil's own edge just inside the white before it would start
        // clipping past the socket outline.
        const radius = 7;
        move((dx / dist) * radius, (dy / dist) * radius);
    };
    if (!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches)) {
        document.addEventListener("mousemove", (e) => lookAt(e.clientX, e.clientY));
    }

    return {
        checking: (on) => wrap.classList.toggle("om-t-checking", on),
        look: () => {}, // superseded by lookAt/mousemove above - kept as a no-op so other drivers' shared call sites don't need a feature check
        hands: (on) => {
            wrap.classList.toggle("om-t-covering", on);
            following = !on;
            if (on) move(0, 0);
        },
        success: () => pulse("om-t-ok", 1400),
        fail: () => {
            pulse("om-t-bad", 900);
            // Web Animations shake: always restarts from the beginning, so
            // every wrong password shakes even if a class is still set.
            const t = wrap.querySelector(".om-t-truck");
            if (t && t.animate) t.animate(
                [{ transform: "translateX(0)" }, { transform: "translateX(-7px)" }, { transform: "translateX(7px)" }, { transform: "translateX(0)" }],
                { duration: 130, iterations: 6 }
            );
        },
    };
}

// Static Om Logistics truck-face image. It is one flat picture (no separate
// eye/hand layers), so it can only float, glow and shake - it cannot close
// its eyes for the password field or change its mouth. Use om_truck_driver
// (the layered SVG truck) instead if those reactions matter more than this
// artwork.
function om_face_driver(wrap) {
    wrap.innerHTML = `<img src="${OM_FACE_IMG}" alt="" draggable="false" class="om-t-face-img" />`;
    const pulse = (cls, ms) => {
        wrap.classList.remove("om-t-ok", "om-t-bad");
        void wrap.offsetWidth;
        wrap.classList.add(cls);
        setTimeout(() => wrap.classList.remove(cls), ms);
    };
    return {
        checking: () => {},
        look: () => {},
        hands: (on) => wrap.classList.toggle("om-t-covering", on),
        success: () => pulse("om-t-ok", 1400),
        fail: () => {
            pulse("om-t-bad", 900);
            const img = wrap.querySelector(".om-t-face-img");
            if (img && img.animate) img.animate(
                [{ transform: "translateX(0)" }, { transform: "translateX(-7px)" }, { transform: "translateX(7px)" }, { transform: "translateX(0)" }],
                { duration: 130, iterations: 6 }
            );
        },
    };
}

function build_login_mascot(loginSection) {
    if (document.querySelector(".om-bear")) return;
    const card = loginSection.querySelector(".login-content.page-card");
    if (!card) return;

    const wrap = document.createElement("div");
    wrap.className = "om-bear";
    wrap.setAttribute("aria-hidden", "true");
    document.body.appendChild(wrap);
    document.body.classList.add("om-has-bear");
    const api = OM_LOGIN_CHARACTER === "face" ? om_face_driver(wrap) : om_truck_driver(wrap);

    const place = () => {
        const r = card.getBoundingClientRect();
        // hidden when the card is not shown, or too near the top of the
        // window for the character to fit above it
        const visible = r.width > 0 && r.height > 0 && r.top - 130 >= 4;
        wrap.style.display = visible ? "" : "none";
        if (!visible) return;
        wrap.style.left = (r.left + r.width / 2 - 90) + "px";
        wrap.style.top = (r.top - 130) + "px";
    };
    place();
    window.addEventListener("resize", place);
    if (window.ResizeObserver) new ResizeObserver(place).observe(card);
    new MutationObserver(place).observe(loginSection, { attributes: true, subtree: true, attributeFilter: ["class", "style"] });

    const email = loginSection.querySelector("#login_email");
    const pwd = loginSection.querySelector("#login_password");
    wrap._api = api;
    if (email) {
        email.addEventListener("focus", () => api.checking(true));
        email.addEventListener("blur", () => api.checking(false));
    }
    if (pwd) {
        pwd.addEventListener("focus", () => { api.checking(false); api.hands(true); });
        pwd.addEventListener("blur", () => api.hands(false));
    }

    // Frappe writes the result of the login into the submit button's text:
    // "Verifying..." while waiting, then "Success" or the error message. Each
    // submit is one attempt, and the first result text after "Verifying..."
    // that is not "Success" counts as one failure - so every wrong password
    // reacts, however often it is repeated.
    let attempt = 0, handled = 0;
    const react = () => {
        const btn = loginSection.querySelector(".btn-primary");
        const txt = btn ? btn.textContent.trim() : "";
        if (txt === "Success") { api.success(); return; }
        if (attempt > handled && txt && txt !== "Verifying..." && txt !== "Login") {
            handled = attempt;
            api.hands(false);
            api.fail();
        }
    };
    new MutationObserver(react).observe(loginSection, { attributes: true, childList: true, characterData: true, subtree: true });

    const form = loginSection.querySelector(".form-login");
    if (form) form.addEventListener("submit", () => { attempt++; }, true);
}

// This script loads via web_include_js, which can execute after
// DOMContentLoaded has already fired (e.g. when the browser serves it from
// cache) - an addEventListener("DOMContentLoaded", ...) attached at that
// point never runs, leaving the page permanently hidden. readyState "loading"
// is the only state where the event hasn't fired yet.
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", build_split_login);
} else {
    build_split_login();
}
