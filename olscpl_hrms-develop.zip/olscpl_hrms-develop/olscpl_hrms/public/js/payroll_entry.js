// olscpl_hrms/public/js/payroll_entry.js
//
// "Get Employees", faster and with visible progress (api/payroll_entry.py).
// Replaces stock HRMS's get_employee_details (loaded after it, so the button's
// frm.events.get_employee_details is this one): the server selects and writes
// the rows in bulk and reports progress; a progress panel replaces the blank
// "Fetching Employees" freeze; the form then reloads.

frappe.ui.form.on("Payroll Entry", {
	get_employee_details(frm) {
		const run = () => fetch_employees_with_progress(frm);
		// a draft with unsaved edits is saved first, as the server reads the saved doc
		return frm.is_dirty() || frm.is_new() ? frm.save().then(run) : run();
	},
});

function fetch_employees_with_progress(frm) {
	const panel = new PayrollFetchProgress();
	const on_progress = (d) => d && d.name === frm.doc.name && panel.update(d);
	frappe.realtime.on("payroll_entry_fetch_progress", on_progress);
	const finish = () => {
		frappe.realtime.off("payroll_entry_fetch_progress", on_progress);
		setTimeout(() => panel.close(), 450);
	};

	return new Promise((resolve) => {
		frappe.call({
			method: "olscpl_hrms.api.payroll_entry.fetch_employees",
			args: { name: frm.doc.name },
			callback: (r) => {
				const res = r.message || {};
				panel.update({ stage: "done", done: res.count, total: res.count });
				frm.reload_doc().then(() => {
					if (res.validate_attendance) {
						frm.fields_dict.attendance_detail_html.html(
							frappe.render_template("employees_with_unmarked_attendance", { data: res.unmarked }),
						);
					}
					frm.scroll_to_field("employees");
					frappe.show_alert({
						message: __("{0} employees added", [format_number(res.count, null, 0)]),
						indicator: "green",
					});
					finish();
					resolve();
				});
			},
			// server error (e.g. "No employees found"): close the panel; frappe shows the message
			error: () => {
				finish();
				resolve();
			},
		});
	});
}

class PayrollFetchProgress {
	constructor() {
		this.shown = 0;
		this.target = 0;
		this.total = 0;
		this.$el = $(`
			<div class="om-pfp" role="dialog" aria-modal="true" aria-live="polite">
				<div class="om-pfp-card">
					<div class="om-pfp-title">${__("Getting employees")}</div>
					<div class="om-pfp-stage">${__("Finding eligible employees…")}</div>
					<div class="om-pfp-count"><span class="om-pfp-done">0</span><span class="om-pfp-of"></span></div>
					<div class="om-pfp-track is-indeterminate"><div class="om-pfp-bar"></div></div>
					<div class="om-pfp-pct"></div>
				</div>
			</div>`).appendTo(document.body);
		requestAnimationFrame(() => this.$el.addClass("is-open"));
		this.tick = this.tick.bind(this);
		requestAnimationFrame(this.tick);
	}

	update({ stage, done = 0, total = 0 }) {
		const stages = {
			finding: __("Finding eligible employees…"),
			saving: __("Adding employees to this payroll…"),
			done: __("All employees added"),
		};
		if (stages[stage]) this.$el.find(".om-pfp-stage").text(stages[stage]);
		if (total) {
			this.total = total;
			this.target = done;
			this.$el.find(".om-pfp-track").removeClass("is-indeterminate");
			this.$el.find(".om-pfp-of").text(` / ${format_number(total, null, 0)} ${__("employees")}`);
		}
		this.$el.toggleClass("is-done", stage === "done");
	}

	// ease the shown count and bar toward the latest reported value
	tick() {
		if (!this.$el) return;
		this.shown += (this.target - this.shown) * 0.18;
		if (Math.abs(this.target - this.shown) < 0.5) this.shown = this.target;
		const pct = this.total ? (this.shown / this.total) * 100 : 0;
		this.$el.find(".om-pfp-done").text(format_number(Math.round(this.shown), null, 0));
		if (this.total) {
			this.$el.find(".om-pfp-bar").css("width", `${pct}%`);
			this.$el.find(".om-pfp-pct").text(`${Math.round(pct)}%`);
		}
		requestAnimationFrame(this.tick);
	}

	close() {
		const $el = this.$el;
		this.$el = null;
		$el.removeClass("is-open");
		setTimeout(() => $el.remove(), 250);
	}
}

frappe.dom.set_style(`
.om-pfp { position: fixed; inset: 0; z-index: 1060; display: grid; place-items: center;
	background: rgba(11, 24, 67, .38); backdrop-filter: blur(6px); opacity: 0; transition: opacity .2s ease; }
.om-pfp.is-open { opacity: 1; }
.om-pfp-card { width: min(440px, calc(100vw - 32px)); padding: 26px 28px 22px; border-radius: 18px;
	background: #fff; box-shadow: 0 30px 60px -20px rgba(11, 24, 67, .45), 0 0 0 1px rgba(16, 34, 95, .06);
	transform: translateY(8px) scale(.98); transition: transform .25s cubic-bezier(.2, .8, .2, 1); }
.om-pfp.is-open .om-pfp-card { transform: none; }
.om-pfp-title { font-size: 17px; font-weight: 700; color: rgb(16, 34, 95); }
.om-pfp-stage { margin-top: 4px; font-size: 13px; color: #6b7393; min-height: 18px; }
.om-pfp-count { margin: 18px 0 10px; font-variant-numeric: tabular-nums; color: rgb(16, 34, 95); }
.om-pfp-done { font-size: 34px; font-weight: 800; letter-spacing: -.02em; }
.om-pfp-of { font-size: 14px; font-weight: 600; color: #8a90ab; }
.om-pfp-track { position: relative; height: 10px; border-radius: 999px; background: #eceff7; overflow: hidden; }
.om-pfp-bar { position: absolute; inset: 0 auto 0 0; width: 0; border-radius: inherit;
	background: linear-gradient(90deg, rgb(23, 46, 122), #4f6bff 60%, #3fc79a); }
.om-pfp-bar::after { content: ""; position: absolute; inset: 0;
	background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .55), transparent);
	transform: translateX(-100%); animation: om-pfp-sheen 1.4s ease-in-out infinite; }
.om-pfp-track.is-indeterminate .om-pfp-bar { width: 35%; animation: om-pfp-slide 1.2s ease-in-out infinite; }
.om-pfp-pct { margin-top: 8px; text-align: right; font-size: 12px; font-weight: 700; color: #4f6bff;
	font-variant-numeric: tabular-nums; min-height: 16px; }
.om-pfp.is-done .om-pfp-pct { color: #1f8a5b; }
@keyframes om-pfp-sheen { to { transform: translateX(100%); } }
@keyframes om-pfp-slide { from { left: -35%; } to { left: 100%; } }
@media (prefers-reduced-motion: reduce) {
	.om-pfp, .om-pfp-card { transition: none; }
	.om-pfp-bar::after, .om-pfp-track.is-indeterminate .om-pfp-bar { animation: none; }
}
`);

// ── Create Salary Slips: progress panel (api/payroll_entry.get_slip_progress) ──
// A panel at the top of the Payroll Entry (not a dialog - it can't be closed):
// submitting, then live slip creation (done / pending / failed, speed, time
// left, failures with reasons), then a lasting summary. Replaces the white
// "Submitting…" freeze and the bare "Queued" status. The jobs run in the
// background; the panel picks up again whenever the form is opened.
frappe.ui.form.on("Payroll Entry", {
	refresh(frm) {
		const draft_ready =
			frm.doc.docstatus === 0 && !frm.is_new() && (frm.doc.employees || []).length &&
			!cint(frm.doc.salary_slips_created) && !frappe.model.has_workflow(frm.doctype);
		if (draft_ready) {
			frm.page.clear_primary_action();
			frm.page.set_primary_action(__("Create Salary Slips"), () => submit_and_create(frm));
		}
		const cancelling = frm.__cancel_panel && document.body.contains(frm.__cancel_panel.$el[0]);
		// Submit Salary Slip on a big run is queued (overrides/payroll_entry.submit_salary_slips) - show it
		frappe.realtime.off("payroll_slip_submit_started");
		frappe.realtime.on("payroll_slip_submit_started", (d) => d.name === frm.doc.name && frm.reload_doc());
		const panel = SlipPanel.get(frm);
		if (!cancelling && frm.doc.docstatus === 1 && ["Queued", "Failed", "Submitted"].includes(frm.doc.status)) panel.watch();
		else if (!panel.busy) panel.remove();
	},
	create_salary_slip(frm) {
		// retry after a Failed run: only the missing employees are created
		const panel = SlipPanel.get(frm);
		panel.stage(__("Starting…"));
		frappe.call({ method: "run_doc_method", args: { method: "create_salary_slips", dt: "Payroll Entry", dn: frm.doc.name } })
			.then(() => frm.reload_doc());
	},
});

function submit_and_create(frm) {
	const panel = SlipPanel.get(frm);
	panel.busy = true;
	panel.stage(__("Submitting the payroll entry…"));
	frm.page.clear_primary_action();
	// same save as frm.save("Submit") but without the full-screen freeze - the panel shows progress
	frappe.call({
		method: "frappe.desk.form.save.savedocs",
		args: { doc: frm.doc, action: "Submit" },
		callback: () => {
			panel.busy = false;
			frm.reload_doc();
		},
		error: () => {
			panel.busy = false;
			panel.remove();
			frm.refresh();
		},
	});
}

class SlipPanel {
	static get(frm) {
		if (!frm.__slip_panel || !document.body.contains(frm.__slip_panel.$el[0])) frm.__slip_panel = new SlipPanel(frm);
		return frm.__slip_panel;
	}

	constructor(frm) {
		this.frm = frm;
		this.samples = [];
		this.$el = $(`
			<div class="om-ssp" aria-live="polite">
				<div class="om-ssp-head">
					<div class="om-ssp-title">${__("Salary slips")}</div>
					<div class="om-ssp-stage"></div>
					<div class="om-ssp-pct"><b>0</b>%</div>
				</div>
				<div class="om-ssp-track is-indeterminate"><div class="om-ssp-bar"></div></div>
				<div class="om-ssp-tiles">
					<div class="om-ssp-tile"><span>${__("Total")}</span><b data-k="total">–</b></div>
					<div class="om-ssp-tile is-ok"><span>${__("Created")}</span><b data-k="created">–</b></div>
					<div class="om-ssp-tile"><span>${__("Pending")}</span><b data-k="pending">–</b></div>
					<div class="om-ssp-tile is-bad"><span>${__("Failed")}</span><b data-k="failed">0</b></div>
				</div>
				<div class="om-ssp-meta"><span data-k="speed"></span><span data-k="eta"></span><span data-k="elapsed"></span><span data-k="jobs"></span>
					<a class="om-ssp-view" hidden>${__("View salary slips")} ›</a>
					<button class="btn btn-xs btn-default om-ssp-stop" hidden>${__("Stop creating slips")}</button></div>
				<div class="om-ssp-procs" hidden></div>
				<details class="om-ssp-fail" hidden><summary></summary><ul></ul></details>
			</div>`);
		frm.layout.wrapper.prepend(this.$el);
		this.$el.on("click", ".om-ssp-view", () => frappe.set_route("List", "Salary Slip", { payroll_entry: frm.doc.name }));
		this.$el.on("click", ".om-ssp-stop", () => this.stop());
	}

	stage(text) {
		this.$el.find(".om-ssp-stage").text(text);
	}

	set(k, v) {
		this.$el.find(`[data-k="${k}"]`).text(v);
	}

	watch() {
		if (this.polling) return;
		this.polling = true;
		const poll = () => {
			frappe.call({
				method: "olscpl_hrms.api.payroll_entry.get_slip_progress",
				args: { name: this.frm.doc.name },
				callback: (r) => {
					if (!r.message || !document.body.contains(this.$el[0])) return (this.polling = false);
					this.render(r.message);
					if (r.message.done) {
						this.polling = false;
						if (this.was_running) this.frm.reload_doc();
						return;
					}
					this.was_running = true;
					this.timer = setTimeout(poll, 2000);
				},
				error: () => (this.timer = setTimeout(poll, 5000)),
			});
		};
		poll();
	}

	render(p) {
		const fmt = (n) => format_number(n, null, 0);
		const submit = p.mode === "submit";
		const emailing = submit && p.phase === "email" && !p.done;
		if (p.phase !== this.phase) [this.phase, this.samples] = [p.phase, []]; // speed per step
		const total = emailing ? p.email_total : p.total || 0;
		const done = emailing ? p.emailed : p.created + p.failed_count;
		const pct = total ? Math.min(100, (done / total) * 100) : 0;
		this.$el.find(".om-ssp-title").text(submit ? __("Submitting salary slips") : __("Salary slips"));
		this.$el.find(".om-ssp-tile.is-ok span").text(emailing ? __("Emailed") : submit ? __("Submitted") : __("Created"));
		this.$el.find(".om-ssp-stop").text(submit ? __("Stop submitting") : __("Stop creating slips"));
		this.$el.toggleClass("is-finished", !!p.done).toggleClass("has-failed", p.done && !!p.failed_count);
		this.$el.find(".om-ssp-track").toggleClass("is-indeterminate", !p.done && (!done || (submit && p.phase === "accounts")));
		this.$el.find(".om-ssp-bar").css("width", `${p.done && !p.failed_count ? 100 : pct}%`);
		this.$el.find(".om-ssp-pct b").text(Math.floor(p.done && !p.failed_count ? 100 : pct));
		this.set("total", fmt(total));
		this.set("created", fmt(emailing ? p.emailed : p.created));
		this.set("pending", fmt(Math.max(0, total - done)));
		this.set("failed", fmt(p.failed_count));
		this.$el.find(".om-ssp-view").prop("hidden", !p.created);
		this.$el.find(".om-ssp-stop").prop("hidden", !!p.done || (submit && p.phase !== "submit"));

		const now = Date.now();
		this.samples.push([now, done]);
		this.samples = this.samples.filter(([t]) => now - t < 60000);
		const [t0, d0] = this.samples[0];
		const rate = !p.done && now > t0 ? ((done - d0) / (now - t0)) * 60000 : 0;
		this.set("speed", rate > 0 ? __("{0} slips/min", [fmt(rate)]) : "");
		this.set("eta", rate > 0 ? __("about {0} left", [this.dur(((total - done) / rate) * 60)]) : "");
		this.set("elapsed", p.started ? __("{0} {1}", [p.done ? __("took") : __("running for"),
			this.dur(moment(p.finished || frappe.datetime.now_datetime()).diff(moment(p.started), "seconds"))]) : "");
		this.set("jobs", p.jobs && !p.done ? __("{0} running in parallel", [p.jobs]) : "");

		if (!p.done && submit && p.phase === "accounts") this.stage(__("Making the accrual Journal Entry…"));
		else if (emailing) this.stage(__("Emailing salary slips to employees (each with its PDF)…"));
		else if (!p.done) this.stage(done ? (submit ? __("Submitting salary slips…") : __("Creating salary slips…"))
			: __("Starting - waiting for a background worker…"));
		else if (submit && p.status === "Failed" && !p.failed_count) this.stage(__("Submission stopped or failed - see the error message below"));
		else if (submit && p.failed_count) this.stage(__("{0} submitted, {1} not submitted or emailed - see why below", [fmt(p.created), fmt(p.failed_count)]));
		else if (submit) this.stage(__("All {0} salary slips submitted", [fmt(p.created)]));
		else if (p.status === "Failed" && !p.failed_count) this.stage(__("Salary slip creation failed - see the error message below"));
		else if (p.failed_count) this.stage(__("{0} created, {1} failed - fix them, then Create Salary Slips retries only those", [fmt(p.created), fmt(p.failed_count)]));
		else this.stage(__("All {0} salary slips created", [fmt(p.created)]));

		// one chip per parallel process: its share done, a tick when it has finished
		const procs = p.done ? [] : p.procs || [];
		this.$el.find(".om-ssp-procs").prop("hidden", !procs.length).html(procs.map((x, i) =>
			`<span class="om-ssp-proc${x.finished ? " is-done" : ""}" title="${__("Process {0}", [i + 1])}">
				<i style="width:${x.total ? Math.min(100, (x.done / x.total) * 100) : 0}%"></i>
				<b>P${i + 1}</b> ${fmt(x.done)}/${fmt(x.total)}${x.finished ? " ✓" : ""}</span>`).join(""));

		const $f = this.$el.find(".om-ssp-fail");
		$f.prop("hidden", !p.failed_count);
		if (p.failed_count) {
			$f.find("summary").text(__("{0} failed - see why", [fmt(p.failed_count)]));
			$f.find("ul").html(p.failed.map((f) =>
				`<li><b>${frappe.utils.escape_html(f.employee)}</b> ${frappe.utils.escape_html(f.error)}</li>`).join(""));
		}
	}

	stop() {
		frappe.confirm(
			__("Stop creating salary slips? Slips already created are kept; you can cancel this Payroll Entry or continue later."),
			() => {
				this.$el.find(".om-ssp-stop").prop("disabled", true).text(__("Stopping…"));
				this.stage(__("Stopping after the current slips…"));
				frappe.call({
					method: "olscpl_hrms.api.payroll_entry.stop_slip_creation",
					args: { name: this.frm.doc.name },
					callback: (r) => r.message && r.message.stopped && this.frm.reload_doc(),
				});
			},
		);
	}

	dur(sec) {
		sec = Math.max(0, Math.round(sec));
		const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
		return h ? `${h}h ${m}m` : m ? `${m}m ${s}s` : `${s}s`;
	}

	remove() {
		clearTimeout(this.timer);
		this.polling = false;
		this.$el.remove();
	}
}

frappe.dom.set_style(`
.om-ssp { margin: 0 0 16px; padding: 18px 20px 16px; border-radius: 16px; background: #fff;
	border: 1px solid #e3e7f3; box-shadow: 0 14px 34px -18px rgba(11, 24, 67, .35); position: relative; overflow: hidden; }
.om-ssp::before { content: ""; position: absolute; inset: 0 0 auto 0; height: 4px; background: linear-gradient(90deg, rgb(23, 46, 122), #4f6bff, #3fc79a); }
.om-ssp-head { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; }
.om-ssp-title { font-size: 16px; font-weight: 700; color: rgb(16, 34, 95); }
.om-ssp-stage { flex: 1; font-size: 13px; color: #4a5072; min-width: 200px; }
.om-ssp.has-failed .om-ssp-stage { color: #b42318; }
.om-ssp.is-finished:not(.has-failed) .om-ssp-stage { color: #1f8a5b; font-weight: 600; }
.om-ssp-pct { color: rgb(16, 34, 95); font-variant-numeric: tabular-nums; font-size: 14px; font-weight: 700; }
.om-ssp-pct b { font-size: 28px; font-weight: 800; letter-spacing: -.02em; }
.om-ssp-track { position: relative; height: 10px; margin-top: 10px; border-radius: 999px; background: #eceff7; overflow: hidden; }
.om-ssp-bar { position: absolute; inset: 0 auto 0 0; width: 0; border-radius: inherit; transition: width .6s cubic-bezier(.2, .8, .2, 1);
	background: linear-gradient(90deg, rgb(23, 46, 122), #4f6bff 60%, #3fc79a); }
.om-ssp-bar::after { content: ""; position: absolute; inset: 0; transform: translateX(-100%);
	background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .55), transparent); animation: om-ssp-sheen 1.5s ease-in-out infinite; }
.om-ssp-track.is-indeterminate .om-ssp-bar { width: 32% !important; animation: om-ssp-slide 1.25s ease-in-out infinite; }
.om-ssp.is-finished .om-ssp-bar::after { animation: none; }
.om-ssp.has-failed .om-ssp-bar { background: linear-gradient(90deg, rgb(23, 46, 122), #4f6bff 70%, #e0726a); }
.om-ssp-tiles { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-top: 14px; }
.om-ssp-tile { border: 1px solid #e8ebf4; border-radius: 12px; padding: 9px 12px; background: #fafbfe; }
.om-ssp-tile span { display: block; font-size: 11.5px; color: #8a90ab; font-weight: 600; }
.om-ssp-tile b { display: block; margin-top: 2px; font-size: 19px; color: rgb(16, 34, 95); font-variant-numeric: tabular-nums; }
.om-ssp-tile.is-ok b { color: #1f8a5b; }
.om-ssp-tile.is-bad b { color: #b42318; }
.om-ssp-meta { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 16px; margin-top: 10px; font-size: 12.5px; color: #6b7393; }
.om-ssp-meta span:empty { display: none; }
.om-ssp-view { margin-left: auto; font-weight: 600; color: #3d4fd6; cursor: pointer; }
.om-ssp-stop { border-color: #f1c4bf; color: #b42318; }
.om-ssp-procs { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
.om-ssp-proc { position: relative; isolation: isolate; overflow: hidden; padding: 3px 9px; border-radius: 999px; border: 1px solid #e3e7f3;
	background: #fafbfe; font-size: 11.5px; color: #4a5072; font-variant-numeric: tabular-nums; }
.om-ssp-proc i { position: absolute; z-index: -1; inset: 0 auto 0 0; background: rgba(79, 107, 255, .14); transition: width .6s ease; }
.om-ssp-proc b { position: relative; color: rgb(16, 34, 95); }
.om-ssp-proc.is-done { border-color: #bfe6d3; color: #1f8a5b; }
.om-ssp-proc.is-done i { background: rgba(63, 199, 154, .16); }
.om-ssp-fail { margin-top: 12px; border: 1px solid #f5d0cc; background: #fff7f6; border-radius: 12px; padding: 8px 12px; }
.om-ssp-fail summary { cursor: pointer; font-size: 13px; font-weight: 600; color: #b42318; }
.om-ssp-fail ul { margin: 8px 0 2px; padding-left: 16px; max-height: 180px; overflow: auto; font-size: 12.5px; color: #4a5072; }
@keyframes om-ssp-sheen { to { transform: translateX(100%); } }
@keyframes om-ssp-slide { from { left: -32%; } to { left: 100%; } }
@media (max-width: 640px) { .om-ssp-tiles { grid-template-columns: repeat(2, 1fr); } }
@media (prefers-reduced-motion: reduce) {
	.om-ssp-bar { transition: none; }
	.om-ssp-bar::after, .om-ssp-track.is-indeterminate .om-ssp-bar { animation: none; }
}
`);

// ── Cancel progress panel (api/payroll_entry.get_cancel_progress) ──
// Cancelling is stock (queued for big runs, slips cancelled and deleted one by
// one); this panel shows how far it is: removed / remaining, speed, time left.
frappe.ui.form.on("Payroll Entry", {
	before_cancel(frm) {
		// the cancel is queued right after this - start following it
		setTimeout(() => CancelPanel.get(frm).watch(), 1200);
	},
	refresh(frm) {
		if (frm.doc.docstatus === 1 || frm.doc.docstatus === 2) CancelPanel.check(frm);
	},
});

class CancelPanel {
	static get(frm) {
		if (!frm.__cancel_panel || !document.body.contains(frm.__cancel_panel.$el[0])) frm.__cancel_panel = new CancelPanel(frm);
		return frm.__cancel_panel;
	}

	// on refresh: show only if a cancel is running, or just finished and was tracked
	static check(frm) {
		frappe.call({
			method: "olscpl_hrms.api.payroll_entry.get_cancel_progress",
			args: { name: frm.doc.name },
			callback: (r) => {
				const p = r.message;
				if (!p) return;
				if (p.running || (p.cancelled && p.tracked)) CancelPanel.get(frm).watch(p);
			},
		});
	}

	constructor(frm) {
		this.frm = frm;
		this.samples = [];
		frm.__slip_panel && frm.__slip_panel.remove();
		this.$el = $(`
			<div class="om-ssp om-cancel" aria-live="polite">
				<div class="om-ssp-head">
					<div class="om-ssp-title">${__("Cancelling payroll")}</div>
					<div class="om-ssp-stage">${__("Starting…")}</div>
					<div class="om-ssp-pct"><b>0</b>%</div>
				</div>
				<div class="om-ssp-track is-indeterminate"><div class="om-ssp-bar"></div></div>
				<div class="om-ssp-tiles om-cancel-tiles">
					<div class="om-ssp-tile"><span>${__("Salary slips")}</span><b data-k="total">–</b></div>
					<div class="om-ssp-tile is-ok"><span>${__("Removed")}</span><b data-k="removed">–</b></div>
					<div class="om-ssp-tile"><span>${__("Remaining")}</span><b data-k="remaining">–</b></div>
				</div>
				<div class="om-ssp-meta"><span data-k="speed"></span><span data-k="eta"></span><span data-k="elapsed"></span></div>
			</div>`);
		frm.layout.wrapper.prepend(this.$el);
	}

	set(k, v) {
		this.$el.find(`[data-k="${k}"]`).text(v);
	}

	watch(first) {
		if (this.polling) return;
		this.polling = true;
		const poll = () => {
			frappe.call({
				method: "olscpl_hrms.api.payroll_entry.get_cancel_progress",
				args: { name: this.frm.doc.name },
				callback: (r) => {
					if (!r.message || !document.body.contains(this.$el[0])) return (this.polling = false);
					this.render(r.message);
					if (r.message.cancelled) {
						this.polling = false;
						if (this.frm.doc.docstatus !== 2) this.frm.reload_doc();
						return;
					}
					this.timer = setTimeout(poll, 2000);
				},
				error: () => (this.timer = setTimeout(poll, 5000)),
			});
		};
		first ? (this.render(first), first.cancelled ? (this.polling = false) : (this.timer = setTimeout(poll, 2000))) : poll();
	}

	render(p) {
		const fmt = (n) => format_number(n, null, 0);
		const pct = p.total ? Math.min(100, (p.removed / p.total) * 100) : p.cancelled ? 100 : 0;
		this.$el.toggleClass("is-finished", !!p.cancelled);
		this.$el.find(".om-ssp-track").toggleClass("is-indeterminate", !p.cancelled && !p.removed);
		this.$el.find(".om-ssp-bar").css("width", `${p.cancelled ? 100 : pct}%`);
		this.$el.find(".om-ssp-pct b").text(Math.floor(p.cancelled ? 100 : pct));
		this.set("total", fmt(p.total));
		this.set("removed", fmt(p.removed));
		this.set("remaining", fmt(p.remaining));

		const now = Date.now();
		this.samples.push([now, p.removed]);
		this.samples = this.samples.filter(([t]) => now - t < 60000);
		const [t0, d0] = this.samples[0];
		const rate = !p.cancelled && now > t0 ? ((p.removed - d0) / (now - t0)) * 60000 : 0;
		this.set("speed", rate > 0 ? __("{0} slips/min", [fmt(rate)]) : "");
		this.set("eta", rate > 0 ? __("about {0} left", [SlipPanel.prototype.dur(((p.total - p.removed) / rate) * 60)]) : "");
		this.set("elapsed", p.started ? __("{0} {1}", [p.cancelled ? __("took") : __("running for"),
			SlipPanel.prototype.dur(moment(p.cancelled ? this.frm.doc.modified : frappe.datetime.now_datetime()).diff(moment(p.started), "seconds"))]) : "");
		this.$el.find(".om-ssp-stage").text(p.cancelled
			? __("Cancelled - {0} salary slips removed", [fmt(p.total)])
			: p.removed ? __("Cancelling salary slips and removing them…") : __("Cancellation queued - waiting for a background worker…"));
	}
}

frappe.dom.set_style(`
.om-cancel::before { background: linear-gradient(90deg, #b42318, #e0726a, #f3b0a8); }
.om-cancel .om-ssp-bar { background: linear-gradient(90deg, #8f1d14, #d4473b 60%, #f08a7e); }
.om-cancel.is-finished .om-ssp-stage { color: #6b7393; font-weight: 600; }
.om-cancel-tiles { grid-template-columns: repeat(3, 1fr); }
`);
