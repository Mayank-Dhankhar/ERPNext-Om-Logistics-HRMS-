// olscpl_hrms/public/js/full_and_final_statement.js
//
// "Fetch Salary Breakup" button (see custom_fetch_salary_breakup field,
// patches.v1_1.add_full_and_final_statement_fields) pulls the employee's
// latest submitted Salary Structure Assignment into the fixed Rate of Pay
// columns used by the "Full and Final Settlement (Legacy)" print format.
//
// "Fetch Last Month Details" button (see custom_fetch_last_month_details
// field, patches.v1_1.add_full_and_final_statement_automation_fields)
// auto-fills Days Worked, the last-month Dues fields with a real Salary
// Component source, EPF/ESI/TDS, Loan/Advance and Excess Leave - see
// olscpl_hrms.overrides.full_and_final_statement.fetch_last_month_details
// for exactly which fields it does and doesn't touch.
frappe.ui.form.on("Full and Final Statement", {
	refresh(frm) {
		frm.set_df_property("custom_fetch_salary_breakup", "hidden", frm.doc.docstatus !== 0);
		frm.set_df_property("custom_fetch_last_month_details", "hidden", frm.doc.docstatus !== 0);
	},

	custom_fetch_salary_breakup(frm) {
		if (!frm.doc.employee) {
			frappe.msgprint(__("Set Employee first"));
			return;
		}
		if (frm.is_dirty()) {
			frappe.msgprint(__("Save the document first"));
			return;
		}
		frappe.call({
			method: "fetch_salary_breakup",
			doc: frm.doc,
			freeze: true,
			freeze_message: __("Fetching salary breakup..."),
			callback: function () {
				frm.reload_doc();
			},
		});
	},

	custom_fetch_last_month_details(frm) {
		if (!frm.doc.employee) {
			frappe.msgprint(__("Set Employee first"));
			return;
		}
		if (!frm.doc.relieving_date) {
			frappe.msgprint(__("Relieving Date is not set on the Employee yet"));
			return;
		}
		if (frm.is_dirty()) {
			frappe.msgprint(__("Save the document first"));
			return;
		}
		frappe.call({
			method: "fetch_last_month_details",
			doc: frm.doc,
			freeze: true,
			freeze_message: __("Fetching last month's payroll details..."),
			callback: function () {
				frm.reload_doc();
			},
		});
	},
});
