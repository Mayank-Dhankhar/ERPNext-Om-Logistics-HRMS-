// Job Applicant list: "Parse Resume" - drop a candidate's resume (PDF/DOCX),
// check the name / email / phone read from it (olscpl_hrms.api.resume_parser)
// and create the Job Applicant with the resume attached; "Bulk Upload Resumes"
// does the same for many at once, as an editable table. The Recruitment
// workspace's "Parse Resume" shortcut opens this list with #parse-resume,
// which opens the dialog straight away. The bulk table shows each resume's
// ATS Score (olscpl_hrms.api.ats) and keeps the rows sorted by it, best first. Added to HRMS's own list settings,
// not replacing them. Styles: .rp-* in public/css/olscpl_theme.css.
(() => {
	const settings = (frappe.listview_settings["Job Applicant"] = frappe.listview_settings["Job Applicant"] || {});
	const onload = settings.onload;
	settings.onload = function (listview) {
		onload && onload.call(this, listview);
		listview.page.add_inner_button(__("Parse Resume"), () => open_resume_parser(listview));
		listview.page.add_inner_button(__("Bulk Upload Resumes"), () => open_bulk_upload(listview));
		if (window.location.hash === "#parse-resume") {
			history.replaceState(null, "", window.location.pathname + window.location.search);
			open_resume_parser(listview);
		}
	};

	const ALLOWED = [".pdf", ".docx"];
	const esc = (v) => frappe.utils.escape_html(v || "");
	const DOC_ICON = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M12 17v-6"/><path d="m9.5 13.5 2.5-2.5 2.5 2.5"/></svg>`;

	// ── shared: drop zone + direct upload ─────────────────────────────────────
	function drop_zone($wrapper, { multiple, on_files }) {
		const $input = $(`<input type="file" accept="${ALLOWED.join(",")}" ${multiple ? "multiple" : ""} hidden>`);
		const $zone = $(`
			<button type="button" class="rp-drop">
				<span class="rp-drop-icon">${DOC_ICON}</span>
				<span>
					<div class="rp-drop-title">${multiple ? __("Drop resumes here, or click to choose") : __("Drop a resume here, or click to choose")}</div>
					<div class="rp-drop-hint">${__("PDF or Word (.docx)")}${multiple ? " · " + __("drop several at once, or hold Ctrl / Shift to pick several") : ""}</div>
				</span>
			</button>`);
		const take = (list) => {
			const files = [...list].filter((f) => ALLOWED.some((ext) => f.name.toLowerCase().endsWith(ext)));
			const skipped = list.length - files.length;
			if (skipped) frappe.show_alert({ message: __("{0} file(s) skipped - only PDF or Word (.docx)", [skipped]), indicator: "orange" });
			if (files.length) on_files(multiple ? files : files.slice(0, 1));
		};
		$zone.on("click", () => $input.trigger("click"));
		$input.on("change", () => { take($input[0].files); $input.val(""); });
		$zone.on("dragover dragenter", (e) => { e.preventDefault(); $zone.addClass("is-over"); });
		$zone.on("dragleave dragend drop", () => $zone.removeClass("is-over"));
		$zone.on("drop", (e) => { e.preventDefault(); take(e.originalEvent.dataTransfer.files); });
		$wrapper.empty().append($zone, $input);
		return $zone;
	}

	// open without Frappe's first-field autofocus (it pops the Job Opening list
	// over the dialog); the drop zone gets focus instead - Enter opens the picker
	function show_focusing_drop(d) {
		d.no_focus = true;
		d.$wrapper.one("shown.bs.modal", () => d.fields_dict.drop.$wrapper.find(".rp-drop").trigger("focus"));
		d.show();
	}

	// big tick at the centre that draws itself, then fades away (click to skip)
	function success_tick(message) {
		return new Promise((resolve) => {
			const $o = $(`
				<div class="rp-success" role="status" aria-live="polite">
					<div class="rp-success-card">
						<svg viewBox="0 0 100 100" aria-hidden="true">
							<circle class="rp-success-ring" cx="50" cy="50" r="46"/>
							<path class="rp-success-check" d="M30 52 l14 14 l27 -30"/>
						</svg>
						<div class="rp-success-text">${esc(message)}</div>
					</div>
				</div>`).appendTo(document.body);
			let gone = false;
			const close = () => {
				if (gone) return;
				gone = true;
				$o.addClass("is-leaving");
				setTimeout(() => { $o.remove(); resolve(); }, 250);
			};
			$o.on("click", close);
			setTimeout(close, 1700);
		});
	}

	// public, like the hosted job application form's resumes
	function upload(file) {
		const form = new FormData();
		form.append("file", file, file.name);
		form.append("is_private", 0);
		form.append("folder", "Home/Attachments");
		return fetch("/api/method/upload_file", {
			method: "POST",
			headers: { "X-Frappe-CSRF-Token": frappe.csrf_token, Accept: "application/json" },
			body: form,
		})
			.then((r) => r.json().then((j) => (r.ok ? j.message : Promise.reject(j))))
			.catch(() => Promise.reject(new Error(__("Could not upload {0}", [file.name]))));
	}

	function parse(file_url, job_title) {
		return frappe.xcall("olscpl_hrms.api.resume_parser.parse_resume", { file_url, job_title });
	}

	function missing_of(r) {
		return [["applicant_name", __("name")], ["email_id", __("email")], ["phone_number", __("phone")]]
			.filter(([f]) => !r[f]).map(([, label]) => label);
	}

	// ── single resume ─────────────────────────────────────────────────────────
	function open_resume_parser(listview) {
		const d = new frappe.ui.Dialog({
			title: __("Parse Resume"),
			size: "large",
			fields: [
				{
					fieldname: "job_title", fieldtype: "Link", options: "Job Opening", label: __("Job Opening"),
					get_query: () => ({ filters: { status: "Open" } }),
					onchange: () => check_existing(d),
				},
				{ fieldname: "drop", fieldtype: "HTML" },
				{ fieldname: "note", fieldtype: "HTML" },
				{ fieldtype: "Section Break", label: __("Applicant details") },
				{ fieldname: "applicant_name", fieldtype: "Data", label: __("Applicant Name"), reqd: 1 },
				{
					fieldname: "email_id", fieldtype: "Data", options: "Email", label: __("Email Address"), reqd: 1,
					onchange: () => check_existing(d),
				},
				{ fieldtype: "Column Break" },
				{ fieldname: "phone_number", fieldtype: "Data", label: __("Phone Number") },
			],
			primary_action_label: __("Create Applicant"),
			primary_action: (values) => create(d, values, false),
			secondary_action_label: __("Create & Next"),
			secondary_action: () => {
				const values = d.get_values();
				if (values) create(d, values, true);
			},
		});
		d.listview = listview;
		reset_drop(d);
		show_focusing_drop(d);
	}

	function reset_drop(d) {
		d.file_url = null;
		drop_zone(d.fields_dict.drop.$wrapper, { multiple: false, on_files: ([file]) => read_one(d, file) });
	}

	function file_card(d, name, state, cls) {
		const $card = $(`
			<div class="rp-file ${cls}">
				<span class="rp-drop-icon">${DOC_ICON}</span>
				<div><div class="rp-file-name">${esc(name)}</div><div class="rp-file-state">${state}</div></div>
				${cls === "is-reading" ? "" : `<button type="button" class="btn btn-xs btn-default rp-file-action">${__("Replace")}</button>`}
			</div>`);
		$card.find(".rp-file-action").on("click", () => { note(d, ""); reset_drop(d); });
		d.fields_dict.drop.$wrapper.empty().append($card);
	}

	function note(d, html, kind) {
		d.fields_dict.note.$wrapper.html(html ? `<div class="rp-note is-${kind}">${html}</div>` : "");
	}

	async function read_one(d, file) {
		note(d, "");
		file_card(d, file.name, __("Reading the resume..."), "is-reading");
		try {
			const doc = await upload(file);
			d.file_url = doc.file_url;
			const r = await parse(doc.file_url, d.get_value("job_title"));
			const filled = ["applicant_name", "email_id", "phone_number"].filter((f) => r[f]);
			d.set_values({ applicant_name: r.applicant_name || "", email_id: r.email_id || "", phone_number: r.phone_number || "" });
			filled.forEach((f) => {
				const $w = d.fields_dict[f].$wrapper.removeClass("rp-filled");
				void $w[0].offsetWidth; // restart the flash
				$w.addClass("rp-filled");
			});
			const missing = missing_of(r);
			if (!r.has_text) {
				file_card(d, file.name, __("No text in this file (scanned image?) - type the details in"), "is-warn");
			} else {
				file_card(d, file.name, missing.length ? __("Read - not found: {0}", [missing.join(", ")]) : __("Read - check the details below"), missing.length ? "is-warn" : "is-done");
			}
			if (r.existing) note_existing(d, r.existing);
		} catch (e) {
			reset_drop(d);
			note(d, esc(e.message || __("Could not read this file")), "warning");
		}
	}

	function note_existing(d, existing) {
		note(d, __("This candidate has already applied to this opening: {0}. They won't be created again.", [
			`<a href="/app/job-applicant/${encodeURIComponent(existing.name)}" target="_blank">${esc(existing.name)}</a>`,
		]), "warning");
	}

	// re-check when the opening or the email is changed after reading the resume
	function check_existing(d) {
		const email_id = d.get_value("email_id"), job_title = d.get_value("job_title");
		if (!d.file_url || !email_id) return;
		frappe.xcall("olscpl_hrms.api.resume_parser.existing_application", { email_id, job_title })
			.then((existing) => (existing ? note_existing(d, existing) : note(d, "")));
	}

	function create(d, values, next) {
		if (!d.file_url) return frappe.msgprint(__("Drop or choose the resume first."));
		frappe.call({
			method: "olscpl_hrms.api.resume_parser.create_applicant",
			args: {
				file_url: d.file_url,
				applicant_name: values.applicant_name,
				email_id: values.email_id,
				phone_number: values.phone_number,
				job_title: values.job_title,
			},
			freeze: true,
			freeze_message: __("Creating applicant..."),
			callback: ({ message: name }) => {
				if (!name) return;
				d.listview.refresh();
				if (next) {
					// keep the Job Opening for the next resume of the same batch
					["applicant_name", "email_id", "phone_number"].forEach((f) => d.set_value(f, ""));
					note(d, "");
					reset_drop(d);
					success_tick(__("Job Applicant created"));
				} else {
					d.hide();
					success_tick(__("Job Applicant created")).then(() => frappe.set_route("Form", "Job Applicant", name));
				}
			},
		});
	}

	// ── bulk: many resumes -> one editable row each -> create them together ──
	function open_bulk_upload(listview) {
		const d = new frappe.ui.Dialog({
			title: __("Bulk Upload Resumes"),
			size: "extra-large",
			fields: [
				{
					fieldname: "job_title", fieldtype: "Link", options: "Job Opening", label: __("Job Opening"),
					get_query: () => ({ filters: { status: "Open" } }),
					description: __("Every applicant created here is put on this opening"),
					onchange: () => score_rows(d),
				},
				{ fieldname: "drop", fieldtype: "HTML" },
				{ fieldname: "status", fieldtype: "HTML" },
				{
					fieldname: "rows", fieldtype: "Table", label: __("Applicants"), cannot_add_rows: true, in_place_edit: true, data: [],
					fields: [
						{ fieldname: "create", fieldtype: "Check", label: __("Create"), in_list_view: 1, columns: 1 },
						{ fieldname: "applicant_name", fieldtype: "Data", label: __("Applicant Name"), in_list_view: 1, columns: 2 },
						{ fieldname: "email_id", fieldtype: "Data", label: __("Email"), in_list_view: 1, columns: 2 },
						{ fieldname: "phone_number", fieldtype: "Data", label: __("Phone"), in_list_view: 1, columns: 1 },
						{ fieldname: "ats_score", fieldtype: "Int", label: __("ATS Score"), in_list_view: 1, read_only: 1, columns: 1 },
						{ fieldname: "file_name", fieldtype: "Data", label: __("Resume"), in_list_view: 1, read_only: 1, columns: 1 },
						{ fieldname: "note", fieldtype: "Data", label: __("Note"), in_list_view: 1, read_only: 1, columns: 2 },
						{ fieldname: "file_url", fieldtype: "Data", hidden: 1 },
					],
				},
			],
			primary_action_label: __("Create Applicants"),
			primary_action: () => create_all(d),
		});
		d.listview = listview;
		d.total = 0;
		d.done = 0;
		drop_zone(d.fields_dict.drop.$wrapper, { multiple: true, on_files: (files) => read_many(d, files) });
		bulk_status(d);
		show_focusing_drop(d);
	}

	function bulk_status(d) {
		const rows = d.fields_dict.rows.df.data;
		const ticked = rows.filter((r) => r.create).length;
		const reading = d.total - d.done;
		const pct = d.total ? Math.round((d.done / d.total) * 100) : 0;
		d.fields_dict.status.$wrapper.html(
			d.total
				? `<div class="rp-progress">
					<div class="rp-progress-bar"><span style="width:${pct}%"></span></div>
					<div class="rp-progress-text">${
						reading ? __("Reading {0} of {1}...", [d.done + 1, d.total]) : __("{0} resume(s) read · {1} ticked to create", [rows.length, ticked])
					}</div>
				</div>`
				: ""
		);
	}

	async function read_many(d, files) {
		d.total += files.length;
		bulk_status(d);
		// three at a time - quick, without flooding the server
		const queue = [...files];
		const worker = async () => {
			for (let file; (file = queue.shift()); ) {
				let row = { create: 0, file_name: file.name, note: __("Could not read") };
				try {
					const doc = await upload(file);
					const r = await parse(doc.file_url, d.get_value("job_title"));
					const missing = missing_of(r);
					row = {
						create: r.existing ? 0 : 1, // already applied to this opening: never created twice
						applicant_name: r.applicant_name || "",
						email_id: r.email_id || "",
						phone_number: r.phone_number || "",
						file_name: file.name,
						file_url: doc.file_url,
						note: !r.has_text ? __("No text (scanned?) - fill in")
							: r.existing ? __("Already applied to this opening ({0}) - won't be created", [r.existing.name])
							: missing.length ? __("Not found: {0}", [missing.join(", ")]) : __("OK"),
					};
				} catch (e) {
					row.note = e.message || row.note;
				}
				d.fields_dict.rows.df.data.push(row);
				d.fields_dict.rows.grid.refresh();
				d.done += 1;
				bulk_status(d);
			}
		};
		await Promise.all([worker(), worker(), worker()]);
		if (d.done === d.total) score_rows(d);
	}

	// ATS Score for every row (against the Job Opening when one is picked), best first
	function score_rows(d) {
		const rows = d.fields_dict.rows.df.data;
		const urls = rows.filter((r) => r.file_url).map((r) => r.file_url);
		if (!urls.length) return;
		frappe.xcall("olscpl_hrms.api.ats.scores", { file_urls: urls, job_title: d.get_value("job_title") }).then((by_url) => {
			rows.forEach((r) => (r.ats_score = by_url[r.file_url] ?? null));
			rows.sort((x, y) => (y.ats_score ?? -1) - (x.ats_score ?? -1));
			rows.forEach((r, i) => (r.idx = i + 1));
			d.fields_dict.rows.grid.refresh();
		});
	}

	function create_all(d) {
		if (d.total > d.done) return frappe.msgprint(__("Still reading {0} resume(s) - wait a moment.", [d.total - d.done]));
		const rows = d.fields_dict.rows.df.data.filter((r) => r.create && r.file_url);
		if (!rows.length) return frappe.msgprint(__("Add resumes and tick at least one row to create."));
		const no_email = rows.filter((r) => !r.email_id);
		if (no_email.length) {
			return frappe.msgprint(__("Add the email for: {0} (or untick those rows).", [no_email.map((r) => esc(r.file_name)).join(", ")]));
		}
		frappe.call({
			method: "olscpl_hrms.api.resume_parser.create_applicants",
			args: { rows: JSON.stringify(rows), job_title: d.get_value("job_title") },
			freeze: true,
			freeze_message: __("Creating {0} applicant(s)...", [rows.length]),
			callback: ({ message: results = [] }) => {
				const by_url = Object.fromEntries(results.map((x) => [x.file_url, x]));
				let created = 0;
				d.fields_dict.rows.df.data.forEach((row) => {
					const res = by_url[row.file_url];
					if (!res) return;
					if (res.name) {
						created += 1;
						row.create = 0;
						row.note = __("Created: {0}", [res.name]);
					} else {
						row.note = __("Failed: {0}", [res.error]);
					}
				});
				d.fields_dict.rows.grid.refresh();
				bulk_status(d);
				d.listview.refresh();
				const failed = results.length - created;
				if (!failed) {
					d.hide();
					return success_tick(created === 1 ? __("1 applicant created") : __("{0} applicants created", [created]));
				}
				frappe.msgprint({
					title: __("Bulk Upload Finished"),
					indicator: failed ? "orange" : "green",
					message: __("Created: {0}<br>Failed: {1}", [created, failed]) +
						(failed ? `<br><span class="text-muted">${__("Fix the failed rows in the table and click Create Applicants again.")}</span>` : ""),
				});
			},
		});
	}
})();
