// om_loader - ATLAS's standard "walking boxes" loader (arjun_theme's page
// loader, shown on every route change) with a message, for slow actions that
// send mail / build PDFs. Frappe's own freeze overlay is blank because its
// freeze message is commented out in core.
//
//   om_loader.show(msg)           show / update the message; stays until hide()
//   om_loader.hide()
//   om_loader.until_unfreeze(msg) show now, hide on Frappe's next unfreeze -
//                                 for a form save/submit, which runs its own
//                                 freeze/unfreeze we don't control
//
// Falls back silently to Frappe's own freeze when arjun_theme isn't loaded.
window.om_loader = (function () {
	let backstop = null;

	function theme() {
		return window.arjun_theme && window.arjun_theme.show_page_loader ? window.arjun_theme : null;
	}

	function show(msg) {
		const t = theme();
		if (!t) return;
		t.show_page_loader();
		// Its own 7s failsafe is meant for page loads - mail/PDF can take longer.
		clearTimeout(t._page_loader_hide_timer);
		$("#arjun-page-loader p").text(msg || __("Loading…"));
		clearTimeout(backstop);
		backstop = setTimeout(hide, 120000);
	}

	function hide() {
		const t = theme();
		clearTimeout(backstop);
		if (!t) return;
		t.hide_page_loader();
		$("#arjun-page-loader p").text(__("Loading…"));
	}

	function until_unfreeze(msg) {
		if (!theme()) return;
		show(msg);
		const original = frappe.dom.unfreeze;
		const wrapped = function () {
			if (frappe.dom.unfreeze === wrapped) frappe.dom.unfreeze = original;
			hide();
			return original.apply(this, arguments);
		};
		frappe.dom.unfreeze = wrapped;
	}

	return { show, hide, until_unfreeze };
})();
