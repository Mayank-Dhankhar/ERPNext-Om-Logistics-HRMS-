// "Appointment Letter" button - added before "Download Employee Digital
// File" below so it renders to its left. Opens a preview (the PDF built
// by olscpl_hrms/api/appointment_letter.py) in a dialog with its own
// "Send Mail" button. That send button is the *only* path that ever
// actually emails the letter - opening the preview alone never sends
// anything.
//
// Rendered via pdf.js (same in-page canvas viewer built for the User
// Manual page - see olscpl_hrms/public/js/user_manual.js's viewPdf()) -
// not a plain iframe. A raw iframe/object pointed at a PDF relies on the
// browser's own PDF handling, and plenty of corporate Chrome installs are
// policy-set to always download PDFs instead of displaying them, which
// would make "preview" silently just trigger a download instead. pdf.js
// renders the same way regardless of that setting.
function _load_pdfjs(callback) {
	if (window.pdfjsLib) { callback(); return; }
	frappe.require('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', function () {
		window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
		callback();
	});
}

function show_appointment_letter_dialog(frm) {
	var preview_url = frappe.urllib.get_full_url(
		'/api/method/olscpl_hrms.api.appointment_letter.get_preview_pdf?employee='
		+ encodeURIComponent(frm.doc.name)
	);

	// Toggled by the "Edit Letter" secondary button below - swaps the PDF
	// viewer out for a rich-text editor loaded from get_editable_body(),
	// and the primary button from Send Mail/Send Again to Save & Preview.
	// already_sent tracks which of those two labels to restore once
	// editing ends, since get_send_status (below) can set it after this
	// dialog is already built.
	var editing = false;
	var already_sent = false;

	var dialog = new frappe.ui.Dialog({
		title: __('Appointment Letter'),
		size: 'extra-large',
		fields: [
			{
				fieldtype: 'HTML',
				fieldname: 'sent_banner',
				options: '<div id="appt-letter-sent-banner"></div>',
			},
			{
				fieldtype: 'HTML',
				fieldname: 'preview',
				options: (
					'<div id="appt-letter-pdf-body" style="height:70vh;overflow-y:auto;background:var(--fg-color);' +
					'border:1px solid var(--border-color);border-radius:8px;padding:16px;display:flex;' +
					'flex-direction:column;align-items:center;gap:14px;">' +
						'<div class="text-muted">' + __('Loading preview…') + '</div>' +
					'</div>'
				),
			},
			{
				fieldtype: 'HTML',
				fieldname: 'editor_toolbar',
				options: (
					'<div style="text-align:right;margin-bottom:6px;">' +
						'<a href="#" id="appt-letter-reset-link">' + __('Reset to auto-filled version') + '</a>' +
					'</div>'
				),
				hidden: 1,
			},
			{
				// Same rich-text control Frappe uses for Notes/comments -
				// get_value()/set_value() work in plain HTML, which is
				// exactly what get_editable_body/save_appointment_letter_
				// body pass around, so no extra conversion is needed here.
				fieldtype: 'Text Editor',
				fieldname: 'editor',
				label: __('Letter Content'),
				hidden: 1,
			},
		],
		primary_action_label: __('Send Mail'),
		primary_action: function () {
			if (editing) {
				save_letter_edit();
				return;
			}
			// Same gate the Job Offer Onboarding Link / Request Changes
			// buttons already use (see signature_gate.js) - without it,
			// the "(Authorized Signatory)" line on this letter just
			// prints blank for anyone who hasn't drawn a signature yet,
			// with nothing here telling them that's about to happen.
			// api/appointment_letter.py's _sender_signature_html() reads
			// the same User.custom_signature field this saves.
			ensureSenderSignature(function () {
				dialog.get_primary_btn().prop('disabled', true).text(__('Sending...'));
				om_loader.show(__('Generating the appointment letter and emailing it…'));
				// frappe.call's `error` key only fires for network/HTTP-level
				// failures, not a whitelisted method's own frappe.throw() (that
				// shows frappe's own error dialog instead and just resolves
				// without calling `callback`) - `always` is what reliably runs
				// either way, so the button never stays stuck on "Sending...".
				frappe.call({
					method: 'olscpl_hrms.api.appointment_letter.send_appointment_letter',
					args: { employee: frm.doc.name },
					callback: function (r) {
						if (!r.message) return;
						frappe.show_alert({
							message: __('Appointment letter sent to {0}', [r.message.sent_to]),
							indicator: 'green',
						});
						dialog.hide();
						// Reflect the new "already sent" state on the form itself
						// without a full reload_doc() round trip - these two
						// fields are hidden bookkeeping only this dialog reads.
						frm.doc.custom_appointment_letter_sent_on = r.message.sent_on;
						frm.doc.custom_appointment_letter_sent_by = r.message.sent_by;
					},
					always: function () {
						om_loader.hide();
						dialog.get_primary_btn().prop('disabled', false).text(already_sent ? __('Send Again') : __('Send Mail'));
					},
				});
			});
		},
		secondary_action_label: __('Edit Letter'),
		secondary_action: function () {
			if (editing) {
				exit_edit_mode();
			} else {
				enter_edit_mode();
			}
		},
	});

	function enter_edit_mode() {
		editing = true;
		dialog.set_df_property('preview', 'hidden', 1);
		dialog.set_df_property('editor_toolbar', 'hidden', 0);
		dialog.set_df_property('editor', 'hidden', 0);
		dialog.get_secondary_btn().text(__('Cancel'));
		dialog.get_primary_btn().text(__('Save & Preview'));
		dialog.set_value('editor', '');
		frappe.call({
			method: 'olscpl_hrms.api.appointment_letter.get_editable_body',
			args: { employee: frm.doc.name },
			callback: function (r) {
				dialog.set_value('editor', (r.message && r.message.body) || '');
			},
		});
	}

	function exit_edit_mode() {
		editing = false;
		dialog.set_df_property('editor', 'hidden', 1);
		dialog.set_df_property('editor_toolbar', 'hidden', 1);
		dialog.set_df_property('preview', 'hidden', 0);
		dialog.get_secondary_btn().text(__('Edit Letter'));
		dialog.get_primary_btn().text(already_sent ? __('Send Again') : __('Send Mail'));
		render_preview();
	}

	function save_letter_edit() {
		var body = dialog.get_value('editor');
		dialog.get_primary_btn().prop('disabled', true).text(__('Saving...'));
		frappe.call({
			method: 'olscpl_hrms.api.appointment_letter.save_appointment_letter_body',
			args: { employee: frm.doc.name, body: body },
			callback: function () {
				frappe.show_alert({ message: __('Letter updated.'), indicator: 'green' });
				exit_edit_mode();
			},
			always: function () {
				dialog.get_primary_btn().prop('disabled', false);
			},
		});
	}

	dialog.$wrapper.find('#appt-letter-reset-link').on('click', function (e) {
		e.preventDefault();
		frappe.confirm(
			__('Discard your changes and go back to the auto-filled letter?'),
			function () {
				frappe.call({
					method: 'olscpl_hrms.api.appointment_letter.reset_appointment_letter_body',
					args: { employee: frm.doc.name },
					callback: function (r) {
						dialog.set_value('editor', (r.message && r.message.body) || '');
						frappe.show_alert({ message: __('Reset to the auto-filled version.'), indicator: 'blue' });
					},
				});
			}
		);
	});

	dialog.show();

	// Read fresh from the server (not frm.doc, which could be stale if
	// this form was loaded before an earlier send, in another tab or by
	// another user) every time the dialog opens.
	frappe.call({
		method: 'olscpl_hrms.api.appointment_letter.get_send_status',
		args: { employee: frm.doc.name },
		callback: function (r) {
			if (!r.message || !r.message.sent) return;
			already_sent = true;
			var when = frappe.datetime.str_to_user(r.message.sent_on);
			var by = frappe.user.full_name(r.message.sent_by) || r.message.sent_by;
			dialog.$wrapper.find('#appt-letter-sent-banner').html(
				'<div class="alert alert-warning" style="margin-bottom:12px;">' +
					__('Already sent by {0} on {1}.', [frappe.utils.escape_html(by), frappe.utils.escape_html(when)]) +
				'</div>'
			);
			if (!editing) dialog.get_primary_btn().text(__('Send Again'));
		},
	});

	function render_preview() {
		var body = dialog.$wrapper.find('#appt-letter-pdf-body');
		body.html('<div class="text-muted">' + __('Loading preview…') + '</div>');

		_load_pdfjs(function () {
			fetch(preview_url, { credentials: 'same-origin' })
				.then(function (res) {
					if (!res.ok) throw new Error('Preview failed');
					return res.arrayBuffer();
				})
				.then(function (buf) {
					return window.pdfjsLib.getDocument({ data: buf }).promise;
				})
				.then(function (pdf) {
					body.empty();
					var renderNext = function (pageNum) {
						if (pageNum > pdf.numPages) return;
						pdf.getPage(pageNum).then(function (page) {
							var unscaled = page.getViewport({ scale: 1 });
							var scale = Math.min((body.width() || 800) / unscaled.width, 2);
							var viewport = page.getViewport({ scale: scale });
							var canvas = document.createElement('canvas');
							canvas.width = viewport.width;
							canvas.height = viewport.height;
							canvas.style.maxWidth = '100%';
							canvas.style.boxShadow = '0 1px 4px rgba(0,0,0,0.15)';
							body.append(canvas);
							page.render({ canvasContext: canvas.getContext('2d'), viewport: viewport }).promise.then(function () {
								renderNext(pageNum + 1);
							});
						});
					};
					renderNext(1);
				})
				.catch(function () {
					body.html('<div class="text-muted">' + __('Could not load the preview.') + '</div>');
				});
		});
	}

	render_preview();
}

frappe.ui.form.on('Employee', {
	// Overrides erpnext core's own onload handler (setup/doctype/employee/
	// employee.js), which does frm.set_query("department", () => ({
	// filters: { company: frm.doc.company } })) - Department options were
	// being narrowed to only that company's own departments. This app's JS
	// loads after erpnext's, so this onload handler registers second and
	// its set_query call is the one that actually wins; returning an empty
	// query removes the company filter entirely instead of narrowing it to
	// a different one.
	onload: function (frm) {
		frm.set_query('department', function () {
			return {};
		});
	},
	refresh: function (frm) {
		if (frm.is_new()) return;

		// straight to the linked login (User.js has the way back)
		if (frm.doc.user_id) {
			frm.add_custom_button(__('Open User'), () => frappe.set_route('Form', 'User', frm.doc.user_id));
		}

		frm.add_custom_button(__('Appointment Letter'), function () {
			show_appointment_letter_dialog(frm);
		});

		// "Download Employee Data" button - see olscpl_hrms/api/employee_data.
		// py for what actually gets generated (the full onboarding submission
		// - personal data, educational/technical qualification, employee
		// history, KYC, language, family background, physical data,
		// reference, declaration, ESIC/EPF/Gratuity/Form 11 statutory
		// sections - followed by every attached document).
		//
		// Fetched as a blob and saved via a throwaway <a download> instead of
		// window.open()'d straight at the endpoint - a plain window.open
		// shows a visible blank tab flash open then auto-close once the
		// browser starts the download. This stays on the current page the
		// whole time and shows frappe.dom.freeze()'s loading overlay instead.
		frm.add_custom_button(__('Download Employee Digital File'), function () {
			var url = frappe.urllib.get_full_url(
				'/api/method/olscpl_hrms.api.employee_data.download_employee_data?employee='
				+ encodeURIComponent(frm.doc.name)
			);

			frappe.dom.freeze(__('Downloading employee data...'));

			fetch(url, { credentials: 'same-origin' })
				.then(function (response) {
					if (!response.ok) throw new Error('Download failed');
					return response.blob();
				})
				.then(function (blob) {
					var blobUrl = window.URL.createObjectURL(blob);
					var a = document.createElement('a');
					a.href = blobUrl;
					a.download = frm.doc.name + '-employee-data.pdf';
					document.body.appendChild(a);
					a.click();
					a.remove();
					window.URL.revokeObjectURL(blobUrl);
				})
				.catch(function () {
					frappe.msgprint(__('Could not download the file. Please try again.'));
				})
				.finally(function () {
					frappe.dom.unfreeze();
				});
		});
	}
});
