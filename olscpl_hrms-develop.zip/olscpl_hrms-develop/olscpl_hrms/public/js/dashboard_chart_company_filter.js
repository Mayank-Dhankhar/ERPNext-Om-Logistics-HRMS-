// Adds a Company quick-filter pill to selected Dashboard Charts, positioned
// next to the built-in Year/Month (timespan / time_interval) controls
// instead of leaving Company buried inside the funnel filter popover.
//
// Chart names listed here should be timeseries, document-type charts whose
// document_type has a "company" field. Extend the list to enable this on
// other charts.
(function () {
	const COMPANY_QUICK_FILTER_CHARTS = ["Outgoing Salary"];

	let company_list_promise = null;
	function get_company_list() {
		if (!company_list_promise) {
			company_list_promise = frappe.db
				.get_list("Company", { fields: ["name"], limit: 0, order_by: "name asc" })
				.then((rows) => rows.map((r) => r.name))
				.catch(() => []);
		}
		return company_list_promise;
	}

	function patch_chart_widget() {
		if (!(frappe.widget && frappe.widget.widget_factory && frappe.widget.widget_factory.chart)) {
			return false;
		}
		const ChartWidget = frappe.widget.widget_factory.chart;
		if (ChartWidget.prototype.__olscpl_company_filter_patched) {
			return true;
		}

		const original_render_time_series_filters = ChartWidget.prototype.render_time_series_filters;

		ChartWidget.prototype.render_time_series_filters = function () {
			original_render_time_series_filters.call(this);

			if (!COMPANY_QUICK_FILTER_CHARTS.includes(this.chart_doc.chart_name)) return;
			if (!this.chart_doc.document_type) return;

			const widget = this;
			const all_companies_label = __("All Companies");

			function current_company() {
				if (widget.chart_settings && widget.chart_settings.custom_company !== undefined) {
					return widget.chart_settings.custom_company;
				}
				const existing = (widget.filters || []).find((f) => f[1] === "company");
				if (existing) return existing[3];
				return frappe.defaults.get_user_default("Company") || null;
			}

			get_company_list().then((companies) => {
				if (!companies.length) return;

				frappe.dashboard_utils.render_chart_filters(
					[
						{
							label: current_company() || all_companies_label,
							options: [all_companies_label].concat(companies),
							class: "company-quick-filter",
							action: (selected) => {
								const doctype = widget.chart_doc.document_type;
								const filters = (widget.filters || []).filter((f) => f[1] !== "company");
								let selected_company = null;

								if (selected !== all_companies_label) {
									selected_company = selected;
									filters.push([doctype, "company", "=", selected_company]);
								}

								widget.filters = filters;
								widget.save_chart_config_for_user({
									filters: widget.filters,
									custom_company: selected_company,
								});
								widget.fetch_and_update_chart();
							},
						},
					],
					"chart-actions",
					widget.action_area,
					0
				);
			});
		};

		ChartWidget.prototype.__olscpl_company_filter_patched = true;
		return true;
	}

	if (!patch_chart_widget()) {
		let attempts = 0;
		const interval = setInterval(() => {
			attempts += 1;
			if (patch_chart_widget() || attempts > 20) clearInterval(interval);
		}, 250);
	}
})();
