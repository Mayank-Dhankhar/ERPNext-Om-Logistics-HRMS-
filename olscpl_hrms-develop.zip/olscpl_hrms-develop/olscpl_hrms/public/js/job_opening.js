// Show all departments in Job Opening, not just the selected company's -
// overrides hrms job_opening.js's company filter (this script loads after it).
frappe.ui.form.on("Job Opening", {
	onload(frm) {
		frm.set_query("department", () => ({ filters: {} }));
	},
});
