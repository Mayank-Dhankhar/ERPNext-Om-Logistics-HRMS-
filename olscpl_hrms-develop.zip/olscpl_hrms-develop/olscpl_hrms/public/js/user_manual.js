(function () {
	"use strict";

	var API = "/api/method/olscpl_hrms.api.user_manual.";

	// ---- helpers (same pattern as social_feed.js) ----

	function escapeHtml(s) {
		var div = document.createElement("div");
		div.textContent = s == null ? "" : String(s);
		return div.innerHTML;
	}

	function formatFileSize(bytes) {
		if (bytes == null) return "";
		if (bytes < 1024) return bytes + " B";
		if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
		return (bytes / (1024 * 1024)).toFixed(1) + " MB";
	}

	function relativeTime(iso) {
		if (!iso) return "";
		var then = new Date(iso.replace(" ", "T"));
		if (isNaN(then.getTime())) return "";
		var diff = Math.max(0, (Date.now() - then.getTime()) / 1000);
		if (diff < 60) return "just now";
		if (diff < 3600) return Math.floor(diff / 60) + "m ago";
		if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
		if (diff < 604800) return Math.floor(diff / 86400) + "d ago";
		return then.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
	}

	function showToast(message, type) {
		var el = document.createElement("div");
		el.className = "um-toast" + (type === "error" ? " um-toast-error" : "");
		el.textContent = message;
		document.body.appendChild(el);
		setTimeout(function () {
			el.classList.add("um-toast-out");
			setTimeout(function () { el.remove(); }, 200);
		}, 3500);
	}

	// Custom confirm, not window.confirm() - same reasoning as
	// social_feed.js's showConfirm: a user can permanently silence native
	// confirm() by ticking "Prevent this page from creating additional
	// dialogs", after which it just returns false forever, no dialog shown.
	function showConfirm(message, onConfirm) {
		var backdrop = document.createElement("div");
		backdrop.className = "um-confirm-backdrop";
		backdrop.innerHTML =
			'<div class="um-confirm-box">' +
			'<div class="um-confirm-message">' + escapeHtml(message) + "</div>" +
			'<div class="um-confirm-actions">' +
			'<button type="button" class="um-confirm-cancel">Cancel</button>' +
			'<button type="button" class="um-confirm-ok">Delete</button>' +
			"</div></div>";
		document.body.appendChild(backdrop);
		function close() { backdrop.remove(); }
		backdrop.addEventListener("click", function (e) { if (e.target === backdrop) close(); });
		backdrop.querySelector(".um-confirm-cancel").addEventListener("click", close);
		backdrop.querySelector(".um-confirm-ok").addEventListener("click", function () { close(); onConfirm(); });
	}

	function apiCall(method, data, useGet) {
		var url = API + method;
		if (useGet) {
			var qs = Object.keys(data || {})
				.filter(function (k) { return data[k] != null; })
				.map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(data[k]); })
				.join("&");
			if (qs) url += "?" + qs;
			return fetch(url, {
				method: "GET",
				credentials: "same-origin",
				headers: { "X-Frappe-CSRF-Token": window.csrf_token || "" },
			}).then(handleRes);
		}
		var body = new URLSearchParams();
		Object.keys(data || {}).forEach(function (k) {
			if (data[k] != null) body.append(k, data[k]);
		});
		return fetch(url, {
			method: "POST",
			credentials: "same-origin",
			headers: {
				"X-Frappe-CSRF-Token": window.csrf_token || "",
				"Content-Type": "application/x-www-form-urlencoded",
			},
			body: body,
		}).then(handleRes);
	}

	function handleRes(res) {
		return res.json().then(function (body) {
			if (!res.ok) {
				var msg = (body && body.exception) || (body && body._server_messages) || "Request failed (" + res.status + ")";
				try {
					var parsed = JSON.parse(msg);
					msg = Array.isArray(parsed) ? JSON.parse(parsed[0]).message : msg;
				} catch (e) { /* not JSON-wrapped, use as-is */ }
				throw new Error(msg);
			}
			return body.message;
		});
	}

	function uploadFile(file) {
		var fd = new FormData();
		fd.append("file", file);
		fd.append("is_private", "0");
		return fetch("/api/method/upload_file", {
			method: "POST",
			credentials: "same-origin",
			headers: { "X-Frappe-CSRF-Token": window.csrf_token || "" },
			body: fd,
		})
			.then(function (res) { return res.json(); })
			.then(function (body) {
				if (!body.message || !body.message.file_url) throw new Error("Upload failed");
				return body.message;
			});
	}

	// ---- icons ----
	var ICONS = {
		play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7Z"/></svg>',
		doc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z" stroke-linejoin="round"/><path d="M14 3v5h5" stroke-linejoin="round"/></svg>',
		eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1.5 12S5 5 12 5s10.5 7 10.5 7-3.5 7-10.5 7S1.5 12 1.5 12Z" stroke-linejoin="round"/><circle cx="12" cy="12" r="3"/></svg>',
		download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v13m0 0-5-5m5 5 5-5" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 20h16" stroke-linecap="round"/></svg>',
		trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m2 0-.8 12.1a2 2 0 0 1-2 1.9H9.8a2 2 0 0 1-2-1.9L7 7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 6l12 12M18 6 6 18" stroke-linecap="round"/></svg>',
		upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 16V4m0 0-4 4m4-4 4 4" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" stroke-linecap="round"/></svg>',
		search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5" stroke-linecap="round"/></svg>',
		video: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2.5" y="5" width="14" height="14" rx="2.5"/><path d="m20.5 9 2-1.5v9l-2-1.5" stroke-linejoin="round"/></svg>',
		fileUp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z" stroke-linejoin="round"/><path d="M14 3v5h5" stroke-linejoin="round"/></svg>',
		// Same icon/markup as ess_dashboard's admin_dashboard.js/dashboard.js
		// "Back to HRMS Home" button, so this page reads as one consistent
		// set with those rather than a one-off.
		home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 11.5 12 4l9 7.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 10v9a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1v-9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
	};

	// ---- state ----
	var state = {
		manuals: [],
		categories: [],
		canManage: false,
		search: "",
		loading: true,
	};

	function root() { return document.getElementById("app"); }
	function gridRegion() { return document.getElementById("um-grid-region"); }

	// ---- rendering ----

	function renderHero() {
		return (
			'<div class="um-hero">' +
				'<a href="/app/atlas-home" class="um-home-btn" title="Back to Atlas Home">' +
					ICONS.home + "<span>Atlas Home</span></a>" +
				'<h1 class="um-hero-title">User Manual</h1>' +
				'<p class="um-hero-sub">Videos and documents to help you get around HRMS</p>' +
			"</div>"
		);
	}

	function renderToolbar() {
		return (
			'<div class="um-toolbar">' +
				'<div class="um-search">' +
					'<input type="text" id="um-search-input" class="um-input" placeholder="Search by title or label…" value="' + escapeHtml(state.search) + '">' +
					'<button type="button" id="um-search-btn" class="um-search-btn" title="Search">' + ICONS.search + "</button>" +
				"</div>" +
				(state.canManage
					? '<button type="button" id="um-upload-trigger" class="um-upload-btn">' + ICONS.upload + "<span>Upload</span></button>"
					: "") +
			"</div>"
		);
	}

	function filteredManuals() {
		var q = (state.search || "").trim().toLowerCase();
		if (!q) return state.manuals;
		return state.manuals.filter(function (m) {
			return (
				(m.title || "").toLowerCase().indexOf(q) !== -1 ||
				(m.category || "").toLowerCase().indexOf(q) !== -1 ||
				(m.fileName || "").toLowerCase().indexOf(q) !== -1
			);
		});
	}

	// mammoth.js only understands the OOXML .docx format, not the legacy
	// binary .doc - and SheetJS's sheet_to_html renders .xlsx/.xls (and
	// old binary .xls) equally well, so both land in the same "sheet" kind.
	function previewKind(m) {
		var name = (m.fileName || m.fileUrl || "").toLowerCase();
		if (/\.pdf$/.test(name)) return "pdf";
		if (/\.docx$/.test(name)) return "docx";
		if (/\.xlsx?$/.test(name)) return "sheet";
		return null;
	}

	function renderCard(m) {
		var isVideo = m.resourceType === "Video";
		// The YouTube thumbnail is an external image (img.youtube.com) -
		// if it fails to load (network hiccup, an ad-blocker, a video that
		// was since taken down), fall back to the same plain video-icon
		// tile a thumbnail-less/Document card gets, instead of leaving a
		// broken-image icon in the grid.
		var media = isVideo
			? (
				'<div class="um-card-media' + (m.thumbnailUrl ? "" : " is-doc") + '">' +
					(m.thumbnailUrl ? '<img src="' + escapeHtml(m.thumbnailUrl) + '" alt="" onerror="this.closest(\'.um-card-media\').classList.add(\'is-doc\');this.remove();">' : ICONS.video) +
					'<div class="um-play">' + ICONS.play + "</div>" +
				"</div>"
			)
			: '<div class="um-card-media is-doc">' + ICONS.doc + "</div>";

		// A .pdf gets rendered in-page via pdf.js instead of a plain link -
		// the site sends PDFs with no Content-Disposition header, but
		// plenty of corporate Chrome installs are policy-set to always
		// download PDFs rather than open them, so a plain link "View" was
		// really just triggering a download for those users. Rendering it
		// ourselves sidesteps that setting entirely.
		//
		// .docx (mammoth.js) and .xlsx/.xls (SheetJS) get the same
		// treatment, rendered entirely client-side - no server conversion,
		// no second file stored. Anything else (old binary .doc, .pptx,
		// .odt...) has no reliable in-browser renderer, so it keeps the
		// plain new-tab link.
		var kind = previewKind(m);
		var actions = isVideo
			? '<div class="um-card-actions"><a class="um-card-action" href="' + escapeHtml(m.youtubeUrl) + '" target="_blank" rel="noopener">' + ICONS.play + "<span>Watch</span></a></div>"
			: (
				'<div class="um-card-actions">' +
					(kind
						? '<button type="button" class="um-card-action" data-view-manual="' + escapeHtml(m.name) + '">' + ICONS.eye + "<span>View</span></button>"
						: '<a class="um-card-action" href="' + escapeHtml(m.fileUrl) + '" target="_blank" rel="noopener">' + ICONS.eye + "<span>View</span></a>") +
					'<a class="um-card-action" href="' + escapeHtml(m.fileUrl) + '" download="' + escapeHtml(m.fileName || "") + '">' + ICONS.download + "<span>Download</span></a>" +
				"</div>"
			);

		var meta = isVideo
			? relativeTime(m.creation)
			: (formatFileSize(m.fileSize) ? formatFileSize(m.fileSize) + " · " : "") + relativeTime(m.creation);

		return (
			'<div class="um-card" data-manual="' + m.name + '">' +
				(state.canManage ? '<button type="button" class="um-card-delete" data-delete="' + m.name + '" title="Delete">' + ICONS.trash + "</button>" : "") +
				media +
				'<div class="um-card-body">' +
					'<span class="um-card-type">' + escapeHtml(m.category || m.resourceType) + "</span>" +
					'<h3 class="um-card-title">' + escapeHtml(m.title) + "</h3>" +
					'<div class="um-card-meta">' + escapeHtml(meta) + "</div>" +
				"</div>" +
				actions +
			"</div>"
		);
	}

	function renderGrid() {
		var list = filteredManuals();
		if (!state.manuals.length) {
			return '<div class="um-empty">No manuals uploaded yet.' + (state.canManage ? " Click Upload to add the first one." : "") + "</div>";
		}
		if (!list.length) {
			return '<div class="um-empty">No manuals match "' + escapeHtml(state.search) + '".</div>';
		}
		return '<div class="um-grid">' + list.map(renderCard).join("") + "</div>";
	}

	function render() {
		root().innerHTML =
			renderHero() +
			'<div class="um-main">' +
				renderToolbar() +
				'<div id="um-grid-region">' + renderGrid() + "</div>" +
			"</div>";
	}

	function patchGrid() {
		var region = gridRegion();
		if (region) region.innerHTML = renderGrid();
	}

	function renderError(message) {
		root().innerHTML = '<div class="um-error"><h2>Something went wrong</h2><p>' + escapeHtml(message) + "</p></div>";
	}

	// ---- document viewer (in-page, all client-side - no server round
	// trip and no second file ever gets stored) ----
	// pdf.js renders every page of a PDF as a canvas, stacked in a
	// scrollable column - the simplest layout that reads naturally on both
	// desktop and mobile, no page-by-page nav controls needed for the
	// length of document this page deals with (manuals/policies, not
	// 300-page books). mammoth.js turns a .docx straight into HTML: SheetJS
	// turns a workbook into one HTML table per sheet - both render into the
	// same modal shape as the PDF viewer.
	var LIB_URLS = {
		pdfjs: "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js",
		mammoth: "https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.7.2/mammoth.browser.min.js",
		xlsx: "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js",
	};

	// No `frappe` global exists on this plain website page (confirmed - it
	// doesn't load the desk bundle, so frappe.require isn't available here
	// the way it is on a desk form like employee.js), so libraries are
	// loaded with a small loader of our own, cached per URL so a second
	// "View" click for the same format doesn't re-fetch the script.
	var _loadedLibs = {};
	function loadLib(url, callback) {
		if (_loadedLibs[url]) { callback(); return; }
		var existing = document.querySelector('script[src="' + url + '"]');
		if (existing) {
			existing.addEventListener("load", function () { _loadedLibs[url] = true; callback(); });
			return;
		}
		var script = document.createElement("script");
		script.src = url;
		script.onload = function () { _loadedLibs[url] = true; callback(); };
		document.head.appendChild(script);
	}

	function openViewerModal(title, rawUrl) {
		var backdrop = document.createElement("div");
		backdrop.className = "um-backdrop um-pdf-backdrop";
		backdrop.innerHTML =
			'<div class="um-pdf-modal">' +
				'<div class="um-modal-header">' +
					"<h3>" + escapeHtml(title) + "</h3>" +
					'<div class="um-pdf-header-actions">' +
						'<a class="um-card-action" href="' + escapeHtml(rawUrl) + '" target="_blank" rel="noopener">' + ICONS.download + "<span>Open raw file</span></a>" +
						'<button type="button" class="um-modal-close">' + ICONS.close + "</button>" +
					"</div>" +
				"</div>" +
				'<div class="um-pdf-body" id="um-pdf-body"><div class="um-pdf-loading"><div class="um-spinner"></div></div></div>' +
			"</div>";
		document.body.appendChild(backdrop);

		function close() { backdrop.remove(); }
		backdrop.addEventListener("click", function (e) { if (e.target === backdrop) close(); });
		backdrop.querySelector(".um-modal-close").addEventListener("click", close);

		return backdrop.querySelector("#um-pdf-body");
	}

	function showViewerError(body, rawUrl, message) {
		body.innerHTML = '<div class="um-pdf-error">' + escapeHtml(message) + ' <a href="' + escapeHtml(rawUrl) + '" target="_blank" rel="noopener">Open the raw file instead</a>.</div>';
	}

	function renderPdf(body, url, rawUrl) {
		loadLib(LIB_URLS.pdfjs, function () {
			window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
			window.pdfjsLib.getDocument(url).promise
				.then(function (pdf) {
					body.innerHTML = "";
					var renderNext = function (pageNum) {
						if (pageNum > pdf.numPages) return;
						pdf.getPage(pageNum).then(function (page) {
							// Fit the page to the modal's own width (not a
							// fixed scale) so it reads cleanly on any screen.
							var unscaled = page.getViewport({ scale: 1 });
							var scale = Math.min((body.clientWidth || 800) / unscaled.width, 2);
							var viewport = page.getViewport({ scale: scale });
							var canvas = document.createElement("canvas");
							canvas.className = "um-pdf-page";
							canvas.width = viewport.width;
							canvas.height = viewport.height;
							body.appendChild(canvas);
							page.render({ canvasContext: canvas.getContext("2d"), viewport: viewport }).promise.then(function () {
								renderNext(pageNum + 1);
							});
						});
					};
					renderNext(1);
				})
				.catch(function () { showViewerError(body, rawUrl, "Couldn't render this PDF."); });
		});
	}

	function renderDocx(body, url, rawUrl) {
		loadLib(LIB_URLS.mammoth, function () {
			fetch(url, { credentials: "same-origin" })
				.then(function (res) {
					if (!res.ok) throw new Error();
					return res.arrayBuffer();
				})
				.then(function (buf) { return window.mammoth.convertToHtml({ arrayBuffer: buf }); })
				.then(function (result) {
					body.innerHTML = '<div class="um-docx-preview">' + result.value + "</div>";
				})
				.catch(function () { showViewerError(body, rawUrl, "Couldn't render this document."); });
		});
	}

	function renderSheet(body, url, rawUrl) {
		loadLib(LIB_URLS.xlsx, function () {
			fetch(url, { credentials: "same-origin" })
				.then(function (res) {
					if (!res.ok) throw new Error();
					return res.arrayBuffer();
				})
				.then(function (buf) {
					var wb = window.XLSX.read(buf, { type: "array" });
					body.innerHTML = wb.SheetNames.map(function (sheetName) {
						// header/footer:"" - sheet_to_html otherwise wraps the
					// table in a full <html><head>... document, which is
					// wrong (and gets silently mangled) inside innerHTML.
					var html = window.XLSX.utils.sheet_to_html(wb.Sheets[sheetName], { id: "", header: "", footer: "" });
						return (
							'<div class="um-sheet-preview">' +
								(wb.SheetNames.length > 1 ? '<h4 class="um-sheet-name">' + escapeHtml(sheetName) + "</h4>" : "") +
								html +
							"</div>"
						);
					}).join("");
				})
				.catch(function () { showViewerError(body, rawUrl, "Couldn't render this spreadsheet."); });
		});
	}

	function viewManual(m) {
		var kind = previewKind(m);
		var body = openViewerModal(m.title, m.fileUrl);
		if (kind === "pdf") renderPdf(body, m.fileUrl, m.fileUrl);
		else if (kind === "docx") renderDocx(body, m.fileUrl, m.fileUrl);
		else if (kind === "sheet") renderSheet(body, m.fileUrl, m.fileUrl);
		else showViewerError(body, m.fileUrl, "No preview available for this file type.");
	}

	// ---- upload dialog ----

	function openUploadDialog() {
		var cs = { type: "Video", file: null };

		var backdrop = document.createElement("div");
		backdrop.className = "um-backdrop";
		backdrop.innerHTML =
			'<div class="um-modal">' +
				'<div class="um-modal-header"><h3>Upload Manual</h3><button type="button" class="um-modal-close">' + ICONS.close + "</button></div>" +
				'<div class="um-modal-body">' +
					'<div class="um-field"><label class="um-label">Type</label>' +
						'<div class="um-type-toggle">' +
							'<button type="button" class="um-type-btn active" data-type="Video">' + ICONS.video + "<span>Video (YouTube)</span></button>" +
							'<button type="button" class="um-type-btn" data-type="Document">' + ICONS.fileUp + "<span>Document</span></button>" +
						"</div>" +
					"</div>" +
					'<div class="um-field"><label class="um-label" for="um-f-title">Title</label>' +
						'<input type="text" id="um-f-title" class="um-input" placeholder="e.g. How to apply for leave" maxlength="140"></div>' +
					'<div class="um-field"><label class="um-label" for="um-f-category">Label</label>' +
						'<input type="text" id="um-f-category" class="um-input" list="um-category-list" placeholder="e.g. Leave, Attendance, Payroll" maxlength="60">' +
						'<datalist id="um-category-list">' + state.categories.map(function (c) { return '<option value="' + escapeHtml(c) + '">'; }).join("") + "</datalist>" +
					"</div>" +
					'<div class="um-field" id="um-video-field"><label class="um-label" for="um-f-youtube">YouTube URL</label>' +
						'<input type="text" id="um-f-youtube" class="um-input" placeholder="https://www.youtube.com/watch?v=…"></div>' +
					'<div class="um-field" id="um-doc-field" style="display:none">' +
						'<label class="um-label">File</label>' +
						'<div id="um-dropzone-region"></div>' +
						'<input type="file" id="um-file-input" style="display:none">' +
					"</div>" +
				"</div>" +
				'<div class="um-modal-footer"><button type="button" class="um-submit-btn" id="um-submit-btn">Upload</button></div>' +
			"</div>";
		document.body.appendChild(backdrop);

		function close() { backdrop.remove(); }
		backdrop.addEventListener("click", function (e) { if (e.target === backdrop) close(); });
		backdrop.querySelector(".um-modal-close").addEventListener("click", close);

		var titleInput = backdrop.querySelector("#um-f-title");
		var categoryInput = backdrop.querySelector("#um-f-category");
		var youtubeInput = backdrop.querySelector("#um-f-youtube");
		var videoField = backdrop.querySelector("#um-video-field");
		var docField = backdrop.querySelector("#um-doc-field");
		var dropzoneRegion = backdrop.querySelector("#um-dropzone-region");
		var fileInput = backdrop.querySelector("#um-file-input");
		var submitBtn = backdrop.querySelector("#um-submit-btn");

		function renderDropzone() {
			if (cs.file) {
				dropzoneRegion.innerHTML =
					'<div class="um-file-picked">' + ICONS.doc +
						'<div><div class="um-file-picked-name">' + escapeHtml(cs.file.name) + '</div>' +
						'<div class="um-file-picked-size">' + formatFileSize(cs.file.size) + "</div></div>" +
						'<button type="button" class="um-file-picked-remove" id="um-file-remove">' + ICONS.close + "</button>" +
					"</div>";
				dropzoneRegion.querySelector("#um-file-remove").addEventListener("click", function () {
					cs.file = null;
					fileInput.value = "";
					renderDropzone();
				});
			} else {
				dropzoneRegion.innerHTML = '<div class="um-dropzone" id="um-dropzone-trigger">' + ICONS.fileUp + "<div>Click to choose a file, or drag one here</div></div>";
				var dz = dropzoneRegion.querySelector("#um-dropzone-trigger");
				dz.addEventListener("click", function () { fileInput.click(); });
				dz.addEventListener("dragover", function (e) { e.preventDefault(); dz.classList.add("is-drag"); });
				dz.addEventListener("dragleave", function () { dz.classList.remove("is-drag"); });
				dz.addEventListener("drop", function (e) {
					e.preventDefault();
					dz.classList.remove("is-drag");
					if (e.dataTransfer.files[0]) { cs.file = e.dataTransfer.files[0]; renderDropzone(); }
				});
			}
		}
		renderDropzone();

		fileInput.addEventListener("change", function () {
			if (fileInput.files[0]) { cs.file = fileInput.files[0]; renderDropzone(); }
		});

		backdrop.querySelectorAll(".um-type-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				cs.type = btn.getAttribute("data-type");
				backdrop.querySelectorAll(".um-type-btn").forEach(function (b) { b.classList.toggle("active", b === btn); });
				videoField.style.display = cs.type === "Video" ? "" : "none";
				docField.style.display = cs.type === "Document" ? "" : "none";
			});
		});

		submitBtn.addEventListener("click", function () {
			var title = titleInput.value.trim();
			var category = categoryInput.value.trim();
			if (!title) { showToast("Enter a title.", "error"); titleInput.focus(); return; }
			if (!category) { showToast("Enter a label.", "error"); categoryInput.focus(); return; }
			if (cs.type === "Video" && !youtubeInput.value.trim()) { showToast("Enter a YouTube link.", "error"); youtubeInput.focus(); return; }
			if (cs.type === "Document" && !cs.file) { showToast("Choose a file to upload.", "error"); return; }

			submitBtn.disabled = true;
			submitBtn.textContent = "Uploading…";

			var proceed = cs.type === "Document"
				? uploadFile(cs.file).then(function (uploaded) {
					return apiCall("create_entry", {
						title: title,
						category: category,
						resource_type: "Document",
						file_url: uploaded.file_url,
						file_name: cs.file.name,
						file_size: cs.file.size,
					});
				})
				: apiCall("create_entry", {
					title: title,
					category: category,
					resource_type: "Video",
					youtube_url: youtubeInput.value.trim(),
				});

			proceed
				.then(function (created) {
					state.manuals.unshift(created);
					if (created.category && state.categories.indexOf(created.category) === -1) {
						state.categories.push(created.category);
						state.categories.sort(function (a, b) { return a.localeCompare(b); });
					}
					patchGrid();
					showToast("Uploaded!");
					close();
				})
				.catch(function (err) {
					showToast(err.message || "Upload failed.", "error");
					submitBtn.disabled = false;
					submitBtn.textContent = "Upload";
				});
		});
	}

	// ---- events ----

	function bindEvents() {
		var app = root();

		app.addEventListener("click", function (e) {
			var t = e.target;
			var el;
			if (t.closest("#um-upload-trigger")) { openUploadDialog(); return; }
			if (t.closest("#um-search-btn")) { runSearch(); return; }
			if ((el = t.closest("[data-view-manual]"))) {
				var manual = state.manuals.filter(function (x) { return x.name === el.getAttribute("data-view-manual"); })[0];
				if (manual) viewManual(manual);
				return;
			}
			if ((el = t.closest("[data-delete]"))) {
				e.preventDefault();
				e.stopPropagation();
				var name = el.getAttribute("data-delete");
				showConfirm("Delete this manual? This can't be undone.", function () {
					apiCall("delete_entry", { name: name })
						.then(function () {
							state.manuals = state.manuals.filter(function (m) { return m.name !== name; });
							patchGrid();
							showToast("Deleted.");
						})
						.catch(function (err) { showToast(err.message || "Delete failed.", "error"); });
				});
			}
		});

		app.addEventListener("keydown", function (e) {
			if (e.target && e.target.id === "um-search-input" && e.key === "Enter") runSearch();
		});
	}

	function runSearch() {
		var input = document.getElementById("um-search-input");
		state.search = input ? input.value : "";
		patchGrid();
	}

	// ---- boot ----
	function boot() {
		apiCall("get_list", {}, true)
			.then(function (res) {
				state.manuals = res.manuals || [];
				state.categories = res.categories || [];
				state.canManage = !!res.canManage;
				render();
				bindEvents();
			})
			.catch(function (err) {
				renderError(err.message || "Something went wrong loading the User Manual. Please refresh.");
			});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}
})();
