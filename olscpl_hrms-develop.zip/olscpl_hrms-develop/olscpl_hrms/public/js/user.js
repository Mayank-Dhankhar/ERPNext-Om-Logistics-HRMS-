// User form: straight to the Employee this login belongs to (employee.js has
// the way back).
frappe.ui.form.on('User', {
	refresh: function (frm) {
		if (frm.is_new()) return;
		frappe.db.get_value('Employee', { user_id: frm.doc.name }, 'name').then(({ message }) => {
			if (message && message.name) {
				frm.add_custom_button(__('Open Employee {0}', [message.name]), () =>
					frappe.set_route('Form', 'Employee', message.name)
				);
			}
		});
	},
});
