// =====================================================
// ATTENDANCE FORM ENHANCEMENTS - CLIENT SCRIPT
// was Client Script: "Attendance Form Enhancements"
// Uses Payroll Month Logic (26-25 Cycle)
// =====================================================

frappe.ui.form.on('Attendance', {

    refresh: function (frm) {
        add_custom_buttons(frm);
        update_status_indicator(frm);
        show_monthly_summary(frm);
    },

    in_time: function (frm) {
        calculate_work_hours(frm);
    },

    out_time: function (frm) {
        calculate_work_hours(frm);
    },

    employee: function (frm) {
        load_branch_info(frm);
        show_monthly_summary(frm);
    },

    attendance_date: function (frm) {
        show_monthly_summary(frm);
    }
});

function add_custom_buttons(frm) {
    if (frm.doc.employee && !frm.is_new()) {
        frm.add_custom_button(__('View Monthly Summary'), function () {
            show_monthly_report(frm);
        });

        frm.add_custom_button(__('Validate Geo-Fence'), function () {
            validate_geofence(frm);
        });
    }
}

function update_status_indicator(frm) {
    if (!frm.doc.status) return;

    let color_map = {
        'Present': 'green',
        'Absent': 'red',
        'Half Day': 'orange',
        'On Leave': 'blue'
    };

    frm.dashboard.set_headline_alert(
        `<div style="padding: 10px; background: ${color_map[frm.doc.status] || 'gray'};
        color: white; border-radius: 5px; text-align: center; font-size: 16px;">
        ${frm.doc.status} - ${frm.doc.custom_violation_type || frm.doc.violation_type || 'No Violation'}
        </div>`,
        color_map[frm.doc.status] || 'gray'
    );
}

function calculate_work_hours(frm) {
    if (!frm.doc.in_time || !frm.doc.out_time) return;

    let in_time = new Date(frm.doc.in_time);
    let out_time = new Date(frm.doc.out_time);
    let diff_hours = (out_time - in_time) / (1000 * 60 * 60);

    frm.set_value('total_work_hours', diff_hours.toFixed(2));

    frappe.show_alert({
        message: `Total Work Hours: ${diff_hours.toFixed(2)} hours`,
        indicator: diff_hours >= 8.5 ? 'green' : 'orange'
    }, 5);
}

// =====================================================
// Show monthly tracker summary — uses PAYROLL MONTH
// =====================================================
function show_monthly_summary(frm) {
    if (!frm.doc.employee || frm.is_new() || !frm.doc.attendance_date) return;

    let date_parts = frm.doc.attendance_date.split('-');
    let year = parseInt(date_parts[0]);
    let month = parseInt(date_parts[1]) - 1;
    let day = parseInt(date_parts[2]);

    let attendance_date = new Date(year, month, day);
    let day_of_month = attendance_date.getDate();
    let cycle_start_day = 26;

    let payroll_month, payroll_year;

    if (day_of_month >= cycle_start_day) {
        let payroll_date = new Date(year, month + 1, 1);
        payroll_month = payroll_date.toLocaleString('default', { month: 'long' });
        payroll_year = payroll_date.getFullYear();
    } else {
        payroll_month = attendance_date.toLocaleString('default', { month: 'long' });
        payroll_year = attendance_date.getFullYear();
    }

    frappe.call({
        method: 'frappe.client.get_list',
        args: {
            doctype: 'Monthly Attendance Tracker',
            filters: {
                employee: frm.doc.employee,
                month: payroll_month,
                year: payroll_year
            },
            fields: ['*']
        },
        callback: function (r) {
            if (r.message && r.message.length > 0) {
                let tracker = r.message[0];

                frm.dashboard.add_comment(
                    `<b>Monthly Summary:</b><br>
                    Late Coming: ${tracker.total_late_coming}/4<br>
                    Short Leave: ${tracker.total_short_leave_hours.toFixed(2)}/4 hours<br>
                    Half Day Deductions: ${tracker.half_day_deductions}<br>
                    Present Days: ${tracker.total_present_days}`,
                    'blue',
                    true
                );
            } else {
                frm.dashboard.add_comment(
                    `<b>Monthly Summary:</b><br>
                    <span style="color: #0c5460;">
                    Payroll Month: ${payroll_month} ${payroll_year}<br>
                    Tracker will be created on save
                    </span>`,
                    'blue',
                    true
                );
            }
        }
    });
}

function load_branch_info(frm) {
    if (!frm.doc.employee) return;

    frappe.call({
        method: 'frappe.client.get_value',
        args: {
            doctype: 'Employee',
            filters: { name: frm.doc.employee },
            fieldname: 'branch'
        },
        callback: function (r) {
            if (r.message && r.message.branch) {
                load_geo_coordinates(frm, r.message.branch);
            }
        }
    });
}

function load_geo_coordinates(frm, branch) {
    frappe.call({
        method: 'frappe.client.get_list',
        args: {
            doctype: 'Branch Geo Coordinates',
            filters: { branch: branch, is_active: 1 },
            fields: ['latitude', 'longitude', 'geo_fence_radius', 'address']
        },
        callback: function (r) {
            if (r.message && r.message.length > 0) {
                let coords = r.message[0];

                frappe.show_alert({
                    message: `Branch Geo-Fence: ${coords.geo_fence_radius}m radius<br>
                              Location: ${coords.address}`,
                    indicator: 'blue'
                }, 10);
            }
        }
    });
}

function validate_geofence(frm) {
    if (!frm.doc.geo_latitude || !frm.doc.geo_longitude) {
        frappe.msgprint('Geo coordinates not available for validation.');
        return;
    }

    frappe.show_alert({
        message: `Distance from branch: ${frm.doc.geo_distance_from_branch.toFixed(2)} meters<br>
                  Validation: ${frm.doc.is_geo_validated ? 'PASSED ✓' : 'FAILED ✗'}`,
        indicator: frm.doc.is_geo_validated ? 'green' : 'red'
    }, 10);
}

function show_monthly_report(frm) {
    if (!frm.doc.attendance_date) {
        frappe.set_route('List', 'Monthly Attendance Tracker', {
            employee: frm.doc.employee
        });
        return;
    }

    let date_parts = frm.doc.attendance_date.split('-');
    let year = parseInt(date_parts[0]);
    let month = parseInt(date_parts[1]) - 1;
    let day = parseInt(date_parts[2]);

    let attendance_date = new Date(year, month, day);
    let day_of_month = attendance_date.getDate();
    let cycle_start_day = 26;

    let payroll_month, payroll_year;

    if (day_of_month >= cycle_start_day) {
        let payroll_date = new Date(year, month + 1, 1);
        payroll_month = payroll_date.toLocaleString('default', { month: 'long' });
        payroll_year = payroll_date.getFullYear();
    } else {
        payroll_month = attendance_date.toLocaleString('default', { month: 'long' });
        payroll_year = attendance_date.getFullYear();
    }

    frappe.set_route('List', 'Monthly Attendance Tracker', {
        employee: frm.doc.employee,
        month: payroll_month,
        year: payroll_year
    });
}
