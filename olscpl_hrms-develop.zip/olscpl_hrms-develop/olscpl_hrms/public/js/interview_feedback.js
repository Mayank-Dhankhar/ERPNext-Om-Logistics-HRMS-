// Auto-fill Interviewer: the logged-in user when they're on the Interview's
// panel, else the only interviewer if the panel has just one. Also runs on
// load because "Submit Feedback"/links open this with Interview prefilled,
// which never fires hrms's own interview handler (so the dropdown filter
// wasn't applied either).
function fill_interviewer(frm) {
	if (!frm.doc.interview || frm.doc.docstatus !== 0) return;
	frappe
		.xcall("hrms.hr.doctype.interview_feedback.interview_feedback.get_applicable_interviewers", {
			interview: frm.doc.interview,
		})
		.then((interviewers) => {
			frm.set_query("interviewer", () => ({ filters: { name: ["in", interviewers] } }));
			if (frm.doc.interviewer) return;
			const pick = interviewers.includes(frappe.session.user)
				? frappe.session.user
				: interviewers.length === 1
				? interviewers[0]
				: null;
			if (pick) frm.set_value("interviewer", pick);
		});
}

// Opened from the Interview's "Submit Feedback" (public/js/interview.js) with
// Interview / Round / Applicant prefilled: load the round's skills (hrms only
// does that when the round changes) and the candidate's details from their
// previous feedback (olscpl_hrms.events.interview_feedback).
function fill_new_feedback(frm) {
	if (frm.doc.interview_round && !(frm.doc.skill_assessment || []).length) frm.trigger("interview_round");
	if (!frm.doc.job_applicant || !frm.fields_dict.custom_current_job_location) return;
	frappe
		.xcall("olscpl_hrms.events.interview_feedback.previous_details", { job_applicant: frm.doc.job_applicant })
		.then((values) => {
			Object.entries(values || {}).forEach(([field, value]) => {
				if (!frm.doc[field]) frm.set_value(field, value);
			});
		});
}

frappe.ui.form.on("Interview Feedback", {
	onload(frm) {
		if (frm.is_new()) {
			fill_interviewer(frm);
			fill_new_feedback(frm);
		}
	},
	interview(frm) {
		fill_interviewer(frm);
	},
});
