// The stock Desk sidebar "x" only fires its confirm+delete when the
// browser's hit-test lands the click directly on the tiny .remove-btn span
// inside the attachment pill - on this build that never happens (the click
// always resolves to the wrapping pill button instead), so the confirm
// dialog never opens and nothing gets deleted. This affects every doctype's
// attachment sidebar identically, so instead of patching core Frappe (or
// repeating this in a Client Script per doctype) it's bound once globally
// here: work out from the click position whether the user meant to hit the
// "x", and if so show a custom-styled confirm dialog and reuse the same
// core deletion call the sidebar itself uses.
(function () {
	if (window.__cad_attachment_delete_bound) {
		return;
	}
	window.__cad_attachment_delete_bound = true;

	var PDF_VIEWER_DOCTYPES = ["Employee", "Employee Onboarding"];

	function _load_pdfjs(callback) {
		if (window.pdfjsLib) { callback(); return; }
		frappe.require('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', function () {
			window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
			callback();
		});
	}

	// Same in-page canvas viewer as the User Manual page (public/js/
	// user_manual.js's viewPdf()) and the Appointment Letter dialog
	// (public/js/employee.js) - fetched with credentials rather than
	// pointed at the URL directly, so it works the same regardless of
	// whether the file is public or private.
	function show_pdf_preview_dialog(title, url) {
		var dialog = new frappe.ui.Dialog({
			title: title || __("Attachment"),
			size: "extra-large",
			fields: [
				{
					fieldtype: "HTML",
					fieldname: "preview",
					options: (
						'<div id="cad-pdf-body" style="height:70vh;overflow-y:auto;background:var(--fg-color);' +
						'border:1px solid var(--border-color);border-radius:8px;padding:16px;display:flex;' +
						'flex-direction:column;align-items:center;gap:14px;">' +
							'<div class="text-muted">' + __("Loading preview…") + "</div>" +
						"</div>"
					),
				},
			],
		});
		dialog.show();

		var body = dialog.$wrapper.find("#cad-pdf-body");

		_load_pdfjs(function () {
			fetch(url, { credentials: "same-origin" })
				.then(function (res) {
					if (!res.ok) throw new Error("Preview failed");
					return res.arrayBuffer();
				})
				.then(function (buf) {
					return window.pdfjsLib.getDocument({ data: buf }).promise;
				})
				.then(function (pdf) {
					body.empty();
					var renderNext = function (pageNum) {
						if (pageNum > pdf.numPages) return;
						pdf.getPage(pageNum).then(function (page) {
							var unscaled = page.getViewport({ scale: 1 });
							var scale = Math.min((body.width() || 800) / unscaled.width, 2);
							var viewport = page.getViewport({ scale: scale });
							var canvas = document.createElement("canvas");
							canvas.width = viewport.width;
							canvas.height = viewport.height;
							canvas.style.maxWidth = "100%";
							canvas.style.boxShadow = "0 1px 4px rgba(0,0,0,0.15)";
							body.append(canvas);
							page.render({ canvasContext: canvas.getContext("2d"), viewport: viewport }).promise.then(function () {
								renderNext(pageNum + 1);
							});
						});
					};
					renderNext(1);
				})
				.catch(function () {
					body.html('<div class="text-muted">' + __("Could not load the preview.") + "</div>");
				});
		});
	}

	// Image preview - a plain <img>, not pdf.js, but the same dialog shape
	// as show_pdf_preview_dialog() so both read as one consistent viewer.
	// Includes its own explicit Download button: the *reason* image clicks
	// were switched to force-download in the first place (see the note
	// below) - a candidate's photo/scanned Aadhaar/PAN etc. - still needs
	// an easy way to actually save the file, this just moves that into an
	// explicit action inside the viewer instead of being the click's only
	// possible outcome.
	function show_image_preview_dialog(title, url) {
		var dialog = new frappe.ui.Dialog({
			title: title || __("Attachment"),
			size: "large",
			fields: [
				{
					fieldtype: "HTML",
					fieldname: "preview",
					options: (
						'<div style="max-height:70vh;overflow:auto;background:var(--fg-color);' +
						'border:1px solid var(--border-color);border-radius:8px;padding:16px;' +
						'display:flex;align-items:center;justify-content:center;">' +
							'<img src="' + frappe.utils.escape_html(url) + '" style="max-width:100%;max-height:66vh;display:block;">' +
						"</div>"
					),
				},
			],
			primary_action_label: __("Download"),
			primary_action: function () {
				var dl = document.createElement("a");
				dl.href = url;
				dl.download = title || "";
				document.body.appendChild(dl);
				dl.click();
				document.body.removeChild(dl);
				dialog.hide();
			},
		});
		dialog.show();
	}

	// Both the "x" and the file name link sit as descendants INSIDE the
	// pill button, but the browser's hit-test on this build always
	// resolves a click anywhere in the pill to the button itself, never
	// to whichever descendant is actually under the pointer - so neither
	// a delegated selector for .remove-btn nor one for the label <a>
	// (jQuery delegation matches via the *target*'s ancestors, and
	// target is always the button) ever sees a real click. Binding on
	// the button itself and working out which sub-area the click
	// coordinates actually fall in is the only way to tell the two apart.
	$(document).on("click", ".form-attachments .data-pill.btn", function (e) {
		var pill = this;
		var frm = window.cur_frm;

		var remove_btn = pill.querySelector(".remove-btn");
		if (remove_btn && point_in_rect(e, remove_btn.getBoundingClientRect())) {
			e.preventDefault();
			e.stopPropagation();

			if (!frm || !frm.attachments) {
				return;
			}

			var row = $(pill).closest(".attachment-row");
			var file_name = row.find(".pill-label").text().trim();
			var icon_link = row.find("> button > div > a").attr("href") || "";
			var fileid = icon_link.split("/").pop();
			if (!fileid) {
				return;
			}

			show_attachment_delete_confirm(file_name, function () {
				frm.attachments.remove_attachment(fileid);
			});
			return;
		}

		// Clicking the file name itself used to just open it in a new tab,
		// which for an image just looked like nothing happened (browser's
		// own bare image view, no obvious way back or to save it) - fixed
		// once already by force-downloading every attachment on click, but
		// that traded "looks broken" for "never get to actually look at
		// it first". On the Employee and Employee Onboarding forms
		// specifically - where onboarding documents (offer letter,
		// guarantor form, Aadhaar/PAN scans, candidate photo, etc.) live -
		// PDFs and images now open in an actual viewer instead (pdf.js
		// canvas / plain <img>, both in the same dialog shape as the User
		// Manual page's and Appointment Letter's viewers), with Download
		// available as an explicit action inside it rather than being the
		// click's only possible outcome. Every other doctype's
		// attachments, and any other file type here (.doc/.xlsx/etc,
		// nothing can usefully preview those in-browser anyway), keep the
		// original force-download behaviour.
		var label_link = pill.querySelector(".pill-label a");
		if (label_link && point_in_rect(e, label_link.getBoundingClientRect())) {
			e.preventDefault();
			e.stopPropagation();

			var href = label_link.getAttribute("href") || "";
			var label_text = $(pill).closest(".attachment-row").find(".pill-label").text().trim();

			if (frm && PDF_VIEWER_DOCTYPES.indexOf(frm.doctype) !== -1) {
				if (/\.pdf($|\?)/i.test(href)) {
					show_pdf_preview_dialog(label_text, href);
					return;
				}
				if (/\.(jpe?g|png|gif|bmp|webp)($|\?)/i.test(href)) {
					show_image_preview_dialog(label_text, href);
					return;
				}
			}

			var dl = document.createElement("a");
			dl.href = href;
			dl.download = label_link.getAttribute("title") || "";
			document.body.appendChild(dl);
			dl.click();
			document.body.removeChild(dl);
		}
	});

	function point_in_rect(e, r, pad) {
		pad = pad || 6;
		return (
			e.clientX >= r.left - pad &&
			e.clientX <= r.right + pad &&
			e.clientY >= r.top - pad &&
			e.clientY <= r.bottom + pad
		);
	}

	function show_attachment_delete_confirm(file_name, on_confirm) {
		$(".cad-confirm-backdrop").remove();

		var backdrop = $(
			'<div class="cad-confirm-backdrop">' +
				'<div class="cad-confirm-box">' +
				'<div class="cad-confirm-message">' +
				__("Delete") +
				' "' +
				frappe.utils.escape_html(file_name) +
				'"? ' +
				__("This can't be undone.") +
				"</div>" +
				'<div class="cad-confirm-actions">' +
				'<button type="button" class="cad-confirm-cancel">' +
				__("Cancel") +
				"</button>" +
				'<button type="button" class="cad-confirm-ok">' +
				__("Delete") +
				"</button>" +
				"</div>" +
				"</div>" +
				"</div>"
		).appendTo("body");

		function close() {
			backdrop.remove();
		}

		backdrop.on("click", function (e) {
			if (e.target === backdrop[0]) {
				close();
			}
		});
		backdrop.find(".cad-confirm-cancel").on("click", close);
		backdrop.find(".cad-confirm-ok").on("click", function () {
			close();
			on_confirm();
		});
	}

	function inject_attachment_delete_css() {
		if (document.getElementById("cad-confirm-style")) {
			return;
		}
		var style = document.createElement("style");
		style.id = "cad-confirm-style";
		style.innerHTML =
			".cad-confirm-backdrop { position: fixed; inset: 0; z-index: 1100; background: rgba(15, 23, 42, 0.45);" +
			" display: flex; align-items: center; justify-content: center; padding: 16px;" +
			" animation: cad-fade-in 0.15s ease both; }" +
			".cad-confirm-box { background: #fff; border-radius: 14px; width: 100%; max-width: 360px; padding: 20px;" +
			" box-shadow: 0 24px 60px -20px rgba(15, 23, 42, 0.45); animation: cad-pop-in 0.18s ease both; }" +
			".cad-confirm-message { font-size: 14.5px; color: #1f2937; line-height: 1.5; }" +
			".cad-confirm-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px; }" +
			".cad-confirm-cancel, .cad-confirm-ok { border: none; border-radius: 999px; padding: 8px 18px;" +
			" font-size: 13px; font-weight: 700; cursor: pointer; font-family: inherit;" +
			" transition: transform 0.15s ease, box-shadow 0.15s ease; }" +
			".cad-confirm-cancel { background: #f1f2f4; color: #374151; }" +
			".cad-confirm-cancel:hover { background: #e4e6e8; }" +
			".cad-confirm-ok { background: #e11d48; color: #fff; }" +
			".cad-confirm-ok:hover { transform: translateY(-1px); box-shadow: 0 6px 16px -6px rgba(225, 29, 72, 0.5); }" +
			"@keyframes cad-fade-in { from { opacity: 0; } to { opacity: 1; } }" +
			"@keyframes cad-pop-in { from { opacity: 0; transform: scale(0.85); } to { opacity: 1; transform: scale(1); } }";
		document.head.appendChild(style);
	}

	inject_attachment_delete_css();
})();
