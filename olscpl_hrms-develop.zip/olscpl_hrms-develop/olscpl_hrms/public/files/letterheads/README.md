# Company letterheads

Source letterhead artwork for the three group companies, and the header/
footer crops generated from them. Wired up automatically (one Letter Head
doctype record per company, set as that Company's `default_letter_head`)
by `olscpl_hrms/patches/v1_1/setup_company_letterheads.py`, which runs on
every `bench migrate`.

| Company | Original | Header crop | Footer crop |
|---|---|---|---|
| OM Logistics Supply Chain PVT. LTD. | `olscpl_letterhead.pdf` (source) / `olscpl_letterhead.jpg` (rasterized) | `olscpl_header.jpg` | `olscpl_footer.jpg` |
| SANJVIK TERMINALS PVT LTD | `sanjvik_letterhead.jpg` | `sanjvik_header.jpg` | `sanjvik_footer.jpg` |
| OM TELECOM LOGISTICS PVT LTD | `telecom_letterhead.jpg` | `telecom_header.jpg` | `telecom_footer.jpg` |
| OPEN SOURCE BUSINESS SOLUTIONS PVT LTD | `rapidshyp_letterhead.pdf` (source) / `rapidshyp_letterhead.jpg` (rasterized) | `rapidshyp_header.jpg` | `rapidshyp_footer.jpg` |
| TRANSAFE SERVICES LTD | `transafe_letterhead.jpg` | `transafe_header.jpg` | `transafe_footer.jpg` |

The originals are full-page A4 templates (logo/address block at top, legal/
contact details at the bottom, blank in between for content) - Frappe's
Letter Head doctype renders a header image and a footer image separately
rather than one full-page background, so each original was cropped into
its top and bottom bands (top ~15-20%, bottom ~10-13%) to fit that model.
If the source artwork ever changes, regenerate the crops and re-run the
patch (`bench execute olscpl_hrms.patches.v1_1.setup_company_letterheads.execute`)
to pick them up - it's idempotent, safe to re-run any time.

Applies automatically to any print format that consults the document's
own/company's letterhead (every ERPNext accounting document, HRMS Salary
Slip, and any Print Format with "With Letterhead" checked). A few
doctype-specific custom Print Formats in this system embed their own
`Company.company_logo` directly instead of going through the Letter Head
system - those are unaffected by this and would need each one's own
template edited to also point at these assets.
