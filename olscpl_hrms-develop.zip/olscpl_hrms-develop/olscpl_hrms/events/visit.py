# Visit - fields mirror the OMSTAFF Android app's existing "Branch Visit
# Entry" screen (activity/visit/AutoVisitReporting.java), which already
# POSTs this same shape to a separate legacy endpoint
# (AppConfig.URL_VISIT, status="visit_entry"): employee/branch/visit_type/
# source/destination/from_date/to_date/time/reporting_person/remarks map
# to empcode/bcode/visit_type/source/destination/from_date/to_date/time/
# reporting_to/remarks (the app's own lat/long/address/clients aren't
# fields here - out of scope for this doctype). api/visit.py's
# create_and_submit_visit() accepts the same field names via the app's
# usual caller_employee/Administrator server-to-server pattern (see
# api/regularization.py's module-level note).
#
# The legacy endpoint this mirrors has no approval step at all -
# submitting IS the whole flow, and its only side effect is a push
# notification telling the reporting person "I am on visit from X to Y"
# (AutoVisitReporting.java's PushNotification.send() call). That
# notification still happens on submit here too. Marking Attendance,
# though, follows the same Draft->Pending->Approved/Rejected Workflow as
# Work From Home Request instead of firing on submit - Attendance should
# only reflect a Visit once the reporting person/HR has actually
# approved it, not the moment the employee files it.
#
# Registered via hooks.py -> doc_events["Visit"]. Marks Attendance
# "Visit" for every day in [from_date, to_date] (a Visit can span
# several days, unlike Work From Home Request's single date) - "Visit"
# added to Attendance's status options by patches/v1_1/
# add_visit_attendance_status.py, same pattern as Week Off/Holiday, and
# to the status lists in overrides/attendance.py, events/
# attendance_steps.py, and public/js/attendance_list.js. The legacy
# "Process Daily Attendance"/"010 SHIFT POLICY RESOLVER"/etc Server
# Scripts that used to duplicate this logic were disabled on this site
# to match production, where they were already off - see this file's
# git history for the Attendance status-clobbering bug that caused.
import frappe
from frappe import _
from frappe.utils import add_days, getdate


def validate(doc, method=None):
	if doc.employee == doc.reporting_person:
		frappe.throw(_("Employee cannot be their own Reporting Person"))


def after_insert(doc, method=None):
	# Fires once, right when the employee files the visit (Draft, still
	# docstatus 0) - not on_submit, which under the Workflow only fires
	# at the "Approve" transition. Notifying only once the reporting
	# person has already approved it themselves would be pointless; the
	# point of this alert is to tell them something is now awaiting
	# their review, matching when the legacy app's PushNotification
	# actually fired.
	_notify_reporting_person(doc)


def on_cancel(doc, method=None):
	_remove_attendance(doc)


def on_update(doc, method=None):
	if doc.workflow_state == "Approved":
		_mark_attendance(doc)
	elif doc.workflow_state == "Rejected":
		_remove_attendance(doc)


def _notify_reporting_person(doc):
	"""Mirrors AutoVisitReporting.java's onSubmit() - after a successful
	create, it fires PushNotification.send(reportingPerson, "I am on visit
	from <source> to <destination>", ...) to let the reporting person know
	a visit has been filed and (with the Workflow) is now awaiting their
	review. Notification Log is Frappe's own equivalent of that in-app
	alert; only sent if the reporting person has a User account to
	receive one."""
	user = frappe.db.get_value("Employee", doc.reporting_person, "user_id")
	if not user:
		return
	from frappe.desk.doctype.notification_log.notification_log import enqueue_create_notification

	enqueue_create_notification(user, {
		"type": "Alert",
		"document_type": doc.doctype,
		"document_name": doc.name,
		"subject": _("{0} is on visit from {1} to {2}").format(doc.employee_name, doc.source, doc.destination),
		"from_user": frappe.session.user,
	})


def _date_range(doc):
	day = getdate(doc.from_date)
	last = getdate(doc.to_date)
	while day <= last:
		yield day
		day = add_days(day, 1)


def _mark_attendance(doc):
	# custom_visit_day_portion (patches/v1_1/add_visit_half_day_support.py)
	# is what events/salary_slip_steps.py's half-day payroll counting
	# actually keys on for a Visit - status alone stays "Visit" either
	# way, so a First/Second Half Visit still needs to read as half a
	# day for pay purposes the same way "Half Day" attendance already
	# does, not as a free extra day off.
	#
	# BUT: if there's already an Attendance record for this date with
	# status "Half Day" (attendance_steps.py's punch-based calculation
	# already determined the OTHER half was actually worked), a
	# First/Second Half Visit covering the remaining half means the
	# whole day is now accounted for - punched half + visited half =
	# a full day, not two separate half-day deductions stacked on top
	# of each other. Merges to day_portion "Full Day" in that case
	# instead of overwriting straight to the requested half. The
	# reverse order (Visit approved first, punches come in after) is
	# handled by reconcile_half_day_visit_with_punches() in
	# events/attendance_steps.py, run on every later Attendance save.
	for day in _date_range(doc):
		existing = frappe.db.get_value(
			"Attendance",
			{"employee": doc.employee, "attendance_date": day, "docstatus": ("!=", 2)},
			["name", "status"],
			as_dict=True,
		)
		portion = doc.day_portion
		if existing:
			if existing.status == "Half Day" and portion in ("First Half", "Second Half"):
				portion = "Full Day"
			frappe.db.set_value("Attendance", existing.name, {
				"status": "Visit",
				"custom_visit_day_portion": portion,
			})
			continue
		attendance = frappe.get_doc({
			"doctype": "Attendance",
			"employee": doc.employee,
			"attendance_date": day,
			"status": "Visit",
			"custom_visit_day_portion": portion,
			"company": frappe.db.get_value("Employee", doc.employee, "company"),
		})
		attendance.insert(ignore_permissions=True)
		attendance.submit()


def _remove_attendance(doc):
	for day in _date_range(doc):
		existing = frappe.db.get_value(
			"Attendance",
			{"employee": doc.employee, "attendance_date": day, "status": "Visit", "docstatus": 1},
			"name",
		)
		if existing:
			# Same gap as Leave Application's create_or_update_attendance
			# (see overrides/leave_application.py): a plain Reporting Person
			# rejecting or cancelling this request has no general permission
			# on another employee's Attendance, so .cancel() without
			# ignore_permissions throws right here.
			attendance = frappe.get_doc("Attendance", existing)
			attendance.flags.ignore_permissions = True
			attendance.cancel()
