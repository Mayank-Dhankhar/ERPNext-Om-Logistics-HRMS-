# olscpl_hrms/events/interview.py
#
# Stock HRMS never emails anyone when an Interview is created - it only mails
# on reschedule, the pre-interview reminder and the feedback reminder. HR
# expects saving a new Interview to notify the candidate and the interviewers.
#
# The two mails are independent on purpose: the applicant gets theirs even if
# the Interview has no interviewers yet, and interviewers get theirs even if
# the applicant has no email. Each has its own try/except so one failing
# (e.g. no outgoing Email Account) never blocks the other or the save itself.
# Sent immediately (now=True) rather than left in the Email Queue, so the
# message shown to the user reflects real delivery to the mail server instead
# of just "queued". The outcome of each is shown in one summary message.
import frappe
from frappe import _
from frappe.utils import format_date, format_time

# Interview details render as a soft card inside the branded email
# (olscpl_hrms.utils.email_layout) - inline styles, for Gmail/Outlook.
DETAILS_TABLE = (
	"width:100%; border-collapse:separate; background-color:#f7f8fc; border:1px solid #e6e9f4;"
	" border-radius:12px; padding:10px 16px; font-size:14px; line-height:22px; margin:6px 0 4px 0;"
)
LABEL_TD = "width:1%; padding:5px 22px 5px 0; color:#7a7d9c; font-weight:600; white-space:nowrap; vertical-align:top;"
VALUE_TD = "padding:5px 0; color:#16264f; font-weight:600;"
from olscpl_hrms.utils.email_layout import company_email, sender_cc


def _company(doc):
	"""The hiring company - the applicant's Company (a General Application
	applicant chose it), else the Job Opening's - for the mail's look."""
	company = frappe.db.get_value("Job Applicant", doc.job_applicant, "custom_company") if doc.get("job_applicant") else None
	if company:
		return company
	opening = doc.get("job_opening") or frappe.db.get_value("Job Applicant", doc.job_applicant, "job_title")
	return frappe.db.get_value("Job Opening", opening, "company") if opening else None


def after_insert(doc, method=None):
	if doc.get("custom_offline_interview"):  # held offline, only recorded - no mails
		frappe.msgprint(_("Offline interview - no emails were sent."), title=_("Interview Notifications"), indicator="blue")
		return
	applicant_result = _notify_applicant(doc)
	interviewers_result = _notify_interviewers(doc)

	lines = [applicant_result, interviewers_result]
	all_sent = all(status == "sent" for status, _m in lines)
	frappe.msgprint(
		"<br>".join(m for _s, m in lines),
		title=_("Interview Notifications"),
		indicator="green" if all_sent else "orange",
	)


def _drop_smtp_popups():
	# Frappe's SMTP layer msgprints its own red "Invalid Outgoing Mail Server"
	# popup before raising; the summary message already reports the failure
	# in plain words, so drop those to avoid stacked duplicate errors.
	frappe.local.message_log = [
		m for m in frappe.local.message_log if "Outgoing Mail Server" not in str(m)
	]


def _cleared_rounds_remark(doc):
	"""For a further round, congratulate the candidate on the rounds they
	have already cleared (submitted Interviews of theirs with status
	"Cleared", oldest first) - e.g. "Congratulations! You have cleared
	Round 1 and Round 2." Empty for a first round, or when nothing has been
	cleared yet."""
	rounds = frappe.get_all(
		"Interview",
		filters={
			"job_applicant": doc.job_applicant,
			"status": "Cleared",
			"docstatus": 1,
			"name": ["!=", doc.name],
		},
		order_by="scheduled_on asc, creation asc",
		pluck="interview_round",
	)
	rounds = list(dict.fromkeys(r for r in rounds if r))  # de-dupe, keep order
	if not rounds:
		return ""
	names = rounds[0] if len(rounds) == 1 else ", ".join(rounds[:-1]) + f" {_('and')} " + rounds[-1]
	return (
		f"<p>{_('Congratulations! You have cleared')} <b>{frappe.utils.escape_html(names)}</b>.</p>"
	)


def _interviewer_details_html(doc):
	"""Name, designation (when the interviewer is also an Employee) and email
	of each interviewer, for the candidate's mail. Mobile numbers are left
	out on purpose - the email address is enough to reach the panel."""
	items = []
	for row in doc.interview_details:
		if not row.interviewer:
			continue
		name, email = frappe.db.get_value("User", row.interviewer, ["full_name", "email"]) or (row.interviewer, row.interviewer)
		designation = frappe.db.get_value("Employee", {"user_id": row.interviewer}, "designation")
		line = frappe.utils.escape_html(name or row.interviewer)
		if designation:
			line += f", {frappe.utils.escape_html(designation)}"
		if email:
			line += f" ({frappe.utils.escape_html(email)})"
		items.append(f"<li>{line}</li>")
	return "".join(items)


def _details_html(doc):
	rows = [
		(_("Interview"), doc.name),
		(_("Round"), doc.interview_round),
		(_("Designation"), doc.designation),
		(_("Date"), format_date(doc.scheduled_on)),
		(_("Time"), f"{format_time(doc.from_time)} - {format_time(doc.to_time)}"),
	]
	if doc.get("custom_mode_of_interview"):
		rows.append((_("Mode of Interview"), doc.custom_mode_of_interview))
	html = "".join(
		f"<tr><td style='{LABEL_TD}'>{label}</td><td style='{VALUE_TD}'>{frappe.utils.escape_html(str(value or ''))}</td></tr>"
		for label, value in rows
	)

	meeting_link = doc.get("custom_meeting_link")
	if meeting_link:
		safe_link = frappe.utils.escape_html(meeting_link)
		html += (
			f"<tr><td style='{LABEL_TD}'>{_('Meeting Link')}</td>"
			f"<td style='{VALUE_TD}'><a href='{safe_link}' style='color:#3d3f9e;'>{safe_link}</a></td></tr>"
		)

	return html


def _notify_applicant(doc):
	email = frappe.db.get_value("Job Applicant", doc.job_applicant, "email_id")
	name = frappe.db.get_value("Job Applicant", doc.job_applicant, "applicant_name") or doc.job_applicant
	if not email:
		return ("skipped", _("Job Applicant email: not sent - applicant has no email address."))

	interviewers_html = _interviewer_details_html(doc)
	message = (
		f"<p>{_('Dear')} {frappe.utils.escape_html(name)},</p>"
		+ _cleared_rounds_remark(doc)
		+ f"<p>{_('Your interview has been scheduled. Details:')}</p>"
		f"<table style='{DETAILS_TABLE}'>{_details_html(doc)}</table>"
		+ (f"<p><b>{_('Interviewer(s)')}</b></p><ul>{interviewers_html}</ul>" if interviewers_html else "")
		+ f"<p>{_('Please be available on time. Reply to this email if you need to reschedule.')}</p>"
	)
	try:
		frappe.sendmail(
			recipients=[email],
			cc=sender_cc([email]),
			subject=_("Interview Scheduled: {0}").format(doc.interview_round),
			message=company_email(_company(doc), _("Interview Scheduled"), message, signoff=True),
			reference_doctype=doc.doctype,
			reference_name=doc.name,
			now=True,
		)
	except Exception:
		frappe.log_error(frappe.get_traceback(), "Interview: applicant mail failed")
		_drop_smtp_popups()
		return ("failed", _("Job Applicant email: could not be sent to {0}. Check the outgoing Email Account.").format(email))
	return ("sent", _("Job Applicant email: sent to {0}.").format(email))


def _notify_interviewers(doc):
	# external interviewers (website users) get their own mail with a feedback link
	external = {r.user for r in doc.get("custom_external_interviewers") or [] if r.user}
	recipients = [row.interviewer for row in doc.interview_details if row.interviewer and row.interviewer not in external]
	if not recipients:
		return ("skipped", _("Interviewer email: not sent - no interviewers added."))

	applicant_name, resume = frappe.db.get_value(
		"Job Applicant", doc.job_applicant, ["applicant_name", "resume_attachment"]
	) or (None, None)
	applicant_name = applicant_name or doc.job_applicant
	message = (
		f"<p>{_('You have been assigned as an interviewer. Details:')}</p>"
		f"<table style='{DETAILS_TABLE}'>{_details_html(doc)}"
		f"<tr><td style='{LABEL_TD}'>{_('Candidate')}</td>"
		f"<td style='{VALUE_TD}'>{frappe.utils.escape_html(applicant_name)}</td></tr></table>"
		+ (f"<p>{_('The candidate resume is attached.')}</p>" if resume else "")
	)
	attachments = [{"file_url": resume}] if resume else []
	message = _with_feedback_pdf(doc, message, attachments)
	message += f"<p>{_('Open the Interview in the system to review the candidate and submit your feedback afterwards.')}</p>"
	try:
		frappe.sendmail(
			recipients=recipients,
			cc=sender_cc(recipients),
			subject=_("Interview Assigned: {0} - {1}").format(applicant_name, doc.interview_round),
			message=company_email(_company(doc), _("Interview Assigned"), message, signoff=True),
			attachments=attachments or None,
			reference_doctype=doc.doctype,
			reference_name=doc.name,
			now=True,
		)
	except Exception:
		frappe.log_error(frappe.get_traceback(), "Interview: interviewer mail failed")
		_drop_smtp_popups()
		return ("failed", _("Interviewer email: could not be sent to {0}. Check the outgoing Email Account.").format(", ".join(recipients)))
	return ("sent", _("Interviewer email: sent to {0}.").format(", ".join(recipients)))


@frappe.whitelist()
def previous_rounds(interview):
	"""Earlier interviews of the same candidate for the same Job Opening, with
	every interviewer's feedback - shown at the top of the next round's form
	(public/js/interview.js)."""
	frappe.has_permission("Interview", "read", interview, throw=True)
	return _previous_rounds(interview)


def _previous_rounds(interview, include_self=False):
	"""previous_rounds() without the permission check (external interviewer mail/form).
	include_self: every round up to and including `interview`."""
	from olscpl_hrms.events.interview_feedback import BLOCK_RE

	doc = frappe.db.get_value("Interview", interview, ["job_applicant", "job_opening", "creation"], as_dict=True)
	if not doc or not doc.job_applicant:
		return []
	filters = {"job_applicant": doc.job_applicant, "docstatus": ["<", 2],
		"creation": ["<=" if include_self else "<", doc.creation]}
	if not include_self:
		filters["name"] = ["!=", interview]
	if doc.job_opening:
		filters["job_opening"] = doc.job_opening
	rounds = frappe.get_all("Interview", filters, ["name", "interview_round", "status", "scheduled_on",
		"average_rating", "interview_summary"], order_by="creation asc")
	seen = {}  # Candidate Details already shown in an earlier round: field -> value
	for r in rounds:
		# the Candidate Details block is shown per feedback below - keep HR's own notes only
		r.interview_summary = BLOCK_RE.sub("", r.interview_summary or "").strip()
		r.feedback = []
		for f in frappe.get_all("Interview Feedback", {"interview": r.name, "docstatus": ["<", 2]}, ["name"],
				order_by="creation asc"):
			fb = frappe.get_doc("Interview Feedback", f.name)
			r.feedback.append({
				"name": fb.name,
				"interviewer": frappe.utils.get_fullname(fb.interviewer) if fb.interviewer else "",
				"result": fb.result,
				"draft": fb.docstatus == 0,
				"average_rating": fb.average_rating,
				"skills": [{"skill": s.skill, "rating": s.rating} for s in fb.skill_assessment],
				"feedback": fb.feedback,
				# only what this round added or changed - earlier values were shown above it
				"details": _new_details(fb, seen),
			})
	return rounds


def external_previous_rounds(interview):
	"""Earlier rounds for an external interviewer: submitted feedback only -
	result, ratings and comments. Candidate Details (family etc.) and HR's own
	summary notes stay internal."""
	out = []
	for r in _previous_rounds(interview):
		fbs = [
			{k: f[k] for k in ("interviewer", "result", "average_rating", "skills", "feedback")}
			for f in r.feedback if not f["draft"]
		]
		if fbs:
			out.append({"round": r.interview_round, "status": r.status, "scheduled_on": r.scheduled_on, "feedback": fbs})
	return out


def _stars(rating):
	"""average_rating is 0-1 in HRMS; shown out of 5."""
	return f"{round(frappe.utils.flt(rating) * 5, 1):g}/5" if rating else ""


def _previous_rounds_pdf(doc, include_self=False):
	"""All earlier rounds' complete feedback as one PDF for the next round's
	interviewers, internal and external (mail attachment, not the mail body):
	results, ratings, comments, each round's Candidate Details and HR's
	summary notes. None when there are no earlier rounds."""
	from frappe.utils.pdf import get_pdf

	esc = frappe.utils.escape_html
	rounds = _previous_rounds(doc.name, include_self)
	blocks = []
	for r in rounds:
		rows = []
		for f in r.feedback:
			if f["draft"]:
				continue
			skills = ", ".join(f"{esc(s['skill'])} {_stars(s['rating'])}" for s in f["skills"] if s["rating"])
			details = "".join(f"<li>{esc(d)}</li>" for d in f["details"])
			rows.append(
				"<div style='padding:10px 0; border-top:1px solid #e6e8f0;'>"
				f"<b>{esc(f['interviewer'])}</b> &middot; {esc(_(f['result'] or ''))}"
				+ (f" &middot; {_stars(f['average_rating'])}" if f["average_rating"] else "")
				+ (f"<div style='color:#5b5f7a;'>{skills}</div>" if skills else "")
				+ (f"<div style='margin-top:4px;'>{esc(frappe.utils.strip_html(f['feedback'] or ''))}</div>" if f["feedback"] else "")
				+ (f"<div style='margin-top:6px; color:#5b5f7a;'>{_('Candidate Details')}:</div><ul style='margin:2px 0;'>{details}</ul>" if details else "")
				+ "</div>"
			)
		notes = esc(r.interview_summary or "").replace("\n", "<br>")
		if not rows and not notes:
			continue
		blocks.append(
			"<div style='margin:12px 0; padding:12px 16px; border:1px solid #e6e8f0; border-radius:8px; page-break-inside:avoid;'>"
			f"<b style='font-size:15px;'>{esc(r.interview_round or '')}</b> &middot; {esc(_(r.status or ''))}"
			+ (f" &middot; {format_date(r.scheduled_on)}" if r.scheduled_on else "")
			+ "".join(rows)
			+ (f"<div style='margin-top:8px; color:#5b5f7a;'><b>{_('HR Notes')}:</b> {notes}</div>" if notes else "")
			+ "</div>"
		)
	if not blocks:
		return None
	name = frappe.db.get_value("Job Applicant", doc.job_applicant, "applicant_name") or doc.job_applicant
	html = (
		"<div style='font-family:Helvetica,Arial,sans-serif; font-size:13px; color:#16264f;'>"
		f"<h2 style='margin:0 0 4px;'>{_('Interview Feedback') if include_self else _('Earlier Rounds Feedback')}</h2>"
		f"<div style='color:#7a7d9c; margin-bottom:8px;'>{esc(name)}"
		+ ("" if include_self else f" &middot; {_('for')} {esc(doc.interview_round or '')}")
		+ f" &middot; {_('Confidential')}</div>"
		+ "".join(blocks) + "</div>"
	)
	title = "Interview Feedback" if include_self else "Earlier Rounds Feedback"
	return {"fname": f"{title} - {name}.pdf", "fcontent": get_pdf(html)}


def _with_feedback_pdf(doc, message, attachments):
	"""Attach the earlier-rounds PDF (if any) and say so in the mail."""
	pdf = _previous_rounds_pdf(doc)
	if pdf:
		attachments.append(pdf)
		message += f"<p>{_('Feedback from all earlier rounds is attached as a PDF.')}</p>"
	return message


# ── External interviewers (patches/v1_1/add_interview_external_interviewers.py) ──
# Someone outside the company on the panel: a website-only user (no desk
# access, no welcome mail) is made for their email and put on the panel, so
# stock Interview Feedback rules (panel member, one feedback each) apply
# unchanged. They're emailed a private no-login link
# (/interview-feedback-form, api/external_feedback.py) to submit it.
def _external_user(email, name):
	email = email.strip().lower()
	if frappe.db.exists("User", email):
		return email
	user = frappe.get_doc({
		"doctype": "User", "email": email, "first_name": name or email, "user_type": "Website User",
		"send_welcome_email": 0,
	})
	user.flags.ignore_permissions = True
	user.insert()
	return user.name


def sync_external_interviewers(doc, method=None):
	"""Interview validate: a user + feedback key per external row, and the panel
	(Interview Detail) holding exactly these external users."""
	import secrets

	rows = doc.get("custom_external_interviewers") or []
	for r in rows:
		if not r.user or (r.email or "").strip().lower() != r.user:
			r.user = _external_user(r.email, r.interviewer_name)
		if not r.feedback_key:
			r.feedback_key = secrets.token_urlsafe(24)
	external = {r.user for r in rows}
	website = set(frappe.get_all("User", {"user_type": "Website User",
		"name": ["in", [d.interviewer for d in doc.interview_details if d.interviewer] or [""]]}, pluck="name"))
	# drop external users no longer listed, add newly listed ones
	doc.interview_details = [d for d in doc.interview_details if not (d.interviewer in website and d.interviewer not in external)]
	on_panel = {d.interviewer for d in doc.interview_details}
	for user in external - on_panel:
		doc.append("interview_details", {"interviewer": user})


def feedback_link(doc, row):
	return frappe.utils.get_url(f"/interview-feedback-form?interview={doc.name}&key={row.feedback_key}")


def invite_external_interviewers(doc, method=None):
	"""Interview on_update: email each external interviewer not yet invited
	(not for an offline interview - HR records their feedback on the desk)."""
	if doc.get("custom_offline_interview"):
		return
	pending = [r for r in doc.get("custom_external_interviewers") or [] if not r.invited_on and r.email]
	if not pending:
		return
	applicant_name, resume = frappe.db.get_value("Job Applicant", doc.job_applicant, ["applicant_name", "resume_attachment"]) or (None, None)
	feedback_pdf = _previous_rounds_pdf(doc)
	attachments = ([{"file_url": resume}] if resume else []) + ([feedback_pdf] if feedback_pdf else [])
	for r in pending:
		link = feedback_link(doc, r)
		message = (
			f"<p>{_('Dear')} {frappe.utils.escape_html(r.interviewer_name or '')},</p>"
			f"<p>{_('Thank you for joining our interview panel. Details:')}</p>"
			f"<table style='{DETAILS_TABLE}'>{_details_html(doc)}"
			f"<tr><td style='{LABEL_TD}'>{_('Candidate')}</td>"
			f"<td style='{VALUE_TD}'>{frappe.utils.escape_html(applicant_name or doc.job_applicant)}</td></tr></table>"
			+ (f"<p>{_('The candidate resume is attached.')}</p>" if resume else "")
			+ (f"<p>{_('Feedback from all earlier rounds is attached as a PDF.')}</p>" if feedback_pdf else "")
			+ f"<p>{_('After the interview, please share your feedback here - no login needed:')}</p>"
			"<p style='margin:20px 0;'><a href='" + link + "' target='_blank' style='display:inline-block; padding:13px 28px;"
			" border-radius:10px; background-color:#242b66; color:#ffffff; font-size:14px; font-weight:700; text-decoration:none;'>"
			+ _("Submit Interview Feedback") + "</a></p>"
			f"<p style='font-size:13px; color:#8a8ca8;'>{_('The link is personal to you; feedback can be submitted from the interview date.')}</p>"
		)
		try:
			frappe.sendmail(
				recipients=[r.email], cc=sender_cc([r.email]),
				subject=_("Interview Feedback Requested: {0} - {1}").format(applicant_name or doc.job_applicant, doc.interview_round),
				message=company_email(_company(doc), _("Interview Assigned"), message, signoff=True),
				attachments=attachments or None,
				reference_doctype=doc.doctype, reference_name=doc.name, now=True,
			)
		except Exception:
			frappe.log_error(frappe.get_traceback(), "Interview: external interviewer mail failed")
			_drop_smtp_popups()
			frappe.msgprint(_("Could not email {0}. Check the outgoing Email Account.").format(r.email), indicator="orange")
			continue
		frappe.db.set_value("Interview External Interviewer", r.name, "invited_on", frappe.utils.now_datetime())
		frappe.msgprint(_("Feedback link emailed to external interviewer {0}.").format(r.email), indicator="green", alert=True)


def _new_details(fb, seen):
	from olscpl_hrms.events.interview_feedback import detail_items

	out = []
	for field, label, value in detail_items(fb):
		if seen.get(field) == value:
			continue
		out.append(f"{label}: {value}" + (" (updated)" if field in seen else ""))
		seen[field] = value
	return out
