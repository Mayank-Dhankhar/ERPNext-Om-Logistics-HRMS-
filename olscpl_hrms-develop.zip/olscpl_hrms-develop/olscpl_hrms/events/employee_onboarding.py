# olscpl_hrms/events/employee_onboarding.py
#
# Candidate self-service onboarding: document checklist + full personal
# data form + consent form, all living on Employee Onboarding (not Job
# Applicant - Employee Onboarding is the actual hub for the joining
# process, has its own required date_of_joining/boarding_begins_on, and
# is where "Create Employee" already lives natively in stock HRMS).
#
# The candidate never gets desk access. They reach a guest-facing page
# (see olscpl_hrms/www/onboarding_documents.py) via a signed, time-limited
# "portal_access_key" that HR generates and emails from the Job Offer
# form. There is no static/shared token in this design - every candidate
# gets their own key, and it expires.

import frappe
from frappe.utils import add_days, now_datetime, random_string
from olscpl_hrms.utils.email_layout import company_email, rapidshyp_email

PORTAL_LINK_VALID_DAYS = 7

# Static forms bundled with the app (see public/files/onboarding/) that go
# out, unchanged, with every first-time onboarding link email.
STATIC_ONBOARDING_ATTACHMENTS = [
	("Guarantee_Form.pdf", "guarantee_form.pdf"),
	("Medical_Fitness_Certificate.pdf", "medical_fitness_certificate.pdf"),
]


def _sender_details():
	"""Name + phone of whoever is actually clicking "Send Onboarding Link"
	(frappe.session.user), for the email signature - was hardcoded to a
	generic "Om Logistics Recruitment Team" before, so the candidate had no
	way to know who to actually call back. Falls back from the User
	record's own phone/mobile_no to their linked Employee's cell_number
	(HR users are usually Employees too, and that's more likely to be kept
	current)."""
	user = frappe.get_doc("User", frappe.session.user)
	name = user.full_name or user.name

	phone = user.mobile_no or user.phone
	if not phone:
		phone = frappe.db.get_value("Employee", {"user_id": frappe.session.user}, "cell_number")

	return name, phone


def _first_send_attachments(doc):
	"""Letter of Intent (generated per candidate) + the two static forms,
	as frappe.sendmail-style attachment dicts. Any one piece failing to
	build (e.g. PDF generation error) shouldn't block the other two or the
	email itself - logged and skipped instead."""
	attachments = []

	# The Letter of Intent reads salary structure/additional-terms fields
	# straight off Job Offer (see build_letter_of_intent_html) - with no
	# job_offer (the "Send Onboarding Link" button on Job Applicant, sent
	# before any offer exists) there's nothing for it to render, so it's
	# skipped rather than built against blank/missing data.
	if doc.job_offer:
		try:
			from olscpl_hrms.api.letter_of_intent import build_letter_of_intent_pdf

			attachments.append({
				"fname": f"{doc.name}-Letter-of-Intent.pdf",
				"fcontent": build_letter_of_intent_pdf(doc),
			})
		except Exception:
			frappe.log_error(title="Letter of Intent generation failed for onboarding email")

	for fname, relpath in STATIC_ONBOARDING_ATTACHMENTS:
		try:
			path = frappe.get_app_path("olscpl_hrms", "public", "files", "onboarding", relpath)
			with open(path, "rb") as f:
				attachments.append({"fname": fname, "fcontent": f.read()})
		except Exception:
			frappe.log_error(title=f"Could not attach {relpath} to onboarding email")

	return attachments


# A candidate can only upload a signed copy of an offer letter they were
# actually sent - never true for an onboarding started straight from Job
# Applicant (no job_offer, no Letter of Intent ever emailed; see
# _first_send_attachments). The master's own "mandatory" flag still
# governs every Job-Offer-based onboarding, which did send one.
OFFER_LETTER_DOCUMENT_TYPE = "Signed Offer Letter"


def seed_onboarding_children(doc, method=None):
	"""Populate the document checklist and consent-question table from
	their respective masters, once, the first time an Employee Onboarding
	is saved. Never overwrites rows that already exist.

	onboarding_documents.particulars and consent_responses.question_text
	are declared fetch_from in their child doctypes (document_type.
	particulars / question.question) - but fetch_from only actually
	populates via the desk UI's client-side JS trigger, not on a plain
	server-side .save(), which is exactly the path this function runs on.
	Left alone that's a silent null on every row, on every site, the
	first time this seeds - not something that only shows up occasionally.
	Set both explicitly here instead of relying on it."""
	if not doc.get("onboarding_documents"):
		document_types = frappe.get_all(
			"Onboarding Document Type",
			filters={"disabled": 0},
			fields=["name", "mandatory", "particulars"],
			order_by="sort_order asc, document_name asc",
		)
		for dt in document_types:
			mandatory = dt.mandatory
			if dt.name == OFFER_LETTER_DOCUMENT_TYPE and not doc.job_offer:
				mandatory = 0
			doc.append(
				"onboarding_documents",
				{"document_type": dt.name, "mandatory": mandatory, "particulars": dt.particulars},
			)

	if not doc.get("consent_responses"):
		questions = frappe.get_all(
			"Onboarding Consent Question",
			filters={"disabled": 0},
			fields=["name", "question"],
			order_by="sort_order asc",
		)
		for q in questions:
			doc.append("consent_responses", {"question": q.name, "question_text": q.question})


def _joining_dates(offer_date):
	"""(date_of_joining, boarding_begins_on) for an Employee Onboarding from
	its Job Offer's offer_date - shown as "Date of Joining" (Property Setter)
	and mandatory there. Boarding begins a week before joining, but never in
	the past and never after joining."""
	joining = frappe.utils.getdate(offer_date)
	return joining, min(max(add_days(joining, -7), frappe.utils.getdate()), joining)


def sync_joining_date_from_offer(doc, method=None):
	"""Job Offer on_update: the Job Offer is the one place HR sets the joining
	date, so carry a change over to its draft Employee Onboarding - otherwise
	the Letter of Intent (which reads the onboarding) keeps the old date."""
	if not doc.offer_date or not doc.has_value_changed("offer_date"):
		return
	joining, begins = _joining_dates(doc.offer_date)
	for name in frappe.get_all(
		"Employee Onboarding", filters={"job_offer": doc.name, "docstatus": 0}, pluck="name"
	):
		frappe.db.set_value(
			"Employee Onboarding", name, {"date_of_joining": joining, "boarding_begins_on": begins}
		)


@frappe.whitelist()
def get_or_create_for_offer(job_offer: str) -> str:
	"""Return the name of the Employee Onboarding record for this Job
	Offer, creating a draft one if none exists yet. Called from the "Send
	Onboarding Link" button on Job Offer - HR shouldn't have to fill in
	date_of_joining/boarding_begins_on just to issue a document-collection
	link - both come from the Job Offer's Date of Joining (offer_date), and
	stay in sync with it (sync_joining_date_from_offer).
	"""
	if frappe.session.user == "Guest":
		frappe.throw(frappe._("Not permitted"), frappe.PermissionError)

	offer = frappe.get_doc("Job Offer", job_offer)
	offer.check_permission("read")

	existing = frappe.db.get_value(
		"Employee Onboarding", {"job_offer": job_offer, "docstatus": ["!=", 2]}, "name"
	)
	if existing:
		return existing

	doc = frappe.new_doc("Employee Onboarding")
	doc.job_applicant = offer.job_applicant
	doc.job_offer = job_offer
	doc.employee_name = offer.applicant_name
	doc.company = offer.company
	doc.date_of_joining, doc.boarding_begins_on = _joining_dates(offer.offer_date)
	# the offer's designation (what HR set) wins; the applicant's is a fallback
	doc.designation = offer.designation or (
		frappe.db.get_value("Job Applicant", offer.job_applicant, "designation") if offer.job_applicant else None
	)
	doc.insert(ignore_permissions=True)
	frappe.db.commit()
	return doc.name


@frappe.whitelist()
def get_or_create_for_applicant(job_applicant: str) -> str:
	"""Same as get_or_create_for_offer, but for the "Send Onboarding Link"
	button on Job Applicant - a new requirement to let HR send the
	onboarding link straight from the application, before any Job Offer
	exists. job_offer is left unset on the resulting doc, which is what
	_first_send_attachments() uses to skip the Letter of Intent PDF (it
	can only render from a Job Offer's own salary-structure fields).

	Job Applicant has no joining-date field to seed date_of_joining/
	boarding_begins_on from (Job Offer's offer_date does that for
	get_or_create_for_offer) - neither is shown in the onboarding email
	itself, so a 15-day-out placeholder is used; HR can correct it on the
	Employee Onboarding record same as any other field.
	"""
	if frappe.session.user == "Guest":
		frappe.throw(frappe._("Not permitted"), frappe.PermissionError)

	applicant = frappe.get_doc("Job Applicant", job_applicant)
	applicant.check_permission("read")

	existing = frappe.db.get_value(
		"Employee Onboarding", {"job_applicant": job_applicant, "docstatus": ["!=", 2]}, "name"
	)
	if existing:
		return existing

	doc = frappe.new_doc("Employee Onboarding")
	doc.job_applicant = job_applicant
	doc.employee_name = applicant.applicant_name
	doc.company = applicant.get("custom_company")
	doc.designation = applicant.designation
	doc.date_of_joining, doc.boarding_begins_on = _joining_dates(add_days(frappe.utils.getdate(), 15))
	doc.insert(ignore_permissions=True)
	frappe.db.commit()
	return doc.name


@frappe.whitelist()
def generate_portal_link(employee_onboarding: str) -> dict:
	"""Issue (or re-issue) a candidate's onboarding portal link.

	Whitelisted to logged-in users only; Frappe's own doctype permission
	check on Employee Onboarding (write) gates who may call this - no
	hardcoded employee-code list the way the old portal had one.
	"""
	if frappe.session.user == "Guest":
		frappe.throw(frappe._("Not permitted"), frappe.PermissionError)

	doc = frappe.get_doc("Employee Onboarding", employee_onboarding)
	doc.check_permission("write")

	seed_onboarding_children(doc)

	doc.portal_access_key = random_string(48)
	doc.portal_link_sent_on = now_datetime()
	doc.portal_link_expires_on = add_days(now_datetime(), PORTAL_LINK_VALID_DAYS)
	doc.portal_link_sent_by = frappe.session.user
	doc.save(ignore_permissions=True)
	# Commit before attempting the email so the new key is durable even if
	# the site has no outgoing Email Account configured (common on dev/test
	# sites) - a broken mail server should not silently roll back the link
	# that was just issued.
	frappe.db.commit()

	portal_url = frappe.utils.get_url(f"/onboarding-documents?key={doc.portal_access_key}")

	candidate_email = doc.candidate_email
	if not candidate_email and doc.job_applicant:
		candidate_email = frappe.db.get_value("Job Applicant", doc.job_applicant, "email_id")

	sender_name, sender_phone = _sender_details()

	email_sent = False
	if candidate_email:
		context = {
			"applicant_name": doc.employee_name,
			"designation": doc.designation,
			"portal_url": portal_url,
			"expires_on": frappe.utils.format_datetime(doc.portal_link_expires_on, "d MMM yyyy"),
			"correction_notes": doc.hr_change_request_notes,
			"sender_name": sender_name,
			"sender_phone": sender_phone,
		}
		attachments = []
		plain = False
		if doc.hr_change_request_notes:
			message = frappe.render_template(
				(
					"<p>Hi {{ applicant_name }},</p>"
					"<p>A few things need to be corrected on your onboarding submission:</p>"
					"<blockquote>{{ correction_notes }}</blockquote>"
					"<p>Please update them here: <a href='{{ portal_url }}'>{{ portal_url }}</a></p>"
					"<p>This link is valid until {{ expires_on }}.</p>"
				),
				context,
			)
			subject = frappe._("Action needed: update your onboarding details")
		else:
			# First-time send only - the Letter of Intent, Guarantee Form and
			# Medical Fitness Certificate go out once, alongside the portal
			# link, not on every "request changes" re-send.
			message = frappe.render_template(
				(
					"<p>Dear {{ applicant_name }},</p>"
					"<p>Thank you for accepting our offer for the position of <b>{{ designation }}</b>."
					" We look forward to welcoming you on board. Please find attached your offer letter"
					" along with the forms required for submission upon joining at our Corporate Office.</p>"
					"<p><b>Next step:</b> please complete the online documentation process before your"
					" joining:</p>"
					"<p style='margin:20px 0;'><a href='{{ portal_url }}' target='_blank' style='display:inline-block;"
					" padding:13px 28px; border-radius:10px; background-color:#242b66; color:#ffffff;"
					" font-size:14px; font-weight:700; text-decoration:none;'>Complete Onboarding Documents</a></p>"
					"<p style='font-size:13px; color:#8a8ca8;'>This link is valid until {{ expires_on }}.</p>"
					"<p>The following two documents must be submitted as per the specified guidelines:</p>"
					"<p>1) Medical Form &ndash; To be completed and stamped by a Government or"
					" MBBS-certified doctor.</p>"
					"<p>2) Guarantee Form &ndash; To be filled out by a Government Authority with the"
					" following conditions:</p>"
					"<p>.The guarantor must not be retired from service.<br>"
					".The guarantor should not be from the defence forces, a fourth-class employee, an"
					" advocate, or fall under any restricted category.</p>"
					"<p>For any queries or further clarifications, please do not hesitate to reach out.</p>"
					"<p>--<br>"
					"Thanks and Regards,<br>"
					"{{ sender_name }}<br>"
					"Om Logistics Ltd.<br>"
					"130 | Transport Center| Punjabi Bagh | New Delhi |110035"
					"{% if sender_phone %}<br>Tel: {{ sender_phone }}{% endif %}</p>"
				),
				context,
			)
			subject = frappe._("Onboarding Documentation Required")
			from olscpl_hrms.api import rapidshyp

			if rapidshyp.is_rapidshyp(doc.company):
				# RapidShyp: its own plain joining mail, link only - no attachments
				subject, message = rapidshyp.onboarding_email(doc, portal_url)
				plain = True
			else:
				attachments = _first_send_attachments(doc)

		# CC whoever actually clicked "Send Onboarding Link" (frappe.session.
		# user - same person _sender_details() above signs the email as) so
		# they get a copy in their own inbox, e.g. to forward or reference
		# later - not "Administrator" or any other non-email session user,
		# which would just bounce.
		cc = [frappe.session.user] if "@" in frappe.session.user else None

		try:
			frappe.sendmail(
				recipients=[candidate_email], cc=cc, subject=subject,
				message=rapidshyp_email(frappe._("Onboarding Documentation"), message) if plain else company_email(
					doc.company,
					frappe._("Onboarding Corrections Needed") if doc.hr_change_request_notes
					else frappe._("Onboarding Documentation"),
					message,
				),
				attachments=attachments, now=True,
			)
			email_sent = True
		except Exception:
			frappe.log_error(title="Onboarding portal link email failed")

	return {
		"portal_url": portal_url,
		"expires_on": doc.portal_link_expires_on,
		"email_sent": email_sent,
	}


@frappe.whitelist()
def request_changes(employee_onboarding: str, notes: str) -> dict:
	"""HR flags what's wrong/missing and re-sends the link. The guest page
	shows `notes` as a banner and pre-fills every field with whatever the
	candidate already submitted (nothing is cleared) - see get_application_data.
	"""
	if frappe.session.user == "Guest":
		frappe.throw(frappe._("Not permitted"), frappe.PermissionError)

	doc = frappe.get_doc("Employee Onboarding", employee_onboarding)
	doc.check_permission("write")

	doc.hr_change_request_notes = notes
	# Re-opens the mandatory-documents-complete gate so a candidate who's
	# asked to swap out one document doesn't get silently skipped from a
	# future completion notification.
	doc.portal_documents_completed_on = None
	doc.save(ignore_permissions=True)
	# Clears the submitted lock (see olscpl_hrms.api.onboarding_portal.
	# _ensure_editable) - a submitted application is otherwise frozen, so
	# this is what actually lets the candidate edit anything again.
	doc.db_set("portal_submitted_on", None, update_modified=False)
	frappe.db.commit()

	return generate_portal_link(employee_onboarding)


@frappe.whitelist()
def save_my_signature(signature: str) -> None:
	"""Called from the "sign before sending" gate (see public/js/
	signature_gate.js) - saves straight to the calling user's own User
	record, not exposed for any other doctype/user, so no extra
	permission check is needed beyond "is actually logged in"."""
	if frappe.session.user == "Guest":
		frappe.throw(frappe._("Not permitted"), frappe.PermissionError)
	# Attach Image upload - only accept a file on this site, never an
	# arbitrary URL that PDF rendering (wkhtmltopdf) would go and fetch.
	if not (signature or "").startswith(("/files/", "/private/files/")):
		frappe.throw(frappe._("Please upload your signature as an image file."))

	frappe.db.set_value("User", frappe.session.user, "custom_signature_image", signature, update_modified=False)
	frappe.db.commit()


HR_VIEW_ROLES = {"HR Manager", "System Manager"}


def get_onboarding_by_key(key: str, allow_hr_view: bool = False):
	"""Resolve a portal access key to a live (non-expired) Employee
	Onboarding, or None. Used by the guest-facing page and its endpoints.

	allow_hr_view: only the *candidate's* link is meant to expire. HR's
	"View Submission" button opens this same page with the same key, so it
	must keep working for a logged-in HR Manager / System Manager after the
	candidate's window has passed. Passed by read-only callers only (the
	page itself, get_application_data, get_document_file); every endpoint
	that writes still requires an unexpired key."""
	if not key:
		return None

	name = frappe.db.get_value("Employee Onboarding", {"portal_access_key": key}, "name")
	if not name:
		return None

	doc = frappe.get_doc("Employee Onboarding", name)
	expired = not doc.portal_link_expires_on or now_datetime() > doc.portal_link_expires_on
	if expired and not (allow_hr_view and HR_VIEW_ROLES & set(frappe.get_roles())):
		return None

	return doc


def notify_hr_if_documents_complete(employee_onboarding: str):
	"""Called after every guest document upload. Just marks when every
	*mandatory* checklist row is submitted - idempotent via
	portal_documents_completed_on, which request_changes() resets to
	reopen the gate if HR sends something back.

	This used to also notify HR the moment documents were complete, but
	that fired before the candidate had actually confirmed they were
	done (documents could be complete a while before the candidate
	finishes reviewing the rest of the form). HR notification now
	happens once, at the point that actually means "the candidate is
	done" - see olscpl_hrms.api.onboarding_portal.final_submit(),
	triggered by the candidate's own explicit Save & Submit + confirm.
	"""
	doc = frappe.get_doc("Employee Onboarding", employee_onboarding)
	if doc.get("portal_documents_completed_on"):
		return

	rows = doc.get("onboarding_documents") or []
	mandatory_rows = [r for r in rows if r.mandatory]
	if not mandatory_rows or not all(r.candidate_submitted for r in mandatory_rows):
		return

	doc.db_set("portal_documents_completed_on", now_datetime(), update_modified=False)

	frappe.db.commit()


def clear_checklist_row_on_file_delete(doc, method=None):
	"""File.on_trash - doc here is the File being deleted, not the Employee
	Onboarding. Whoever removes an attachment (the Desk sidebar's own "x",
	a script, anything) deletes the File doc directly - nothing about that
	touches the Document Checklist row that pointed at it, so without
	this, the row (and everything downstream that reads it: the "Submitted"
	badge on this form, the candidate's own portal page) kept showing the
	document as submitted with a link to a file that no longer exists.
	This puts the row back to a genuine, honest "Pending" the moment the
	file is actually gone, instead of only whenever someone happens to
	notice and fix it by hand."""
	if doc.attached_to_doctype != "Employee Onboarding" or not doc.attached_to_name:
		return
	# Deleting the onboarding itself removes it first and its attachments
	# after - nothing left to update then, and loading it would throw and
	# block that whole delete.
	if not frappe.db.exists("Employee Onboarding", doc.attached_to_name):
		return

	onboarding = frappe.get_doc("Employee Onboarding", doc.attached_to_name)
	changed = False
	for row in onboarding.get("onboarding_documents") or []:
		if row.file == doc.file_url:
			row.file = None
			row.candidate_submitted = 0
			row.hr_received = 0
			row.hr_received_by = None
			row.hr_received_on = None
			changed = True

	if changed:
		onboarding.save(ignore_permissions=True)
		# Reflects back in notify_hr_if_documents_complete's own gate - a
		# document that just got un-submitted means the checklist is no
		# longer actually complete, even if it was a moment ago.
		if onboarding.get("portal_documents_completed_on"):
			onboarding.db_set("portal_documents_completed_on", None, update_modified=False)
		frappe.db.commit()
