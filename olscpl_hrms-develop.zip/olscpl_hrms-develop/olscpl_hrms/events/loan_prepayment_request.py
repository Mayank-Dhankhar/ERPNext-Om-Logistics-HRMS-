from olscpl_hrms.events.loan_prepayment_request_steps import (
	snapshot_outstanding_balance,
	process_prepayment_on_approval,
)


def validate(doc, method=None):
	snapshot_outstanding_balance(doc, method)


def on_update(doc, method=None):
	process_prepayment_on_approval(doc, method)
	
    