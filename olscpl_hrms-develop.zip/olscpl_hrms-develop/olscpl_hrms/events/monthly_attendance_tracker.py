import frappe


def validate_uniqueness(doc, method=None):
    """was Server Script: Employee Existence Validation
    Before Validate on Monthly Attendance Tracker"""
    existing = frappe.db.exists(
        "Monthly Attendance Tracker",
        {
            "employee": doc.employee,
            "month": doc.month,
            "year": doc.year,
            "name": ["!=", doc.name]
        }
    )
    if existing:
        frappe.throw(
            "Attendance Tracker already exists for this Employee, Month, and Year."
        )