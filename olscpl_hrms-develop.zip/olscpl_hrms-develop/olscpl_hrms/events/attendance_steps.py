from datetime import datetime as _dt, time as _dtime, timedelta

import frappe
from frappe.utils import get_datetime, getdate
from olscpl_hrms.events.attendance_utils import (
    has_sufficient_hours,
    is_in_late_coming_range,
    has_sufficient_balance,
    decimal_to_hhmm,
    is_weekly_off,
    get_employee_info,
    get_shift_type_info,
    get_payroll_cycle_config,
    get_holiday,
    calc_work_metrics,
    get_payroll_month_year,
)

EXCLUDED_SHIFTS = [
    "IT DEPARTMENT SHIFT",
    "HEAD OFFICE COMMON SHIFT"
]

# BRANCH: Shift Type name (upper-case) used for Branch Employee attendance.
BRANCH_SHIFT = "BRANCH SHIFT"


def resolve_shift_policy(doc):
    """was Server Script: 010 SHIFT POLICY RESOLVER
    Before Save on Attendance. Must run BEFORE process_daily_attendance."""

    # Guard added Sep 30, 2026: validate() (and therefore this function)
    # runs again on submit(), not just insert() - bulk_backfill_attendance
    # calls doc.insert() then doc.submit() on the SAME doc object.
    # process_daily_attendance() already guards itself with
    # custom_calculation_done so it only computes once, but this function
    # had no such guard and was unconditionally resetting
    # custom_shift_name/custom_shift_start_time back to the raw
    # Shift-Assignment-resolved values on that second pass - silently
    # undoing the night-shift auto-detect override process_daily_
    # attendance() applied during the first pass (insert), since that
    # function's own guard then prevents it from ever running again to
    # re-apply the override. Once the day's calculation is done, this
    # function has nothing left to resolve.
    if doc.get("custom_calculation_done"):
        return

    doc.custom_shift_start_time = "09:00:00"
    doc.custom_grace_period_mins = 70
    doc.custom_late_coming_end_mins = 90
    doc.custom_short_leave_end_mins = 180
    doc.custom_shift_name = "Default"

    # Transient (not a stored docfield) - whether the resolved shift is
    # expected to cross midnight, e.g. Shift Type start_time=21:00,
    # end_time=09:00. Read by process_daily_attendance() below, in the
    # same request, to correct an OUT punch whose timestamp lands on the
    # same calendar date as the IN punch (or fails to widen the checkin
    # lookup to the next day) - see "Night shift crossing midnight" fix,
    # Sep 30, 2026.
    doc._shift_is_overnight = False
    # True only when NO real shift config exists for this employee at all
    # (no Shift Assignment for the date AND no usable Employee.default_shift)
    # - i.e. exactly the case that logs "No Shift Assignment found" below.
    doc._shift_is_fallback_default = False

    # PERF: cached lookup (was an uncached get_value per record)
    employee = get_employee_info(doc.employee)

    employee_shift = ""
    if employee and employee.default_shift:
        employee_shift = str(employee.default_shift).strip().upper()

    if employee_shift in EXCLUDED_SHIFTS:
        if employee_shift == "IT DEPARTMENT SHIFT":
            doc.custom_required_work_hours = 9.0
        else:
            doc.custom_required_work_hours = 8.5

    else:
        shift_info = frappe.db.sql("""
            SELECT
                esa.shift_type,
                st.start_time,
                st.end_time,
                COALESCE(st.custom_grace_period_mins_from_start, 70) as grace_mins,
                COALESCE(st.custom_late_coming_window_end_mins, 90) as late_coming_mins,
                COALESCE(st.custom_short_leave_window_end_mins, 180) as short_leave_mins,
                COALESCE(st.custom_required_work_hours, 9.0) as req_hours
            FROM `tabShift Assignment` esa
            JOIN `tabShift Type` st
                ON st.name = esa.shift_type
            WHERE esa.employee = %s
              AND esa.start_date <= %s
              AND esa.end_date >= %s
              AND esa.docstatus < 2
            ORDER BY esa.start_date DESC
            LIMIT 1
        """, (
            doc.employee,
            doc.attendance_date,
            doc.attendance_date
        ), as_dict=True)

        if shift_info:
            s = shift_info[0]
            st_seconds = 0

            if s.start_time:
                try:
                    st_seconds = int(s.start_time.total_seconds())
                except Exception:
                    parts = str(s.start_time).split(":")
                    st_seconds = (int(parts[0]) * 3600 + int(parts[1]) * 60)

            sh = st_seconds // 3600
            sm = (st_seconds % 3600) // 60
            ss = st_seconds % 60

            start_str = (
                str(sh).zfill(2) + ":" + str(sm).zfill(2) + ":" + str(ss).zfill(2)
            )

            doc.custom_shift_start_time = start_str

            if s.end_time:
                try:
                    en_seconds = int(s.end_time.total_seconds())
                except Exception:
                    eparts = str(s.end_time).split(":")
                    en_seconds = (int(eparts[0]) * 3600 + int(eparts[1]) * 60)
                # end_time <= start_time (e.g. 09:00 end vs 21:00 start)
                # means the shift is defined to run past midnight.
                doc._shift_is_overnight = en_seconds <= st_seconds

            doc.custom_grace_period_mins = int(s.grace_mins)
            doc.custom_late_coming_end_mins = int(s.late_coming_mins)
            doc.custom_short_leave_end_mins = int(s.short_leave_mins)
            doc.custom_required_work_hours = float(s.req_hours)
            doc.custom_shift_name = str(s.shift_type)

        else:
            # FALLBACK TO EMPLOYEE DEFAULT SHIFT
            if employee and employee.default_shift:
                default_shift = get_shift_type_info(employee.default_shift)

                if default_shift:
                    st_seconds = 0
                    if default_shift.start_time:
                        try:
                            st_seconds = int(default_shift.start_time.total_seconds())
                        except Exception:
                            parts = str(default_shift.start_time).split(":")
                            st_seconds = (int(parts[0]) * 3600 + int(parts[1]) * 60)

                    sh = st_seconds // 3600
                    sm = (st_seconds % 3600) // 60
                    ss = st_seconds % 60

                    doc.custom_shift_start_time = (
                        str(sh).zfill(2) + ":" + str(sm).zfill(2) + ":" + str(ss).zfill(2)
                    )

                    if default_shift.end_time:
                        try:
                            en_seconds = int(default_shift.end_time.total_seconds())
                        except Exception:
                            eparts = str(default_shift.end_time).split(":")
                            en_seconds = (int(eparts[0]) * 3600 + int(eparts[1]) * 60)
                        doc._shift_is_overnight = en_seconds <= st_seconds

                    doc.custom_grace_period_mins = int(
                        default_shift.custom_grace_period_mins_from_start or 70
                    )
                    doc.custom_late_coming_end_mins = int(
                        default_shift.custom_late_coming_window_end_mins or 90
                    )
                    doc.custom_short_leave_end_mins = int(
                        default_shift.custom_short_leave_window_end_mins or 180
                    )
                    doc.custom_required_work_hours = float(
                        default_shift.custom_required_work_hours or 8.5
                    )
                    doc.custom_shift_name = employee.default_shift

                else:
                    doc.custom_shift_start_time = "09:00:00"
                    doc.custom_grace_period_mins = 70
                    doc.custom_late_coming_end_mins = 90
                    doc.custom_short_leave_end_mins = 180
                    doc.custom_required_work_hours = 8.5
                    doc.custom_shift_name = "Default"
                    doc._shift_is_fallback_default = True

            else:
                doc.custom_shift_start_time = "09:00:00"
                doc.custom_grace_period_mins = 70
                doc.custom_late_coming_end_mins = 90
                doc.custom_short_leave_end_mins = 180
                doc.custom_required_work_hours = 8.5
                doc.custom_shift_name = "Default"
                doc._shift_is_fallback_default = True

            # PERF: was frappe.log_error() - one Error Log INSERT per record
            # frappe.logger("olscpl_hrms").debug(
            #     "No Shift Assignment found. Using "
            #     + str(doc.custom_shift_name)
            #     + " for "
            #     + str(doc.employee)
            # )

    # BRANCH: whichever way the shift was resolved (Shift Assignment or
    # Employee default_shift), Branch Shift always requires 9 working hours.
    if str(doc.custom_shift_name or "").strip().upper() == BRANCH_SHIFT:
        doc.custom_required_work_hours = 9.0


def reconcile_half_day_visit_with_punches(doc):
    """Handles the reverse order of events/visit.py's own half-day merge
    (that one handles punch-first-then-Visit-approved; this handles
    Visit-approved-first-then-punched): a First/Second Half Visit whose
    Attendance record was created before the employee had punched in for
    the day. process_daily_attendance() below skips entirely once
    status == "Visit" (see its own guard), so it would never notice a
    later punch on its own.

    Runs the REAL, unmodified resolve_shift_policy()/process_daily_
    attendance() - the same grace period, late coming, short leave,
    shift-specific hour thresholds and Saturday rules a genuine
    punch-based Half Day/Present/Absent determination already goes
    through - on a throwaway in-memory trial copy (never inserted, so
    nothing about the real Visit-derived Attendance record is touched
    by running it) to find out what the OTHER half's punches alone would
    have produced. Deliberately does NOT take a shortcut like "does any
    checkin exist" or "is there a completed IN+OUT session" - those
    don't apply the same 8.5hr/grace-period/late-coming rules a real
    Half Day determination does, so they could both under- and
    over-count what should be a straightforward Half Day evaluation."""
    if doc.status != "Visit" or doc.get("custom_visit_day_portion") not in ("First Half", "Second Half"):
        return

    trial = frappe.get_doc({
        "doctype": "Attendance",
        "employee": doc.employee,
        "attendance_date": doc.attendance_date,
        "status": "",
        "custom_calculation_done": 0,
        "attendance_request": doc.get("attendance_request"),
    })
    resolve_shift_policy(trial)
    process_daily_attendance(trial)

    if trial.status in ("Present", "Half Day"):
        # the other half was genuinely worked (by the same rules any
        # other Attendance record would be judged by) - combined with
        # the already-approved half-day Visit, the whole day is now
        # accounted for.
        doc.custom_visit_day_portion = "Full Day"
    elif trial.status in ("Week Off", "Holiday"):
        # a Week Off/Holiday for this date overrides the Visit entirely,
        # same precedence Attendance would give it on its own.
        doc.status = trial.status
        doc.custom_status_detail = trial.get("custom_status_detail")
        doc.custom_visit_day_portion = None
    # else (Absent / no valid punches): stays exactly the half-day Visit
    # it already was - nothing to merge.


def process_daily_attendance(doc):
    """was Server Script: Process Daily Attendance
    Before Save on Attendance. Must run AFTER resolve_shift_policy."""

    if doc.custom_calculation_done:
        return
    if doc.attendance_request:
        return
    if doc.status in ["On Leave", "Holiday", "Work From Home", "Week Off", "Visit"]:
        return
    if not (doc.employee and doc.attendance_date):
        return

    # Punch lookup moved ahead of the weekly-off check below (it used to run
    # after) - Comp Off is earned by actually working on a day off, and its
    # own validate() (olscpl_hrms/api/compensatory_leave.py) requires a
    # submitted Present/WFH/Half Day Attendance for that date. The weekly-off
    # check must know whether the employee has real check-in punches before
    # it decides to force "Week Off", the same way the holiday check further
    # below already guards itself with `and not first_in` - otherwise an
    # employee who genuinely punched in and worked their fixed weekly off day
    # could never get a Present attendance record for it, making Comp Off
    # impossible to earn for anyone with a fixed weekly off.
    first_in = None
    last_out = None

    if doc.custom_check_in_time and doc.custom_check_out_time:
        first_in = doc.custom_check_in_time
        last_out = doc.custom_check_out_time
    else:
        # PERF: ONE sargable range query for first IN + same-day last OUT
        # (was DATE(time) = %s, which cannot use an index, run twice).
        _day_start = _dt.combine(getdate(doc.attendance_date), _dtime.min)
        _day_end = _day_start + timedelta(days=1)
        punch_row = frappe.db.sql("""
            SELECT
                MIN(CASE WHEN log_type = 'IN'  THEN time END) AS first_in,
                MAX(CASE WHEN log_type = 'OUT' THEN time END) AS same_day_out
            FROM `tabEmployee Checkin`
            WHERE employee = %s
              AND time >= %s
              AND time <  %s
              AND custom_custom_geo_validation = 'Valid'
        """, (doc.employee, _day_start, _day_end), as_dict=True)

        if punch_row and punch_row[0].first_in:
            first_in = punch_row[0].first_in

            # Same-day MAX(OUT) first - this is EXACTLY the original
            # query's behaviour (unchanged for every normal day-shift
            # record, including multiple same-day OUT punches e.g. a
            # lunch break: the LATEST one still wins, same as before).
            same_day_out = punch_row[0].same_day_out

            if same_day_out and same_day_out >= first_in:
                # Normal case - identical to pre-fix behaviour.
                last_out = same_day_out
            else:
                # Night-shift fix (Sep 30, 2026): either there's no
                # same-day OUT at all (a shift that runs past midnight
                # has its OUT punch on the NEXT calendar date, invisible
                # to the query above), or there IS one but its clock time
                # is before first_in - the OUT punch was mis-stamped with
                # the SAME date as the IN punch instead of the next day
                # (this is what produced the negative-hours "Insufficient
                # Working Hours" bug on a shift the employee actually
                # worked in full). Only in these two cases, widen the
                # search to a 20-hour window after first_in and take the
                # first OUT punch found there - same-day multi-punch
                # shifts never reach this branch.
                widened_row = frappe.db.sql("""
                    SELECT MIN(time) AS last_out
                    FROM `tabEmployee Checkin`
                    WHERE employee = %s
                      AND log_type = 'OUT'
                      AND custom_custom_geo_validation = 'Valid'
                      AND time > %s
                      AND time <= DATE_ADD(%s, INTERVAL 20 HOUR)
                """, (doc.employee, first_in, first_in), as_dict=True)

                if widened_row and widened_row[0].last_out:
                    last_out = widened_row[0].last_out
                elif same_day_out:
                    # Nothing found beyond first_in either, but there was
                    # a mis-stamped same-day OUT - treat it as the next
                    # calendar day rather than leaving it negative below.
                    last_out = same_day_out + timedelta(days=1)

    doc.custom_check_in_time = first_in
    doc.custom_check_out_time = last_out

    # --- Week Off check, must run before holiday logic - only forces the
    # status when there's no real check-in that day; a genuine punch takes
    # precedence and falls through to the normal working-hours calculation
    # below, same as the holiday branch does. ---
    if is_weekly_off(doc.employee, doc.attendance_date) and not first_in:
        doc.status = "Week Off"
        doc.custom_status_detail = "Weekly Off"
        doc.custom_calculation_done = 1
        return
    # --- end weekly-off block ---

    # PERF: read once per request instead of once per record
    cycle_start_day, cycle_end_day, use_custom_cycle = get_payroll_cycle_config()

    emp_info = get_employee_info(doc.employee)
    holiday = get_holiday(emp_info.get("holiday_list"), doc.attendance_date)

    if holiday and not first_in:
        holiday_desc = holiday.description

        if "Saturday" in holiday_desc:
            doc.status = "Week Off"
            doc.custom_status_detail = "W/O"
        elif "Sunday" in holiday_desc:
            doc.status = "Week Off"
            doc.custom_status_detail = "Sunday"
        else:
            doc.status = "Holiday"
            doc.custom_status_detail = holiday_desc

        doc.custom_calculation_done = 1
        return

    if not first_in:
        doc.status = "Absent"
        doc.custom_status_detail = "No valid check-ins found"
        doc.custom_calculation_done = 1
        return

    if not last_out:
        doc.status = "Absent"
        doc.custom_status_detail = "No check-out yet"
        doc.custom_calculation_done = 1
        return

    # BRANCH: resolved shift is Branch Shift (from Shift Assignment, or the
    # Employee Master default_shift when no assignment covers the date).
    # Must be evaluated BEFORE the night-shift auto-detect below, because
    # that block overwrites doc.custom_shift_name with
    # "Night Shift (Auto-Detected)". The auto-detect itself is untouched.
    is_branch = str(doc.custom_shift_name or "").strip().upper() == BRANCH_SHIFT

    if first_in and not doc.get("_shift_is_overnight"):
        # Broadened Sep 30, 2026 (was: only when NO shift config existed
        # at all). Turns out HR sometimes DOES create a Shift Assignment
        # for a night-shift employee - just pointing it at a plain,
        # day-anchored Shift Type (commonly one literally named
        # "Default", 09:00 start) rather than a real night shift. That
        # employee has _shift_is_fallback_default == False (a real
        # Shift Assignment/default_shift WAS resolved), so the narrower
        # check missed them entirely: working hours already compute
        # correctly (see the OUT-pairing fix above), but punch_category
        # below is still bucketed against a 09:00 anchor, and any first
        # punch past 14:00 unconditionally lands in "full_absent" ->
        # Absent / "Punch After 2 PM", REGARDLESS of hours worked (that
        # branch only runs once working_hours is already >= 6.5h - i.e.
        # a full shift). The only real signal that a shift is genuinely
        # night/overnight-aware is _shift_is_overnight (set from Shift
        # Type start_time/end_time in resolve_shift_policy()) - so re-
        # anchor whenever that's NOT true and the actual first punch is
        # after 6 PM, whether or not a Shift Assignment happened to
        # exist. Grace/late-coming/short-leave window LENGTHS stay the
        # same defaults - only the anchor moves - so a genuinely on-time
        # night-shift check-in isn't miscategorised as ~12 hours late
        # for a day shift it was never actually working.
        first_in_dt = get_datetime(first_in)
        if first_in_dt.hour >= 18:
            doc.custom_shift_name = "Night Shift (Auto-Detected)"
            doc.custom_shift_start_time = first_in_dt.strftime("%H:%M:%S")
            doc._shift_is_overnight = True

    if last_out and first_in and last_out < first_in:
        # Belt-and-braces: whatever produced last_out (including data fed
        # in directly via doc.custom_check_in_time/custom_check_out_time
        # at the top of this function), a checkout timestamped earlier
        # than the checkin can only mean it actually happened the next
        # calendar day.
        last_out = last_out + timedelta(days=1)

    doc.custom_check_in_time = first_in
    doc.custom_check_out_time = last_out

    # PERF: was a SELECT round-trip that only did date arithmetic
    working_hours, punch_hour, punch_minute, is_saturday, day_of_month = (
        calc_work_metrics(first_in, last_out, doc.attendance_date)
    )
    punch_minutes = punch_hour * 60 + punch_minute

    doc.working_hours = round(working_hours, 2)

    # PERF: was 1 SELECT round-trip that only did date arithmetic
    payroll_month, payroll_year = get_payroll_month_year(
        doc.attendance_date, use_custom_cycle, cycle_start_day
    )

    tracker = frappe.db.get_value(
        "Monthly Attendance Tracker",
        {"employee": doc.employee, "month": payroll_month, "year": payroll_year},
        ["name", "remaining_late_coming", "remaining_short_leave_hours"],
        as_dict=True
    )

    if not tracker:
        new_tracker = frappe.get_doc({
            "doctype": "Monthly Attendance Tracker",
            "employee": doc.employee,
            "month": payroll_month,
            "year": payroll_year,
            "total_late_coming": 0,
            "total_short_leave_hours": 0,
            "remaining_late_coming": 4,
            "remaining_short_leave_hours": 4,
            "half_day_deductions": 0,
            "total_present_days": 0,
            "total_absent_days": 0
        })
        new_tracker.insert(ignore_permissions=True)
        tracker = {"remaining_late_coming": 4, "remaining_short_leave_hours": 4.0}

    remaining_late_coming = tracker.get("remaining_late_coming", 4)
    remaining_short_leave = tracker.get("remaining_short_leave_hours", 4.0)

    # PERF: was frappe.get_doc("Employee") - loads all child tables just
    # to read default_shift
    shift_name = (emp_info.get("default_shift") or "").strip().upper()

    if is_branch:  # BRANCH: fixed 9h every day (incl. Saturday)
        required_hours = 9.0
    elif is_saturday:
        required_hours = 5.833
    elif shift_name == "IT DEPARTMENT SHIFT":
        required_hours = 9.0
    elif shift_name == "HEAD OFFICE COMMON SHIFT":
        required_hours = 8.5
    elif doc.custom_required_work_hours:
        required_hours = float(doc.custom_required_work_hours)
    else:
        required_hours = 8.5

    employee_shift = shift_name

    # Night-shift fix (Sep 30, 2026): EXCLUDED_SHIFTS ("IT Department
    # Shift" / "Head Office Common Shift") use hardcoded literal minute
    # cutoffs below (610/630/720/840 - the same 09:00-anchored windows as
    # everyone else, just baked in as numbers) that never read
    # doc.custom_shift_start_time at all. That bypasses the auto-detected
    # night-shift re-anchor above entirely: an employee whose
    # Employee.default_shift happens to BE one of these two legacy shifts
    # but who was just re-anchored to a real ~21:00 punch time would still
    # get bucketed against a phantom 09:00+2h cutoff here, landing in
    # "full_absent" regardless. Route them through the dynamic (doc.
    # custom_shift_start_time-based) branch instead whenever
    # _shift_is_overnight is true, exactly like every other shift.
    if employee_shift in EXCLUDED_SHIFTS and not doc.get("_shift_is_overnight"):
        if punch_minutes <= 610:
            punch_category = "grace"
        elif punch_minutes <= 630:
            punch_category = "late_coming"
        elif punch_minutes <= 720:
            punch_category = "short_leave"
        elif punch_minutes <= 840:
            punch_category = "first_half_absent"
        else:
            punch_category = "full_absent"
    else:
        shift_start_str = doc.custom_shift_start_time or "09:00:00"
        sparts = shift_start_str.split(":")
        shift_hour = int(sparts[0])
        shift_minute = int(sparts[1])
        shift_start_minutes = (shift_hour * 60) + shift_minute

        grace_limit = shift_start_minutes + int(doc.custom_grace_period_mins or 70)
        late_limit = shift_start_minutes + int(doc.custom_late_coming_end_mins or 90)
        short_leave_limit = shift_start_minutes + int(doc.custom_short_leave_end_mins or 180)
        first_half_limit = shift_start_minutes + 300

        if punch_minutes <= grace_limit:
            punch_category = "grace"
        elif punch_minutes <= late_limit:
            punch_category = "late_coming"
        elif punch_minutes <= short_leave_limit:
            punch_category = "short_leave"
        elif punch_minutes <= first_half_limit:
            punch_category = "first_half_absent"
        else:
            punch_category = "full_absent"

    status = "Present"
    violation = ""
    short_leave_used = 0
    late_coming_marked = 0

    if employee_shift in EXCLUDED_SHIFTS and not doc.get("_shift_is_overnight"):
        saturday_cutoff = 720
    else:
        saturday_cutoff = shift_start_minutes + 180

    if is_branch:
        # BRANCH: hours-only rules, applies on day, night (incl. auto-
        # detected night) and Saturday. No late coming, no short leave, no
        # punch-time checks. The existing 5-minute clock-sync tolerance
        # (has_sufficient_hours) still applies to the 9h requirement.
        if working_hours < 4.5:
            status = "Absent"
            violation = "Insufficient Working Hours (< 4h 30m)"
        elif not has_sufficient_hours(working_hours, required_hours):
            status = "Half Day"
            violation = "Half Day Hours"
        else:
            status = "Present"
            violation = ""
    elif is_saturday:
        if punch_minutes > saturday_cutoff:
            status = "Absent"
            violation = "Saturday Punch After 12 PM"
        elif working_hours < 2.916:
            status = "Absent"
            violation = "Insufficient Working Hours (< 2h 55m)"
        elif working_hours < (required_hours - 2):
            status = "Half Day"
            violation = "Half Day Hours"
        else:
            if punch_category == "full_absent":
                status = "Absent"
                violation = "Saturday Punch After 12 PM"
            elif punch_category == "first_half_absent":
                status = "Half Day"
                violation = "First Half Absent"
            elif punch_category == "short_leave":
                short_leave_needed = required_hours - working_hours
                if short_leave_needed <= 1.0:
                    short_leave_to_deduct = 1.0
                elif short_leave_needed <= 2.0:
                    short_leave_to_deduct = 2.0
                else:
                    status = "Half Day"
                    violation = "Excessive Short Leave Needed (> 2h)"
                    short_leave_to_deduct = 0

                if status != "Half Day":
                    if has_sufficient_balance(short_leave_to_deduct, remaining_short_leave):
                        status = "Present"
                        violation = f"Short Leave ({int(short_leave_to_deduct)}h)"
                        short_leave_used = short_leave_to_deduct
                    else:
                        status = "Half Day"
                        violation = "Short Leave Balance Exhausted"
                        short_leave_used = short_leave_to_deduct
            elif punch_category == "late_coming":
                if has_sufficient_hours(working_hours, required_hours):
                    if remaining_late_coming >= 1:
                        status = "Present"
                        violation = "Late Coming"
                        late_coming_marked = 1
                    else:
                        status = "Half Day"
                        violation = "Late Coming Limit Exceeded (5th+)"
                        late_coming_marked = 1
                elif is_in_late_coming_range(working_hours, required_hours):
                    if remaining_late_coming >= 1:
                        status = "Present"
                        violation = "Late Coming"
                        late_coming_marked = 1
                    else:
                        status = "Half Day"
                        violation = "Late Coming Limit Exceeded (5th+)"
                        late_coming_marked = 1
                # AFTER
                else:
                    # Punch itself falls in late-coming window -> treat purely
                    # as Late Coming, do NOT also deduct short leave for the
                    # resulting low hours (that's a consequence of being late,
                    # not a separate violation).
                    if remaining_late_coming >= 1:
                        status = "Present"
                        violation = "Late Coming"
                        late_coming_marked = 1
                    else:
                        status = "Half Day"
                        violation = "Late Coming Limit Exceeded"
                        late_coming_marked = 1
            elif punch_category == "grace":
                if has_sufficient_hours(working_hours, required_hours):
                    status = "Present"
                    violation = ""
                else:
                    short_leave_needed = required_hours - working_hours
                    if short_leave_needed <= 1.0:
                        short_leave_to_deduct = 1.0
                    elif short_leave_needed <= 2.0:
                        short_leave_to_deduct = 2.0
                    else:
                        status = "Half Day"
                        violation = "Excessive Short Leave Needed"
                        short_leave_to_deduct = 0

                    if status != "Half Day":
                        if has_sufficient_balance(short_leave_to_deduct, remaining_short_leave):
                            status = "Present"
                            violation = f"Short Leave ({int(short_leave_to_deduct)}h)"
                            short_leave_used = short_leave_to_deduct
                        else:
                            status = "Half Day"
                            violation = "Short Leave Exhausted"
                            short_leave_used = short_leave_to_deduct
    else:
        if working_hours < 4.0:
            status = "Absent"
            violation = "Insufficient Working Hours (< 4h)"
        elif working_hours >= 4.0 and working_hours < 6.5:
            status = "Half Day"
            violation = "Half Day Hours"
        else:
            if punch_category == "full_absent":
                status = "Absent"
                violation = "Punch After 2 PM"
            elif punch_category == "first_half_absent":
                status = "Half Day"
                violation = "First Half Absent"
            elif punch_category == "short_leave":
                short_leave_needed = required_hours - working_hours
                if short_leave_needed <= 1.0:
                    short_leave_to_deduct = 1.0
                elif short_leave_needed <= 2.0:
                    short_leave_to_deduct = 2.0
                else:
                    status = "Half Day"
                    violation = "Excessive Short Leave Needed (> 2h)"
                    short_leave_to_deduct = 0

                if status != "Half Day":
                    if has_sufficient_balance(short_leave_to_deduct, remaining_short_leave):
                        status = "Present"
                        violation = f"Short Leave ({int(short_leave_to_deduct)}h)"
                        short_leave_used = short_leave_to_deduct
                    else:
                        status = "Half Day"
                        violation = "Short Leave Balance Exhausted"
                        short_leave_used = short_leave_to_deduct
            elif punch_category == "late_coming":
                if has_sufficient_hours(working_hours, required_hours):
                    if remaining_late_coming >= 1:
                        status = "Present"
                        violation = "Late Coming"
                        late_coming_marked = 1
                    else:
                        status = "Half Day"
                        violation = "Late Coming Limit Exceeded (5th+)"
                        late_coming_marked = 1
                elif is_in_late_coming_range(working_hours, required_hours):
                    if remaining_late_coming >= 1:
                        status = "Present"
                        violation = "Late Coming"
                        late_coming_marked = 1
                    else:
                        status = "Half Day"
                        violation = "Late Coming Limit Exceeded (5th+)"
                        late_coming_marked = 1
                # AFTER
                else:
                    # Same reasoning as Saturday block: pure Late Coming call,
                    # no stacked short-leave deduction.
                    if remaining_late_coming >= 1:
                        status = "Present"
                        violation = "Late Coming"
                        late_coming_marked = 1
                    else:
                        status = "Half Day"
                        violation = "Late Coming Limit Exceeded"
                        late_coming_marked = 1
            elif punch_category == "grace":
                if has_sufficient_hours(working_hours, required_hours):
                    status = "Present"
                    violation = ""
                elif working_hours < 4.0:
                    status = "Absent"
                    violation = "Grace Period - Insufficient Hours"
                else:
                    short_leave_needed = required_hours - working_hours
                    if short_leave_needed <= 1.0:
                        short_leave_to_deduct = 1.0
                    elif short_leave_needed <= 2.0:
                        short_leave_to_deduct = 2.0
                    else:
                        status = "Half Day"
                        violation = "Excessive Short Leave Needed"
                        short_leave_to_deduct = 0

                    if status != "Half Day":
                        if has_sufficient_balance(short_leave_to_deduct, remaining_short_leave):
                            status = "Present"
                            violation = f"Short Leave ({int(short_leave_to_deduct)}h)"
                            short_leave_used = short_leave_to_deduct
                        else:
                            status = "Half Day"
                            violation = "Short Leave Exhausted"
                            short_leave_used = short_leave_to_deduct

    doc.status = status
    doc.custom_violation_type = violation
    doc.custom_short_leave_hours = short_leave_used
    doc.custom_late_coming_count = late_coming_marked
    doc.custom_monthly_late_coming = remaining_late_coming
    doc.custom_monthly_short_leave = remaining_short_leave
    doc.custom_calculation_done = 1

    punch_time_str = f"{punch_hour:02d}:{punch_minute:02d}"
    work_hhmm = decimal_to_hhmm(working_hours)
    req_hhmm = decimal_to_hhmm(required_hours)

    doc.custom_status_detail = (
        f"Punch: {punch_time_str} | "
        f"Work: {work_hhmm} | "
        f"Req: {req_hhmm} | "
        f"Payroll: {payroll_month} {payroll_year} | "
        f"Status: {status} | {violation or 'No Violation'}"
    )

    # frappe.logger("olscpl_hrms").debug(
    #     f"Attendance calc — {doc.employee} {doc.attendance_date}: "
    #     f"punch_category={punch_category}, status={status}, violation={violation or 'None'}"
    # )