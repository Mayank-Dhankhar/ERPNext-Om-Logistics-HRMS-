import frappe
from olscpl_hrms.events import attendance_regularization_steps as steps


def validate(doc, method=None):
    """Runs at Before Save. Order matches original script sequence:
    Auto Fill Missing Punch runs first (populates times from Attendance),
    then Day Limit and Punch Times (validates + creates tracker),
    then Maximum Regularizations check (blocks 5th+ request in cycle)."""
    if not doc.get("reporting_person"):
        from olscpl_hrms.utils.reporting_person import default_reporting_value

        doc.reporting_person = default_reporting_value(doc.doctype, doc.employee)
    if doc.reporting_person and doc.reporting_person == doc.employee:
        frappe.throw(frappe._("Employee cannot be their own Reporting Person"))
    steps.auto_fill_missing_punch(doc)
    steps.day_limit_and_punch_times(doc)
    steps.maximum_regularizations_check(doc)


def after_insert(doc, method=None):
    steps.auto_assign_to_manager(doc)


def on_update(doc, method=None):
    steps.update_attendance_after_approval(doc)

def on_cancel(doc, method=None):
    steps.revert_attendance_on_cancel(doc)
