# Work From Home Request - fields mirror the OMSTAFF Android app's
# existing WFH submission (activity/WfmAct.kt + model/wfm/{Main,Detail}.kt,
# which POSTs this same shape to the separate legacy endpoint
# other/work-from-home on omapp.omlogistics.co.in): employee/date/
# reporting_person/latitude/longitude/location/financial_year map to
# Main.EmpCode/today_date/rPerson/lat/lng/locations/FIN_YR, and
# work_details (a child table, since the app's own Detail is a list) maps
# to Detail[].DESCRIPTION. api/work_from_home.py's
# create_and_submit_work_from_home_request() accepts the same field names
# via the app's usual caller_employee/Administrator server-to-server
# pattern (see api/regularization.py's module-level note) and drives the
# same Draft->Pending->Approved/Rejected Workflow as Attendance
# Regularization/Compensatory Leave Request, rather than the legacy
# endpoint's no-approval "submit == applied" behaviour.
#
# Registered via hooks.py -> doc_events["Work From Home Request"]
import frappe
from frappe import _
from frappe.utils import getdate


def validate(doc, method=None):
	if doc.employee == doc.reporting_person:
		frappe.throw(_("Employee cannot be their own Reporting Person"))


def after_insert(doc, method=None):
	# Mirrors events/visit.py's after_insert()/_notify_reporting_person() -
	# that sibling doctype already notifies its reporting person the
	# moment a request is filed (Draft, still docstatus 0), matching the
	# legacy OMSTAFF app's own PushNotification.send() on submit. This
	# doctype had the same "reporting person should know something needs
	# review" need but no notification at all until now.
	_notify_reporting_person(doc)


def _notify_reporting_person(doc):
	user = frappe.db.get_value("Employee", doc.reporting_person, "user_id")
	if not user:
		return
	from frappe.desk.doctype.notification_log.notification_log import enqueue_create_notification

	enqueue_create_notification(user, {
		"type": "Alert",
		"document_type": doc.doctype,
		"document_name": doc.name,
		"subject": _("{0} has requested Work From Home on {1}").format(doc.employee_name, doc.date),
		"from_user": frappe.session.user,
	})


def on_update(doc, method=None):
	"""Mirrors attendance_regularization_steps.update_attendance_after_approval:
	only the Manager/HR "Approve" transition (workflow_state -> Approved,
	which is also what submits the document, docstatus 0 -> 1) actually
	marks Attendance - Draft/Pending create nothing yet, and a later
	Reject reverts whatever Approved had created."""
	if doc.workflow_state == "Approved":
		_mark_attendance(doc)
	elif doc.workflow_state == "Rejected":
		_remove_attendance(doc)


def _mark_attendance(doc):
	att_date = getdate(doc.date)
	existing = frappe.db.get_value(
		"Attendance",
		{"employee": doc.employee, "attendance_date": att_date, "docstatus": ("!=", 2)},
		"name",
	)
	if existing:
		frappe.db.set_value("Attendance", existing, "status", "Work From Home")
		return
	attendance = frappe.get_doc({
		"doctype": "Attendance",
		"employee": doc.employee,
		"attendance_date": att_date,
		"status": "Work From Home",
		"company": frappe.db.get_value("Employee", doc.employee, "company"),
	})
	attendance.insert(ignore_permissions=True)
	attendance.submit()


def on_cancel(doc, method=None):
	"""Mirrors visit.py's on_cancel(): undo whatever an Approved request
	created, same as this doctype's own on_update() already does for a
	Reject - the generic Cancel button doesn't go through that transition,
	so without this the Attendance it marked stays stuck submitted."""
	_remove_attendance(doc)


def _remove_attendance(doc):
	existing = frappe.db.get_value(
		"Attendance",
		{
			"employee": doc.employee,
			"attendance_date": getdate(doc.date),
			"status": "Work From Home",
			"docstatus": 1,
		},
		"name",
	)
	if existing:
		# Same gap as Leave Application's create_or_update_attendance (see
		# overrides/leave_application.py): a plain Reporting Person rejecting
		# or cancelling this request has no general permission on another
		# employee's Attendance, so .cancel() without ignore_permissions
		# throws right here.
		attendance = frappe.get_doc("Attendance", existing)
		attendance.flags.ignore_permissions = True
		attendance.cancel()
