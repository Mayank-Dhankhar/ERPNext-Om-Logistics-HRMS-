import frappe


def snapshot_outstanding_balance(doc, method=None):
	"""
	On validate, snapshot the loan's current outstanding balance so HR sees
	an accurate figure at the time of request (not just at creation).
	"""
	if not doc.employee_loan:
		return

	doc.outstanding_balance_at_request = frappe.db.get_value(
		"Employee Loan", doc.employee_loan, "outstanding_balance"
	)


def process_prepayment_on_approval(doc, method=None):
	"""
	Fires on Loan Prepayment Request update. When workflow_state transitions
	to 'Approved', marks all remaining Pending EMIs as Prepaid, zeroes the
	outstanding balance, and closes the loan (full prepayment only - no
	partial prepayment supported).
	Idempotent - if loan is already Closed, does nothing.
	"""
	if doc.workflow_state != "Approved":
		return

	loan = frappe.get_doc("Employee Loan", doc.employee_loan)

	if loan.status == "Closed":
		return  # already processed

	for emi_row in loan.emi_schedule:
		if emi_row.status == "Pending":
			emi_row.status = "Prepaid"
			emi_row.paid_date = frappe.utils.today()
			emi_row.remarks = f"Prepaid via {doc.name} - HR approved"

	loan.total_paid = loan.principal_amount
	loan.outstanding_balance = 0
	loan.status = "Closed"
	loan.closed_date = frappe.utils.today()
	loan.save(ignore_permissions=True)

	frappe.msgprint(
		f"Loan {loan.name} fully prepaid and closed.",
		title="Loan Closed",
		indicator="green"
	)
	