import frappe
from frappe.utils import getdate
from olscpl_hrms.utils.payroll_constants import (
	LATE_COMING_FREE_LIMIT,
	LATE_COMING_LWP_RATE,
	SHORT_LEAVE_FREE_LIMIT_HRS,
	SHORT_LEAVE_LWP_FLAT,
	HALF_DAY_EXCLUDED_VIOLATION_TYPES,
	MONTH_MAP,
	NO_PF_ESI_DESIGNATIONS_ON_MANUAL,
	OSBS_SALARY_STRUCTURE,
	OSBS_MIN_BASIC_AMOUNT,
    EMPLOYER_PF_RATE_DEFAULT,
    EMPLOYEE_PF_RATE_DEFAULT,
    BASE_BASIC_RATE,
    BASE_HRA_RATE,
    OSBS_BASIC_RATE,
    OSBS_HRA_RATE,
    OSBS_CONVEYANCE_RATE,
    OSBS_PF_RATE,
    ONE_TIME_COMPONENTS,
    is_manual_salary_structure,
    is_base_salary_structure,
	is_no_deduction_employment_type,
)
from olscpl_hrms.utils.payroll_changeable_component_utils import get_component_value
from olscpl_hrms.utils.fbp_slabs import (
	FLEXI_EARNING_COMPONENTS,
	get_verified_fbp_exemption,
	is_flexi_salary_structure,
)


def purge_blank_rows(doc, method=None):
	"""was Server Script: 000 Salary Slip Blank Row Purge
	Runs at Before Save (validate stage)."""
	doc.deductions = [r for r in doc.deductions if str(r.salary_component or "").strip()]
	doc.earnings = [r for r in doc.earnings if str(r.salary_component or "").strip()]

	for idx, row in enumerate(doc.deductions, start=1):
		row.idx = idx
	for idx, row in enumerate(doc.earnings, start=1):
		row.idx = idx





def apply_attendance_lwp_bridge(doc, method=None):
	"""
	Apply LWP from Monthly Attendance Tracker
	Migrated from Server Script: Attendance LWP Bridge Script (Before Save)
	Payroll Cycle: 26 -> 25
	Logic preserved exactly as original - review during regression.
	"""
	if not (doc.employee and doc.start_date):
		return

	# Full month override can come from either source:
	#  - the checkbox on THIS Salary Slip directly (single/manual
	#    slip creation, where doc.payroll_entry is blank), OR
	#  - the Payroll Entry that created this slip (bulk runs).
	full_month_override = doc.get("custom_pay_full_month") or False

	if doc.payroll_entry:
		full_month_override = full_month_override or frappe.db.get_value(
			"Payroll Entry", doc.payroll_entry, "custom_pay_full_month"
		)

	if full_month_override:
		manual_lwp = doc.leave_without_pay or 0
		doc.absent_days = 0

		# Even in "full month" test mode, an employee who joined or
		# left DURING this payroll period must not be paid for days
		# outside their actual employment window. Same doj/relieving
		# clamp used in the normal (non-override) path below.
		start_date = frappe.utils.getdate(doc.start_date)
		end_date = frappe.utils.getdate(doc.end_date)

		doj = frappe.db.get_value("Employee", doc.employee, "date_of_joining")
		doj = frappe.utils.getdate(doj) if doj else None

		relieving_date = frappe.db.get_value("Employee", doc.employee, "relieving_date")
		relieving_date = frappe.utils.getdate(relieving_date) if relieving_date else None

		period_start = start_date
		period_end = end_date

		if doj and start_date <= doj <= end_date:
			period_start = doj

		if relieving_date and start_date <= relieving_date <= end_date:
			period_end = relieving_date

		full_month_days = (period_end - period_start).days + 1
		doc.payment_days = full_month_days - manual_lwp

		if doc.payment_days < 0:
			doc.payment_days = 0

		doc.flags.lwp_bridge_applied = True

		frappe.msgprint(
			f"Full Month Salary Override active (Payroll Entry: {doc.payroll_entry})"
			f" | Payment Days set to {doc.payment_days} (window: {period_start} to {period_end})"
			f" | Attendance-based LWP/Absent calculation skipped"
		)
		return

	# ---------------------------------------
	# Get day/month/year from salary slip
	# ---------------------------------------
	parts = str(doc.start_date).split('-')
	year_num = int(parts[0])
	month_num = int(parts[1])
	day_num = int(parts[2])

	# ---------------------------------------
	# Determine Payroll Month (26->25 logic)
	# ---------------------------------------
	if day_num >= 26:
		if month_num == 12:
			payroll_month_num = 1
			payroll_year = year_num + 1
		else:
			payroll_month_num = month_num + 1
			payroll_year = year_num
	else:
		payroll_month_num = month_num
		payroll_year = year_num

	payroll_month = MONTH_MAP.get(payroll_month_num)

	# ---------------------------------------
	# Determine cycle_start and cycle_end
	# ---------------------------------------
	if payroll_month_num == 1:
		cycle_start = f"{payroll_year - 1}-12-26"
	else:
		prev_month = payroll_month_num - 1
		cycle_start = f"{payroll_year}-{str(prev_month).zfill(2)}-26"

	cycle_end = f"{payroll_year}-{str(payroll_month_num).zfill(2)}-25"

	# ---------------------------------------
	# Fetch Monthly Attendance Tracker
	# ---------------------------------------
	tracker = frappe.db.get_value(
		"Monthly Attendance Tracker",
		{"employee": doc.employee, "month": payroll_month, "year": payroll_year},
		["total_late_coming", "total_short_leave_hours", "half_day_deductions"],
		as_dict=True
	)

	# ---------------------------------------
	# Calculate LWP
	# ---------------------------------------
	extra_lwp = 0
	late_count = 0
	short_hrs = 0
	short_excess = 0

	if tracker:
		late_count = tracker.total_late_coming or 0
		short_hrs = tracker.total_short_leave_hours or 0

		late_excess = late_count - LATE_COMING_FREE_LIMIT
		if late_excess > 0:
			extra_lwp += late_excess * LATE_COMING_LWP_RATE

		short_excess = short_hrs - SHORT_LEAVE_FREE_LIMIT_HRS
		if short_excess > 0:
			extra_lwp += SHORT_LEAVE_LWP_FLAT
	else:
		frappe.msgprint(
			f"LWP Bridge WARNING: No Monthly Attendance Tracker found "
			f"for {doc.employee} | Month: {payroll_month} {payroll_year}"
		)

	# ---------------------------------------
	# APPLY LEAVE BALANCE ADJUSTMENT
	# Only the SYSTEM-COMPUTED extra_lwp (late-coming / short-leave
	# penalties) is eligible for auto-conversion against available
	# leave balance. Any LWP the user manually entered on the slip
	# (manual_lwp) is respected as-is and NEVER auto-adjusted --
	# a manual entry is a deliberate decision to treat that time as
	# unpaid, not something the system should silently substitute
	# with leave balance.
	# ---------------------------------------
	manual_lwp = doc.leave_without_pay or 0

	leave_balance = frappe.db.sql("""
		SELECT SUM(leaves)
		FROM `tabLeave Ledger Entry`
		WHERE employee = %s
		  AND leave_type = 'Leave'
		  AND docstatus < 2
	""", (doc.employee,))[0][0] or 0

	adjusted_extra_lwp = extra_lwp
	leave_used = 0

	if leave_balance > 0 and extra_lwp > 0:
		if leave_balance >= extra_lwp:
			adjusted_extra_lwp = 0
			leave_used = extra_lwp
		else:
			adjusted_extra_lwp = extra_lwp - leave_balance
			leave_used = leave_balance

		frappe.msgprint(
			f"✅ Leave Adjustment Applied (system-computed LWP only) | "
			f"Available: {leave_balance} | "
			f"Used: {leave_used} | "
			f"Remaining System LWP: {adjusted_extra_lwp} | "
			f"Manual LWP (untouched): {manual_lwp}"
		)
	elif extra_lwp > 0:
		frappe.msgprint("⚠️ No Leave balance found for Leave Type = Leave")

	total_lwp = manual_lwp + adjusted_extra_lwp
	adjusted_lwp = total_lwp

	doc.leave_without_pay = adjusted_lwp

	# =====================================================
	# AUTO CREATE LEAVE APPLICATION
	# BASED ON ACTUAL ABSENT DATES FROM PAYROLL CYCLE
	# =====================================================
	if leave_balance > 0:

		# NOTE: full-day absent records are intentionally NOT
		# consumed here (kept disabled to match original script) --
		# only Half Day records are converted against leave balance.
		# absent_records = frappe.db.sql("""
		# 	SELECT name, attendance_date
		# 	FROM `tabAttendance`
		# 	WHERE employee = %s
		# 	  AND status = 'Absent'
		# 	  AND attendance_date BETWEEN %s AND %s
		# 	ORDER BY attendance_date ASC
		# """, (doc.employee, cycle_start, cycle_end), as_dict=True)

		# status = 'Half Day' only here - NOT extended to a half-day Visit
		# (status = 'Visit') the way the pure payroll-day count further
		# down is. This block converts each half-day record against
		# available leave balance into a real Leave Application, and
		# HRMS core's own Leave Application.on_submit() then rewrites the
		# linked Attendance record's status directly (see
		# hrms/hr/doctype/leave_application/leave_application.py) -
		# running a half-day Visit through that would silently flip its
		# Attendance status away from "Visit" to "On Leave"/"Half Day",
		# which is exactly what a half-day Visit must NOT do.
		half_day_records = frappe.db.sql("""
			SELECT
				name,
				attendance_date,
				custom_violation_type
			FROM `tabAttendance`
			WHERE employee = %s
			AND status = 'Half Day'
			AND attendance_date BETWEEN %s AND %s
			ORDER BY attendance_date ASC
		""", (
			doc.employee,
			cycle_start,
			cycle_end
		), as_dict=True)

		days_remaining = leave_balance
		dates_to_adjust = []

		# for record in absent_records:
		# 	if days_remaining < 1.0:
		# 		break
		# 	dates_to_adjust.append({
		# 		"name": record.name,
		# 		"attendance_date": record.attendance_date,
		# 		"is_half": False
		# 	})
		# 	days_remaining -= 1.0

		for record in half_day_records:
			if days_remaining <= 0:
				break
			dates_to_adjust.append({
				"name": record.name,
				"attendance_date": record.attendance_date,
				"is_half": True
			})
			days_remaining -= 0.5

		if dates_to_adjust:
			for d in dates_to_adjust:
				att_date = d["attendance_date"]
				is_half = d["is_half"]

				already_exists = frappe.db.exists("Leave Application", {
					"employee": doc.employee,
					"leave_type": "Leave",
					"from_date": att_date,
					"to_date": att_date,
					"docstatus": 1
				})

				# Attendance status intentionally left untouched here --
				# it should remain "Half Day" even after the auto Leave
				# Application is created below.

				# if already_exists:
				# 	continue

				# try:
				# 	leave_doc = frappe.new_doc("Leave Application")
				# 	leave_doc.employee = doc.employee
				# 	leave_doc.leave_type = "Leave"
				# 	leave_doc.company = doc.company
				# 	leave_doc.from_date = att_date
				# 	leave_doc.to_date = att_date
				# 	leave_doc.status = "Approved"
				# 	leave_doc.description = (
				# 		f"Auto LWP Adjustment | Payroll: {payroll_month} {payroll_year}"
				# 	)

				# 	if is_half:
				# 		leave_doc.half_day = 1
				# 		leave_doc.half_day_date = att_date
				# 		leave_doc.total_leave_days = 0.5
				# 	else:
				# 		leave_doc.half_day = 0
				# 		leave_doc.total_leave_days = 1.0

				# 	leave_doc.flags.ignore_permissions = True
				# 	leave_doc.flags.ignore_validate = True
				# 	leave_doc.flags.ignore_mandatory = True
				# 	leave_doc.insert(ignore_permissions=True)
				# 	leave_doc.submit()

				# except Exception as e:
				# 	frappe.throw(str(e))


				#10-08-2026
				if already_exists:
					continue

				try:
					# AFTER (goes through the workflow properly):
					from frappe.model.workflow import apply_workflow

					leave_doc = frappe.new_doc("Leave Application")
					leave_doc.employee = doc.employee
					leave_doc.leave_type = "Leave"
					leave_doc.company = doc.company
					leave_doc.from_date = att_date
					leave_doc.to_date = att_date
					leave_doc.status = "Open"          # start in the workflow's real initial state
					leave_doc.description = (
						f"Auto LWP Adjustment | Payroll: {payroll_month} {payroll_year}"
					)
					if is_half:
						leave_doc.half_day = 1
						leave_doc.half_day_date = att_date
						leave_doc.total_leave_days = 0.5
					else:
						leave_doc.half_day = 0
						leave_doc.total_leave_days = 1.0
					leave_doc.flags.ignore_permissions = True
					leave_doc.flags.ignore_validate = True
					leave_doc.flags.ignore_mandatory = True
					leave_doc.insert(ignore_permissions=True)

										# Transition Open -> Approved through the actual workflow action,
					# so Frappe's workflow guard sees a valid transition (this also
					# handles the submit()/docstatus=1 change internally).
					frappe.set_user("Administrator")   # ensures HR Manager-equivalent transition rights
					apply_workflow(leave_doc, "Approve")

					# ---------------------------------------------------
					# Attendance status is intentionally NOT re-asserted
					# here. HRMS's own on_submit sync for a Half Day Leave
					# Application will (re)set Attendance status to
					# "Half Day" -- which is exactly the desired final
					# state now, so no override is needed.
					# ---------------------------------------------------
					final_status = frappe.db.get_value("Attendance", d["name"], "status")
					frappe.msgprint(
						f"{att_date} Leave Application created | Attendance Status = {final_status}"
					)

				except Exception as e:
					frappe.throw(str(e))

	# -----------------------------------------------
	# COUNT ABSENT DAYS for salary slip
	#
	# NEW: attendance_end -- if the employee's relieving_date falls
	# inside this payroll cycle, no Attendance record dated AFTER
	# relieving_date should be considered AT ALL (not as Absent, not
	# as Present, nothing) -- the employee wasn't employed on those
	# dates. Without this, any post-relieving Attendance record
	# (correct or a punch-system glitch) still leaks into absent/
	# half-day counts and skews payment_days.
	# -----------------------------------------------
	relieving_date_for_cycle = frappe.db.get_value(
		"Employee", doc.employee, "relieving_date"
	)
	relieving_date_for_cycle = (
		frappe.utils.getdate(relieving_date_for_cycle)
		if relieving_date_for_cycle else None
	)

	attendance_end = cycle_end
	cycle_end_date = frappe.utils.getdate(cycle_end)
	if relieving_date_for_cycle and relieving_date_for_cycle < cycle_end_date:
		attendance_end = str(relieving_date_for_cycle)

	absent = frappe.db.sql("""
		SELECT COUNT(*)
		FROM `tabAttendance`
		WHERE employee = %s
		  AND status = 'Absent'
		  AND attendance_date BETWEEN %s AND %s
	""", (doc.employee, cycle_start, attendance_end))[0][0]

	# Half Day attendance counts here (subject to the violation-type
	# exclusion below), and so does a half-day Visit
	# (custom_visit_day_portion, see events/visit.py's
	# _mark_attendance()) - but the violation-type exclusion is a
	# punch-based concept that never applies to a Visit (its
	# custom_violation_type is always blank), so it's scoped to the
	# Half Day branch only rather than applied to both - a blank
	# custom_violation_type would otherwise fail a bare `NOT IN (...)`
	# check (NULL NOT IN (...) is NULL, not true) and silently drop
	# every half-day Visit from this count.
	exclusion_placeholders = ", ".join(["%s"] * len(HALF_DAY_EXCLUDED_VIOLATION_TYPES))
	half_day_rows = frappe.db.sql(f"""
		SELECT a.attendance_date, a.status, a.custom_violation_type
		FROM `tabAttendance` a
		WHERE a.employee = %s
		  AND (
				(a.status = 'Half Day' AND a.custom_violation_type NOT IN ({exclusion_placeholders}))
				OR (a.status = 'Visit' AND a.custom_visit_day_portion IN ('First Half', 'Second Half'))
		  )
		  AND a.attendance_date BETWEEN %s AND %s
		  AND NOT EXISTS (
				SELECT 1 FROM `tabLeave Application` la
				WHERE la.employee = a.employee
				  AND la.docstatus = 1
				  AND la.leave_type = 'Leave'
				  AND la.from_date = a.attendance_date
				  AND la.to_date = a.attendance_date
		  )
	""", (doc.employee, *HALF_DAY_EXCLUDED_VIOLATION_TYPES, cycle_start, cycle_end), as_dict=True)

	frappe.msgprint(str(half_day_rows))

	half_days = len(half_day_rows)

	if leave_balance > 0:
		absent_total = absent + (half_days * 0.5)
	else:
		if short_excess > 1:
			absent_total = absent + (half_days * 0.5) + ((short_excess - 1) * 0.5)
		else:
			absent_total = absent + (half_days * 0.5)

	frappe.msgprint(
		f"Absent={absent}, HalfDays={half_days}, ShortExcess={short_excess}, LeaveBalance={leave_balance}"
	)

	doc.absent_days = absent_total

	# ---------------------------------------
	# Payment Days Recalculation
	#
	# Ceiling uses CALENDAR dates (doc.start_date/doc.end_date), NOT
	# cycle_start/cycle_end. The 26-30(ish) "advance tail" days of
	# the PREVIOUS cycle are never an ADDITIONAL payable ceiling here
	# -- they were already paid as advance in the previous month's
	# slip. Only doj/relieving_date clamp the calendar-day ceiling.
	# absent_days (counted above, from cycle_start to attendance_end)
	# DOES still include that advance-tail window, so an absence in
	# the 26-30 previous-month days correctly claws back against
	# THIS month's ceiling -- that part is intentional and unchanged.
	# ---------------------------------------
	payment_days = doc.total_working_days - (
		(doc.absent_days or 0) + (doc.leave_without_pay or 0)
	)

	doj = frappe.db.get_value("Employee", doc.employee, "date_of_joining")
	doj = frappe.utils.getdate(doj) if doj else None
	start_date = frappe.utils.getdate(doc.start_date)
	end_date = frappe.utils.getdate(doc.end_date)

	# Reuse relieving_date_for_cycle (already fetched above for the
	# attendance-window clamp) instead of querying it again.
	relieving_date = relieving_date_for_cycle

	period_start = start_date
	period_end = end_date
	partial_period = False

	if doj and start_date <= doj <= end_date:
		period_start = doj
		partial_period = True

	if relieving_date and start_date <= relieving_date <= end_date:
		period_end = relieving_date
		partial_period = True

	if partial_period:
		joining_based_days = (period_end - period_start).days + 1
		payment_days = joining_based_days - (
			(doc.absent_days or 0) + (doc.leave_without_pay or 0)
		)

	if payment_days < 0:
		payment_days = 0

	doc.payment_days = payment_days

	#07-08-2026
	doc.flags.lwp_bridge_applied = True

	frappe.msgprint(
		f"LWP Bridge | Employee: {doc.employee}"
		f" | Month: {payroll_month} {payroll_year}"
		f" | Cycle: {cycle_start} → {cycle_end}"
		f" | Late Coming: {late_count}"
		f" | Short Leave Hrs: {short_hrs}"
		f" | Extra LWP: {extra_lwp}"
		f" | Leave Used: {leave_used}"
		f" | Final LWP: {doc.leave_without_pay}"
		f" | Absent Days: {doc.absent_days}"
		f" | Payment Days: {doc.payment_days}"
	)


def apply_manual_salary_structure_override(doc, method=None):
	"""was Server Script: 00 MANUAL SALARY STRUCTURE OVERRIDE (Before Save)
	Purpose: Override salary slip components for employees on
	formula-free "OLSCPL Manual Salary Structure".
	Logic preserved exactly as original - review during regression."""

	if not (is_manual_salary_structure(doc.salary_structure) and doc.employee):
		return

	# Kill blank rows first
	doc.earnings = [r for r in doc.earnings if r.salary_component]
	doc.deductions = [r for r in doc.deductions if r.salary_component]

	ssa_name = frappe.db.get_value(
		"Salary Structure Assignment",
		{
			"employee": doc.employee,
			"salary_structure": doc.salary_structure,
			"from_date": ["<=", doc.end_date],
			"docstatus": 1
		},
		"name",
		order_by="from_date desc"
	)

	if not ssa_name:
		return

	manual_rows = frappe.db.sql("""
		SELECT salary_component, component_type,
			   amount, depends_on_payment_days, abbr
		FROM `tabManual Salary Component`
		WHERE parent = %s
		  AND parenttype = 'Salary Structure Assignment'
		ORDER BY idx
	""", ssa_name, as_dict=1)

	if not manual_rows:
		return

	total_working_days = doc.total_working_days or 0
	payment_days = doc.payment_days or 0
	payment_days_fraction = (
		payment_days / total_working_days if total_working_days > 0 else 1.0
	)

	# Preserve employer rows + additional salary rows
	keep_components = ['Employer PF', 'Employer ESI', 'Gratuity']

	preserved_earnings = []
	preserved_deductions = []

	for r in doc.earnings:
		is_additional = 0
		try:
			if r.additional_salary:
				is_additional = 1
		except:
			pass

		if r.salary_component in keep_components or is_additional:
			preserved_earnings.append({
				'salary_component': r.salary_component,
				'abbr': r.abbr or '',
				'amount': r.amount,
				'default_amount': r.default_amount,
				'depends_on_payment_days': r.depends_on_payment_days
			})

	for r in doc.deductions:
		is_additional = 0
		try:
			if r.additional_salary:
				is_additional = 1
		except:
			pass

		if is_additional or r.salary_component in ["TDS", "Provident Fund", "Professional Tax", "ESIC", "LWF"]:
			preserved_deductions.append({
				'salary_component': r.salary_component,
				'abbr': r.abbr or '',
				'amount': r.amount,
				'default_amount': r.default_amount,
				'depends_on_payment_days': r.depends_on_payment_days
			})

	frappe.msgprint(
		"Preserved Earnings: " + str(len(preserved_earnings)) +
		" | Preserved Deductions: " + str(len(preserved_deductions))
	)

	# Full wipe (proper child table clear)
	doc.set("earnings", [])
	doc.set("deductions", [])

	seen_components = set()

	for mrow in manual_rows:
		if mrow.salary_component in seen_components:
			continue
		seen_components.add(mrow.salary_component)

		base = mrow.amount or 0

		if payment_days <= 0:
			final = 0
		elif mrow.salary_component in ONE_TIME_COMPONENTS:
			final = base
		elif total_working_days > 0 and payment_days < total_working_days:
			final = round(base * payment_days_fraction, 2)
		else:
			final = base

		entry = {
			'salary_component': mrow.salary_component,
			'abbr': mrow.abbr or '',
			'amount': final,
			'default_amount': base,
			'depends_on_payment_days': int(mrow.depends_on_payment_days or 0)
		}

		if mrow.component_type == 'Earning':
			doc.append('earnings', entry)
		elif mrow.component_type == 'Deduction':
			doc.append('deductions', entry)

	# Restore preserved earnings
	for prow in preserved_earnings:
		doc.append('earnings', prow)

	# Restore preserved deductions
	for prow in preserved_deductions:
		doc.append('deductions', prow)

	# Recalc gross
	new_gross = 0
	for row in doc.earnings:
		comp_flags = frappe.db.get_value(
			'Salary Component',
			row.salary_component,
			['do_not_include_in_total', 'statistical_component'],
			as_dict=1
		)
		if comp_flags and (comp_flags.do_not_include_in_total or comp_flags.statistical_component):
			continue
		new_gross += (row.amount or 0)

	doc.gross_pay = new_gross
	doc.total_deduction = sum(r.amount or 0 for r in doc.deductions)
	doc.net_pay = doc.gross_pay - doc.total_deduction
	doc.rounded_total = round(doc.net_pay)

	# frappe.log_error(
	# 	"\n".join([
	# 		str(d.salary_component) + " = " + str(d.amount)
	# 		for d in doc.deductions
	# 	]),
	# 	"MANUAL OVERRIDE END"
	# )
	# frappe.msgprint(
	# 	'Manual Override ✓ | PD: ' + str(payment_days) + '/' + str(total_working_days) +
	# 	' | Factor: ' + str(round(payment_days_fraction, 4)) +
	# 	' | Gross: ₹' + str(doc.gross_pay)
	# )  


def apply_pf_epf_eps_split(doc, method=None):
	"""was Server Script: PF EPF EPS Split Calculation (Before Save)
	FIX 1: prorated_sixty_percent used for MW condition gate
	FIX 2: Washing Allowance pro-rated same as Special Allowance
	Logic preserved exactly as original - review during regression."""

	if not (doc.employee and doc.earnings):
		return

	salary_structure_name = doc.salary_structure or ""
	# RapidShyp Flexi Benefit Plan structure: PF on Basic (+ Special Allowance)
	# like the OSBS structures - 12%, no minimum-wage override - but its Basic /
	# HRA come from its own formulas, so the OSBS override further down skips it
	is_flexi_structure = is_flexi_salary_structure(salary_structure_name)
	is_base_structure = is_base_salary_structure(salary_structure_name) or is_flexi_structure
	is_manual_structure = is_manual_salary_structure(salary_structure_name)

	is_osbs_structure = (
		salary_structure_name == OSBS_SALARY_STRUCTURE
		or is_flexi_structure
	)

	doc.earnings = [r for r in doc.earnings if r.salary_component]
	doc.deductions = [r for r in doc.deductions if r.salary_component]

	# --- after ---
	employee_data = frappe.db.get_value(
		"Employee", doc.employee,
		["custom_pf_applicable", "custom_state", "custom_state_wage_category",
		 "employment_type", "designation"],
		as_dict=True
	) or {}

	pf_applicable = employee_data.get("custom_pf_applicable") or "Yes"
	employee_state = employee_data.get("custom_state") or ""
	employee_category = employee_data.get("custom_state_wage_category") or ""

	# CHANGED: Outsourced no longer goes through minimum-wage logic at
	# all (see early-return block below) -- flat 60/40 split instead.
	# Drivers get PF/ESI suppressed only on Manual structure; on Base
	# structure they go through the normal min-wage/PF path untouched
	# (component values there are a data/sheet concern, not code).
	is_outsourced = is_no_deduction_employment_type(employee_data.get("employment_type"))
	is_driver = (employee_data.get("designation") or "").strip().upper() in NO_PF_ESI_DESIGNATIONS_ON_MANUAL

	base_salary = frappe.utils.flt(frappe.db.get_value(
		"Salary Structure Assignment",
		{"employee": doc.employee, "salary_structure": doc.salary_structure, "docstatus": 1},
		"base"
	)) or 0.0

	# CHANGED: effective-dated lookup against Payroll Changeable Component
	# (Item + Audit) instead of reading the single latest-created doc.
	# doc.end_date used as as-on date -- same field the State Wage
	# Master lookup below already keys off, so both stay consistent
	# for the payroll period being processed.
	pf_ceiling_amount = int(get_component_value("PF Ceiling Amount", doc.end_date) or 15000)
	bonus_limit_amount = int(get_component_value("Bonus Limit Amount", doc.end_date) or 21000)
	bonus_ceiling_amount = int(get_component_value("Bonus Ceiling Amount", doc.end_date) or 7000)

	bonus_doc = frappe.get_all(
		"Bonus Payable",
		filters={"company": doc.company},
		fields=["bonus_payable_percentage"],
		limit=1
	)

	if bonus_doc:
		bonus_percentage = bonus_doc[0].get("bonus_payable_percentage") or 20
		bonus_percentage = float(bonus_percentage) / 100
	else:
		bonus_percentage = 0.20

	# STEP A: Read earnings rows
	basic_amount = 0
	hra_amount = 0
	special_allowance = 0
	actual_basic_for_pf = 0
	other_deduction_amount = 0

	for row in doc.earnings:
		if row.salary_component == "Basic":
			basic_amount = frappe.utils.flt(row.amount)
			actual_basic_for_pf = frappe.utils.flt(row.default_amount or row.amount)
		elif row.salary_component == "House Rent Allowance":
			hra_amount = frappe.utils.flt(row.amount)
		elif row.salary_component == "Special Allowance":
			special_allowance = frappe.utils.flt(row.amount)

	sixty_percent_of_base = base_salary * BASE_BASIC_RATE

	# STEP B: Minimum Wage
	min_wage = 0

	if employee_state:
		wage_row = frappe.get_all(
			"State Wage Master",
			filters={"state": employee_state, "effective_date": ["<=", doc.end_date]},
			fields=["effective_date", "unskilled", "semi_skilled", "skilled", "highly_skilled"],
			order_by="effective_date desc",
			limit=1
		)

		if wage_row:
			wage_row = wage_row[0]
			if employee_category == "Unskilled":
				min_wage = frappe.utils.flt(wage_row.unskilled)
			elif employee_category == "Semi-Skilled":
				min_wage = frappe.utils.flt(wage_row.semi_skilled)
			elif employee_category == "Skilled":
				min_wage = frappe.utils.flt(wage_row.skilled)
			elif employee_category == "Highly Skilled":
				min_wage = frappe.utils.flt(wage_row.highly_skilled)

		frappe.msgprint("Min Wage = " + str(min_wage))

	# PRO-RATE FACTOR
	working_days = doc.total_working_days or 0
	payment_days = doc.payment_days or 0

	frappe.msgprint(f"PF Script → Working={working_days}, Payment={payment_days}")

	if payment_days <= 0:
		pro_rate_factor = 0
		for row in doc.earnings:
			row.amount = 0
		for row in doc.deductions:
			if row.salary_component != "LWF":
				row.amount = 0
	elif working_days > 0:
		pro_rate_factor = payment_days / working_days
	else:
		pro_rate_factor = 1
    
    # NEW: Outsourced -- flat 60/40 Basic/HRA split, prorated by
	# payment days. Bypasses minimum-wage override, Advance Bonus,
	# PF (employee + employer), and every deduction entirely.
	if is_outsourced:
		flat_basic = round(base_salary * BASE_BASIC_RATE * pro_rate_factor, 2)
		flat_hra = round(base_salary * BASE_HRA_RATE * pro_rate_factor, 2)

		for row in doc.earnings:
			if row.salary_component == "Basic":
				row.amount = flat_basic
			elif row.salary_component == "House Rent Allowance":
				row.amount = flat_hra
			elif row.salary_component in ["Advance Bonus", "Employer PF", "Employer ESI", "Gratuity"]:
				row.amount = 0

		doc.custom_mw_basic_entitlement = 0
		doc.custom_mw_hra_entitlement = 0
		doc.custom_mw_advance_bonus_entitlement = 0
		doc.custom_pf_basis = 0
		doc.set("deductions", [])   # No PF/ESIC/PT/ACCOM/anything for Outsourced

		# Employer PF contributes 0 this month -- carry prior YTD
		# forward unchanged rather than leaving custom_employer_pf_amount
		# stale from an earlier save cycle.
		slip_end_pf = frappe.utils.getdate(doc.end_date)
		fy_start_year_pf = slip_end_pf.year if slip_end_pf.month >= 4 else slip_end_pf.year - 1
		fy_start_date_pf = frappe.utils.getdate(str(fy_start_year_pf) + "-04-01")
		prev_employer_pf = frappe.db.sql("""
			SELECT COALESCE(SUM(custom_employer_pf_amount), 0)
			FROM `tabSalary Slip`
			WHERE employee = %s AND docstatus = 1
			  AND end_date >= %s AND end_date < %s AND name != %s
		""", (doc.employee, fy_start_date_pf, slip_end_pf, doc.name or ""))[0][0] or 0
		doc.custom_employer_pf_amount = 0
		doc.custom_employer_pf_ytd = round(prev_employer_pf, 2)

		doc.earnings = [r for r in doc.earnings if r.salary_component]
		doc.gross_pay = round(sum(float(r.amount or 0) for r in doc.earnings), 2)
		doc.total_deduction = 0
		doc.net_pay = doc.gross_pay
		return
    
    # 09-10-2026
	# ============================================================
	# OSBS: BASIC / HRA / CONVEYANCE OVERRIDE
	# Gross salary is taken from the active Salary Structure
	# Assignment's base amount.
	# ============================================================
	if is_osbs_structure and not is_flexi_structure and base_salary > 0:

		gross_salary = frappe.utils.flt(base_salary)
		min_basic = OSBS_MIN_BASIC_AMOUNT

		# Basic = MAX(50% of Gross, Minimum Basic)
		osbs_basic = max(gross_salary * OSBS_BASIC_RATE, min_basic)

		# HRA and Conveyance follow the OSBS Excel rules
		if osbs_basic <= min_basic:
			osbs_hra = min(
				gross_salary - osbs_basic,
				gross_salary * OSBS_HRA_RATE
			)
			osbs_conveyance = gross_salary - osbs_basic - osbs_hra
		else:
			osbs_hra = gross_salary * OSBS_HRA_RATE
			osbs_conveyance = gross_salary * OSBS_CONVEYANCE_RATE

		osbs_components = {
			"Basic": round(osbs_basic, 2),
			"House Rent Allowance": round(osbs_hra, 2),
			"Conveyance": round(osbs_conveyance, 2),
		}

		for row in doc.earnings:
			component = row.salary_component
			if component in osbs_components:
				amount = osbs_components[component]
				row.amount = amount
				row.default_amount = amount

		# frappe.log_error(
		# 	"OSBS | Gross=" + str(gross_salary)
		# 	+ " | Basic=" + str(osbs_basic)
		# 	+ " | HRA=" + str(osbs_hra)
		# 	+ " | Conveyance=" + str(osbs_conveyance),
		# 	"OSBS Salary Calculation"
		# )


	# PRO-RATED VALUES USED FOR CONDITION GATE
	prorated_min_wage = min_wage

	if working_days > 0 and payment_days > 0 and payment_days < working_days:
		prorated_min_wage = round((frappe.utils.flt(min_wage) * frappe.utils.flt(payment_days)) / frappe.utils.flt(working_days), 2)
		prorated_base_salary = round((base_salary * payment_days) / working_days, 2)
	else:
		prorated_base_salary = base_salary

	if payment_days <= 0:
		prorated_sixty_percent = sixty_percent_of_base
		prorated_min_wage = min_wage
	else:
		prorated_sixty_percent = round(sixty_percent_of_base * pro_rate_factor, 2)

	
	# APPLY MINIMUM WAGE FOR FORMULA-BASED STRUCTURE *OR* OUTSOURCED
	is_base_structure = is_base_salary_structure(doc.salary_structure) or is_flexi_structure

	if (
		is_base_structure
		and not is_osbs_structure
		and min_wage > 0
		and (
			prorated_sixty_percent < prorated_min_wage
			or (sixty_percent_of_base >= min_wage and sixty_percent_of_base <= bonus_limit_amount)
		)
	):
		if prorated_sixty_percent < prorated_min_wage:
			new_basic = min_wage
		else:
			new_basic = sixty_percent_of_base

		if new_basic <= bonus_limit_amount:
			effective_bonus_ceiling = max(bonus_ceiling_amount, min_wage)
			bonus_reference_basic = min_wage
			bonus_base = min(bonus_reference_basic, effective_bonus_ceiling)
			bonus_gross = bonus_base * bonus_percentage
			advance_bonus = bonus_gross - (bonus_ceiling_amount * bonus_percentage)
			if advance_bonus < 0:
				advance_bonus = 0
		else:
			advance_bonus = 0

		if new_basic > bonus_limit_amount and min_wage > sixty_percent_of_base:
			extra_basic = new_basic - sixty_percent_of_base
			new_hra = hra_amount - extra_basic
		else:
			new_hra = base_salary - new_basic - advance_bonus

		doc.custom_mw_basic_entitlement = round(new_basic, 2)
		doc.custom_mw_hra_entitlement = round(new_hra, 2)
		doc.custom_mw_advance_bonus_entitlement = round(advance_bonus, 2)

		new_basic = round(new_basic * pro_rate_factor, 2)
		new_hra = round(new_hra * pro_rate_factor, 2)
		advance_bonus = round(advance_bonus * pro_rate_factor, 2)

		other_deduction_amount = 0

		if new_hra < 0:
			other_deduction_amount = abs(new_hra)
			new_hra = 0

		frappe.msgprint("DEBUG → new_hra=" + str(new_hra) + " | other_deduction_amount=" + str(other_deduction_amount))

		bonus_found = False

		for row in doc.earnings:
			if row.salary_component == "Basic":
				row.amount = round(new_basic, 2)
				basic_amount = frappe.utils.flt(row.amount)
				actual_basic_for_pf = frappe.utils.flt(doc.custom_mw_basic_entitlement or new_basic)

			elif row.salary_component == "House Rent Allowance":
				row.amount = round(new_hra, 2)
				hra_amount = frappe.utils.flt(row.amount)

			elif row.salary_component == "Advance Bonus":
				row.amount = round(advance_bonus, 2)
				bonus_found = True

			elif row.salary_component == "Special Allowance":
				is_manual_structure = is_manual_salary_structure(doc.salary_structure)
				if is_manual_structure:
					special_allowance = frappe.utils.flt(row.amount)
				else:
					row.amount = round(frappe.utils.flt(row.amount) * pro_rate_factor, 2)
					special_allowance = frappe.utils.flt(row.amount)

			elif row.salary_component not in ["Basic", "House Rent Allowance", "Advance Bonus", "Employer PF", "Employer ESI", "Gratuity"]:
				row.default_amount = round(row.amount or 0, 2)

				if payment_days > 0 and payment_days < working_days:
					if row.salary_component not in ONE_TIME_COMPONENTS:
						row.amount = round((row.amount or 0) * pro_rate_factor, 2)

		if not bonus_found:
			doc.append("earnings", {"salary_component": "Advance Bonus", "amount": round(advance_bonus, 2)})

		frappe.msgprint(
			"MIN WAGE OVERRIDE APPLIED"
			+ " | State=" + str(employee_state)
			+ " | Min Wage=" + str(min_wage)
			+ " | Base=" + str(base_salary)
			+ " | ProRateFactor=" + str(round(pro_rate_factor, 4))
			+ " | 60%Base(full)=" + str(sixty_percent_of_base)
			+ " | 60%Base(pror)=" + str(prorated_sixty_percent)
			+ " | PrMinWage=" + str(prorated_min_wage)
			+ " | Basic(ent)=" + str(doc.custom_mw_basic_entitlement)
			+ " | Basic(earned)=" + str(new_basic)
			+ " | Bonus(ent)=" + str(doc.custom_mw_advance_bonus_entitlement)
			+ " | Bonus(earned)=" + str(advance_bonus)
			+ " | HRA(ent)=" + str(doc.custom_mw_hra_entitlement)
			+ " | HRA(earned)=" + str(new_hra)
		)

	else:
		rows_to_remove = []
		for row in doc.earnings:
			if row.salary_component == "Advance Bonus":
				rows_to_remove.append(row)
		for row in rows_to_remove:
			doc.earnings.remove(row)

		doc.custom_mw_basic_entitlement = 0
		doc.custom_mw_hra_entitlement = 0
		doc.custom_mw_advance_bonus_entitlement = 0

		basic_amount = 0
		hra_amount = 0
		special_allowance = 0

		for row in doc.earnings:
			if not is_manual_structure:
				if row.salary_component in ["Employer PF", "Employer ESI", "Gratuity"]:
					continue

				row.default_amount = round(row.amount or 0, 2)

				if payment_days > 0 and payment_days < working_days:
					if row.salary_component not in ONE_TIME_COMPONENTS:
						row.amount = round((row.amount or 0) * pro_rate_factor, 2)

			if row.salary_component == "Basic":
				basic_amount = frappe.utils.flt(row.amount)
				actual_basic_for_pf = frappe.utils.flt(row.default_amount or row.amount)
			elif row.salary_component == "House Rent Allowance":
				hra_amount = frappe.utils.flt(row.amount)
			elif row.salary_component == "Special Allowance":
				special_allowance = frappe.utils.flt(row.amount)

	# STEP C: PF Calculation
	basic_for_pf = float(basic_amount)
	spall_for_pf = float(special_allowance)

	if basic_for_pf < pf_ceiling_amount:
		pf_wage = min(basic_for_pf + spall_for_pf, pf_ceiling_amount)
	else:
		pf_wage = basic_for_pf

	# --- after ---
	if is_driver and is_manual_structure:      # NEW: Drivers on Manual structure -- no PF at all
		skip_pf = True
	elif pf_applicable == "No" and actual_basic_for_pf > pf_ceiling_amount:
		skip_pf = True
	else:
		skip_pf = False

	employer_pf_this_calc = 0   # NEW: default, overridden below when PF actually applies

	if skip_pf:
		for row in doc.deductions:
			if row.salary_component == "Provident Fund":
				row.amount = 0
				break

		# CHANGED: no "Employer PF" earnings row exists/should exist
		# anymore -- nothing to zero out here.
		doc.custom_pf_basis = 0

	else:
		if is_base_structure or is_manual_structure:
			pf_rate = OSBS_PF_RATE if is_osbs_structure else EMPLOYEE_PF_RATE_DEFAULT
			if pf_applicable == "Ceiling":
				pf_basis = min(pf_wage, pf_ceiling_amount)
				total_pf = min(round(pf_basis * pf_rate, 0), round(pf_ceiling_amount * pf_rate, 0))
			elif pf_applicable == "Yes":
				pf_basis = pf_wage
				total_pf = round(pf_basis * pf_rate, 0)
			else:
				pf_basis = pf_wage
				total_pf = round(pf_basis * pf_rate, 0)
		else:
			pf_basis = 0
			total_pf = 0

		pf_row = None
		for row in doc.deductions:
			if row.salary_component == "Provident Fund":
				pf_row = row
				break

		if not pf_row:
			pf_row = doc.append("deductions", {"salary_component": "Provident Fund", "amount": 0})

		pf_row.amount = total_pf
		doc.custom_pf_basis = pf_basis

		# CHANGED: Employer PF is captured into a variable, never
		# added to doc.earnings -- on Manual structure, ZZ Fixed
		# Component never rebuilds earnings, so an appended row would
		# stay visible on the slip permanently instead of being
		# whitelisted away like it is on Base structure.
		# Employer PF rate:
		# OSBS = 12%
		# All other applicable structures = 13%
		employer_pf_rate = (
			OSBS_PF_RATE
			if is_osbs_structure
			else EMPLOYER_PF_RATE_DEFAULT
		)

		employer_pf_this_calc = round(pf_basis * employer_pf_rate, 0)

	# Final cleanup — runs always
	doc.earnings = [r for r in doc.earnings if r.salary_component]
	doc.deductions = [r for r in doc.deductions if r.salary_component]

	# FINAL NEGATIVE HRA → ACCOM (runs always)
	doc.deductions = [r for r in doc.deductions if r.salary_component != "Other Deductions"]

	if other_deduction_amount > 0:
		accom_found = False
		for row in doc.deductions:
			if row.salary_component == "ACCOM":
				row.amount = round(other_deduction_amount, 2)
				accom_found = True
				break

		if not accom_found:
			doc.append("deductions", {"salary_component": "ACCOM", "amount": round(other_deduction_amount, 2)})

	else:
		cleaned_deductions = []
		for row in doc.deductions:
			if row.salary_component != "ACCOM":
				cleaned_deductions.append(row)
		doc.set("deductions", cleaned_deductions)

	frappe.msgprint(
		"FINAL DEDUCTIONS → "
		+ str([r.salary_component + "=" + str(r.amount) for r in doc.deductions])
	)

	# RECALCULATE TOTALS (runs always)
	total_earnings = sum(float(row.amount or 0) for row in doc.earnings)
	total_deductions = sum(float(row.amount or 0) for row in doc.deductions)

	doc.gross_pay = round(total_earnings, 2)
	doc.total_deduction = round(total_deductions, 2)
	doc.net_pay = round(doc.gross_pay - doc.total_deduction, 2)

	# CHANGED: read from the local variable set above, not from
	# doc.earnings -- there is no "Employer PF" earnings row anymore.
	employer_pf_this_month = employer_pf_this_calc

	slip_end_pf = frappe.utils.getdate(doc.end_date)
	fy_start_year_pf = slip_end_pf.year if slip_end_pf.month >= 4 else slip_end_pf.year - 1
	fy_start_date_pf = frappe.utils.getdate(str(fy_start_year_pf) + "-04-01")

	prev_employer_pf = frappe.db.sql("""
		SELECT COALESCE(SUM(custom_employer_pf_amount), 0)
		FROM `tabSalary Slip`
		WHERE employee = %s
		  AND docstatus = 1
		  AND end_date >= %s
		  AND end_date < %s
		  AND name != %s
	""", (doc.employee, fy_start_date_pf, slip_end_pf, doc.name or ""))[0][0] or 0

	doc.custom_employer_pf_amount = round(employer_pf_this_month, 2)
	doc.custom_employer_pf_ytd = round(prev_employer_pf + employer_pf_this_month, 2)

def apply_ex_gratia_provision(doc, method=None):
	"""
	Ex-Gratia is an accrued provision, paid out separately.
	Skipped for OSBS salary structure.
	"""

	salary_structure = doc.salary_structure or ""

	# Skip Ex-Gratia calculation for OSBS (and its flexi structure)
	if salary_structure == OSBS_SALARY_STRUCTURE or is_flexi_salary_structure(salary_structure):
		doc.custom_ex_gratia_amount = 0
		doc.custom_ex_gratia_ytd = 0
		return

	if not doc.employee:
		return

	final_basic = 0
	final_adv_bonus = 0
	for row in doc.earnings:
		comp = str(row.salary_component or "").strip()
		if comp == "Basic":
			final_basic = row.amount or 0
		elif comp == "Advance Bonus":
			final_adv_bonus = row.amount or 0

	# CHANGED: effective-dated lookup, same as apply_pf_epf_eps_split.
	# doc.end_date is used here too, so a slip recalculated for a past
	# period picks up whatever ceiling was in force during that period,
	# not whatever is current right now.
	bonus_ceiling_amount = int(get_component_value("Bonus Ceiling Amount", doc.end_date) or 7000)

	bonus_doc = frappe.get_all(
		"Bonus Payable",
		filters={"company": doc.company},
		fields=["bonus_payable_percentage"],
		limit=1
	)
	bonus_percentage = (
		float(bonus_doc[0].get("bonus_payable_percentage") or 20) / 100
		if bonus_doc else 0.20
	)

	base_component = (
		final_basic * bonus_percentage
		if final_basic < bonus_ceiling_amount
		else bonus_ceiling_amount * bonus_percentage
	)
	ex_gratia_this_month = base_component
	if ex_gratia_this_month < 0:  # ASSUMPTION: floor at 0 -- confirm this is right
		ex_gratia_this_month = 0
	ex_gratia_this_month = round(ex_gratia_this_month, 2)

	# Strip any "Ex-Gratia" row the Salary Structure formula already
	# injected -- it's no longer a payable line item.
	had_exgratia_row = False
	remaining_earnings = []
	for row in doc.earnings:
		if str(row.salary_component or "").strip() == "Ex-Gratia":
			had_exgratia_row = True
			continue
		remaining_earnings.append(row)
	doc.set("earnings", remaining_earnings)

	if had_exgratia_row:
		doc.gross_pay = round(sum(float(r.amount or 0) for r in doc.earnings), 2)
		doc.base_gross_pay = doc.gross_pay
		doc.total_deduction = round(sum(float(r.amount or 0) for r in doc.deductions), 2)
		doc.base_total_deduction = doc.total_deduction
		doc.net_pay = round(doc.gross_pay - doc.total_deduction, 2)
		doc.base_net_pay = doc.net_pay
		doc.rounded_total = round(doc.net_pay)
		doc.base_rounded_total = doc.rounded_total

	# FY-to-date total -- recomputed fresh from already-SUBMITTED slips
	# each time (same pattern as your TDS true-up), never incrementally
	# added to a running counter, so repeated validate() calls before
	# submit never double-count.
	slip_end = frappe.utils.getdate(doc.end_date)
	fy_start_year = slip_end.year if slip_end.month >= 4 else slip_end.year - 1
	fy_start_date = frappe.utils.getdate(str(fy_start_year) + "-04-01")

	prev_total = frappe.db.sql("""
		SELECT COALESCE(SUM(custom_ex_gratia_amount), 0)
		FROM `tabSalary Slip`
		WHERE employee = %s
		  AND docstatus = 1
		  AND end_date >= %s
		  AND end_date < %s
		  AND name != %s
	""", (doc.employee, fy_start_date, slip_end, doc.name or ""))[0][0] or 0

	doc.custom_ex_gratia_amount = ex_gratia_this_month
	doc.custom_ex_gratia_ytd = round(prev_total + ex_gratia_this_month, 2)
def apply_professional_tax(doc, method=None):
	"""was Server Script: Professional Tax State-wise Calculation (Before Save)
	Logic preserved exactly as original - review during regression."""

	if not doc.employee:
		return

	# ============================================================
	# STEP 0: PURGE BLANK ROWS
	# ============================================================
	clean_deductions = []
	for row in doc.deductions:
		if str(row.salary_component or "").strip():
			clean_deductions = clean_deductions + [row]
	doc.deductions = clean_deductions

	clean_earnings = []
	for row in doc.earnings:
		if str(row.salary_component or "").strip():
			clean_earnings = clean_earnings + [row]
	doc.earnings = clean_earnings

	# ============================================================
	# PT/LWF GROSS — USE ACTUAL EARNED SALARY SLIP EARNINGS
	# ============================================================
	gross = 0

	exclude_components = [
		"Employer PF",
		"Employer ESI",
		"Gratuity",
		"Leave Encashment",
		"Ex-Gratia"
	]

	for row in doc.earnings:
		comp_name = row.salary_component or ""

		if comp_name in exclude_components:
			continue

		comp_flags = frappe.db.get_value(
			"Salary Component",
			comp_name,
			["do_not_include_in_total", "statistical_component"],
			as_dict=True
		)

		if comp_flags and (comp_flags.do_not_include_in_total or comp_flags.statistical_component):
			continue

		gross = gross + (row.amount or 0)

	pt_amount = 0
	lwf_amount = 0

	# STEP 1: FETCH EMPLOYEE STATE
	employee_state = frappe.db.get_value("Employee", doc.employee, "custom_state") or ""
	employee_state = str(employee_state).strip()

	# STEP 2: CURRENT MONTH FROM end_date
	current_month = 0
	if doc.end_date:
		date_parts = str(doc.end_date).split("-")
		if len(date_parts) >= 2:
			current_month = int(date_parts[1])

	# PROFESSIONAL TAX CALCULATION
	pt_rule_name = frappe.db.get_value(
		"Professional Tax Rule",
		{"state": employee_state, "is_active": 1},
		"name"
	)

	if pt_rule_name:
		pt_rule = frappe.get_doc("Professional Tax Rule", pt_rule_name)
		special_month = pt_rule.special_month or 0

		for slab in pt_rule.pt_slabs:
			from_amount = slab.from_amount or 0
			to_amount = slab.to_amount or 999999999

			if gross >= from_amount and gross <= to_amount:
				special_amount = slab.special_month_amount or 0

				if current_month == special_month and special_amount > 0:
					pt_amount = special_amount
				else:
					pt_amount = slab.pt_amount or 0

				break

	# LWF CALCULATION
	lwf_config = frappe.db.get_value(
		"LWF Configuration",
		{"state": employee_state, "is_active": 1},
		["employee_type", "employee_amount", "employee_percentage", "employee_max_cap"],
		as_dict=True
	)

	if lwf_config:
		if lwf_config.employee_type == "Fixed":
			lwf_amount = lwf_config.employee_amount or 0

		elif lwf_config.employee_type == "Percentage":
			percentage = lwf_config.employee_percentage or 0
			lwf_amount = round(gross * (percentage / 100), 0)
			max_cap = lwf_config.employee_max_cap or 0
			if max_cap > 0 and lwf_amount > max_cap:
				lwf_amount = max_cap

	# STEP 3: FETCH abbr FROM SALARY COMPONENT MASTER
	pt_abbr = frappe.db.get_value("Salary Component", "Professional Tax", "salary_component_abbr") or "PT"
	lwf_abbr = frappe.db.get_value("Salary Component", "LWF", "salary_component_abbr") or "LWF"

	# STEP 4: UPDATE PT ROW IN PLACE
	pt_found = False

	for row in doc.deductions:
		if row.salary_component == "Professional Tax":
			row.amount = round(pt_amount, 2)
			row.default_amount = round(pt_amount, 2)
			row.abbr = pt_abbr
			pt_found = True
			break

	if not pt_found and pt_amount > 0:
		doc.append("deductions", {
			"salary_component": "Professional Tax",
			"abbr": pt_abbr,
			"amount": round(pt_amount, 2),
			"default_amount": round(pt_amount, 2)
		})

	# STEP 5: UPDATE LWF ROW IN PLACE
	lwf_found = False

	for row in doc.deductions:
		if row.salary_component == "LWF":
			row.amount = round(lwf_amount, 2)
			row.default_amount = round(lwf_amount, 2)
			row.abbr = lwf_abbr
			lwf_found = True
			break

	if not lwf_found and lwf_amount > 0:
		doc.append("deductions", {
			"salary_component": "LWF",
			"abbr": lwf_abbr,
			"amount": round(lwf_amount, 2),
			"default_amount": round(lwf_amount, 2)
		})

	# STEP 6: RECALCULATE TOTAL DEDUCTION
	total_deduction = 0
	for row in doc.deductions:
		total_deduction = total_deduction + (row.amount or 0)
	doc.total_deduction = round(total_deduction, 2)

	# STEP 7: RECALCULATE NET PAY
	doc.net_pay = round((doc.gross_pay or 0) - total_deduction, 2)
	doc.base_net_pay = doc.net_pay
	doc.rounded_total = round(doc.net_pay)
	doc.base_rounded_total = doc.rounded_total

	# STEP 8: DEBUG
	frappe.msgprint(
		"PT-LWF Debug"
		+ "<br><b>State:</b> " + str(employee_state)
		+ "<br><b>Gross:</b> " + str(gross)
		+ "<br><b>PT:</b> " + str(pt_amount)
		+ "<br><b>PT Abbr:</b> " + str(pt_abbr)
		+ "<br><b>LWF:</b> " + str(lwf_amount)
		+ "<br><b>LWF Abbr:</b> " + str(lwf_abbr)
	) 


def apply_dynamic_esi(doc, method=None):
	"""was Server Script: 05 DYNAMIC ESI CALCULATION (Before Save)
	OFFICIAL ESIC RULE
	Logic preserved exactly as original - review during regression.
	NOTE: this step has DB write side-effects (creates Employee ESI Coverage
	records), not just doc mutation - relevant for testing."""

	if not (doc.employee and doc.end_date):
		return

	# STEP 0: BUILD CLEAN ESIC GROSS
	basic_amount = 0
	for earn_row in doc.earnings:
		if (earn_row.salary_component or "").strip() == "Basic":
			basic_amount = round(earn_row.amount or 0, 2)
			break

	actual_basic = 0
	employee = doc.employee

	# DETECT MANUAL STRUCTURE
	ssa_name = frappe.db.get_value(
		"Salary Structure Assignment",
		{"employee": employee, "docstatus": 1, "from_date": ["<=", doc.end_date]},
		"name",
		order_by="from_date desc"
	)

	manual_count = 0
	if ssa_name:
		manual_count = frappe.db.sql("""
			SELECT COUNT(*) FROM `tabManual Salary Component` WHERE parent=%s
		""", (ssa_name,))[0][0]

	if manual_count > 0:
		manual_rows = frappe.db.sql("""
			SELECT salary_component, amount
			FROM `tabManual Salary Component`
			WHERE parent=%s AND component_type='Earning'
		""", (ssa_name,), as_dict=True)

		for r in manual_rows:
			if (r.salary_component or "").strip() == "Basic":
				actual_basic = r.amount or 0
				break

	else:
		for earn_row in doc.earnings:
			if (earn_row.salary_component or "").strip() == "Basic":
				payment_days = doc.payment_days or 0
				total_days = doc.total_working_days or 0

				if payment_days > 0 and total_days > 0:
					actual_basic = (earn_row.amount or 0) * total_days / payment_days
				else:
					actual_basic = earn_row.amount or 0
				break

	# STEP 1: GET ACTIVE ESI RULE
	esi_rule = frappe.db.get_value(
		"ESI Rule",
		{"is_active": 1},
		["wage_limit", "employee_rate", "employer_rate"],
		as_dict=1
	)

	if not esi_rule:
		return

	# STEP 2: GET MONTH/YEAR
	date_parts = str(doc.end_date).split("-")
	year = int(date_parts[0])
	month = int(date_parts[1])

	# STEP 3: CONTRIBUTION PERIOD
	if month >= 4 and month <= 9:
		period_start = str(year) + "-04-01"
		period_end = str(year) + "-09-30"
		contribution_period = "Apr-Sep " + str(year)
	elif month >= 10:
		period_start = str(year) + "-10-01"
		period_end = str(year + 1) + "-03-31"
		contribution_period = "Oct-Mar " + str(year + 1)
	else:
		period_start = str(year - 1) + "-10-01"
		period_end = str(year) + "-03-31"
		contribution_period = "Oct-Mar " + str(year)

	# STEP 4: CHECK EXISTING COVERAGE
	# --- after ---
	# NEW: Drivers on Manual Salary Structure -- no ESI at all
	# (employee or employer side). Skips even the Employee ESI
	# Coverage insert, since this employee was never eligible under
	# this policy to begin with.
	designation = (frappe.db.get_value("Employee", doc.employee, "designation") or "").strip().upper()
	is_manual_structure_for_esi = is_manual_salary_structure(doc.salary_structure)
	is_driver_manual_no_esi = (designation in NO_PF_ESI_DESIGNATIONS_ON_MANUAL and is_manual_structure_for_esi)

	eligible = 0

	if is_driver_manual_no_esi:
		pass   # eligible stays 0 -- no coverage lookup/insert, no ESIC/Employer ESI
	else:
		# STEP 4: CHECK EXISTING COVERAGE
		coverage = frappe.db.get_value(
			"Employee ESI Coverage",
			{
				"employee": doc.employee,
				"period_start": ["<=", doc.end_date],
				"period_end": [">=", doc.end_date],
				"is_active": 1
			},
			["name", "esi_eligible"],
			as_dict=1
		)

		if coverage:
			eligible = coverage.esi_eligible or 0
		else:
			wage_limit = esi_rule.wage_limit or 0
			if actual_basic <= wage_limit:
				eligible = 1

			coverage_doc = frappe.get_doc({
				"doctype": "Employee ESI Coverage",
				"employee": doc.employee,
				"contribution_period": contribution_period,
				"period_start": period_start,
				"period_end": period_end,
				"esi_eligible": eligible,
				"wage_at_entry": round(actual_basic, 2),
				"is_active": 1
			})

			coverage_doc.insert(ignore_permissions=True)

	# STEP 5: CALCULATE ESI AMOUNT (employee side)
	employee_esi = 0

	if eligible:
		esi_amount = basic_amount * ((esi_rule.employee_rate or 0) / 100)
		employee_esi = int(esi_amount)

		if esi_amount > employee_esi:
			employee_esi += 1

	
	# STEP 5b: CALCULATE EMPLOYER ESI (same eligibility gate,
	# employer_rate instead of employee_rate). CHANGED: this is NOT
	# added as an earnings row anymore -- for Manual Salary Structure
	# slips, the ZZ Fixed Component script never rebuilds `earnings`
	# (it's a no-op for Manual structures), so an appended row here
	# would stay visible on the slip forever, unlike Base structure
	# where ZZ's whitelist would eventually strip it. Compute once,
	# capture into the custom field below, never touch doc.earnings.
	employer_esi = 0

	if eligible:
		employer_esi_amount = basic_amount * ((esi_rule.employer_rate or 0) / 100)
		employer_esi = int(employer_esi_amount)

		if employer_esi_amount > employer_esi:
			employer_esi += 1

	# Defensive cleanup: strip any "Employer ESI" earnings row that
	# may already exist on this doc from a prior save cycle (before
	# this fix), so it doesn't linger on old drafts.
	had_esi_earn_row = False
	remaining_earnings = []
	for row in doc.earnings:
		if row.salary_component == "Employer ESI":
			had_esi_earn_row = True
			continue
		remaining_earnings.append(row)
	doc.set("earnings", remaining_earnings)

	# STEP 6: UPDATE ESIC ROW IN PLACE
	esic_row_found = False

	for row in doc.deductions:
		comp = (row.salary_component or "").strip()
		if comp == "ESIC":
			row.amount = round(employee_esi, 2)
			row.default_amount = round(employee_esi, 2)
			esic_row_found = True
			break

	if not esic_row_found:
		doc.append("deductions", {
			"salary_component": "ESIC",
			"amount": round(employee_esi, 2),
			"default_amount": round(employee_esi, 2)
		})

	# STEP 7: RECALCULATE TOTALS
	doc.gross_pay = round(sum(float(e.amount or 0) for e in doc.earnings), 2)   # NEW: Employer ESI earnings row changes gross
	doc.base_gross_pay = doc.gross_pay                                          # NEW

	doc.total_deduction = round(sum(float(d.amount or 0) for d in doc.deductions), 2)
	doc.base_total_deduction = doc.total_deduction

	doc.net_pay = round((doc.gross_pay or 0) - doc.total_deduction, 2)
	doc.base_net_pay = doc.net_pay
	doc.rounded_total = round(doc.net_pay)
	doc.base_rounded_total = doc.rounded_total

	# NEW: capture Employer ESI into dedicated field + FY-to-date total,
	# reading from the earnings row just like custom_employer_pf_amount
	# reads from the "Employer PF" row -- same pattern, same reasoning
	# (won't survive ZZ's allowed_earnings whitelist otherwise).
	slip_end_esi = frappe.utils.getdate(doc.end_date)
	fy_start_year_esi = slip_end_esi.year if slip_end_esi.month >= 4 else slip_end_esi.year - 1
	fy_start_date_esi = frappe.utils.getdate(str(fy_start_year_esi) + "-04-01")

	prev_employer_esi = frappe.db.sql("""
		SELECT COALESCE(SUM(custom_employer_esi_amount), 0)
		FROM `tabSalary Slip`
		WHERE employee = %s
		  AND docstatus = 1
		  AND end_date >= %s
		  AND end_date < %s
		  AND name != %s
	""", (doc.employee, fy_start_date_esi, slip_end_esi, doc.name or ""))[0][0] or 0

	doc.custom_employer_esi_amount = round(employer_esi, 2)
	doc.custom_employer_esi_ytd = round(prev_employer_esi + employer_esi, 2)  


def apply_tds_validation(doc, method=None):
	"""
	PHASE 3: TDS Validation & Audit Logging — v3.3
	Cumulative "true-up" TDS projection, with:
	 - a repeat-TDS shortcut: if this month has no one-time
	   component AND its recurring gross matches the immediately
	   previous month's, TDS repeats from that previous month
	   instead of recomputing.
	 - a payment-days / LOP fix: if this month's payment_days is
	   less than total_working_days, this month's OWN gross
	   contribution to annual_gross still correctly reflects the
	   reduced actual pay, but the gross used to PROJECT future
	   months falls back to the most recent FULL-ATTENDANCE month's
	   recurring gross (walking backward through submitted slips,
	   not just the immediately previous one, since that month
	   could itself have had LOP too). If no full-attendance month
	   exists this FY, this month's reduced gross is normalized up
	   by its own attendance ratio as a last resort.
	Payroll cycle runs 26th-to-25th, so the slip's "month" is
	identified by END DATE, not start_date.
	Current month gross mirrors the "ZZ Salary Slip Fixed Component"
	script's definition of what actually survives onto the visible
	slip (allowed_earnings whitelist OR Additional Salary injected).
	Previous-month/fallback lookups trust already-submitted slips'
	Salary Detail as-is (no whitelist/additional_salary filtering),
	since the ZZ script wipes the additional_salary link on rebuild
	and has already curated what belongs on a submitted slip.
	"""

	earning_dump = []
	for e in doc.earnings:
		earning_dump.append(
			str(e.salary_component)
			+ " = " + str(e.amount)
			+ " | do_not_include_in_total=" + str(e.get("do_not_include_in_total"))
			+ " | statistical_component=" + str(e.get("statistical_component"))
		)
	# frappe.log_error("\n".join(earning_dump), "TDS Earnings Dump")

	employee = doc.employee
	employee_name = doc.employee_name
	net_pay = doc.net_pay or 0

	GROSS_MATCH_TOLERANCE = 1  # rupees, to absorb float rounding noise

	# ============================================================
	# STEP 0: FISCAL YEAR & PAYROLL MONTH NUMBER (based on end_date)
	# ============================================================
	slip_end = frappe.utils.getdate(doc.end_date)

	if slip_end.month >= 4:
		fy_start_year = slip_end.year
	else:
		fy_start_year = slip_end.year - 1

	fy_start_date = frappe.utils.getdate(str(fy_start_year) + "-04-01")
	fy_end_date = frappe.utils.getdate(str(fy_start_year + 1) + "-03-31")

	if slip_end.month >= 4:
		payroll_month_number = slip_end.month - 3
	else:
		payroll_month_number = slip_end.month + 9

	remaining_payroll_months = 13 - payroll_month_number
	if remaining_payroll_months < 1:
		remaining_payroll_months = 1

	# ============================================================
	# STEP 1: GET SALARY STRUCTURE ASSIGNMENT (for tax slab only)
	# ============================================================
	income_tax_slab = None
	salary_structure_name = None
	ssa_from_date = None

	ssa = frappe.db.sql("""
		SELECT income_tax_slab, salary_structure, from_date
		FROM `tabSalary Structure Assignment`
		WHERE employee = %s
		  AND docstatus = 1
		  AND from_date <= %s
		ORDER BY from_date DESC
		LIMIT 1
	""", (employee, doc.end_date), as_dict=True)

	if ssa:
		income_tax_slab = ssa[0].get("income_tax_slab")
		salary_structure_name = ssa[0].get("salary_structure")
		ssa_from_date = ssa[0].get("from_date")

	if not income_tax_slab:
		frappe.msgprint(
			"Income Tax Slab not set on Salary Structure Assignment!"
			+ "\nEmployee: " + employee_name + " (" + employee + ")"
			+ "\nSalary Structure: " + str(salary_structure_name or "Not Found")
			+ "\nSSA From Date: " + str(ssa_from_date or "N/A"),
			title="Income Tax Slab Missing",
			indicator="red"
		)
		# frappe.log_error(
		# 	message="Income Tax Slab missing on SSA | Employee: " + employee,
		# 	title="TDS Config Error"
		# )

	# ============================================================
	# STEP 2: GET SLAB METADATA
	# ============================================================
	standard_deduction = 0
	allow_tax_exemption = 0
	regime_label = "Unknown"

	if income_tax_slab:
		slab_meta = frappe.db.get_value(
			"Income Tax Slab",
			income_tax_slab,
			["standard_tax_exemption_amount", "allow_tax_exemption"],
			as_dict=True
		) or {}

		standard_deduction = slab_meta.get("standard_tax_exemption_amount") or 0
		allow_tax_exemption = slab_meta.get("allow_tax_exemption") or 0

		regime_label = ("Old Regime (" if allow_tax_exemption else "New Regime (") + income_tax_slab + ")"

	# ============================================================
	# FETCH TAX EXEMPTION DECLARATIONS (Old Regime only)
	# ============================================================
	declaration_total = 0
	hra_exemption_declared = 0
	monthly_rent = 0
	is_metro = 0

	if allow_tax_exemption:
		declaration = frappe.db.sql("""
			SELECT name
			FROM `tabEmployee Tax Exemption Declaration`
			WHERE employee = %s
			AND docstatus = 1
			LIMIT 1
		""", (employee,), as_dict=True)

		if declaration:
			declaration_doc = frappe.get_doc(
				"Employee Tax Exemption Declaration",
				declaration[0].name
			)
			declaration_total = declaration_doc.total_declared_amount or 0
			hra_exemption_declared = declaration_doc.total_exemption_amount or 0
			monthly_rent = declaration_doc.monthly_house_rent or 0
			is_metro = declaration_doc.rented_in_metro_city or 0

	# ============================================================
	# STEP 3: FETCH TAX SLAB ROWS
	# ============================================================
	slab_rows = []
	nil_tax_threshold = 0

	if income_tax_slab:
		slab_rows = frappe.db.sql("""
			SELECT from_amount, to_amount, percent_deduction
			FROM `tabTaxable Salary Slab`
			WHERE parent = %s
			ORDER BY from_amount ASC
		""", (income_tax_slab,), as_dict=True)

		for row in slab_rows:
			if (row.get("percent_deduction") or 0) == 0:
				nil_tax_threshold = row.get("to_amount") or 0
				break

	# ============================================================
	# STEP 5: CUMULATIVE GROSS PROJECTION (TRUE-UP METHOD)
	# ============================================================
	prev_gross_row = frappe.db.sql("""
		SELECT COALESCE(SUM(gross_pay), 0) as total_gross
		FROM `tabSalary Slip`
		WHERE employee = %s
		  AND docstatus = 1
		  AND end_date >= %s
		  AND end_date < %s
		  AND name != %s
	""", (
		employee, fy_start_date, slip_end, doc.name or ""
	), as_dict=True)

	actual_gross_previous_months = (prev_gross_row[0].total_gross or 0) if prev_gross_row else 0

	prev_tds_row = frappe.db.sql("""
		SELECT COALESCE(SUM(sd.amount), 0) as total_tds
		FROM `tabSalary Detail` sd
		INNER JOIN `tabSalary Slip` ss ON sd.parent = ss.name
		WHERE ss.employee = %s
		  AND ss.docstatus = 1
		  AND ss.end_date >= %s
		  AND ss.end_date < %s
		  AND ss.name != %s
		  AND sd.parentfield = 'deductions'
		  AND sd.salary_component = 'TDS'
	""", (
		employee, fy_start_date, slip_end, doc.name or ""
	), as_dict=True)

	tds_already_deducted = (prev_tds_row[0].total_tds or 0) if prev_tds_row else 0

	# Current month's own gross — mirrors the "ZZ Salary Slip Fixed
	# Component" script's definition of what actually survives onto
	# the visible slip. Intentionally reflects LOP/payment-days
	# reduction as-is, since annual_gross should include what was
	# ACTUALLY paid this month.
	ALLOWED_EARNINGS_FOR_SLIP = [
		"Basic",
		"House Rent Allowance",
		"Conveyance",
		"Child Education Allowance",
		"Uniform Allowance",
		"Advance Bonus",
	]
	# same exception as the ZZ step above: a flexi-structure slip's gross is its
	# Basic, HRA, FBP benefits and Special Allowance
	if is_flexi_salary_structure(doc.salary_structure):
		ALLOWED_EARNINGS_FOR_SLIP = ALLOWED_EARNINGS_FOR_SLIP + FLEXI_EARNING_COMPONENTS

	# current_month_gross = 0
	# for e in doc.earnings:
	# 	comp = str(e.salary_component or "").strip()
	# 	if not comp:
	# 		continue
	# 	if comp in ALLOWED_EARNINGS_FOR_SLIP or e.additional_salary:
	# 		current_month_gross += float(e.amount or 0)


	#18-08-2026
	is_manual_structure = is_manual_salary_structure(doc.salary_structure)

	current_month_gross = 0

	if is_manual_structure:
		# Manual structure slips: apply_manual_salary_structure_override
		# has already fully curated doc.earnings (its manual_rows
		# rebuild doesn't set additional_salary on genuine components
		# like Special Allowance / Education Scholarship, so the
		# whitelist/additional_salary filter used for base-structure
		# slips would silently drop real components here). Trust
		# doc.earnings as-is.
		for e in doc.earnings:
			comp = str(e.salary_component or "").strip()
			if not comp:
				continue
			current_month_gross += float(e.amount or 0)
	else:
		for e in doc.earnings:
			comp = str(e.salary_component or "").strip()
			if not comp:
				continue
			if comp in ALLOWED_EARNINGS_FOR_SLIP or e.additional_salary:
				current_month_gross += float(e.amount or 0)

	# Recurring gross for THIS month — strip configured one-time
	# components so we don't project bonuses/encashment forward.
	# one_time_amount_this_month = 0
	# for e in doc.earnings:
	# 	comp = str(e.salary_component or "").strip()
	# 	if not comp:
	# 		continue
	# 	is_on_slip = comp in ALLOWED_EARNINGS_FOR_SLIP or e.additional_salary
	# 	if is_on_slip and comp in ONE_TIME_COMPONENTS:
	# 		one_time_amount_this_month += (e.amount or 0)



	#18-08-2026
	one_time_amount_this_month = 0

	if is_manual_structure:
		for e in doc.earnings:
			comp = str(e.salary_component or "").strip()
			if not comp:
				continue
			if comp in ONE_TIME_COMPONENTS:
				one_time_amount_this_month += (e.amount or 0)
	else:
		for e in doc.earnings:
			comp = str(e.salary_component or "").strip()
			if not comp:
				continue
			is_on_slip = comp in ALLOWED_EARNINGS_FOR_SLIP or e.additional_salary
			if is_on_slip and comp in ONE_TIME_COMPONENTS:
				one_time_amount_this_month += (e.amount or 0)

	recurring_monthly_gross = current_month_gross - one_time_amount_this_month

	# ============================================================
	# STEP 5g: IMMEDIATELY PREVIOUS MONTH'S SLIP — for the
	# repeat-TDS shortcut only. Trusts Salary Detail as-is (no
	# whitelist/additional_salary filtering), one-time components
	# stripped by name.
	# ============================================================
	previous_month_slip = frappe.db.sql("""
		SELECT name, payment_days, total_working_days
		FROM `tabSalary Slip`
		WHERE employee = %s
		  AND docstatus = 1
		  AND end_date >= %s
		  AND end_date < %s
		  AND name != %s
		ORDER BY end_date DESC
		LIMIT 1
	""", (
		employee, fy_start_date, slip_end, doc.name or ""
	), as_dict=True)

	previous_month_recurring_gross = None
	previous_month_tds = None
	previous_month_had_lop = None

	if previous_month_slip:
		prev_slip_name = previous_month_slip[0].name
		prev_payment_days = previous_month_slip[0].payment_days or 0
		prev_total_working_days = previous_month_slip[0].total_working_days or 0

		previous_month_had_lop = (
			prev_total_working_days > 0
			and prev_payment_days > 0
			and prev_payment_days < prev_total_working_days
		)

		prev_earning_rows = frappe.db.sql("""
			SELECT salary_component, amount
			FROM `tabSalary Detail`
			WHERE parent = %s AND parentfield = 'earnings'
		""", (prev_slip_name,), as_dict=True)

		prev_current_gross = 0
		prev_one_time_amount = 0

		for e in prev_earning_rows:
			comp = str(e.salary_component or "").strip()
			if not comp:
				continue
			amt = e.amount or 0
			prev_current_gross += amt
			if comp in ONE_TIME_COMPONENTS:
				prev_one_time_amount += amt

		previous_month_recurring_gross = prev_current_gross - prev_one_time_amount

		prev_tds_deduction_row = frappe.db.sql("""
			SELECT amount
			FROM `tabSalary Detail`
			WHERE parent = %s AND parentfield = 'deductions' AND salary_component = 'TDS'
			LIMIT 1
		""", (prev_slip_name,), as_dict=True)

		previous_month_tds = (prev_tds_deduction_row[0].amount or 0) if prev_tds_deduction_row else 0

	# ============================================================
	# STEP 5h: PAYMENT-DAYS / LOP CHECK -> PROJECTION BASELINE
	# If this month has LOP, future months must be projected using
	# the RECURRING GROSS OF THE MOST RECENT FULL-ATTENDANCE MONTH --
	# not just the immediately previous month, since that month
	# itself might also have had LOP. Walk backward through this
	# FY's submitted slips, most recent first, until a
	# full-attendance month is found.
	# ============================================================
    



    # Ensure the Attendance LWP Bridge has actually run before we read
	# payment_days/absent_days/leave_without_pay. This is the function
	# that computes the AUTHORITATIVE values for this environment (from
	# Monthly Attendance Tracker + Leave Ledger) -- not ERPNext's core
	# logic. If hook ordering in hooks.py ever puts this script before
	# the bridge, this guard forces it to run now instead of silently
	# reading stale pre-bridge values. Guarded by a flag so it never
	# runs twice in one save cycle (the bridge has DB side-effects --
	# creating Leave Applications, updating Attendance status -- so it
	# must not be invoked more than once per save).
	if not doc.flags.get("lwp_bridge_applied"):
		apply_attendance_lwp_bridge(doc)

	raw_payment_days = doc.payment_days or 0
	total_working_days = doc.total_working_days or 0
	absent_days = doc.absent_days or 0
	leave_without_pay = doc.leave_without_pay or 0



    
    # Don't trust doc.payment_days blindly -- independently recompute
	# it from the same authoritative source fields (total_working_days,
	# absent_days, leave_without_pay) that ERPNext itself derives
	# Payment Days from. This guards against reading a not-yet-finalized
	# client-side prefill value in case of any hook-ordering edge case,
	# and logs both figures side by side so a genuine mismatch is
	# immediately visible in the audit trail rather than silently
	# producing a wrong LOP flag.
	# raw_payment_days = doc.payment_days or 0
	# total_working_days = doc.total_working_days or 0
	# absent_days = doc.absent_days or 0
	# leave_without_pay = doc.leave_without_pay or 0

	recomputed_payment_days = total_working_days - absent_days - leave_without_pay
	if recomputed_payment_days < 0:
		recomputed_payment_days = 0
	if total_working_days > 0 and recomputed_payment_days > total_working_days:
		recomputed_payment_days = total_working_days

	payment_days_mismatch = abs(raw_payment_days - recomputed_payment_days) > 0.01

	payment_days = recomputed_payment_days

	has_lop_this_month = (
		total_working_days > 0
		and payment_days > 0
		and payment_days < total_working_days
	)


	#payment_days = doc.payment_days or 0
	# total_working_days = doc.total_working_days or 0
	# has_lop_this_month = (
	# 	total_working_days > 0
	# 	and payment_days > 0
	# 	and payment_days < total_working_days
	# )

	projection_gross = recurring_monthly_gross
	lop_adjustment_note = "None"
	lop_fallback_slip_used = None

	if has_lop_this_month:

		candidate_slips = frappe.db.sql("""
			SELECT name, payment_days, total_working_days
			FROM `tabSalary Slip`
			WHERE employee = %s
			  AND docstatus = 1
			  AND end_date >= %s
			  AND end_date < %s
			  AND name != %s
			ORDER BY end_date DESC
		""", (
			employee, fy_start_date, slip_end, doc.name or ""
		), as_dict=True)

		full_attendance_slip_name = None

		for cand in candidate_slips:
			cand_payment_days = cand.payment_days or 0
			cand_total_working_days = cand.total_working_days or 0
			if cand_total_working_days > 0 and cand_payment_days >= cand_total_working_days:
				full_attendance_slip_name = cand.name
				break

		if full_attendance_slip_name:
			fallback_rows = frappe.db.sql("""
				SELECT salary_component, amount
				FROM `tabSalary Detail`
				WHERE parent = %s AND parentfield = 'earnings'
			""", (full_attendance_slip_name,), as_dict=True)

			fallback_gross = 0
			fallback_one_time = 0
			for e in fallback_rows:
				comp = str(e.salary_component or "").strip()
				if not comp:
					continue
				amt = e.amount or 0
				fallback_gross += amt
				if comp in ONE_TIME_COMPONENTS:
					fallback_one_time += amt

			projection_gross = fallback_gross - fallback_one_time
			lop_fallback_slip_used = full_attendance_slip_name
			lop_adjustment_note = (
				"LOP detected (payment_days=" + str(payment_days)
				+ "/" + str(total_working_days)
				+ ") -- projection uses most recent full-attendance month's recurring gross ("
				+ full_attendance_slip_name + ")"
			)
		else:
			# No full-attendance month exists this FY to reference
			# (e.g. this is the very first slip ever, with LOP).
			# Do NOT scale up by the attendance ratio -- that
			# overcorrects and produces an inflated, unrealistic
			# projection (e.g. 5/30 days would multiply gross by 6x).
			# Simply use this month's own recurring gross as-is;
			# it will self-correct via true-up in later months once
			# a full-attendance month establishes a real baseline.
			projection_gross = recurring_monthly_gross
			lop_adjustment_note = (
				"LOP detected (payment_days=" + str(payment_days)
				+ "/" + str(total_working_days)
				+ ") -- no full-attendance month found this FY, using this month's own recurring gross as projection baseline (no scaling)"
			)

	months_after_current = remaining_payroll_months - 1
	if months_after_current < 0:
		months_after_current = 0

	projected_remaining_gross = projection_gross * months_after_current

	annual_gross = (
		actual_gross_previous_months
		+ current_month_gross
		+ projected_remaining_gross
	)

	gross_pay = current_month_gross
    


    # 18-08-2026
	# ============================================================
	# STEP 5i: OLD REGIME-ONLY EXEMPTIONS
	# Uniform Allowance: entire annual amount fully exempt under
	# Old Regime, mirroring the manual Excel workflow's treatment.
	#
	# Uses the same true-up + LOP-fallback projection approach as
	# overall gross: actual sum from prior submitted slips + this
	# month's actual amount (LOP-reduced as-is, since that's what
	# was genuinely paid/exempt this month) + a PROJECTION amount
	# for remaining months. If this month has LOP, the projection
	# amount comes from the same most-recent full-attendance slip
	# (lop_fallback_slip_used, already found in Step 5h) rather than
	# this month's reduced figure.
	# ============================================================

	def _project_annual_component(component_name, parentfield):
		prev_row = frappe.db.sql("""
			SELECT COALESCE(SUM(sd.amount), 0) as total
			FROM `tabSalary Detail` sd
			INNER JOIN `tabSalary Slip` ss ON sd.parent = ss.name
			WHERE ss.employee = %s
			  AND ss.docstatus = 1
			  AND ss.end_date >= %s
			  AND ss.end_date < %s
			  AND ss.name != %s
			  AND sd.parentfield = %s
			  AND sd.salary_component = %s
		""", (
			employee, fy_start_date, slip_end, doc.name or "",
			parentfield, component_name
		), as_dict=True)
		prev_total = prev_row[0].total or 0

		current_amount = 0
		rows = doc.earnings if parentfield == "earnings" else doc.deductions
		for r in rows:
			if str(r.salary_component or "").strip() == component_name:
				current_amount += (r.amount or 0)

		if has_lop_this_month and lop_fallback_slip_used:
			fallback_amt = frappe.db.get_value(
				"Salary Detail",
				{
					"parent": lop_fallback_slip_used,
					"parentfield": parentfield,
					"salary_component": component_name,
				},
				"amount"
			) or 0
			projection_amount = fallback_amt
		else:
			projection_amount = current_amount

		remaining_after = remaining_payroll_months - 1
		if remaining_after < 0:
			remaining_after = 0

		return prev_total + current_amount + (projection_amount * remaining_after)

	uniform_allowance_annual = 0
	old_regime_extra_exemptions = 0

	if allow_tax_exemption:
		uniform_allowance_annual = _project_annual_component("Uniform Allowance", "earnings")
		old_regime_extra_exemptions = uniform_allowance_annual
		# Flexi Benefit Plan: bills HR has verified are exempt (old regime only)
		if is_flexi_salary_structure(doc.salary_structure):
			old_regime_extra_exemptions += get_verified_fbp_exemption(employee, fy_start_date)


	
    #24-08-2026
	# ============================================================
	# STEP 5j: OLD REGIME HRA EXEMPTION -- MONTH-WISE RECOMPUTE
	# Instead of a flat annual figure from the Declaration doc, this
	# mirrors the manual Excel workflow: for EACH month, HRA
	# exemption = MIN(cap% * that month's Basic, that month's actual
	# HRA received, monthly_rent - 10% * that month's Basic). Summed
	# across all 12 months. Actual Basic/HRA used for months with a
	# submitted slip; LOP-aware projection baseline (same
	# lop_fallback_slip_used as gross/Uniform Allowance) used for
	# months without one -- so a reduced-payment-days month doesn't
	# just get a flat exemption, and future months aren't dragged
	# down by that one reduced month either.
	# ============================================================

	def _compute_monthly_hra_exemption(basic_amt, hra_amt, rent, metro):
		cap_pct = 0.5 if metro else 0.4
		rent_limit = rent - (basic_amt * 0.10)
		if rent_limit < 0:
			rent_limit = 0
		return min(cap_pct * basic_amt, hra_amt, rent_limit)

	hra_exemption = hra_exemption_declared  # fallback if no rent declared

	if allow_tax_exemption and monthly_rent > 0:

		monthly_basic = {}
		monthly_hra = {}

		submitted_this_fy = frappe.db.sql("""
			SELECT ss.end_date, sd.salary_component, sd.amount
			FROM `tabSalary Slip` ss
			INNER JOIN `tabSalary Detail` sd ON sd.parent = ss.name
			WHERE ss.employee = %s
			  AND ss.docstatus = 1
			  AND ss.end_date >= %s
			  AND ss.end_date < %s
			  AND ss.name != %s
			  AND sd.parentfield = 'earnings'
			  AND sd.salary_component IN ('Basic', 'House Rent Allowance')
		""", (employee, fy_start_date, slip_end, doc.name or ""), as_dict=True)

		for r in submitted_this_fy:
			d = frappe.utils.getdate(r.end_date)
			m_no = d.month - 3 if d.month >= 4 else d.month + 9
			if r.salary_component == "Basic":
				monthly_basic[m_no] = monthly_basic.get(m_no, 0) + (r.amount or 0)
			else:
				monthly_hra[m_no] = monthly_hra.get(m_no, 0) + (r.amount or 0)

		current_basic = 0
		current_hra = 0
		for e in doc.earnings:
			comp = str(e.salary_component or "").strip()
			if comp == "Basic":
				current_basic += (e.amount or 0)
			elif comp == "House Rent Allowance":
				current_hra += (e.amount or 0)

		monthly_basic[payroll_month_number] = current_basic
		monthly_hra[payroll_month_number] = current_hra

		if has_lop_this_month and lop_fallback_slip_used:
			proj_basic = frappe.db.get_value(
				"Salary Detail",
				{"parent": lop_fallback_slip_used, "parentfield": "earnings", "salary_component": "Basic"},
				"amount"
			) or 0
			proj_hra = frappe.db.get_value(
				"Salary Detail",
				{"parent": lop_fallback_slip_used, "parentfield": "earnings", "salary_component": "House Rent Allowance"},
				"amount"
			) or 0
		else:
			proj_basic = current_basic
			proj_hra = current_hra

		annual_hra_exemption_recomputed = 0
		for m in range(1, 13):
			b = monthly_basic.get(m, proj_basic)
			h = monthly_hra.get(m, proj_hra)
			annual_hra_exemption_recomputed += _compute_monthly_hra_exemption(b, h, monthly_rent, is_metro)

		hra_exemption = annual_hra_exemption_recomputed

	# ============================================================
	# STEP 6: TAXABLE INCOME & TAX ON PROJECTED ANNUAL GROSS
	# ============================================================
	taxable_income = annual_gross - standard_deduction

	if allow_tax_exemption:
		taxable_income = taxable_income - hra_exemption - old_regime_extra_exemptions

	if taxable_income < 0:
		taxable_income = 0

	raw_tax = _compute_tax(taxable_income, slab_rows)

	# SECTION 87A REBATE
	rebate = 0
	if allow_tax_exemption:
		if taxable_income <= 500000:
			rebate = raw_tax
	else:
		if taxable_income <= 1200000:
			rebate = raw_tax
		elif (taxable_income - 1200000) < raw_tax:
			rebate = raw_tax - (taxable_income - 1200000)

	raw_tax = max(raw_tax - rebate, 0)

	# SURCHARGE
	# surcharge_rate = 0
	# rule_doc = frappe.get_doc("Income Tax Surcharge Rule")
	# regime_type = "Old" if income_tax_slab and "old regime" in str(income_tax_slab).lower() else "New"
	# surcharge_rows = rule_doc.old_regime_slabs if regime_type == "Old" else rule_doc.new_regime_slabs

	# for row in surcharge_rows:
	# 	from_amt = row.from_amount or 0
	# 	to_amt = row.to_amount or 999999999
	# 	if from_amt <= taxable_income <= to_amt:
	# 		surcharge_rate = row.surcharge_percentage or 0
	# 		break

	# raw_tax += raw_tax * surcharge_rate / 100


	#30-09-2026
	# SURCHARGE (with marginal relief)
	surcharge_rate = 0
	surcharge_from = None
	rule_doc = frappe.get_doc("Income Tax Surcharge Rule")
	surcharge_rows = rule_doc.old_regime_slabs if allow_tax_exemption else rule_doc.new_regime_slabs

	for row in surcharge_rows:
		from_amt = row.from_amount or 0
		to_amt = row.to_amount or 999999999
		if (from_amt - 1) < taxable_income <= to_amt:
			surcharge_rate = row.surcharge_percentage or 0
			surcharge_from = from_amt
			break

	surcharge = raw_tax * surcharge_rate / 100

	if surcharge_rate > 0:
		limit = surcharge_from - 1
		prev_rate = 0
		for row in surcharge_rows:
			if (row.to_amount or 0) == limit:
				prev_rate = row.surcharge_percentage or 0
				break
		tax_at_limit = _compute_tax(limit, slab_rows)
		tax_at_limit += tax_at_limit * prev_rate / 100
		max_allowed = tax_at_limit + (taxable_income - limit)
		if raw_tax + surcharge > max_allowed:
			surcharge = max(max_allowed - raw_tax, 0)

	raw_tax += surcharge
	

	# CESS
	total_annual_tax_projected = raw_tax + (raw_tax * 0.04)

	# ============================================================
	# STEP 7: TRUE-UP -> THIS MONTH'S TDS (fallback value)
	# ============================================================
	true_up_tds = (
		(total_annual_tax_projected - tds_already_deducted)
		/ remaining_payroll_months
	)

	if true_up_tds < 0:
		true_up_tds = 0

	true_up_tds = round(true_up_tds)

	# ============================================================
	# STEP 7b: DECIDE — REPEAT PREVIOUS MONTH'S TDS, OR TRUE-UP?
	# Only valid when THIS month has NO one-time component AND no
	# LOP. Otherwise always true-up.
	# ============================================================
	tds_method_used = "True-Up"

	this_month_has_one_time = one_time_amount_this_month > GROSS_MATCH_TOLERANCE

	if (
		not this_month_has_one_time
		and not has_lop_this_month
		and not previous_month_had_lop
		and previous_month_recurring_gross is not None
		and previous_month_tds is not None
		and abs(recurring_monthly_gross - previous_month_recurring_gross) <= GROSS_MATCH_TOLERANCE
	):
		expected_monthly_tds = round(previous_month_tds)
		tds_method_used = "Repeated (no one-time component this month, recurring gross unchanged from previous full-attendance month)"
	else:
		expected_monthly_tds = true_up_tds
		if this_month_has_one_time:
			tds_method_used = "True-Up (one-time component present this month: Rs " + str(one_time_amount_this_month) + ")"
		elif has_lop_this_month:
			tds_method_used = "True-Up (LOP present this month: payment_days=" + str(payment_days) + "/" + str(total_working_days) + ")"
		elif previous_month_had_lop:
			tds_method_used = "True-Up (previous month had LOP, so its TDS/gross is not a reliable repeat baseline)"
	# ============================================================
	# EXTRACT ACTUAL TDS
	# ============================================================
	tds_amount = 0
	for d in doc.deductions:
		if d.salary_component == "TDS":
			tds_amount = d.amount or 0
			break

	if tds_amount < 0:
		frappe.throw(
			"TDS cannot be negative!"
			+ " | Employee: " + employee_name
			+ " | Regime: " + regime_label
		)

	# VALIDATION 2: ZERO TDS ALERT
	gross_after_std = annual_gross - standard_deduction
	if (income_tax_slab and nil_tax_threshold > 0 and gross_after_std > nil_tax_threshold
			and tds_amount == 0 and expected_monthly_tds > 5):
		frappe.msgprint(
			"Zero TDS Alert!"
			+ "\nEmployee: " + employee_name
			+ "\nRegime: " + regime_label
			+ "\nExpected Monthly TDS: Rs " + str(expected_monthly_tds),
			title="Zero TDS Warning",
			indicator="orange"
		)

	# VALIDATION 3: LOW TDS
	if income_tax_slab and tds_amount > 0 and expected_monthly_tds > 0:
		tolerance = expected_monthly_tds * 0.20
		if tds_amount < tolerance:
			frappe.msgprint(
				"Low TDS Warning!"
				+ "\nEmployee: " + employee_name
				+ "\nActual TDS: Rs " + str(round(tds_amount, 2))
				+ "\nEstimated TDS: Rs " + str(expected_monthly_tds),
				title="Low TDS Warning",
				indicator="yellow"
			)

	# VALIDATION 4: SURCHARGE ALERT
	if annual_gross > 5000000:
		frappe.msgprint(
			"High Income Detected"
			+ "\nEmployee: " + employee_name
			+ "\nProjected Annual Gross: Rs " + str(annual_gross),
			title="Surcharge Check",
			indicator="red"
		)

	# ============================================================
	# UPDATE TDS IN DEDUCTIONS TABLE
	# ============================================================
	tds_found = False
	for row in doc.deductions:
		if row.salary_component == "TDS":
			row.amount = expected_monthly_tds
			tds_found = True
			break

	if not tds_found and expected_monthly_tds > 0:
		doc.append("deductions", {
			"salary_component": "TDS",
			"amount": expected_monthly_tds
		})

	# ============================================================
	# AUDIT LOG
	# ============================================================
	# frappe.log_error(
	# 	message=(
	# 		"TDS AUDIT (Cumulative True-Up, end_date-based) v3.3"
	# 		+ " | Logged At: " + str(frappe.utils.now())
	# 		+ " | Slip: " + str(doc.name or "NEW")
	# 		+ " | Employee: " + employee
	# 		+ " | Name: " + employee_name
	# 		+ " | Regime: " + regime_label
	# 		+ " | FY: " + str(fy_start_year) + "-" + str(fy_start_year + 1)
	# 		+ " | Slip End Date: " + str(slip_end)
	# 		+ " | Payroll Month #: " + str(payroll_month_number)
	# 		+ " | Remaining Months: " + str(remaining_payroll_months)
	# 		+ " | Prev Gross: " + str(actual_gross_previous_months)
	# 		+ " | This Month Gross: " + str(current_month_gross)
	# 		+ " | One-Time Stripped: " + str(one_time_amount_this_month)
	# 		+ " | Recurring Gross (this month, actual): " + str(recurring_monthly_gross)
	# 		+ " | Uniform Allowance Annual (Old Regime exempt): " + str(uniform_allowance_annual)
	# 		+ " | HRA Exemption Declared (flat, unused): " + str(hra_exemption_declared)
	# 		+ " | HRA Exemption Recomputed (month-wise): " + str(round(hra_exemption, 2))
	# 		+ " | Payment Days: " + str(payment_days) + "/" + str(total_working_days)
	# 		+ " | Payment Days (raw field): " + str(raw_payment_days) + "/" + str(total_working_days)
	# 		+ " | Payment Days (recomputed from absent/LWP): " + str(payment_days) + "/" + str(total_working_days)
	# 		+ " | Payment Days Mismatch: " + str(payment_days_mismatch)
	# 		+ " | LOP Adjustment: " + lop_adjustment_note
	# 		+ " | LOP Fallback Slip Used: " + str(lop_fallback_slip_used)
	# 		+ " | Projection Gross (used for future months): " + str(projection_gross)
	# 		+ " | Previous Month Recurring Gross: " + str(previous_month_recurring_gross)
	# 		+ " | Previous Month TDS: " + str(previous_month_tds)
	# 		+ " | Previous Month Had LOP: " + str(previous_month_had_lop)
	# 		+ " | TDS Method Used: " + tds_method_used
	# 		+ " | Projected Annual Gross: " + str(annual_gross)
	# 		+ " | Projected Annual Tax: " + str(round(total_annual_tax_projected, 2))
	# 		+ " | TDS Deducted Prior: " + str(tds_already_deducted)
	# 		+ " | True-Up TDS (fallback calc): " + str(true_up_tds)
	# 		+ " | Actual TDS (before override): " + str(tds_amount)
	# 		+ " | Expected TDS This Month: " + str(expected_monthly_tds)
	# 		+ " | Net Pay: " + str(net_pay)
	# 	),
	# 	title="TDS Audit"
	# )
    


    #11-08-2026
	# ============================================================
	# STEP 7c: POPULATE INCOME TAX BREAKUP SECTION
	# Standard Salary Slip fields, driven by this script's own
	# true-up calculation (not ERPNext's built-in tax engine, which
	# this script bypasses entirely).
	# ============================================================
    

	doc.annual_taxable_amount = round(taxable_income, 2)
	doc.income_tax_deducted_till_date = round(tds_already_deducted + expected_monthly_tds, 2)
	doc.current_month_income_tax = expected_monthly_tds
	doc.total_income_tax = round(total_annual_tax_projected, 2)

	future_income_tax_cal = total_annual_tax_projected - doc.income_tax_deducted_till_date
	if future_income_tax_cal < 0:
		future_income_tax_cal = 0
	doc.future_income_tax_deductions = round(future_income_tax_cal, 2)

	doc.standard_tax_exemption_amount = round(standard_deduction, 2)
	doc.total_earnings = round(annual_gross, 2)
	doc.ctc = round(annual_gross, 2)

	tax_exemption_declaration_total = 0
	deductions_before_tax = standard_deduction
	if allow_tax_exemption:
		tax_exemption_declaration_total = round(
			declaration_total + old_regime_extra_exemptions, 2
		)
		deductions_before_tax += hra_exemption + old_regime_extra_exemptions

	doc.tax_exemption_declaration = tax_exemption_declaration_total
	doc.deductions_before_tax_calculation = round(deductions_before_tax, 2)

	# non_taxable = annual_gross - taxable_income
	# if non_taxable < 0:
	# 	non_taxable = 0
	# doc.non_taxable_earnings = round(non_taxable, 2)

	# doc.income_from_other_sources = 0



	# ============================================================
	# FINAL TOTAL RECALCULATION
	# ============================================================
	total_deductions = sum(float(d.amount or 0) for d in doc.deductions)

	doc.total_deduction = total_deductions
	doc.net_pay = doc.gross_pay - total_deductions
	doc.rounded_total = round(doc.net_pay)

	doc.base_total_deduction = total_deductions
	doc.base_net_pay = doc.net_pay
	doc.base_rounded_total = doc.rounded_total

def _compute_tax(taxable_income, rows):
	tax = 0.0
	for row in rows:
		from_amt = row.get("from_amount") or 0
		to_amt = row.get("to_amount") or 999999999
		rate = (row.get("percent_deduction") or 0) / 100
		if taxable_income > from_amt:
			band = min(taxable_income, to_amt) - from_amt
			tax += band * rate
	return tax

def apply_salary_slip_fixed_component(doc, method=None):
	"""was Server Script: ZZ Salary Slip Fixed Component (Before Save)
	RUNS LAST — ZZ prefix
	Logic preserved exactly as original - review during regression."""

	salary_structure = doc.salary_structure or ""
	is_manual_structure = is_manual_salary_structure(salary_structure)

	if is_manual_structure:
		pass

	else:
		allowed_earnings = [
			"Basic",
			"House Rent Allowance",
			"Advance Bonus",
		]

		# Include Conveyance only for OSBS
		if salary_structure == OSBS_SALARY_STRUCTURE:
			allowed_earnings.append("Conveyance")

		# RapidShyp Flexi Benefit Plan: Basic, HRA, the FBP benefits and Special
		# Allowance are the whole salary of that structure (utils/fbp_slabs.py)
		if is_flexi_salary_structure(salary_structure):
			for component in FLEXI_EARNING_COMPONENTS:
				if component not in allowed_earnings:
					allowed_earnings.append(component)

		allowed_deductions = [
			"Provident Fund",
			"Professional Tax",
			"TDS",
			"ESIC",
			"LWF",
			"Other Deductions",
			"ACCOM",
			"LOAN-PERSONAL",
			"LOAN-MOBILE",
			"LOAN-LAPTOP",
			"LOAN"
		]

		# STEP 1: SNAPSHOT into dicts
		earn_map = {}
		for row in doc.earnings:
			comp = str(row.salary_component or "").strip()
			if not comp:
				continue
			earn_map[comp] = {
				"salary_component": comp,
				"amount": round(float(row.amount or 0), 2),
				"default_amount": round(float(row.default_amount or 0), 2),
				"additional_salary": row.additional_salary or ""
			}

		ded_map = {}
		for row in doc.deductions:
			comp = str(row.salary_component or "").strip()
			if not comp:
				continue
			ded_map[comp] = {
				"salary_component": comp,
				"amount": round(float(row.amount or 0), 2),
				"default_amount": round(float(row.default_amount or 0), 2),
				"additional_salary": row.additional_salary or ""
			}

		# STEP 2: FETCH abbr FOR EVERY COMPONENT
		abbr_cache = {}
		all_comps = list(earn_map.keys()) + list(ded_map.keys())

		for comp in all_comps:
			if comp not in abbr_cache:
				fetched = frappe.db.get_value(
					"Salary Component", comp, "salary_component_abbr"
				) or comp[:4].upper()
				abbr_cache[comp] = fetched

		# STEP 3: BUILD SORTED LISTS
		sorted_earnings = []
		for comp in allowed_earnings:
			if comp in earn_map:
				row_data = earn_map[comp].copy()
				row_data["abbr"] = abbr_cache.get(comp, "")
				sorted_earnings.append(row_data)

		for comp in earn_map:
			if earn_map[comp]["additional_salary"]:
				row_data = earn_map[comp].copy()
				row_data["abbr"] = abbr_cache.get(comp, "")
				sorted_earnings.append(row_data)

		sorted_deductions = []
		for comp in allowed_deductions:
			if comp in ded_map:
				row_data = ded_map[comp].copy()
				row_data["abbr"] = abbr_cache.get(comp, "")
				sorted_deductions.append(row_data)

		for comp in ded_map:
			if ded_map[comp]["additional_salary"]:
				row_data = ded_map[comp].copy()
				row_data["abbr"] = abbr_cache.get(comp, "")
				sorted_deductions.append(row_data)

		# STEP 4: WIPE AND REBUILD CHILD TABLES
		doc.set("earnings", [])
		doc.set("deductions", [])

		for e in sorted_earnings:
			doc.append("earnings", {
				"salary_component": e["salary_component"],
				"abbr": e["abbr"],
				"amount": e["amount"],
				"default_amount": e["default_amount"]
			})

		for d in sorted_deductions:
			doc.append("deductions", {
				"salary_component": d["salary_component"],
				"abbr": d["abbr"],
				"amount": d["amount"],
				"default_amount": d["default_amount"]
			})

		# STEP 5: RECALCULATE TOTALS
		total_earnings = 0
		for e in doc.earnings:
			total_earnings = total_earnings + float(e.amount or 0)

		doc.gross_pay = round(total_earnings, 2)
		doc.base_gross_pay = doc.gross_pay

		total_deductions = 0
		for d in doc.deductions:
			total_deductions = total_deductions + float(d.amount or 0)

		doc.total_deduction = round(total_deductions, 2)
		doc.base_total_deduction = doc.total_deduction

		doc.net_pay = round(doc.gross_pay - doc.total_deduction, 2)
		doc.base_net_pay = doc.net_pay
		doc.rounded_total = round(doc.net_pay)
		doc.base_rounded_total = doc.rounded_total

		# frappe.log_error(
		# 	"FINAL Gross = " + str(doc.gross_pay),
		# 	"Final Gross Debug"
		# )

	# STEP 6: GROSS YEAR TO DATE (runs always, regardless of manual structure)
	posting_date = frappe.utils.getdate(doc.posting_date)

	if posting_date.month >= 4:
		fiscal_start = frappe.utils.getdate(str(posting_date.year) + "-04-01")
	else:
		fiscal_start = frappe.utils.getdate(str(posting_date.year - 1) + "-04-01")

	previous_gross = frappe.db.sql("""
		SELECT COALESCE(SUM(gross_pay), 0)
		FROM `tabSalary Slip`
		WHERE employee = %s
		  AND docstatus IN (0,1)
		  AND posting_date >= %s
		  AND posting_date <= %s
		  AND name != %s
	""", (doc.employee, fiscal_start, posting_date, doc.name))[0][0] or 0

	doc.gross_year_to_date = previous_gross + (doc.gross_pay or 0)
	doc.base_gross_year_to_date = doc.gross_year_to_date

	# STEP 7: BLOCK ERPNext POST-VALIDATE RECALCULATION (runs always)
	doc.flags.ignore_recompute = True
	doc.flags.dont_update_if_missing = True

LOAN_TYPE_COMPONENT_MAP = {
	"Personal Loan": "LOAN-PERSONAL",
	"Mobile Loan": "LOAN-MOBILE",
	"Laptop Loan": "LOAN-LAPTOP",
}
LOAN_COMPONENT_FALLBACK = "LOAN"

def apply_loan_emi_deduction(doc, method=None):
	"""
	Checks for active Employee Loans for this employee and deducts the next
	pending EMI as a Salary Slip deduction row, matching policy point 6
	(EMIs automatically deducted from monthly salary until fully repaid).
	Uses a per-loan-type Salary Component (LOAN-PERSONAL, LOAN-MOBILE, etc.)
	so multiple simultaneous loans of different types show as separate lines.
	Does NOT mark the EMI as paid here - that happens on Salary Slip submit.
	"""
	if not doc.employee:
		return

	active_loans = frappe.get_all(
		"Employee Loan",
		filters={"employee": doc.employee, "status": "Active"},
		fields=["name", "loan_type"]
	)

	if not active_loans:
		return

	doc.set("loan", [])
	emi_by_component = {}

	for loan_row in active_loans:
		loan = frappe.get_doc("Employee Loan", loan_row.name)

		pending_emi = None
		for emi_row in loan.emi_schedule:
			if emi_row.status == "Pending" and getdate(emi_row.due_date) <= getdate(doc.end_date):
				pending_emi = emi_row
				break

		if not pending_emi:
			continue

		doc.append("loan", {
			"employee_loan": loan.name,
			"emi_amount": pending_emi.emi_amount,
			"installment_number": pending_emi.installment_number
		})

		component = LOAN_TYPE_COMPONENT_MAP.get(loan.loan_type, LOAN_COMPONENT_FALLBACK)
		emi_by_component[component] = emi_by_component.get(component, 0) + pending_emi.emi_amount

	if not emi_by_component:
		return

	for component, amount in emi_by_component.items():
		row_found = False
		for row in doc.deductions:
			if row.salary_component == component:
				row.amount = round(amount, 2)
				row_found = True
				break

		if not row_found:
			doc.append("deductions", {
				"salary_component": component,
				"amount": round(amount, 2)
			})

	doc.total_deduction = sum(float(d.amount or 0) for d in doc.deductions)
	doc.net_pay = round((doc.gross_pay or 0) - doc.total_deduction, 2)


def mark_loan_emis_paid_on_submit(doc, method=None):
	"""
	Fires on Salary Slip submit. Marks the EMI Schedule rows referenced in
	doc.loan as Paid, links this Salary Slip, and updates Employee Loan's
	total_paid / outstanding_balance. Auto-closes the loan if fully repaid.
	"""
	if not doc.get("loan"):
		return

	for loan_ref in doc.loan:
		loan = frappe.get_doc("Employee Loan", loan_ref.employee_loan)

		for emi_row in loan.emi_schedule:
			if emi_row.installment_number == loan_ref.installment_number and emi_row.status == "Pending":
				emi_row.status = "Paid"
				emi_row.salary_slip = doc.name
				emi_row.paid_date = doc.posting_date
				break

		total_paid = sum(
			float(e.emi_amount or 0) for e in loan.emi_schedule if e.status in ("Paid", "Offset", "Prepaid")
		)
		loan.total_paid = total_paid
		loan.outstanding_balance = loan.principal_amount - total_paid

		if loan.outstanding_balance <= 0:
			loan.status = "Closed"
			loan.closed_date = doc.posting_date

		loan.save(ignore_permissions=True)   
