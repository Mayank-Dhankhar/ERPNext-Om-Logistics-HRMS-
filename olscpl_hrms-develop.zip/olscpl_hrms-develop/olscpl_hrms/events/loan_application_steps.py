import frappe
from frappe.utils import add_months, getdate
from olscpl_hrms.utils.payroll_constants import BASE_BASIC_RATE


def compute_eligibility(doc, method=None):
	"""
	Fetch employee's current Basic Salary and compute max eligible loan amount
	based on Loan Type's max_multiple_of_basic (policy point 4: 5x Basic Salary).
	Flags exceeds_policy_limit for Management discretion review, does not block.
	Also auto-defaults approved_amount / approved_repayment_months from the
	requested values, so HR can approve as-is or override before final approval.
	"""
	if not (doc.employee and doc.loan_type):
		return

	ssa_name = frappe.db.get_value(
		"Salary Structure Assignment",
		{"employee": doc.employee, "docstatus": 1},
		"name",
		order_by="from_date desc"
	)

	basic_amount = 0

	if ssa_name:
		manual_row = frappe.db.get_value(
			"Manual Salary Component",
			{"parent": ssa_name, "salary_component": "Basic"},
			"amount"
		)

		if manual_row:
			basic_amount = manual_row
		else:
			base_salary = frappe.db.get_value("Salary Structure Assignment", ssa_name, "base") or 0
			basic_amount = base_salary * BASE_BASIC_RATE

	doc.basic_salary = basic_amount

	max_multiple = frappe.db.get_value("Loan Type", doc.loan_type, "max_multiple_of_basic") or 5
	doc.max_eligible_amount = basic_amount * max_multiple

	if doc.requested_amount and doc.requested_amount > doc.max_eligible_amount:
		doc.exceeds_policy_limit = 1
	else:
		doc.exceeds_policy_limit = 0

	# Auto-default approved terms from requested terms, only if not already set
	# (so HR's manual override, once made, is never silently clobbered on re-save)
	if not doc.approved_amount and doc.requested_amount:
		doc.approved_amount = doc.requested_amount

	if not doc.approved_repayment_months and doc.requested_repayment_months:
		doc.approved_repayment_months = doc.requested_repayment_months


def create_employee_loan_on_approval(doc, method=None):
	"""
	Fires on Loan Application update. When workflow_state transitions to
	'Approved', auto-creates the Employee Loan record with a generated
	EMI Schedule (policy point 6: equal monthly installments).
	Idempotent - if Employee Loan already exists for this application, skip.
	Requires HR to have explicitly set a Disbursement Date before approval.
	"""
	if doc.workflow_state != "Approved":
		return

	if doc.employee_loan:
		return

	if not doc.approved_amount or not doc.approved_repayment_months:
		frappe.throw(
			"Cannot create Employee Loan: Approved Amount and Approved Repayment Months must be set."
		)

	if not doc.disbursement_date:
		frappe.throw(
			"Cannot create Employee Loan: Disbursement Date must be set by HR before final approval."
		)

	emi_amount = round(doc.approved_amount / doc.approved_repayment_months, 2)

	loan = frappe.get_doc({
        "doctype": "Employee Loan",
        "employee": doc.employee,
        "company": doc.company,
        "loan_application": doc.name,
        "loan_type": doc.loan_type,
        "principal_amount": doc.approved_amount,
        "disbursement_date": doc.disbursement_date,
        "total_installments": doc.approved_repayment_months,
        "emi_amount": emi_amount,
        "status": "Active",
        "total_paid": 0,
        "outstanding_balance": doc.approved_amount,
    })

	start_date = getdate(doc.disbursement_date)

	for i in range(1, doc.approved_repayment_months + 1):
		due_date = add_months(start_date, i)
		loan.append("emi_schedule", {
			"installment_number": i,
			"due_date": due_date,
			"emi_amount": emi_amount,
			"status": "Pending",
		})

	loan.insert(ignore_permissions=True)

	frappe.db.set_value("Loan Application", doc.name, "employee_loan", loan.name)
	doc.employee_loan = loan.name

	frappe.msgprint(
		f"Employee Loan {loan.name} created with {doc.approved_repayment_months} EMIs of ₹{emi_amount} each, starting {add_months(start_date, 1)}.",
		title="Loan Disbursed",
		indicator="green"
	)
	