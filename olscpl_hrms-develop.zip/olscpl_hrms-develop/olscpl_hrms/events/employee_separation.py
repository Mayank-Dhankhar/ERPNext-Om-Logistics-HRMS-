# olscpl_hrms/events/employee_separation.py
import frappe
from frappe import _
from frappe.utils.pdf import get_pdf
from olscpl_hrms.utils.email_layout import branded_email

# Matches the reference system's HRIS_FINAL_CLEARANCE_DETAILS sequence
# exactly (SEQUENCEORDER 1-9 -> clearanceTypeMapping in the SCM frontend).
CLEARANCE_TYPES = [
	"Manager and Department",
	"Accounts",
	"Audit",
	"Admin",
	"PTP CCD",
	"POD (DBP Dept.)",
	"IT",
	"TDS",
	"Regional HR",
]


def default_separation_manager(doc, method=None):
	"""Pre-fill the approving manager from the employee's current
	reports_to, same convenience get_or_create_for_offer() already does
	for Employee Onboarding - only on a fresh record, never overwriting a
	value someone deliberately set (reporting lines can legitimately
	differ from who should actually approve a given exit)."""
	if doc.employee and not doc.get("separation_manager"):
		doc.separation_manager = frappe.db.get_value("Employee", doc.employee, "reports_to")

	# Frappe's Workflow feature only sets the initial workflow_state
	# client-side (desk form JS, on a fresh New form) - a record created
	# any other way (API, a script, this app's own future self-service
	# code) would otherwise sit with workflow_state blank, satisfying no
	# transition's starting state and effectively stuck. Default it
	# explicitly instead of relying on the client to have done it.
	if not doc.get("workflow_state"):
		doc.workflow_state = "Initiated"


def sync_boarding_status(doc, method=None):
	"""Keeps the stock boarding_status field (Pending/In Process/
	Completed - a real field on Employee Separation that nothing was
	updating) roughly in step with the actual process, instead of every
	record sitting on "Pending" forever regardless of how far along it
	actually is. Never downgrades away from Completed - that's set once,
	by sync_clearance_completion() below, when every clearance stage is
	done."""
	if doc.get("boarding_status") == "Completed":
		return
	if doc.get("workflow_state") in ("Submitted to Manager", "Submitted to HR", "Signed Off"):
		doc.boarding_status = "In Process"


# Set this to True once real outbound email should actually go out for
# workflow transitions. While False, notify_on_workflow_action() still
# runs its full recipient-resolution logic every time and posts what it
# WOULD have sent as a comment directly on the record's own timeline -
# so the mechanism is fully wired and visibly testable without risking a
# real email to a manager/HR/employee before this is ready.
SEND_REAL_WORKFLOW_EMAILS = False

# new workflow_state -> (who to notify, subject template). "employee_name"
# is the only placeholder available in the template.
WORKFLOW_NOTIFY_RULES = {
	"Submitted to Manager": ("manager", "Exit request from {employee_name} needs your approval"),
	"Submitted to HR": ("hr", "Exit request from {employee_name} needs HR approval"),
	"Signed Off": ("employee", "Your exit request has been signed off"),
	"Rejected": ("employee", "Your exit request was rejected"),
	# Both the manager's and HR's "Send Back" transitions land back on
	# Initiated - the employee needs to know either way, to revise and
	# resubmit.
	"Initiated": ("employee", "Your exit request was sent back - please review and resubmit"),
}


def notify_on_workflow_action(doc, method=None):
	"""Registered on Employee Separation's on_update - fires once per
	actual workflow_state change (Submit to Manager, Approve, Reject, Send
	Back, the Direct-HR fast path - whichever action caused it), not on
	every save, and notifies whoever needs to act next (or the employee,
	for a terminal/send-back state). Real delivery is gated by
	SEND_REAL_WORKFLOW_EMAILS above.

	Guarded against firing on a brand-new record: has_value_changed() is
	True for workflow_state going from unset -> "Initiated" on the very
	first save too (there's no "before" value to compare against), which
	would otherwise fire the "Initiated" rule's send-back-style
	notification on every new exit request - not what happened."""
	if not doc.get_doc_before_save():
		return
	if not doc.has_value_changed("workflow_state"):
		return

	rule = WORKFLOW_NOTIFY_RULES.get(doc.workflow_state)
	if not rule:
		return
	who, subject_template = rule

	recipients = _resolve_workflow_notify_recipients(doc, who)
	if not recipients:
		return

	subject = subject_template.format(employee_name=doc.employee_name or doc.employee)
	message = _("Employee Separation {0} ({1}) moved to <b>{2}</b>.").format(
		doc.name, doc.employee_name or doc.employee, doc.workflow_state
	)
	_send_or_log_workflow_notification(doc, recipients, subject, message)


def _resolve_workflow_notify_recipients(doc, who):
	if who == "manager":
		if not doc.separation_manager:
			return []
		user = frappe.db.get_value("Employee", doc.separation_manager, "user_id")
		return [user] if user else []

	if who == "employee":
		user = frappe.db.get_value("Employee", doc.employee, "user_id")
		return [user] if user else []

	if who == "hr":
		users = frappe.get_all(
			"Has Role", filters={"role": "HR Manager", "parenttype": "User"}, pluck="parent"
		)
		return [u for u in users if u not in ("Administrator", "Guest")]

	return []


def _send_or_log_workflow_notification(doc, recipients, subject, message):
	if SEND_REAL_WORKFLOW_EMAILS:
		frappe.sendmail(
			recipients=recipients,
			subject=subject,
			message=branded_email(_("Employee Separation"), message, signoff=True),
			reference_doctype=doc.doctype,
			reference_name=doc.name,
		)
		return

	# Dry run - visible right on the record's own comment timeline instead
	# of actually emailing anyone, until SEND_REAL_WORKFLOW_EMAILS is
	# flipped on.
	doc.add_comment(
		"Info",
		_("\U0001f4e7 Would notify: {0} — Subject: {1}").format(", ".join(recipients), subject),
	)


def sync_clearance_completion(doc, method=None):
	"""Registered on Employee Separation Clearance's on_update - once every
	stage for a given separation reports Cleared, mark the parent
	Completed. This is the one automatic signal that exists today that
	a record is actually ready to move into Full & Final (Phase 3) -
	right now that's just a status flip, since Phase 3 itself isn't
	built yet."""
	if not doc.employee_separation:
		return
	total = frappe.db.count("Employee Separation Clearance", {"employee_separation": doc.employee_separation})
	cleared = frappe.db.count(
		"Employee Separation Clearance",
		{"employee_separation": doc.employee_separation, "status": "Cleared"},
	)
	if total and total == cleared:
		frappe.db.set_value("Employee Separation", doc.employee_separation, "boarding_status", "Completed")


@frappe.whitelist()
def prepare_full_and_final(employee_separation):
	"""Stock hrms's Full and Final Statement.relieving_date is
	fetch_from: employee.relieving_date, read-only - a new FnF form can't
	just be prefilled with it client-side, it has to actually be set on
	the Employee record first, which is what this does (from this
	separation's own last_working_day) before the "Start Full & Final
	Settlement" button opens a new one. Never overwrites an
	already-set relieving_date - HR may have deliberately set a
	different one directly on the Employee record."""
	if "HR Manager" not in frappe.get_roles() and "HR User" not in frappe.get_roles():
		frappe.throw(_("Only HR can start Full & Final settlement."), frappe.PermissionError)

	doc = frappe.get_doc("Employee Separation", employee_separation)
	current = frappe.db.get_value("Employee", doc.employee, "relieving_date")
	if not current and doc.last_working_day:
		frappe.db.set_value("Employee", doc.employee, "relieving_date", doc.last_working_day)
		frappe.db.commit()


@frappe.whitelist()
def initiate_clearance(employee_separation, approvers):
	"""Creates all 9 Employee Separation Clearance stages for this exit -
	matches the reference system's HR-manual initiateClearanceRequest()
	(HR picks/confirms every approver, it's not auto-derived from any
	department-head mapping - we don't have that data modelled either).

	approvers: dict of clearance_type -> approver Employee id. "Manager
	and Department" defaults to the record's own separation_manager if
	not given, same default the reference system's own form pre-fills."""
	if "HR Manager" not in frappe.get_roles() and "HR User" not in frappe.get_roles():
		frappe.throw(_("Only HR can initiate the clearance process."), frappe.PermissionError)

	doc = frappe.get_doc("Employee Separation", employee_separation)

	# "Signed Off only" was previously enforced only by the desk button's
	# own visibility condition (frm.doc.workflow_state === "Signed Off") -
	# real for anyone using the actual UI, but not a real server-side
	# guard: this whitelisted method itself would happily run for a
	# record still sitting at Initiated if called directly (API, console,
	# a stale/cached button). Same belt-and-suspenders style as the rest
	# of this app.
	if doc.workflow_state != "Signed Off":
		frappe.throw(
			_("Clearance can only be initiated once the exit request is Signed Off (currently: {0}).").format(
				doc.workflow_state
			)
		)

	if frappe.db.exists("Employee Separation Clearance", {"employee_separation": employee_separation}):
		frappe.throw(_("Clearance has already been initiated for this separation."))

	approvers = dict(frappe.parse_json(approvers) if isinstance(approvers, str) else (approvers or {}))
	approvers.setdefault("Manager and Department", doc.separation_manager)

	created = []
	for idx, clearance_type in enumerate(CLEARANCE_TYPES, start=1):
		approver = approvers.get(clearance_type)
		if not approver:
			frappe.throw(_("Please select an approver for {0}.").format(clearance_type))
		row = frappe.get_doc(
			{
				"doctype": "Employee Separation Clearance",
				"employee_separation": employee_separation,
				"employee": doc.employee,
				"clearance_type": clearance_type,
				"sequence_order": idx,
				"approver": approver,
				"status": "Pending",
			}
		)
		row.insert(ignore_permissions=True)
		created.append(row.name)

	frappe.db.commit()
	_notify_clearance_approvers(doc, approvers)
	return {"created": created}


def _notify_clearance_approvers(doc, approvers):
	"""One notification per approver HR just picked in the Initiate
	Clearance dialog - each needs to know they now have a stage of this
	exit to clear. Same dry-run mechanism and SEND_REAL_WORKFLOW_EMAILS
	switch as notify_on_workflow_action() above; a single approver
	assigned to more than one stage (not unusual - the same person often
	covers two departments) gets one notification per stage, not merged,
	so each one names the specific clearance type it's about."""
	for clearance_type, approver in approvers.items():
		if not approver:
			continue
		user = frappe.db.get_value("Employee", approver, "user_id")
		if not user:
			continue
		subject = _("Clearance needed: {0} - {1}").format(clearance_type, doc.employee_name or doc.employee)
		message = _(
			"You've been assigned as the approver for the <b>{0}</b> clearance stage "
			"of {1}'s exit ({2}). Please review and clear it."
		).format(clearance_type, doc.employee_name or doc.employee, doc.name)
		_send_or_log_workflow_notification(doc, [user], subject, message)


@frappe.whitelist()
def get_exit_dashboard_data(year=None):
	"""Backs the two charts (monthly exit count, reason breakdown) shown
	above the Employee Separation list view - matches the reference
	system's own "Yearly exit dashboard" / "Reason Analysis" charts.

	Grouped by this record's own `creation` timestamp, not the stock
	resignation_letter_date field - that one turned out to be
	fetch_from: employee.resignation_letter_date (mirrors a single value
	on the Employee record, not something per-request), so it can't
	actually vary per exit request the way the reference system's own
	RESIGNATION_DATE (set once, at creation, per request) does. `creation`
	is the genuine per-request equivalent."""
	year = frappe.utils.cint(year) or frappe.utils.getdate().year

	monthly_rows = frappe.db.sql(
		"""
		SELECT MONTH(creation) AS month, COUNT(*) AS count
		FROM `tabEmployee Separation`
		WHERE YEAR(creation) = %s AND docstatus < 2
		GROUP BY MONTH(creation)
		""",
		(year,),
		as_dict=True,
	)
	monthly = [0] * 12
	for row in monthly_rows:
		if row.month:
			monthly[int(row.month) - 1] = row.count

	reason_rows = frappe.db.sql(
		"""
		SELECT exit_reason, COUNT(*) AS count
		FROM `tabEmployee Separation`
		WHERE YEAR(creation) = %s
			AND exit_reason IS NOT NULL AND exit_reason != ''
			AND docstatus < 2
		GROUP BY exit_reason
		ORDER BY count DESC
		""",
		(year,),
		as_dict=True,
	)

	return {
		"year": year,
		"monthly": monthly,
		"reasons": [{"label": r.exit_reason, "count": r.count} for r in reason_rows],
	}


@frappe.whitelist()
def get_clearance_status(employee_separation):
	"""frappe.get_list (not get_all) so the permission_query_conditions
	hook actually applies - a plain approver only gets their own row(s)
	back, not the whole table; HR/Administrator get everything. Each row
	also carries whether the calling user is actually allowed to change
	it, for the clearance-status dialog to render as an editable field
	vs plain text - though the real enforcement is server-side, in
	EmployeeSeparationClearance._enforce_approver_only_edit(), not this
	flag."""
	rows = frappe.get_list(
		"Employee Separation Clearance",
		filters={"employee_separation": employee_separation},
		fields=["name", "clearance_type", "approver", "status", "remarks", "cleared_on"],
		order_by="sequence_order asc",
	)

	approver_ids = [r["approver"] for r in rows if r.get("approver")]
	approver_names = {
		e.name: e.employee_name
		for e in (
			frappe.get_all("Employee", filters={"name": ["in", approver_ids]}, fields=["name", "employee_name"])
			if approver_ids
			else []
		)
	}

	for row in rows:
		row["approver_name"] = approver_names.get(row.get("approver"))
		row["editable"] = bool(frappe.has_permission("Employee Separation Clearance", "write", row["name"]))

	return rows


@frappe.whitelist()
def download_clearance_pdf(employee_separation):
	"""One PDF combining the exit request's key details with the full
	clearance table (every stage's status/approver/remarks) - a
	paper-trail HR and the resigning employee can each save or print,
	which the desk-only "Clearance Status" dialog itself can't be handed
	around as. No separate role check needed: check_permission("read")
	on the parent record and get_clearance_status()'s own permission
	-scoped query (frappe.get_list, not get_all) already resolve to
	exactly who should see what - HR/Administrator get every stage, the
	resigning employee gets all of their own record's stages, and an
	approver who somehow reaches this would only ever get their own."""
	doc = frappe.get_doc("Employee Separation", employee_separation)
	doc.check_permission("read")

	rows = get_clearance_status(employee_separation)
	cleared_count = len([r for r in rows if r.get("status") == "Cleared"])

	html = frappe.render_template(
		"olscpl_hrms/templates/print/clearance_status.html",
		{"doc": doc, "rows": rows, "cleared_count": cleared_count},
	)
	pdf = get_pdf(html)

	frappe.local.response.filename = f"{doc.name}-clearance-status.pdf"
	frappe.local.response.filecontent = pdf
	frappe.local.response.type = "pdf"


@frappe.whitelist()
def update_clearance_rows(updates):
	"""Bulk save from the clearance-status dialog's "Save Changes" - one
	call, one row per approver's actual permission checked independently
	(via doc.has_permission, which re-enters the same has_permission hook
	get_clearance_status used to compute "editable"; the doctype's own
	validate() is the real gate either way). A row a caller isn't
	allowed to touch fails on its own without blocking the rest of the
	batch - the dialog only ever sends editable rows in the first place,
	this is the server-side backstop, not the primary defense.

	updates: JSON list of {"name": ..., "status": ..., "remarks": ...}."""
	updates = frappe.parse_json(updates) if isinstance(updates, str) else (updates or [])

	results = []
	for u in updates:
		name = u.get("name")
		try:
			doc = frappe.get_doc("Employee Separation Clearance", name)
			if not doc.has_permission("write"):
				results.append({"name": name, "ok": False, "error": _("Not permitted")})
				continue
			was_cleared = doc.status == "Cleared"
			doc.status = u.get("status") or doc.status
			doc.remarks = u.get("remarks")
			doc.save()
			results.append({"name": doc.name, "ok": True, "status": doc.status})
			if doc.status == "Cleared" and not was_cleared:
				_notify_hr_of_clearance(doc)
		except Exception as e:
			results.append({"name": name, "ok": False, "error": str(e)})

	return results


def _notify_hr_of_clearance(clearance_row):
	"""Fires once, right when a stage actually flips to Cleared - not on
	every save of an already-cleared row (editing its remarks afterward
	doesn't re-notify), and not on clearing then un-clearing back to
	Pending. Posted on the parent Employee Separation, same place the
	other exit notifications land, so HR sees the whole story - request
	submitted, approvers assigned, each stage clearing - in one timeline.
	Same dry-run mechanism (SEND_REAL_WORKFLOW_EMAILS) as the rest of
	this file."""
	sep = frappe.get_doc("Employee Separation", clearance_row.employee_separation)
	recipients = _resolve_workflow_notify_recipients(sep, "hr")
	if not recipients:
		return

	subject = _("{0} cleared for {1} - you can process accordingly").format(
		clearance_row.clearance_type, sep.employee_name or sep.employee
	)
	message = _("The <b>{0}</b> clearance stage for {1}'s exit ({2}) has just been marked Cleared.").format(
		clearance_row.clearance_type, sep.employee_name or sep.employee, sep.name
	)
	_send_or_log_workflow_notification(sep, recipients, subject, message)
