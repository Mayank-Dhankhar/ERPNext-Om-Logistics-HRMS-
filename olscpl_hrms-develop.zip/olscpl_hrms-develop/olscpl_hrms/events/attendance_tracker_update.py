import frappe


def update_monthly_tracker(doc):
    """was Server Script: Update Monthly Attendance Tracker
    After Save on Attendance."""

    if doc.status not in ["Present", "Half Day", "Absent"] or not doc.custom_calculation_done:
        return

    payroll_config = frappe.db.get_value(
        "Payroll Cycle Settings",
        None,
        ["cycle_start_day", "cycle_end_day", "enabled", "use_calendar_month"],
        as_dict=True
    )

    if not payroll_config:
        cycle_start_day = 26
        cycle_end_day = 25
        use_custom_cycle = True
    else:
        cycle_start_day = int(payroll_config.get('cycle_start_day') or 26)
        cycle_end_day = int(payroll_config.get('cycle_end_day') or 25)
        use_custom_cycle = payroll_config.get('enabled', True) and not payroll_config.get('use_calendar_month', False)

    day_info = frappe.db.sql("""
        SELECT DAY(%s) as day_of_month
    """, (doc.attendance_date,), as_dict=True)[0]
    day_of_month = day_info.day_of_month

    if use_custom_cycle:
        if day_of_month >= cycle_start_day:
            payroll_calc = frappe.db.sql("""
                SELECT
                    MONTHNAME(DATE_ADD(%s, INTERVAL 1 MONTH)) as payroll_month,
                    YEAR(DATE_ADD(%s, INTERVAL 1 MONTH)) as payroll_year,
                    MONTH(DATE_ADD(%s, INTERVAL 1 MONTH)) as payroll_month_num,
                    YEAR(DATE_ADD(%s, INTERVAL 1 MONTH)) as payroll_year_num
            """, (doc.attendance_date, doc.attendance_date, doc.attendance_date, doc.attendance_date), as_dict=True)[0]
        else:
            payroll_calc = frappe.db.sql("""
                SELECT
                    MONTHNAME(%s) as payroll_month,
                    YEAR(%s) as payroll_year,
                    MONTH(%s) as payroll_month_num,
                    YEAR(%s) as payroll_year_num
            """, (doc.attendance_date, doc.attendance_date, doc.attendance_date, doc.attendance_date), as_dict=True)[0]

        payroll_month = payroll_calc.payroll_month
        payroll_year = payroll_calc.payroll_year
        payroll_month_num = payroll_calc.payroll_month_num
        payroll_year_num = payroll_calc.payroll_year_num

        cycle_dates = frappe.db.sql("""
            SELECT
                DATE_FORMAT(
                    STR_TO_DATE(
                        CONCAT(
                            YEAR(DATE_SUB(STR_TO_DATE(CONCAT(%s, '-', %s, '-01'), '%%Y-%%m-%%d'), INTERVAL 1 MONTH)),
                            '-',
                            MONTH(DATE_SUB(STR_TO_DATE(CONCAT(%s, '-', %s, '-01'), '%%Y-%%m-%%d'), INTERVAL 1 MONTH)),
                            '-',
                            %s
                        ),
                        '%%Y-%%m-%%d'
                    ),
                    '%%Y-%%m-%%d'
                ) as cycle_start,
                DATE_FORMAT(
                    STR_TO_DATE(
                        CONCAT(%s, '-', %s, '-', %s),
                        '%%Y-%%m-%%d'
                    ),
                    '%%Y-%%m-%%d'
                ) as cycle_end
        """, (
            payroll_year_num, payroll_month_num,
            payroll_year_num, payroll_month_num,
            cycle_start_day,
            payroll_year_num, payroll_month_num, cycle_end_day
        ), as_dict=True)[0]

        cycle_start = cycle_dates.cycle_start
        cycle_end = cycle_dates.cycle_end

    else:
        payroll_calc = frappe.db.sql("""
            SELECT
                MONTHNAME(%s) as payroll_month,
                YEAR(%s) as payroll_year,
                DATE_FORMAT(DATE_SUB(%s, INTERVAL (DAY(%s) - 1) DAY), '%%Y-%%m-%%d') as cycle_start,
                DATE_FORMAT(LAST_DAY(%s), '%%Y-%%m-%%d') as cycle_end
        """, (
            doc.attendance_date, doc.attendance_date,
            doc.attendance_date, doc.attendance_date,
            doc.attendance_date
        ), as_dict=True)[0]

        payroll_month = payroll_calc.payroll_month
        payroll_year = payroll_calc.payroll_year
        cycle_start = payroll_calc.cycle_start
        cycle_end = payroll_calc.cycle_end

    tracker_name = frappe.db.get_value(
        "Monthly Attendance Tracker",
        {"employee": doc.employee, "month": payroll_month, "year": payroll_year}
    )

    if not tracker_name:
        # RACE CONDITION FIX (Sep 14, 2026):
        # The bulk backfill DAG runs multiple batches concurrently
        # (ThreadPoolExecutor). Two different batches can each be
        # processing a different attendance_date for the SAME employee
        # within the SAME payroll cycle at the same moment. Both threads
        # can pass the "tracker doesn't exist yet" check above before
        # either one's insert commits, so both attempt to create a new
        # Monthly Attendance Tracker for the same
        # (employee, month, year) -- the second insert then fails with
        # ERPNext's own duplicate-entry validation:
        # "Monthly Attendance Tracker already exists for this Employee,
        # Month and Year", which was surfacing as an error in the
        # backfill results and silently blocking that Attendance record.
        #
        # Fix: treat that specific duplicate-entry failure as a benign
        # race, not an error -- re-fetch the tracker the other thread
        # just created and continue updating it, instead of raising.
        #
        # CORRECTION (Sep 14, 2026, 2nd deploy): the actual guard that
        # fires here is NOT Frappe's built-in DuplicateEntryError -- it's
        # this app's own before_validate hook on Monthly Attendance
        # Tracker (olscpl_hrms/events/monthly_attendance_tracker.py,
        # validate_uniqueness()), which does a plain
        # frappe.throw("Attendance Tracker already exists for this
        # Employee, Month, and Year.") -- that raises a generic
        # frappe.exceptions.ValidationError, not DuplicateEntryError, so
        # the first version of this fix never actually caught it (proven
        # by the Sep 14 11:29 UTC run still showing the identical 7
        # errors). Catching ValidationError and checking the message
        # text below is what actually handles this race.
        try:
            new_tracker = frappe.get_doc({
                "doctype": "Monthly Attendance Tracker",
                "employee": doc.employee,
                "month": payroll_month,
                "year": payroll_year,
                "total_late_coming": 0,
                "total_short_leave_hours": 0,
                "remaining_late_coming": 4,
                "remaining_short_leave_hours": 4,
                "half_day_deductions": 0,
                "total_present_days": 0,
                "total_absent_days": 0
            })
            new_tracker.insert(ignore_permissions=True)
            tracker_name = new_tracker.name

            # frappe.logger("olscpl_hrms").debug(
            #     f"New Monthly Attendance Tracker created for {doc.employee} "
            #     f"({payroll_month} {payroll_year}) via after-save trigger."
            # )
        except (frappe.exceptions.DuplicateEntryError, frappe.exceptions.ValidationError) as e:
            msg = str(e).lower()
            is_duplicate_tracker = (
                isinstance(e, frappe.exceptions.DuplicateEntryError)
                or "already exists" in msg
            )
            if not is_duplicate_tracker:
                # Some other, unrelated validation error on insert --
                # don't swallow it.
                raise

            tracker_name = frappe.db.get_value(
                "Monthly Attendance Tracker",
                {"employee": doc.employee, "month": payroll_month, "year": payroll_year}
            )
            # frappe.logger("olscpl_hrms").debug(
            #     f"Concurrent batch already created the Monthly Attendance "
            #     f"Tracker for {doc.employee} ({payroll_month} {payroll_year}); "
            #     f"using the existing one instead of failing."
            # )
            if not tracker_name:
                # Extremely unlikely (would mean it was created and then
                # deleted between the failed insert and this re-fetch),
                # but re-raise rather than silently doing nothing.
                raise

    month_summary = frappe.db.sql("""
        SELECT
            COUNT(CASE WHEN status = 'Present' THEN 1 END) as present_count,
            COUNT(CASE WHEN status = 'Absent' THEN 1 END) as absent_count,
            COUNT(CASE WHEN status = 'Half Day' THEN 1 END) as half_day_count,
            SUM(CASE WHEN custom_late_coming_count > 0 THEN custom_late_coming_count ELSE 0 END) as late_coming_total,
            SUM(CASE WHEN custom_short_leave_hours > 0 THEN custom_short_leave_hours ELSE 0 END) as short_leave_total,
            COUNT(*) as total_records
        FROM `tabAttendance`
        WHERE employee = %s
        AND attendance_date >= %s
        AND attendance_date <= %s
        AND docstatus < 2
        AND status IN ('Present', 'Half Day', 'Absent')
    """, (doc.employee, cycle_start, cycle_end), as_dict=True)[0]

    tracker = frappe.get_doc("Monthly Attendance Tracker", tracker_name)

    tracker.total_present_days = month_summary.present_count or 0
    tracker.total_absent_days = month_summary.absent_count or 0
    tracker.total_late_coming = int(month_summary.late_coming_total or 0)
    tracker.total_short_leave_hours = float(month_summary.short_leave_total or 0)

    tracker.remaining_late_coming = 4 - tracker.total_late_coming
    tracker.remaining_short_leave_hours = 4.0 - tracker.total_short_leave_hours

    if tracker.total_late_coming > 4:
        tracker.half_day_deductions = tracker.total_late_coming - 4
    else:
        tracker.half_day_deductions = 0

    tracker.last_updated = frappe.utils.now()
    tracker.flags.ignore_validate = True
    tracker.save(ignore_permissions=True)

    # frappe.logger("olscpl_hrms").debug(
    #     f"Tracker updated — {doc.employee} {payroll_month} {payroll_year}: "
    #     f"present={tracker.total_present_days}, absent={tracker.total_absent_days}, "
    #     f"LC={tracker.total_late_coming}/4, SL={tracker.total_short_leave_hours:.2f}/4"
    # )
