# olscpl_hrms/events/leave_application.py
#
# Comp-off "avail" enforcement, shared by Desk and the mobile API since
# both go through this same Document lifecycle (doc_events fire on save/
# submit regardless of the caller). Comp Off leave must be availed
# against a specific acquired credit (an Approved Compensatory Leave
# Request for the same employee) rather than a generic balance number -
# validate() is the source of truth for "is this credit still free"
# (a live query against other active Leave Applications), while
# Compensatory Leave Request.custom_consumption_status is just a
# maintained cache used to filter the Desk/API picker to unclaimed
# credits.
import frappe
from frappe import _


def validate(doc, method=None):
	if doc.leave_type != "Comp Off":
		return
	if not doc.custom_against_compensatory_leave_request:
		frappe.throw(_("Please select which acquired Compensatory Leave Request this Comp Off is being availed against"))
	clr_name = doc.custom_against_compensatory_leave_request
	clr = frappe.db.get_value(
		"Compensatory Leave Request", clr_name, ["employee", "workflow_state"], as_dict=True
	)
	if not clr:
		frappe.throw(_("Selected Compensatory Leave Request does not exist"))
	if clr.employee != doc.employee:
		frappe.throw(_("Selected Compensatory Leave Request does not belong to this employee"))
	if clr.workflow_state != "Approved":
		frappe.throw(_("Selected Compensatory Leave Request is not Approved yet"))
	existing = frappe.db.get_value(
		"Leave Application",
		{
			"custom_against_compensatory_leave_request": clr_name,
			"status": ["in", ["Open", "Approved"]],
			"name": ["!=", doc.name or ""],
		},
		"name",
	)
	if existing:
		frappe.throw(_("This Compensatory Leave Request has already been availed by {0}").format(existing))


def on_update(doc, method=None):
	_sync_consumption_status(doc)


def on_cancel(doc, method=None):
	if doc.leave_type == "Comp Off" and doc.custom_against_compensatory_leave_request:
		frappe.db.set_value(
			"Compensatory Leave Request", doc.custom_against_compensatory_leave_request,
			"custom_consumption_status", "Available",
		)


def _sync_consumption_status(doc):
	if doc.leave_type != "Comp Off" or not doc.custom_against_compensatory_leave_request:
		return
	# "Open" already reserves the credit (see validate()'s double-booking
	# check), not just "Approved" - otherwise the picker would still list
	# a credit that's already claimed by a pending request, and only fail
	# at save time instead of being filtered out up front.
	target = "Available" if doc.status in ("Rejected", "Cancelled") else "Consumed"
	frappe.db.set_value(
		"Compensatory Leave Request", doc.custom_against_compensatory_leave_request,
		"custom_consumption_status", target,
	)
