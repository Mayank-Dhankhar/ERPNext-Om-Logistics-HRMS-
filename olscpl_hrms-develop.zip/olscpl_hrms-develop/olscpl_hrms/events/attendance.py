import frappe
from frappe import _
from olscpl_hrms.events import attendance_steps as steps


def validate(doc, method=None):
    """Runs at Before Save. Order matches the original alphabetical
    chain: 010 Shift Policy Resolver runs first, then Process Daily
    Attendance (which depends on shift values it sets)."""
    steps.resolve_shift_policy(doc)      # was: 010 SHIFT POLICY RESOLVER
    steps.process_daily_attendance(doc)  # was: Process Daily Attendance
    steps.reconcile_half_day_visit_with_punches(doc)


def before_update_after_submit(doc, method=None):
    """validate() (above) only ever runs for Document._action == "save" -
    Frappe's own run_before_save_methods() calls a *different* hook,
    before_update_after_submit, for a save on an already-submitted
    document (Document._action == "update_after_submit") - see
    frappe/model/document.py's own docstring on this. Attendance is
    submittable and already-submitted by the time a later punch could
    possibly reconcile a half-day Visit (events/attendance_steps.py's
    reconcile_half_day_visit_with_punches()), so that reconciliation
    needs to run here too, not only from validate()."""
    steps.reconcile_half_day_visit_with_punches(doc)


def on_update(doc, method=None):
    """Runs After Save."""
    from olscpl_hrms.events.attendance_tracker_update import update_monthly_tracker
    update_monthly_tracker(doc)

def relink_open_regularizations(doc, method=None):
    """on_submit: attendance re-marked (old record cancelled, this one made)
    - point any still-open Attendance Regularization for that employee/day at
    this record. Otherwise approving it fails: "Cannot link cancelled document"."""
    frappe.db.sql(
        """UPDATE `tabAttendance Regularization` SET attendance_link = %s
        WHERE employee = %s AND for_date = %s AND docstatus = 0 AND IFNULL(attendance_link, '') != %s
        AND workflow_state IN ('Draft', 'Pending')""",
        (doc.name, doc.employee, doc.attendance_date, doc.name),
    )


def cancel_linked_regularizations(doc, method=None):
    """on_cancel: cancelling an Attendance cancels its Attendance
    Regularizations too. Approved ones are cancelled for real (runs before
    Frappe's linked-document check, so the cancel isn't blocked); Draft /
    Pending ones are marked Cancelled and unlinked, so they leave the
    approver's queue and no longer block deleting this Attendance.

    Neither path used to tell the employee it happened at all - the comment
    below explained why on the document itself, but nothing surfaced that to
    them, so a pending request just silently flipping to "Cancelled" in the
    app read as an unexplained rejection. clear()'s own "assignment removed"
    notification only reaches the approver, and reusing that path's
    Notification Log type ("Assignment") also used to make the mobile app
    misreport this as a freshly *raised* request to the approver (fixed
    separately in reporting_person.make_app_notification, which now also
    only treats a type "Alert" entry as a new request)."""
    from frappe.desk.doctype.notification_log.notification_log import enqueue_create_notification
    from frappe.desk.form.assign_to import clear

    for name, docstatus, employee in frappe.get_all(
        "Attendance Regularization",
        {"attendance_link": doc.name, "docstatus": ["<", 2], "workflow_state": ["not in", ["Rejected", "Withdrawn"]]},
        ["name", "docstatus", "employee"],
        as_list=True,
    ):
        reg = frappe.get_doc("Attendance Regularization", name)
        if docstatus == 1:
            reg.workflow_state = "Cancelled"
            reg.flags.ignore_permissions = True
            reg.cancel()
        else:
            reg.db_set({"workflow_state": "Cancelled", "attendance_link": None})
        clear(reg.doctype, reg.name, ignore_permissions=True)  # approver's to-do
        reg.add_comment("Comment", _("Cancelled with Attendance {0}").format(doc.name))

        employee_user = frappe.db.get_value("Employee", employee, "user_id")
        if employee_user:
            enqueue_create_notification(employee_user, {
                "type": "Alert",
                "document_type": reg.doctype,
                "document_name": reg.name,
                "from_user": frappe.session.user,
                "subject": _("Your Attendance Regularization {0} was cancelled because Attendance {1} was cancelled.").format(
                    reg.name, doc.name
                ),
            })
