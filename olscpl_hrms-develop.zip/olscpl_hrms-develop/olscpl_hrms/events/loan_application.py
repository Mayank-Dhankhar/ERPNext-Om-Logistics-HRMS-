from olscpl_hrms.events.loan_application_steps import (
	compute_eligibility,
	create_employee_loan_on_approval,
)


def validate(doc, method=None):
	compute_eligibility(doc, method)


def on_update(doc, method=None):
	create_employee_loan_on_approval(doc, method)