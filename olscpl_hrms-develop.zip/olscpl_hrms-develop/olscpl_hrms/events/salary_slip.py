import frappe
from olscpl_hrms.utils.payroll_constants import (
	NO_PF_ESI_DESIGNATIONS_ON_MANUAL,
	is_manual_salary_structure,
	is_no_deduction_employment_type,
)
from olscpl_hrms.events.salary_slip_steps import (
	purge_blank_rows,
	apply_attendance_lwp_bridge,
	apply_manual_salary_structure_override,
	apply_pf_epf_eps_split,
	apply_ex_gratia_provision,
	apply_professional_tax,
	apply_dynamic_esi,
	apply_tds_validation,
	apply_salary_slip_fixed_component,
	apply_loan_emi_deduction,
	mark_loan_emis_paid_on_submit,
)


def is_outsourced_employee(doc):
	"""
	Returns True if the Salary Slip's employee has Employment Type = 'Outsourced'.
	Used to suppress all deduction logic for outsourced staff (flat 60/40
	Basic/HRA split is handled separately, inside apply_pf_epf_eps_split).
	"""
	employment_type = frappe.db.get_value("Employee", doc.employee, "employment_type")
	return is_no_deduction_employment_type(employment_type)

def is_no_deduction_manual_designation(doc):
	"""
	True when this Salary Slip's employee has a Designation in
	NO_PF_ESI_DESIGNATIONS_ON_MANUAL (DRIVER, SUPERVISOR, SUPERVISOR-2)
	AND is on a Manual Salary Structure. For this combination, NO
	deductions apply at all (not just PF/ESI, but PT/LWF/ESIC/TDS/Loan
	EMI too) -- matches the requirement literally: no deduction field
	should populate on the slip for this case.
	"""
	if not is_manual_salary_structure(doc.salary_structure):
		return False
	designation = (frappe.db.get_value("Employee", doc.employee, "designation") or "").strip().upper()
	return designation in NO_PF_ESI_DESIGNATIONS_ON_MANUAL


def validate(doc, method=None):
	purge_blank_rows(doc, method)                          # Script: 000 Salary Slip Blank Row Purge
	apply_attendance_lwp_bridge(doc, method)                # Script: Attendance LWP Bridge Script
	apply_manual_salary_structure_override(doc, method)     # Script: 00 MANUAL SALARY STRUCTURE OVERRIDE
	apply_pf_epf_eps_split(doc, method)                     # Script: PF EPF EPS Split Calculation
	                                                          # (handles Outsourced flat 60/40 internally,
	                                                          # and Driver/Supervisor PF-skip on Manual)
	apply_ex_gratia_provision(doc, method)                  # Final Basic/AdvBon now settled; runs for ALL employees

	outsourced = is_outsourced_employee(doc)
	no_deduction_manual = is_no_deduction_manual_designation(doc)   # NEW

	if not outsourced and not no_deduction_manual:           # CHANGED: added second gate
		apply_professional_tax(doc, method)                # Script: Professional Tax State-wise Calculation
		apply_dynamic_esi(doc, method)                      # Script: Dynamic ESI Calculation
		apply_loan_emi_deduction(doc, method)               # New: Loan EMI deduction
		apply_tds_validation(doc, method)                   # Script: Phase3_TDS_Validation

	else:
		# CHANGED: full clear for BOTH cases now -- Outsourced uses a
		# flat 60/40 split (never produces negative HRA, so no ACCOM
		# case to preserve anymore), and Driver/Supervisor-on-Manual
		# gets zero deductions of any kind per the requirement.
		doc.set("deductions", [])

		doc.total_deduction = 0
		doc.base_total_deduction = 0
		doc.net_pay = round(doc.gross_pay or 0, 2)
		doc.base_net_pay = doc.net_pay
		doc.rounded_total = round(doc.net_pay)
		doc.base_rounded_total = doc.rounded_total

		doc.income_tax_deducted_till_date = 0
		doc.current_month_income_tax = 0
		doc.future_income_tax_deductions = 0
		doc.total_income_tax = 0
		doc.annual_taxable_amount = 0
		doc.tax_exemption_declaration = 0
		doc.standard_tax_exemption_amount = 0
		doc.deductions_before_tax_calculation = 0

	apply_salary_slip_fixed_component(doc, method)          # Script: ZZ Salary Slip Fixed Component
	                                                          # (kept running for all — earnings side too)


def on_submit(doc, method=None):
	# CHANGED: no EMI was deducted for Outsourced OR for
	# Driver/Supervisor-on-Manual staff, so nothing to mark paid /
	# no balance to touch for either case.
	if not is_outsourced_employee(doc) and not is_no_deduction_manual_designation(doc):
		mark_loan_emis_paid_on_submit(doc, method)