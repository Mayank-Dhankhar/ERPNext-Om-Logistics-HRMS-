import frappe
from frappe import _

PAYROLL_CYCLE_START_DAY = 26  # cycle runs 26th -> 25th of next month
PAYROLL_GRACE_DAYS = 3  # previous cycle stays open for this many days after a new cycle starts


def get_payroll_cycle(ref_date):
    """Returns (start_date, end_date) of the payroll cycle containing ref_date."""
    ref_date = frappe.utils.getdate(ref_date)
    if ref_date.day >= PAYROLL_CYCLE_START_DAY:
        start = ref_date.replace(day=PAYROLL_CYCLE_START_DAY)
    else:
        start = frappe.utils.add_months(ref_date, -1).replace(day=PAYROLL_CYCLE_START_DAY)
    end = frappe.utils.add_days(frappe.utils.add_months(start, 1), -1)
    return start, end


def auto_fill_missing_punch(doc):
    """was Server Script: Auto Fill Missing Punch From Attendance
    Before Save on Attendance Regularization"""
    attendance_name = doc.attendance_link

    # attendance_link is only set later in day_limit_and_punch_times, so on the
    # very first save look the Attendance up here so the times can be pre-filled.
    if not attendance_name and doc.employee and doc.for_date:
        attendance_name = frappe.db.get_value(
            "Attendance",
            {
                "employee": doc.employee,
                "attendance_date": doc.for_date,
                "docstatus": ["!=", 2]
            },
            "name",
        )

    if attendance_name:
        attendance = frappe.db.get_value(
            "Attendance",
            attendance_name,
            ["custom_check_in_time", "custom_check_out_time"],
            as_dict=True
        )

        if attendance:
            att_in = attendance.get("custom_check_in_time")
            att_out = attendance.get("custom_check_out_time")
            if not att_out and not att_in:
                # Attendance keeps no check-out without a check-in (Missing
                # Punch IN days) - take the day's last valid OUT punch.
                att_out = frappe.db.sql("""
                    SELECT MAX(time) FROM `tabEmployee Checkin`
                    WHERE employee = %s AND log_type = 'OUT' AND custom_custom_geo_validation = 'Valid'
                      AND time >= %s AND time < DATE_ADD(%s, INTERVAL 1 DAY)
                """, (doc.employee, doc.for_date, doc.for_date))[0][0]

            # The punch a type does not ask for always comes from the day's
            # real punches, or stays empty: insert() fills an unset Time
            # field with the current time (Document._set_defaults), which
            # approval would otherwise write to Attendance as a punch.
            if doc.regularization_type in ("Missing Punch OUT", "Less Working Hours"):
                if not att_in and doc.is_new():
                    frappe.throw(_("No Punch IN found for this day. Choose \"Both Punches Missing\"."))
                doc.requested_punch_in_time = att_in.time() if att_in else None

            elif doc.regularization_type == "Missing Punch IN":
                if not att_out and doc.is_new():
                    frappe.throw(_("No Punch OUT found for this day. Choose \"Both Punches Missing\"."))
                doc.requested_punch_out_time = att_out.time() if att_out else None


def day_limit_and_punch_times(doc):
    """was Server Script: Day Limit and Punch Times
    Before Save on Attendance Regularization"""
    if not doc.regularization_type:
        return

    attendance_date = doc.for_date
    if not attendance_date:
        frappe.throw("Attendance Date is required.")

    days_diff = frappe.utils.date_diff(frappe.utils.nowdate(), attendance_date)
    doc.days_since_attendance = days_diff

    # Original 7-day limit (restore later if needed):
    # if days_diff > 7:
    #     frappe.throw(
    #         f"Regularization allowed only within 7 days. "
    #         f"This request is {days_diff} days old."
    #     )

    # TEMPORARY 15-day limit (replaced by payroll cycle check below):
    # if days_diff > 15:
    #     frappe.throw(
    #         f"Regularization allowed only within 15 days. "
    #         f"This request is {days_diff} days old."
    #     )

    # Current payroll cycle check (+ grace window into the previous cycle)
    today = frappe.utils.getdate(frappe.utils.nowdate())
    cycle_start, cycle_end = get_payroll_cycle(today)
    att_date = frappe.utils.getdate(attendance_date)

    # Today's attendance is still open (punches can come in) - only past days.
    # New requests only, so ones raised before this rule can still be approved.
    if doc.is_new() and att_date >= today:
        frappe.throw("Regularization works on next day (you can regularise tomorrow for today's attendance)")

    allowed_start = cycle_start
    if frappe.utils.date_diff(today, cycle_start) < PAYROLL_GRACE_DAYS:
        # Still within grace days of the new cycle: previous cycle is open too
        allowed_start, _prev_end = get_payroll_cycle(frappe.utils.add_days(cycle_start, -1))

    if not (allowed_start <= att_date <= cycle_end):
        frappe.throw(
            f"Regularization is allowed only from "
            f"{frappe.utils.formatdate(allowed_start)} to {frappe.utils.formatdate(cycle_end)}."
        )

    att = frappe.db.get_value(
        "Attendance",
        {
            "employee": doc.employee,
            "attendance_date": attendance_date,
            "docstatus": ["!=", 2]
        },
        ["name", "status"],
        as_dict=True,
    )

    if not att:
        if doc.is_new() or doc.workflow_state == "Approved":
            frappe.throw("No Attendance found for this date. Regularization is not possible."
                + ("" if doc.is_new() else " Mark the attendance for this day again, then approve."))
        # Its attendance was cancelled: still let it be rejected / edited.
        doc.attendance_link = None
        return

    doc.attendance_link = att.name
    doc.original_status = att.status

    month = frappe.utils.formatdate(attendance_date, "MMMM")
    year = frappe.utils.getdate(attendance_date).year

    tracker_name = frappe.db.get_value(
        "Attendance Regularization Tracker",
        {"employee": doc.employee, "month": month, "year": year},
        "name",
    )

    total = 0
    if tracker_name:
        tracker = frappe.get_doc("Attendance Regularization Tracker", tracker_name)
        total = tracker.total_count or 0
    else:
        tracker = frappe.get_doc({
            "doctype": "Attendance Regularization Tracker",
            "employee": doc.employee,
            "month": month,
            "year": year,
            "total_count": 0,
        })
        tracker.insert(ignore_permissions=True)

    doc.monthly_regularization_count = total + 1
    doc.requires_hr_approval = 1 if (total + 1) > 4 else 0

    if doc.regularization_type in ("Missing Punch IN", "Both Punches Missing"):
        if not doc.requested_punch_in_time:
            frappe.throw("Requested Punch IN Time is required.")

    if doc.regularization_type in ("Missing Punch OUT", "Both Punches Missing", "Less Working Hours"):
        if not doc.requested_punch_out_time:
            frappe.throw("Requested Punch OUT Time is required.")


def maximum_regularizations_check(doc):
    """was Server Script: Maximum Attendance Regularizations
    Before Save on Attendance Regularization. Triggers only when
    workflow_state transitions from non-Pending to Pending.

    TEMPORARILY DISABLED: monthly (payroll cycle 26-25) limit of 4 requests
    is switched off for testing. Delete the `return` and uncomment the block
    below to re-enable.
    """
    # The function is kept (and returns immediately) so the hook that
    # calls it keeps working without errors.
    return

    # if not (doc.employee and doc.for_date):
    #     return
    #
    # old_doc = doc.get_doc_before_save()
    #
    # if old_doc and old_doc.workflow_state != "Pending" and doc.workflow_state == "Pending":
    #     att_date = doc.for_date
    #
    #     count = frappe.db.sql("""
    #     SELECT COUNT(*)
    #     FROM `tabAttendance Regularization`
    #     WHERE employee = %s
    #     AND workflow_state IN ('Pending','Approved','Rejected')
    #     AND name != %s
    #     AND for_date BETWEEN
    #         (
    #             CASE
    #                 WHEN DAY(%s) >= 26
    #                     THEN DATE_FORMAT(%s, '%%Y-%%m-26')
    #                 ELSE
    #                     DATE_FORMAT(DATE_SUB(%s, INTERVAL 1 MONTH), '%%Y-%%m-26')
    #             END
    #         )
    #     AND
    #         (
    #             CASE
    #                 WHEN DAY(%s) >= 26
    #                     THEN DATE_FORMAT(DATE_ADD(%s, INTERVAL 1 MONTH), '%%Y-%%m-25')
    #                 ELSE
    #                     DATE_FORMAT(%s, '%%Y-%%m-25')
    #             END
    #         )
    #     """, (
    #         doc.employee,
    #         doc.name,
    #         att_date, att_date, att_date,
    #         att_date, att_date, att_date
    #     ))[0][0]
    #
    #     if count >= 4:
    #         frappe.throw(
    #             "You cannot submit more than 4 Attendance Regularization requests in a payroll cycle (26-25)."
    #         )


def auto_assign_to_manager(doc):
    """was Server Script: Attendance Regularization Auto Assign To Manager
    After Insert on Attendance Regularization"""
    # Assigned to the chosen Reporting Person (only they or a System Manager
    # can approve - utils/reporting_person.py), not reports_to.
    manager = doc.get("reporting_person")

    if manager:
        manager_user = frappe.db.get_value("Employee", manager, "user_id")

        if manager_user:
            frappe.get_doc({
                "doctype": "ToDo",
                "owner": manager_user,
                "allocated_to": manager_user,
                "assigned_by": frappe.session.user,
                "reference_type": doc.doctype,
                "reference_name": doc.name,
                "description": "Attendance Regularization Pending Approval"
            }).insert(ignore_permissions=True)
            # The bare ToDo above raises no alert - notify like Visit/WFH do.
            from frappe.desk.doctype.notification_log.notification_log import enqueue_create_notification

            enqueue_create_notification(manager_user, {
                "type": "Alert",
                "document_type": doc.doctype,
                "document_name": doc.name,
                "subject": frappe._("{0} has requested Attendance Regularization for {1}").format(doc.employee_name, doc.for_date),
                "from_user": frappe.session.user,
            })


def update_attendance_after_approval(doc):
    """was Server Script: Auto-Update Logic
    After Save on Attendance Regularization"""
    if doc.workflow_state == "Approved" and doc.attendance_link:
        attendance = frappe.get_doc("Attendance", doc.attendance_link)
        attendance.flags.ignore_validate_update_after_submit = True

        att_date = frappe.utils.getdate(doc.for_date)

        if doc.requested_punch_in_time:
            t = frappe.utils.get_time(doc.requested_punch_in_time)
            new_in = frappe.utils.get_datetime(f"{att_date} {t}")
            attendance.custom_check_in_time = new_in

        if doc.requested_punch_out_time:
            t = frappe.utils.get_time(doc.requested_punch_out_time)
            new_out = frappe.utils.get_datetime(f"{att_date} {t}")
            attendance.custom_check_out_time = new_out

        attendance.custom_calculation_done = 0
        attendance.working_hours = 0
        attendance.custom_violation_type = ""
        attendance.custom_short_leave_hours = 0
        attendance.custom_late_coming_count = 0
        attendance.custom_status_detail = ""

        attendance.run_method("validate")
        attendance.run_method("before_save")

        attendance.save(ignore_permissions=True)
        attendance.reload()

        frappe.msgprint(
            f"Attendance {attendance.name} updated after Manager approval.",
            indicator="green"
        )

def revert_attendance_on_cancel(doc):
    """on_cancel: undo update_attendance_after_approval - drop the requested
    punch times and recalculate the day from the real check-ins, by the same
    rules (events/attendance_steps.process_daily_attendance)."""
    if not doc.attendance_link or frappe.db.get_value("Attendance", doc.attendance_link, "docstatus") != 1:
        return
    attendance = frappe.get_doc("Attendance", doc.attendance_link)
    attendance.flags.ignore_validate_update_after_submit = True
    attendance.custom_check_in_time = None
    attendance.custom_check_out_time = None
    attendance.custom_calculation_done = 0
    attendance.working_hours = 0
    attendance.custom_violation_type = ""
    attendance.custom_short_leave_hours = 0
    attendance.custom_late_coming_count = 0
    attendance.custom_status_detail = ""
    attendance.run_method("validate")
    attendance.run_method("before_save")
    attendance.save(ignore_permissions=True)
    frappe.msgprint(
        frappe._("Attendance {0} recalculated from the actual punches.").format(attendance.name), indicator="blue"
    )
