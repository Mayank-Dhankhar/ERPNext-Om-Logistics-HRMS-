# olscpl_hrms/events/job_opening.py
import frappe
from frappe import _


def only_one_general_application(doc, method=None):
	"""validate: there is one pinned General Application, shared by every
	company (patches/v1_1/setup_job_application_reference_fields.py) - no
	second one, however it is made (desk, import, API)."""
	if doc.get("custom_is_general") and frappe.db.exists(
		"Job Opening", {"custom_is_general": 1, "name": ["!=", doc.name]}
	):
		frappe.throw(_("There is already a General Application - only one can exist."))
