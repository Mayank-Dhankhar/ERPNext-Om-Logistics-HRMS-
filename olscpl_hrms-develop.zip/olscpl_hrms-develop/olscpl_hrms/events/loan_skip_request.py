from olscpl_hrms.events.loan_skip_request_steps import process_skip_on_approval


def on_update(doc, method=None):
	process_skip_on_approval(doc, method)
	