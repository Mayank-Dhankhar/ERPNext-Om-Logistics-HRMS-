# olscpl_hrms/events/job_offer.py
#
# Submitting a Job Offer emails the candidate their Letter of Intent with
# Accept / Decline buttons (job_offer.js confirms with HR first). The buttons
# open /job-offer-response, a no-login page keyed by a per-offer secret; the
# candidate confirms there, which calls respond_to_offer() below. Requiring a
# click on the page - not acting on the link itself - means mail security
# scanners that pre-open links can't accept an offer by accident.
import secrets

import frappe
from frappe import _
from frappe.rate_limiter import rate_limit
from frappe.utils import escape_html, format_date, get_url, now_datetime

from olscpl_hrms.utils.email_layout import branded_email, company_email, rapidshyp_email, sender_cc

BUTTON = (
	"display:inline-block; padding:13px 28px; border-radius:10px; font-size:14px;"
	" font-weight:700; text-decoration:none; letter-spacing:0.2px;"
)


def _response_url(doc, action):
	return get_url(
		f"/job-offer-response?offer={doc.name}&key={doc.custom_offer_response_key}&action={action}"
	)


def _cc_emails(doc):
	"""custom_offer_letter_cc split on commas / semicolons / spaces / new lines."""
	import re

	return [e for e in re.split(r"[\s,;]+", doc.get("custom_offer_letter_cc") or "") if e]


def validate_offer_letter_cc(doc, method=None):
	"""Job Offer validate: every Offer Letter CC entry must be an email."""
	for email in _cc_emails(doc):
		frappe.utils.validate_email_address(email, throw=True)


def require_sender_signature(doc, method=None):
	"""Job Offer before_submit: the emailed offer letter prints the submitting
	user's signature as Authorised Signatory - refuse to send it unsigned.
	job_offer.js asks for an upload first; this catches any other route."""
	from olscpl_hrms.api.employee_data import get_user_signature

	if not get_user_signature(frappe.session.user):
		frappe.throw(
			_("Upload your signature on your User profile before submitting - it's printed as the Authorised Signatory on the offer letter."),
			title=_("Signature Required"),
		)


def send_offer_letter(doc, method=None):
	"""Job Offer on_submit."""
	if not doc.applicant_email:
		frappe.msgprint(
			_("Offer letter email not sent - the applicant has no email address."),
			title=_("Offer Letter"),
			indicator="orange",
		)
		return

	if not doc.custom_offer_response_key:
		doc.db_set("custom_offer_response_key", secrets.token_urlsafe(24), update_modified=False)

	from olscpl_hrms.api import rapidshyp

	# RapidShyp: no letter attached - it's handed over on the day of joining
	is_rapidshyp = rapidshyp.is_rapidshyp(doc.company)
	attachments = [] if is_rapidshyp else _offer_letter_attachment(doc)

	name = escape_html(doc.applicant_name or "")
	intro = rapidshyp.offer_email_intro(doc) if is_rapidshyp else (
		f"<p>Dear {name},</p>"
		f"<p>We are delighted to offer you the position of <b>{escape_html(doc.designation or '')}</b>"
		f" at <b>{escape_html(doc.company or '')}</b>, with your date of joining on"
		f" <b>{format_date(doc.offer_date)}</b>.</p>"
		+ (
			"<p>Your offer letter is attached. Please review it and let us know your decision below.</p>"
			if attachments
			else "<p>Please let us know your decision below. Your offer letter will be shared with you separately.</p>"
		)
	)
	body = (
		intro
		+ "<table role='presentation' cellpadding='0' cellspacing='0' style='margin:24px 0 8px 0;'><tr>"
		f"<td style='padding-right:10px;'><a href='{_response_url(doc, 'accept')}' target='_blank'"
		f" style='{BUTTON} background-color:#1f8a5b; color:#ffffff;'>Accept Offer</a></td>"
		f"<td><a href='{_response_url(doc, 'decline')}' target='_blank'"
		f" style='{BUTTON} background-color:#ffffff; color:#b42318; border:1px solid #f1c4c0;'>Decline</a></td>"
		"</tr></table>"
		"<p style='font-size:13px; color:#8a8ca8;'>You will be asked to confirm your choice on the next page.</p>"
	)

	try:
		frappe.sendmail(
			recipients=[doc.applicant_email],
			cc=sender_cc([doc.applicant_email]),
			subject=_("Your Job Offer - {0}").format(rapidshyp.BRAND) if is_rapidshyp
			else _("Your Offer Letter - {0}").format(doc.company),
			message=rapidshyp_email(_("Your Job Offer"), body + rapidshyp.signoff_html()) if is_rapidshyp
			else branded_email(_("Your Offer Letter"), body, signoff=True),
			attachments=attachments,
			reference_doctype=doc.doctype,
			reference_name=doc.name,
			now=True,
		)
	except Exception:
		frappe.log_error(title=f"Offer letter email failed for {doc.name}")
		frappe.local.message_log = [
			m for m in frappe.local.message_log if "Outgoing Mail Server" not in str(m)
		]
		frappe.msgprint(
			_("Offer letter email could not be sent to {0}. Check the outgoing Email Account.").format(
				doc.applicant_email
			),
			title=_("Offer Letter"),
			indicator="orange",
		)
		return

	frappe.msgprint(
		_("Offer letter email: sent to {0}.").format(doc.applicant_email),
		title=_("Offer Letter"),
		indicator="green",
	)
	_send_offer_letter_cc(doc, attachments)


def _offer_letter_attachment(doc):
	"""[offer letter PDF] for sendmail, or [] if it can't be built."""
	try:
		from olscpl_hrms.api.letter_of_intent import _onboarding_doc_for_print, build_letter_of_intent_pdf

		return [
			{
				"fname": f"Offer-Letter-{doc.name}.pdf",
				"fcontent": build_letter_of_intent_pdf(_onboarding_doc_for_print("Job Offer", doc.name)),
			}
		]
	except Exception:
		frappe.log_error(title=f"Offer letter PDF failed for {doc.name}")
		return []


def _send_offer_letter_cc(doc, attachments):
	"""Offer Letter CC: a separate email with just the candidate's details and
	the offer letter - none of the candidate's Accept / Decline links. Always
	has the letter, also for RapidShyp (whose candidate gets it on joining)."""
	cc = _cc_emails(doc)
	if not cc:
		return
	attachments = attachments or _offer_letter_attachment(doc)

	phone = frappe.db.get_value("Job Applicant", doc.job_applicant, "phone_number") if doc.job_applicant else None
	rows = [
		(_("Candidate"), doc.applicant_name),
		(_("Email"), doc.applicant_email),
		(_("Phone"), phone),
		(_("Designation"), doc.designation),
		(_("Company"), doc.company),
		(_("Date of Joining"), format_date(doc.offer_date) if doc.offer_date else None),
		(_("Job Offer"), doc.name),
	]
	body = (
		f"<p>An offer letter has been sent to <b>{escape_html(doc.applicant_name or '')}</b>.</p>"
		"<table role='presentation' cellpadding='6' cellspacing='0' style='border-collapse:collapse; font-size:14px;'>"
		+ "".join(
			f"<tr><td style='color:#8a8ca8; padding-right:18px;'>{label}</td><td><b>{escape_html(str(value))}</b></td></tr>"
			for label, value in rows
			if value
		)
		+ "</table>"
		+ ("<p>The offer letter is attached.</p>" if attachments else "")
	)
	try:
		frappe.sendmail(
			recipients=cc,
			subject=_("Offer Letter - {0} - {1}").format(doc.applicant_name, doc.designation),
			message=branded_email(_("Offer Letter"), body),
			attachments=attachments,
			reference_doctype=doc.doctype,
			reference_name=doc.name,
			now=True,
		)
	except Exception:
		frappe.log_error(title=f"Offer letter CC email failed for {doc.name}")
		frappe.msgprint(_("Offer letter CC email could not be sent."), title=_("Offer Letter"), indicator="orange")
		return
	frappe.msgprint(_("Offer letter CC: sent to {0}.").format(", ".join(cc)), title=_("Offer Letter"), indicator="green")


def get_offer_by_key(offer, key):
	"""The submitted Job Offer this link is for, or None if the key is wrong."""
	if not offer or not key:
		return None
	stored = frappe.db.get_value("Job Offer", {"name": offer, "docstatus": 1}, "custom_offer_response_key")
	if not stored or not secrets.compare_digest(stored, key):
		return None
	return frappe.get_doc("Job Offer", offer)


@frappe.whitelist(allow_guest=True, methods=["POST"])
@rate_limit(limit=20, seconds=60 * 60)
def respond_to_offer(offer, key, response, reason=None):
	doc = get_offer_by_key(offer, key)
	if not doc:
		frappe.throw(_("This link is invalid."), frappe.PermissionError)
	if response not in ("accept", "decline"):
		frappe.throw(_("Invalid response."))
	if doc.status != "Awaiting Response":
		frappe.throw(_("You have already responded to this offer ({0}).").format(_(doc.status)))

	doc.status = "Accepted" if response == "accept" else "Rejected"
	doc.custom_offer_responded_on = now_datetime()
	if response == "decline":
		doc.custom_offer_decline_reason = (reason or "").strip()[:1000] or None
	# Key checked above. Job Offer.on_change (stock hrms) updates the Job
	# Applicant through permission-checked frappe.set_value, which a Guest
	# can never pass - so this one save runs as Administrator, then back.
	frappe.set_user("Administrator")
	try:
		doc.save(ignore_permissions=True)  # status is allow_on_submit
		frappe.db.commit()
	finally:
		frappe.set_user("Guest")

	_notify_hr(doc)
	return {"status": doc.status}


def _notify_hr(doc):
	"""Tell whoever created the offer that the candidate responded."""
	owner_email = frappe.db.get_value("User", doc.owner, "email")
	if not owner_email or "@" not in owner_email:
		return
	accepted = doc.status == "Accepted"
	body = (
		f"<p><b>{escape_html(doc.applicant_name or '')}</b> has "
		f"<b style='color:{'#1f8a5b' if accepted else '#b42318'};'>{'accepted' if accepted else 'declined'}</b>"
		f" the offer for <b>{escape_html(doc.designation or '')}</b> ({escape_html(doc.name)}).</p>"
		+ (
			f"<p><b>Reason:</b> {escape_html(doc.custom_offer_decline_reason)}</p>"
			if not accepted and doc.custom_offer_decline_reason
			else ""
		)
		+ (
			"<p>Next step: open the Job Offer and click <b>Send Onboarding Link</b>.</p>"
			if accepted
			else ""
		)
		+ f"<p><a href='{get_url(f'/app/job-offer/{doc.name}')}' style='color:#3d3f9e; font-weight:700;'>Open Job Offer</a></p>"
	)
	try:
		frappe.sendmail(
			recipients=[owner_email],
			subject=_("Offer {0}: {1}").format(
				_("Accepted") if accepted else _("Declined"), doc.applicant_name
			),
			message=company_email(doc.company, _("Offer Accepted") if accepted else _("Offer Declined"), body, signoff=True),
			reference_doctype=doc.doctype,
			reference_name=doc.name,
		)
	except Exception:
		frappe.log_error(title=f"Offer response HR notification failed for {doc.name}")
