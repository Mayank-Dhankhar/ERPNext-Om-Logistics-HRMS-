from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

import frappe
from frappe.utils import get_datetime, getdate


def has_sufficient_hours(actual, required):
    """Standard tolerance for clock sync only (5 minutes)"""
    tolerance = 0.0833  # 5 minutes
    return actual >= (required - tolerance)


def is_in_late_coming_range(actual, required):
    """
    Check if hours are in Late Coming range.
    Range: 8h 00m to (required - 1 min)
    For 8.5h requirement: 8.0h to 8.49h
    For 9.0h requirement: 8.0h to 8.98h
    """
    if required < 8:
        lower_bound = required - 1.0
    else:
        lower_bound = 8.0
    upper_bound = required - 0.0167
    return lower_bound <= actual < upper_bound


def has_sufficient_balance(needed, available):
    """Check if sufficient balance with 1-minute tolerance"""
    tolerance = 0.0167  # 1 minute
    return available >= (needed - tolerance)


def decimal_to_hhmm(hours):
    """Convert decimal hours to HHh MMm format"""
    h = int(hours)
    m = int((hours - h) * 60)
    return f"{h}h {m:02d}m"


def is_weekly_off(employee, att_date):
	# Defensive fix: att_date can arrive as a string (e.g. from Attendance
	# Request bulk creation) or as a proper date object (e.g. from normal
	# Attendance save). Normalize it before calling strftime().
	att_date = frappe.utils.getdate(att_date)

	day_name = att_date.strftime("%A")
	emp = get_employee_info(employee)
	off_type, fixed_day = emp.get("weekly_off_type"), emp.get("fixed_off_day")
	if off_type == "Fixed Weekly Off":
		return fixed_day == day_name
	# Branch Rotational -> check Shift Assignment
	off_day = frappe.db.get_value(
		"Shift Assignment",
		{
			"employee": employee,
			"start_date": ["<=", att_date],
			"end_date": [">=", att_date],
			"docstatus": ["!=", 2],
		},
		"weekly_off_day",
	)
	return off_day == day_name


# ---------------------------------------------------------------------------
# PERF helpers (Oct 2026): remove per-record DB round-trips from
# resolve_shift_policy() / process_daily_attendance().
# ---------------------------------------------------------------------------

_MONTH_NAMES = (
    "January", "February", "March", "April", "May", "June", "July",
    "August", "September", "October", "November", "December",
)


def _request_cache(name):
    """Dict stored on frappe.local - lives for ONE request / background job
    only, so it is always fresh at the start of the next one. Deliberately
    NOT the Redis document cache: that is only invalidated by saves made
    through Frappe, not by direct SQL updates on tabEmployee / tabShift Type."""
    cache = getattr(frappe.local, name, None)
    if cache is None:
        cache = {}
        setattr(frappe.local, name, cache)
    return cache


def get_employee_info(employee):
    """Employee fields used by the attendance steps - ONE query per employee
    per request (was 4-5 queries plus a full get_doc per record)."""
    cache = _request_cache("_olscpl_emp_cache")
    if employee not in cache:
        cache[employee] = frappe.db.get_value(
            "Employee",
            employee,
            ["default_shift", "holiday_list", "weekly_off_type", "fixed_off_day"],
            as_dict=True,
        ) or frappe._dict()
    return cache[employee]


def get_shift_type_info(shift_type):
    """Shift Type fields (None if it does not exist, as before) - one query
    per shift type per request."""
    cache = _request_cache("_olscpl_shift_cache")
    if shift_type not in cache:
        cache[shift_type] = frappe.db.get_value(
            "Shift Type",
            shift_type,
            [
                "start_time",
                "end_time",
                "custom_grace_period_mins_from_start",
                "custom_late_coming_window_end_mins",
                "custom_short_leave_window_end_mins",
                "custom_required_work_hours",
            ],
            as_dict=True,
        )
    return cache[shift_type]


def get_payroll_cycle_config():
    """(cycle_start_day, cycle_end_day, use_custom_cycle) - read once per
    request. Logic is identical to the old inline block."""
    cached = getattr(frappe.local, "_olscpl_payroll_cycle", None)
    if cached:
        return cached

    payroll_config = None
    if frappe.db.table_exists("Payroll Cycle Settings"):
        payroll_config = frappe.db.get_value(
            "Payroll Cycle Settings",
            None,
            ["cycle_start_day", "cycle_end_day", "enabled", "use_calendar_month"],
            as_dict=True,
        )

    if not payroll_config:
        result = (26, 25, True)
    else:
        result = (
            int(payroll_config.get("cycle_start_day") or 26),
            int(payroll_config.get("cycle_end_day") or 25),
            bool(
                payroll_config.get("enabled", True)
                and not payroll_config.get("use_calendar_month", False)
            ),
        )

    frappe.local._olscpl_payroll_cycle = result
    return result


def get_holiday(holiday_list, att_date):
    """Holiday row (with .description) for the date, or None. Cached per
    request - a backfill batch looks up the same few holiday lists/dates
    thousands of times."""
    if not holiday_list:
        return None

    att_date = getdate(att_date)
    cache = _request_cache("_olscpl_holiday_cache")

    key = (holiday_list, att_date)
    if key not in cache:
        cache[key] = frappe.db.get_value(
            "Holiday",
            {"parent": holiday_list, "holiday_date": att_date},
            ["description"],
            as_dict=True,
        )
    return cache[key]


def calc_work_metrics(first_in, last_out, att_date):
    """Pure-Python replacement for the old work_calc SELECT.
    Returns (working_hours, punch_hour, punch_minute, is_saturday, day_of_month).

    working_hours is rounded to 4 decimals, half-up, to match MariaDB's
    TIMESTAMPDIFF(SECOND, ...) / 3600 (DECIMAL scale 4) exactly."""
    fi = get_datetime(first_in)
    lo = get_datetime(last_out)
    seconds = int((lo - fi).total_seconds())  # TIMESTAMPDIFF truncates to whole seconds
    working_hours = float(
        (Decimal(seconds) / Decimal(3600)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
    )
    d = getdate(att_date)
    # MariaDB DAYOFWEEK(): Sunday=1 ... Saturday=7  ->  Python weekday(): Saturday=5
    return working_hours, fi.hour, fi.minute, d.weekday() == 5, d.day


def get_payroll_month_year(att_date, use_custom_cycle, cycle_start_day):
    """(MONTHNAME, YEAR) of the payroll period - same rule as the old SQL:
    custom cycle and day >= cycle_start_day -> next calendar month."""
    d = getdate(att_date)
    month, year = d.month, d.year
    if use_custom_cycle and d.day >= cycle_start_day:
        month += 1
        if month == 13:
            month, year = 1, year + 1
    return _MONTH_NAMES[month - 1], year
