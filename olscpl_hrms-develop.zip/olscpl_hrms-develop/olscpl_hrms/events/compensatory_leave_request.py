# olscpl_hrms/events/compensatory_leave_request.py
#
# Stock Compensatory Leave Request has no before_cancel/on_cancel logic
# to keep workflow_state in sync with docstatus (unlike Leave Application,
# whose before_cancel() sets status="Cancelled" itself). Without this,
# cancelling an Approved request correctly reverses the Leave Allocation
# credit but leaves workflow_state stuck showing "Approved" - the Desk
# title indicator and get_available_comp_off_dates' own filtering both
# read workflow_state, so a stale value there is more than cosmetic.
import frappe


def on_cancel(doc, method=None):
	frappe.db.set_value("Compensatory Leave Request", doc.name, "workflow_state", "Cancelled")


def set_approver(doc, method=None):
	"""Keep custom_approver (a hidden Link to User) in sync with the
	requesting employee's actual manager, same reports_to lookup
	api/compensatory_leave.py's _is_direct_manager already uses for
	authorization - so the "Comp Off Alerts" Notification (recipient:
	receiver_by_document_field=custom_approver) reaches only this request's
	real approver, not every user holding the org-wide "Leave Approver"
	role (the previous receiver_by_role config, which sent one alert per
	pending Comp Off request, company-wide, to every such user - the
	"multiple notifications" bug). No manager on file (reports_to unset)
	means no recipient, same as desk's own approval authorization already
	has nobody to notify in that case.
	"""
	# custom_approver is now the employee's chosen Reporting Person (picked
	# in the app; only they or a System Manager can approve - see
	# utils/reporting_person.py). reports_to is just the fallback when
	# nothing was picked, so a choice is never overwritten.
	if not doc.custom_approver:
		from olscpl_hrms.utils.reporting_person import default_reporting_value

		doc.custom_approver = default_reporting_value(doc.doctype, doc.employee)
