# olscpl_hrms/events/job_applicant.py
#
# The public Job Application web form's "Resume Attachment" field goes
# through Frappe core's own generic upload_file endpoint (ControlAttach ->
# FileUploader -> POST /api/method/upload_file, see arjun_theme's earlier
# "always public" fix for the same field) - unlike
# olscpl_hrms.api.onboarding_portal.upload_document(), there's no seam to
# hook a custom filename into before the file is physically written, and
# overriding /api/method/upload_file itself would be a site-wide change
# to every file upload on the system for the sake of one field. Renaming
# the File after the fact - once the Job Applicant record actually exists
# and has an applicant_name to name it after - is the safe, narrowly-scoped
# way to get the same "readable name, not whatever the candidate's device
# called it" result upload_document() already gives the onboarding
# checklist documents.
#
# Only File.file_name (the display name shown in list views/attachments
# panels) is changed here, not File.name (a random hash, Frappe's own
# primary key for the doctype) or file_url (the physical storage path) -
# renaming the actual bytes on disk to match isn't needed for what this is
# for (a readable name in the UI) and would be considerably riskier for no
# extra benefit.
import re

import frappe
from frappe import _


def rename_resume_attachment(doc, method=None):
	if not doc.resume_attachment:
		return

	file_name = frappe.get_all(
		"File",
		filters={
			"attached_to_doctype": "Job Applicant",
			"attached_to_name": doc.name,
			"attached_to_field": "resume_attachment",
			"file_url": doc.resume_attachment,
		},
		pluck="name",
		limit=1,
	)
	if not file_name:
		return
	file_name = file_name[0]

	current = frappe.db.get_value("File", file_name, "file_name") or ""
	ext = f".{current.rsplit('.', 1)[-1]}" if "." in current else ""
	applicant = re.sub(r'[\\/:*?"<>|]+', " ", (doc.applicant_name or "").strip()).strip() or doc.name
	new_name = f"Resume_{applicant}{ext}"

	if current == new_name:
		return

	frappe.db.set_value("File", file_name, "file_name", new_name, update_modified=False)


def set_department_and_position(doc, method=None):
	"""Department comes from the opening applied to. The pinned general
	opening (Job Opening.custom_is_general) has none: there the applicant
	picks it (or "Other" and names it), plus any open job (by title) or
	"Other" and names the position. The application itself stays on the
	general opening."""
	if not doc.job_title:
		return
	jo = frappe.db.get_value("Job Opening", doc.job_title, ["department", "custom_is_general", "company"], as_dict=True)
	if not jo:
		return
	if not jo.custom_is_general:
		if jo.department:
			doc.custom_department = jo.department
		doc.custom_company = jo.company  # follows the opening (fetch_if_empty keeps a general pick)
		return
	if not doc.is_new():
		return
	from olscpl_hrms.api.job_application import general_companies

	# the general opening is shared by every company - the applicant picks one
	if doc.get("custom_preferred_company"):
		if doc.custom_preferred_company not in general_companies():
			frappe.throw(_("Please choose a Company from the list"))
		doc.custom_company = doc.custom_preferred_company
	elif frappe.flags.in_web_form or frappe.session.user == "Guest":
		frappe.throw(_("Please choose a Company"))
	else:
		doc.custom_company = doc.custom_company or jo.company
	department = doc.custom_preferred_department
	if not department:
		frappe.throw(_("Please choose a Department"))
	if department == "Other":
		if not (doc.custom_other_department or "").strip():
			frappe.throw(_("Please enter the department name"))
		doc.custom_department = None
	elif frappe.db.exists("Department", department):
		doc.custom_department = department
		doc.custom_other_department = None
	else:
		frappe.throw(_("Please choose a Department from the list, or Other"))
	if not doc.custom_position_applied:
		frappe.throw(_("Please choose the position you are applying for"))
	if doc.custom_position_applied == "Other":
		if not (doc.custom_other_position or "").strip():
			frappe.throw(_("Please enter the position you are applying for"))
		return
	doc.custom_other_position = None
	if not frappe.db.exists("Job Opening", {
		"job_title": doc.custom_position_applied, "status": "Open", "publish": 1, "custom_is_general": 0,
		"company": doc.custom_company,
	}):
		frappe.throw(_("That job opening is no longer open - please choose another, or Other"))


def set_channel_and_source(doc, method=None):
	"""New applicants: Application Channel (set by the job application form from
	?via=qr / ?via=link, see setup_job_application_reference_fields) defaults to
	Website for the public form / careers API and "Added by HR" for the desk.
	QR Code and Link applicants are walk-ins: source Walk In; straight off the
	site with no source given: Company Websites."""
	if not doc.is_new():
		return
	if not doc.get("custom_application_channel"):
		doc.custom_application_channel = "Website" if frappe.session.user == "Guest" else "Added by HR"
	if doc.custom_application_channel in ("QR Code", "Link"):
		doc.source = "Walk In"
	elif doc.custom_application_channel == "Website" and not doc.source:
		doc.source = "Company Websites"
