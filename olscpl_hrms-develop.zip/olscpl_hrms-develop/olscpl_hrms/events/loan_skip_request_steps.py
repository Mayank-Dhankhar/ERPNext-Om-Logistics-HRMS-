import frappe
from frappe.utils import add_months, getdate


def process_skip_on_approval(doc, method=None):
	"""
	Fires on Loan Skip Request update. When workflow_state transitions to
	'Approved', marks the target EMI as Skipped and extends the loan term
	by appending a new EMI row at the end of the schedule (deferred, not
	forgiven - policy point 9).
	Idempotent - if the target installment is already Skipped, does nothing.
	"""
	if doc.workflow_state != "Approved":
		return

	loan = frappe.get_doc("Employee Loan", doc.employee_loan)

	target_row = None
	for emi_row in loan.emi_schedule:
		if emi_row.installment_number == doc.installment_number:
			target_row = emi_row
			break

	if not target_row:
		frappe.throw(f"Installment {doc.installment_number} not found on {loan.name}")

	if target_row.status == "Skipped":
		return  # already processed, avoid duplicate extension

	if target_row.status != "Pending":
		frappe.throw(
			f"Installment {doc.installment_number} is '{target_row.status}', can only skip a Pending installment."
		)

	target_row.status = "Skipped"
	target_row.remarks = f"Skipped via {doc.name} - HR approved"

	last_installment = max(loan.emi_schedule, key=lambda r: r.installment_number)
	new_due_date = add_months(getdate(last_installment.due_date), 1)

	loan.append("emi_schedule", {
		"installment_number": last_installment.installment_number + 1,
		"due_date": new_due_date,
		"emi_amount": target_row.emi_amount,
		"status": "Pending",
		"remarks": f"Added due to skip of installment {doc.installment_number} via {doc.name}"
	})

	loan.total_installments = loan.total_installments + 1
	loan.save(ignore_permissions=True)

	frappe.msgprint(
		f"Installment {doc.installment_number} skipped. New installment {last_installment.installment_number + 1} added, due {new_due_date}.",
		title="Loan Term Extended",
		indicator="blue"
	)
	