# olscpl_hrms/events/interview_feedback.py
#
# Interview Feedback's "Candidate Details" (patches/v1_1/
# add_interview_feedback_candidate_details.py): what the HR / personal round
# learns about the candidate. A new feedback starts with what the candidate's
# previous feedback held, so the next round's interviewer sees it; and the
# details go into the Interview's Interview Summary as points - replacing only
# that block, so anything HR typed there themselves stays.
import re

import frappe

from olscpl_hrms.patches.v1_1.add_interview_feedback_candidate_details import CARRIED, FIELDS, SUMMARY_LABELS

HEADER = "Candidate Details (from interview feedback"
BLOCK_RE = re.compile(re.escape(HEADER) + r"[^\n]*\n(?:• [^\n]*(?:\n|$))*")
MARRIED_ONLY = {"custom_spouse", "custom_son", "custom_daughter"}


def _ready():
	return frappe.get_meta("Interview Feedback").has_field(CARRIED[0])


@frappe.whitelist()
def previous_details(job_applicant, exclude=None):
	"""The candidate's latest feedback that has Candidate Details -> {field: value}."""
	if not job_applicant or not _ready():
		return {}
	frappe.has_permission("Job Applicant", "read", job_applicant, throw=True)
	return _previous_details(job_applicant, exclude)


def _previous_details(job_applicant, exclude=None):
	"""previous_details() without the permission check. Each field takes its
	latest non-empty value across the candidate's feedback, so a round where
	only a few details were noted doesn't hide fuller earlier ones."""
	if not job_applicant or not _ready():
		return {}
	values = {}
	for row in frappe.get_all("Interview Feedback", {"job_applicant": job_applicant, "docstatus": ["<", 2],
			"name": ["!=", exclude or ""]}, CARRIED, order_by="creation desc", limit=20):
		for f, v in row.items():
			if v and f not in values:
				values[f] = v
	return values

def copy_previous_details(doc, method=None):
	"""before_insert - for feedback made without the form (e.g. through the API)."""
	for field, value in previous_details(doc.job_applicant).items():
		if not doc.get(field):
			doc.set(field, value)


def detail_items(doc):
	"""[(field, label, value)] of the Candidate Details filled on this feedback."""
	labels = {f["fieldname"]: f["label"] for f in FIELDS} | SUMMARY_LABELS
	items = []
	for field in CARRIED:
		value = doc.get(field)
		if not value or (field in MARRIED_ONLY and not doc.get("custom_married")):
			continue
		items.append((field, labels[field], "Yes" if field == "custom_married" else " ".join(str(value).split())))
	return items


def summary_points(doc):
	return [f"• {label}: {value}" for _f, label, value in detail_items(doc)]


def update_interview_summary(doc, method=None):
	"""on_update / on_submit / on_update_after_submit: the details as points in the Interview Summary."""
	if not doc.interview or not _ready():
		return
	points = summary_points(doc)
	current = frappe.db.get_value("Interview", doc.interview, "interview_summary") or ""
	rest = BLOCK_RE.sub("", current).strip()
	interviewer = frappe.utils.get_fullname(doc.interviewer) if doc.interviewer else ""
	block = (f"{HEADER}{' by ' + interviewer if interviewer else ''}):\n" + "\n".join(points)) if points else ""
	summary = "\n\n".join(part for part in (block, rest) if part)
	if summary != current:
		frappe.db.set_value("Interview", doc.interview, "interview_summary", summary)


def sync_interview_status(doc, method=None):
	"""on_submit / on_cancel: the Interview's Status follows its submitted feedback
	(stock HRMS leaves it for HR to set by hand). Until every interviewer on the
	panel has submitted it stays Under Review; then any Rejected -> Rejected, any
	Under Review -> Under Review, all Cleared -> Cleared. No feedback left -> Pending.
	Only while the Interview is still a draft - a submitted one keeps its result."""
	if not doc.interview:
		return
	iv = frappe.db.get_value("Interview", doc.interview, ["status", "docstatus"], as_dict=True)
	if not iv or iv.docstatus != 0:
		return
	results = frappe.get_all("Interview Feedback", {"interview": doc.interview, "docstatus": 1}, ["interviewer", "result"])
	panel = set(frappe.get_all("Interview Detail", {"parent": doc.interview}, pluck="interviewer"))
	given = {r.interviewer for r in results}
	got = {r.result for r in results}
	if not results:
		status = "Pending"
	elif panel - given:  # still waiting on someone on the panel
		status = "Under Review"
	elif "Rejected" in got:
		status = "Rejected"
	elif "Under Review" in got:
		status = "Under Review"
	else:
		status = "Cleared"
	if status != iv.status:
		frappe.db.set_value("Interview", doc.interview, "status", status)
