"""
olscpl_hrms/events/iam_sync.py

Employee doc_event handlers that build the agreed IAM payload and publish
the corresponding Kafka event. Wire these into hooks.py as shown at the
bottom of this file.

Resolved decisions (see file history for the earlier back-and-forth):

  1. Department/Designation format — RESOLVED 2026-09-15. Tested against
     two real Employee records on uat-copy.local and found the "Name - ABBR"
     convention is NOT consistent across records (one record's abbreviation
     turned out to be a company code, not a department code; another had
     no dash at all). Per Chandan's confirmation that HRMS should "send the
     existing values" as-is, get_department_code()/get_designation_code()
     below now pass the raw department/designation display name through
     unchanged — no splitting.

  2. Company/Branch code — RESOLVED 2026-09-15. `add_company_branch_code_fields`
     (olscpl_hrms.patches.v1_1) added `custom_company_code` on Company and
     `custom_branch_code` on Branch; both are fetched from their respective
     masters as confirmed on uat-copy.local. get_company_code()/
     get_branch_code() below now read those fields directly.

  3. Username is mandatory for IAM, but in ERPNext the Employee record is
     routinely created before a linked User (login) account exists — so a
     CREATION event fired at Employee insert time can have a blank
     username. RESOLVED 2026-09-17 (Option A, agreed with Sumit): defer
     CREATION until a user_id is actually present, tracked via the
     `custom_iam_synced` Check field (added by
     olscpl_hrms.patches.v1_1.add_iam_synced_field). An Employee with no
     user_id yet publishes nothing at insert; the first save afterward
     where user_id becomes set is treated as the real CREATION moment
     instead of a generic UPDATE, and the flag is set so later saves go
     through the normal UPDATE/ACTIVATION/DELETION path.
"""

import frappe
from olscpl_hrms.utils.kafka_producer import publish_employee_event

# Employee fields that matter to IAM — used to detect no-op updates so we
# don't spam Kafka on every unrelated Employee save (e.g. changing a leave
# balance field should not fire an UPDATE event).
IAM_RELEVANT_FIELDS = [
	"employee_number",
	"user_id",
	"first_name",
	"last_name",
	"cell_number",
	"department",
	"designation",
	"status",
	"company",
	"branch",
]


def get_department_code(department: str) -> str:
	"""Send the existing Department display name as-is — the 'Name - ABBR'
	dash convention was found NOT to be a reliable department code across
	records (see note at top of file), so no parsing is done here."""
	return department or ""


def get_designation_code(designation: str) -> str:
	"""Send the existing Designation display name as-is."""
	return designation or ""


def get_company_code(company: str) -> str:
	"""Read the numeric code from Company.custom_company_code (added by
	olscpl_hrms.patches.v1_1.add_company_branch_code_fields)."""
	if not company:
		return ""
	return frappe.db.get_value("Company", company, "custom_company_code") or ""


def get_branch_code(branch: str) -> str:
	"""Read the numeric code from Branch.custom_branch_code (added by
	olscpl_hrms.patches.v1_1.add_company_branch_code_fields)."""
	if not branch:
		return ""
	return frappe.db.get_value("Branch", branch, "custom_branch_code") or ""


def build_iam_payload(doc) -> dict:
	return {
		"employeeId": doc.employee_number or doc.name,
		"username": doc.user_id or "",
		"firstName": doc.first_name or "",
		"lastName": doc.last_name or "",
		"email": doc.user_id or doc.company_email or doc.personal_email or "",
		"phoneNumber": doc.cell_number or "",
		"departmentCode": get_department_code(doc.department),
		"designationCode": get_designation_code(doc.designation),
		"activeStatus": doc.status == "Active",
		"companyCode": get_company_code(doc.company),
		"branchCode": get_branch_code(doc.branch),
		"metadata": {},
	}


def _mark_synced(doc):
	"""Flip custom_iam_synced without triggering another on_update cycle or
	bumping modified/modified_by noise."""
	frappe.db.set_value("Employee", doc.name, "custom_iam_synced", 1, update_modified=False)
	doc.custom_iam_synced = 1


def on_employee_after_insert(doc, method=None):
	if not doc.user_id:
		# No linked login yet — publishing now would send IAM a mandatory
		# username as blank. Wait for on_employee_update to catch the save
		# where user_id gets set, and treat that as the real CREATION.
		frappe.logger("iam_kafka").info(
			f"Skipping CREATION for {doc.employee_number or doc.name} — no user_id yet"
		)
		return

	publish_employee_event("CREATION", build_iam_payload(doc))
	_mark_synced(doc)


def on_employee_update(doc, method=None):
	before = doc.get_doc_before_save()
	if before is None:
		# nothing to diff against (e.g. programmatic re-save) — skip
		return

	if not doc.get("custom_iam_synced"):
		# CREATION hasn't gone out yet (see on_employee_after_insert). This
		# employee only becomes real to IAM once a user_id shows up.
		if doc.user_id:
			publish_employee_event("CREATION", build_iam_payload(doc))
			_mark_synced(doc)
		else:
			frappe.logger("iam_kafka").info(
				f"Skipping event for {doc.employee_number or doc.name} — still no user_id, not yet synced to IAM"
			)
		return

	changed_iam_fields = [f for f in IAM_RELEVANT_FIELDS if before.get(f) != doc.get(f)]
	if not changed_iam_fields:
		return

	# Status transition into/out of Active gets its own event type per the
	# agreed contract; everything else is a generic UPDATE.
	if "status" in changed_iam_fields:
		was_active = before.get("status") == "Active"
		is_active = doc.status == "Active"
		if not was_active and is_active:
			publish_employee_event("ACTIVATION", build_iam_payload(doc))
			return
		if was_active and not is_active:
			publish_employee_event("DELETION", build_iam_payload(doc))
			return

	publish_employee_event("UPDATE", build_iam_payload(doc))


# ---------------------------------------------------------------------------
# hooks.py wiring — already merged into olscpl_hrms/hooks.py's Employee
# doc_events entry, alongside the existing sync_username / onboarding
# copy hooks:
#
#   "Employee": {
#       "after_insert": [
#           "olscpl_hrms.events.employee.sync_username",
#           "olscpl_hrms.events.employee.copy_onboarding_attachments",
#           "olscpl_hrms.events.employee.copy_onboarding_salary_annexure",
#           "olscpl_hrms.events.iam_sync.on_employee_after_insert",
#       ],
#       "on_update": [
#           "olscpl_hrms.events.employee.sync_username",
#           "olscpl_hrms.events.iam_sync.on_employee_update",
#       ],
#   },
# ---------------------------------------------------------------------------
