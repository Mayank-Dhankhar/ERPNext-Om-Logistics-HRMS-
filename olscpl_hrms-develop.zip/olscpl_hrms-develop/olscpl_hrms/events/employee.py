# olscpl_hrms/events/employee.py
#
# Employees want to log in with their Employee ID (e.g. "699999") instead
# of their email. Frappe already accepts User.username as a login
# identifier once "Allow Login Using User Name" is on in System Settings -
# this just keeps that field mirroring the linked Employee's ID so no new
# login mechanism is needed.
import frappe
from frappe import _
from frappe.utils import add_days, getdate, today
from olscpl_hrms.utils.email_layout import branded_email

PROBATION_REMINDER_DAYS_BEFORE = 15


def copy_onboarding_attachments(doc, method=None):
	"""Employees created via Employee Onboarding's "Create > Employee" mapped-doc
	button (see employee_onboarding.js) start out with none of the candidate's
	documents - Aadhaar, PAN, marksheets, guarantor form, photograph, etc. -
	that were attached to the Employee Onboarding record. HR had to keep both
	records open to find them.

	get_mapped_doc auto-copies same-named fields between source and target, so
	the new Employee carries the same job_applicant as the Employee Onboarding
	it came from - that's the reliable link back to the source record (no
	direct Employee Onboarding -> Employee link is guaranteed to exist yet,
	since that field is only set client-side after the fact).
	"""
	if not doc.get("job_applicant"):
		return

	onboarding_name = frappe.db.get_value(
		"Employee Onboarding", {"job_applicant": doc.job_applicant}, "name"
	)
	if not onboarding_name:
		return

	_copy_files("Employee Onboarding", onboarding_name, "Employee", doc.name)
	attach_interview_feedback(doc)


def attach_interview_feedback(doc):
	"""All interview rounds' feedback (results, ratings, comments, Candidate
	Details, HR notes) as one private PDF on the new Employee, next to the
	onboarding documents - same PDF the next round's interviewers get."""
	from olscpl_hrms.events.interview import _previous_rounds_pdf

	last = frappe.get_all("Interview", {"job_applicant": doc.job_applicant, "docstatus": ["<", 2]},
		["name", "job_applicant", "job_opening", "interview_round"], order_by="creation desc", limit=1)
	if not last:
		return
	try:
		pdf = _previous_rounds_pdf(last[0], include_self=True)
		if not pdf or frappe.db.exists("File", {"attached_to_doctype": "Employee", "attached_to_name": doc.name,
				"file_name": pdf["fname"]}):
			return
		frappe.get_doc({
			"doctype": "File",
			"file_name": pdf["fname"],
			"content": pdf["fcontent"],
			"attached_to_doctype": "Employee",
			"attached_to_name": doc.name,
			"is_private": 1,
		}).insert(ignore_permissions=True)
	except Exception:
		frappe.log_error(title=f"Interview feedback PDF not attached to Employee {doc.name}")


def _copy_files(source_doctype, source_name, target_doctype, target_name):
	source_files = frappe.get_all(
		"File",
		filters={"attached_to_doctype": source_doctype, "attached_to_name": source_name},
		fields=["name", "file_url"],
	)
	if not source_files:
		return 0

	already_copied = set(
		frappe.get_all(
			"File",
			filters={"attached_to_doctype": target_doctype, "attached_to_name": target_name},
			pluck="file_url",
		)
	)

	copied = 0
	for f in source_files:
		if f.file_url in already_copied:
			continue
		new_file = frappe.copy_doc(frappe.get_doc("File", f.name))
		new_file.attached_to_doctype = target_doctype
		new_file.attached_to_name = target_name
		new_file.attached_to_field = None
		new_file.insert(ignore_permissions=True)
		copied += 1
	return copied


@frappe.whitelist()
def backfill_onboarding_attachments():
	"""One-time catch-up for Employees created before copy_onboarding_attachments
	existed. Employee Onboarding.employee gets set (client-side, once HR links
	the two records) for every onboarding that already resulted in an Employee -
	that's a more complete net than job_applicant matching for a backfill, since
	it covers records the live hook's matching wouldn't reach in edge cases.
	Safe to re-run: _copy_files skips files already present on the target.
	"""
	frappe.only_for("System Manager")

	onboardings = frappe.get_all(
		"Employee Onboarding",
		filters={"employee": ["is", "set"]},
		fields=["name", "employee"],
	)

	total_copied = 0
	touched_employees = []
	for ob in onboardings:
		copied = _copy_files("Employee Onboarding", ob.name, "Employee", ob.employee)
		if copied:
			total_copied += copied
			touched_employees.append(ob.employee)

	return {"total_files_copied": total_copied, "employees_updated": touched_employees}


# Job Offer fieldname -> Employee fieldname. Both doctypes carry their own
# "Salary annexure" tab (see custom_field.json / add_job_offer_custom_fields.py) -
# same totals, but the Job Offer side also holds the itemised breakup/
# allowances/deductions/benefits child tables used to print the Letter of
# Intent (see api/letter_of_intent.py). Employee only keeps the summary
# figures, so only those need to travel across; only custom_base_salary
# renames (to custom_base_amount) on the way.
SALARY_ANNEXURE_FIELD_MAP = {
	"custom_loi_salary_structure": "custom_loi_salary_structure",
	"custom_base_salary": "custom_base_amount",
	"custom_total_breakupmonth": "custom_total_breakupmonth",
	"custom_total_breakupannum": "custom_total_breakupannum",
	"custom_total_allowmonth": "custom_total_allowmonth",
	"custom_gross_salarymonth": "custom_gross_salarymonth",
	"custom_total_allowannum": "custom_total_allowannum",
	"custom_gross_salaryannum": "custom_gross_salaryannum",
	"custom_total_deductmonth": "custom_total_deductmonth",
	"custom_total_deductannum": "custom_total_deductannum",
	"custom_total_benefitmonth": "custom_total_benefitmonth",
	"custom_total_benefitannum": "custom_total_benefitannum",
	"custom_ctcmonth": "custom_ctcmonth",
	"custom_net_salarymonth": "custom_net_salarymonth",
	"custom_ctcannum": "custom_ctcannum",
	"custom_net_salaryannum": "custom_net_salaryannum",
}


def copy_onboarding_salary_annexure(doc, method=None):
	"""Employees created via "Create > Employee" start with a blank Salary
	annexure tab even though the candidate's Job Offer/Letter of Intent
	already has the full breakup HR agreed with them - nothing carried it
	across, so HR had to retype every figure by hand. Same job_applicant
	matching approach as copy_onboarding_attachments above.
	"""
	if not doc.get("job_applicant"):
		return

	job_offer = frappe.db.get_value(
		"Job Offer",
		{"job_applicant": doc.job_applicant},
		list(SALARY_ANNEXURE_FIELD_MAP.keys()),
		as_dict=True,
	)
	if not job_offer:
		return

	values = {
		employee_fieldname: job_offer.get(job_offer_fieldname)
		for job_offer_fieldname, employee_fieldname in SALARY_ANNEXURE_FIELD_MAP.items()
		if job_offer.get(job_offer_fieldname)
	}
	if not values:
		return

	if hasattr(doc, "db_set"):
		# doc is the real just-inserted Document, same object the insert
		# response is built from - db_set (unlike a bare frappe.db.set_value)
		# also updates the in-memory field, so the browser's "New Employee"
		# form shows these figures right away instead of only after a
		# separate reload.
		for fieldname, value in values.items():
			doc.db_set(fieldname, value, update_modified=False)
	else:
		frappe.db.set_value("Employee", doc.name, values, update_modified=False)


@frappe.whitelist()
def backfill_salary_annexure():
	"""One-time catch-up for Employees created before copy_onboarding_salary_annexure
	existed - same idea as backfill_onboarding_attachments above. Only fills
	employees with no LOI Salary Structure set yet, so it never overwrites
	figures HR has since edited by hand on the Employee record itself.
	"""
	frappe.only_for("System Manager")

	employees = frappe.get_all(
		"Employee",
		filters={"job_applicant": ["is", "set"], "custom_loi_salary_structure": ["is", "not set"]},
		fields=["name", "job_applicant"],
	)

	updated = []
	for emp in employees:
		before = frappe.db.get_value("Employee", emp.name, "custom_loi_salary_structure")
		copy_onboarding_salary_annexure(frappe._dict(name=emp.name, job_applicant=emp.job_applicant))
		after = frappe.db.get_value("Employee", emp.name, "custom_loi_salary_structure")
		if after and after != before:
			updated.append(emp.name)

	return {"employees_updated": updated}


def sync_username(doc, method=None):
	if not doc.user_id:
		return

	current_username = frappe.db.get_value("User", doc.user_id, "username")
	if current_username == doc.name:
		return

	taken_by = frappe.db.get_value("User", {"username": doc.name}, "name")
	if taken_by and taken_by != doc.user_id:
		return

	frappe.db.set_value("User", doc.user_id, "username", doc.name)


def send_probation_ending_reminders():
	"""Daily scheduled job (see hooks.py) - nothing else in stock hrms or
	this app watches Employee.scheduled_confirmation_date, so a probation
	period could quietly lapse with nobody prompted to confirm or extend
	it. Fires once, PROBATION_REMINDER_DAYS_BEFORE days out, to the
	reporting manager (falling back to an HR Manager if the employee has
	no reports_to, or no linked user), same recipient-resolution pattern
	as notify_hr_if_documents_complete.

	Exact-date match, same idempotency approach as hrms's own birthday/
	work-anniversary reminders - only fires the one day the offset
	lands on, not a standing daily nag.
	"""
	target_date = add_days(getdate(today()), PROBATION_REMINDER_DAYS_BEFORE)

	employees = frappe.get_all(
		"Employee",
		filters={
			"status": "Active",
			"scheduled_confirmation_date": target_date,
			"final_confirmation_date": ["is", "not set"],
		},
		fields=["name", "employee_name", "reports_to", "department", "designation"],
	)

	for emp in employees:
		_notify_manager_of_upcoming_confirmation(emp, target_date)


def _notify_manager_of_upcoming_confirmation(emp, confirmation_date):
	notify_user = None
	if emp.reports_to:
		notify_user = frappe.db.get_value("Employee", emp.reports_to, "user_id")

	if not notify_user:
		hr_managers = frappe.get_all(
			"Has Role", filters={"role": "HR Manager", "parenttype": "User"}, pluck="parent"
		)
		notify_user = hr_managers[0] if hr_managers else None

	if not notify_user:
		return

	review_url = frappe.utils.get_url(f"/app/employee/{emp.name}")

	frappe.get_doc(
		{
			"doctype": "ToDo",
			"allocated_to": notify_user,
			"reference_type": "Employee",
			"reference_name": emp.name,
			"description": _(
				"{0}'s probation period ends on {1} - confirm or extend before then. Review: {2}"
			).format(emp.employee_name, frappe.utils.format_date(confirmation_date), review_url),
			"priority": "Medium",
		}
	).insert(ignore_permissions=True)

	user_email = frappe.db.get_value("User", notify_user, "email")
	if user_email:
		try:
			message = frappe.render_template(
				(
					"<p>{{ employee_name }}'s probation period ends on {{ confirmation_date }}.</p>"
					"<p>Please review and either confirm or extend before then.</p>"
					"<p><a href='{{ url }}'>Open their Employee record</a></p>"
				),
				{
					"employee_name": emp.employee_name,
					"confirmation_date": frappe.utils.format_date(confirmation_date),
					"url": review_url,
				},
			)
			frappe.sendmail(
				recipients=[user_email],
				subject=_("{0}: probation ending {1}").format(
					emp.employee_name, frappe.utils.format_date(confirmation_date)
				),
				message=branded_email(_("Probation Ending"), message, signoff=True),
				now=True,
			)
		except Exception:
			frappe.log_error(title="Probation-ending reminder email failed")

	frappe.db.commit()
