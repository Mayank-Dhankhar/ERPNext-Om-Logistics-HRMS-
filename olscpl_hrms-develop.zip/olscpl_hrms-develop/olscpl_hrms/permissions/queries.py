import frappe


def attendance_regularization(user):
    """List scope: own requests + ones where this user is the chosen
    Reporting Person (see utils/reporting_person.py), plus approved/cancelled
    ones for HR Managers (they may cancel those). System Manager sees all."""
    if not user:
        user = frappe.session.user
    if user == "Administrator" or frappe.db.exists("Has Role", {"parent": user, "role": "System Manager"}):
        return ""

    employee = frappe.db.get_value("Employee", {"user_id": user}, "name")
    hr = _is_hr_manager(user)
    if not employee:
        return "`tabAttendance Regularization`.docstatus > 0" if hr else "1=0"
    return (
        "(`tabAttendance Regularization`.employee = {0} "
        "OR `tabAttendance Regularization`.reporting_person = {0} "
        "OR {1}{2})"
    ).format(frappe.db.escape(employee), _shared("Attendance Regularization", user),
        " OR `tabAttendance Regularization`.docstatus > 0" if hr else "")


def _is_hr_manager(user):
    return bool(frappe.db.exists("Has Role", {"parent": user, "role": "HR Manager"}))


def attendance_regularization_has_permission(doc, user=None, ptype=None, **kwargs):
    """Doc-level gate (hooks.py `has_permission`): permission_query_conditions
    above only scopes list views, not a direct fetch by name/URL."""
    user = user or frappe.session.user

    if user == "Administrator":
        return True
    if frappe.db.exists("Has Role", {"parent": user, "role": "System Manager"}):
        return True

    # HR Managers: approved (and cancelled) requests, to cancel one if needed
    # - pending ones stay with the Reporting Person
    if doc.docstatus in (1, 2) and _is_hr_manager(user):
        return True
    employee = frappe.db.get_value("Employee", {"user_id": user}, "name")
    if not employee:
        return False
    return doc.employee == employee or doc.get("reporting_person") == employee


def work_from_home_request(user):
    """Replaces the DB-only "Permission Query WFH" Server Script, which only
    matched an `approver` field the app never fills - so the chosen
    Reporting Person never saw the request. Own + chosen; System Manager all."""
    if not user:
        user = frappe.session.user
    if user == "Administrator" or frappe.db.exists("Has Role", {"parent": user, "role": "System Manager"}):
        return ""

    u = frappe.db.escape(user)
    employee = frappe.db.get_value("Employee", {"user_id": user}, "name")
    emp = frappe.db.escape(employee) if employee else "''"
    return (
        "(`tabWork From Home Request`.owner = {u} "
        "OR `tabWork From Home Request`.employee = {emp} "
        "OR `tabWork From Home Request`.reporting_person = {emp} "
        "OR {shared})"
    ).format(u=u, emp=emp, shared=_shared("Work From Home Request", user))


def _shared(doctype, user):
    """Records shared with `user` (the Reporting Person - utils/reporting_person.py).
    Frappe only ORs shared docs into a list for users WITHOUT role read
    access, so HR Manager/HR User/Manager holders would lose them here."""
    return (
        "`tab{0}`.name in (select share_name from `tabDocShare` "
        "where share_doctype = {1} and user = {2} and `read` = 1)"
    ).format(doctype, frappe.db.escape(doctype), frappe.db.escape(user))


def employee_separation(user):
    if not user:
        user = frappe.session.user

    is_admin = user == "Administrator"
    is_hr = frappe.db.exists("Has Role", {"parent": user, "role": "HR Manager"})
    if is_admin or is_hr:
        return ""

    employee = frappe.db.get_value("Employee", {"user_id": user}, "name")
    if not employee:
        return "1=0"

    # Separation records are explicit about who their approving manager is
    # (separation_manager, set at creation - see reference system's
    # MANGER_ID) rather than always trusting the employee's *current*
    # reports_to, which can change after the request was filed. Also
    # visible to anyone who's the assigned approver on one of this
    # separation's clearance stages (PTP CCD, IT, Regional HR, etc.) -
    # without this a clearance approver can never even open the record to
    # reach the "Clearance Status" button in the first place, discovered
    # by actually testing as that role rather than assuming the query
    # above covered it.
    return (
        "(`tabEmployee Separation`.employee = {employee} "
        "OR `tabEmployee Separation`.separation_manager = {employee} "
        "OR `tabEmployee Separation`.name IN ("
        "SELECT employee_separation FROM `tabEmployee Separation Clearance` "
        "WHERE approver = {employee}))"
    ).format(employee=frappe.db.escape(employee))


def employee_separation_has_permission(doc, user=None, ptype=None, **kwargs):
    """Doc-level gate (registered via hooks.py `has_permission`) - the
    query condition above only scopes list views, not a direct single-doc
    fetch by name/URL."""
    user = user or frappe.session.user

    if user == "Administrator":
        return True
    if frappe.db.exists("Has Role", {"parent": user, "role": "HR Manager"}):
        return True

    employee = frappe.db.get_value("Employee", {"user_id": user}, "name")
    if not employee:
        return False

    if doc.employee == employee or doc.get("separation_manager") == employee:
        return True

    is_clearance_approver = bool(
        frappe.db.exists(
            "Employee Separation Clearance",
            {"employee_separation": doc.name, "approver": employee},
        )
    )
    if not is_clearance_approver:
        return False

    # A clearance approver can open this record (read) - otherwise they'd
    # have no way to ever reach the "Clearance Status" button - but has no
    # business editing salary/personal/exit details on it. Their own
    # write access is scoped separately, to just their own clearance
    # row(s), by employee_separation_clearance_has_permission.
    return ptype not in ("write", "delete", "submit", "cancel")



def employee_separation_clearance(user):
    if not user:
        user = frappe.session.user

    is_admin = user == "Administrator"
    is_hr = frappe.db.exists("Has Role", {"parent": user, "role": "HR Manager"})
    if is_admin or is_hr:
        return ""

    employee = frappe.db.get_value("Employee", {"user_id": user}, "name")
    if not employee:
        return "1=0"

    # Visible to the resigning employee themselves (read their own
    # clearance progress) and to whoever is the assigned approver for
    # that specific stage - never to an unrelated employee just because
    # they hold the broad "Employee" role.
    return (
        "(`tabEmployee Separation Clearance`.employee = {employee} "
        "OR `tabEmployee Separation Clearance`.approver = {employee})"
    ).format(employee=frappe.db.escape(employee))


def employee_separation_clearance_has_permission(doc, user=None, ptype=None, **kwargs):
    # Frappe's has_permission controller hook calls this with the keyword
    # `ptype` (see frappe.permissions.has_controller_permissions), not
    # `permission_type` - the wrong name here previously meant every call
    # silently got permission_type=None and always fell through to the
    # read-level check below, even for a write. **kwargs absorbs the other
    # keywords Frappe also passes (user, debug) without needing to declare
    # each one explicitly.
    user = user or frappe.session.user

    if user == "Administrator":
        return True
    if frappe.db.exists("Has Role", {"parent": user, "role": "HR Manager"}):
        return True

    employee = frappe.db.get_value("Employee", {"user_id": user}, "name")
    if not employee:
        return False

    if ptype in ("write", "delete", "submit", "cancel"):
        # Only the assigned approver for THIS stage may change it - never
        # the resigning employee, even though they're allowed to read
        # their own clearance progress below. Employee-role doctype
        # permission grants write=1 broadly (approvers need that, since
        # an approver is themselves just an Employee-role user) - this is
        # what actually narrows it down to their own assigned row.
        return doc.approver == employee

    # Read (and anything else): visible to the resigning employee, to see
    # their own progress, as well as the assigned approver.
    return doc.employee == employee or doc.approver == employee
