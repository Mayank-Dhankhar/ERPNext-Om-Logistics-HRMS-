# olscpl_hrms/asset_version.py
#
# Same technique as ess_dashboard.asset_version / arjun_theme.hooks._v():
# these website pages' JS/CSS are plain files under public/ with a fixed
# URL, so editing the file on the server has no visible effect for anyone
# whose browser already cached it, until the query string itself changes.
import os

_PUBLIC_DIR = os.path.join(os.path.dirname(__file__), "public")


def asset_v(relpath):
	abs_path = os.path.join(_PUBLIC_DIR, relpath)
	try:
		return str(int(os.path.getmtime(abs_path)))
	except OSError:
		return "0"
