app_name = "olscpl_hrms"
app_title = "OLSCPL HRMS"
app_publisher = "OM Logistics Supply Chain Pvt. Ltd."
app_description = "Custom HRMS extensions for OM Logistics"
app_email = "sumitgupta@olsc.in"
app_license = "mit"

app_logo_url = "/assets/olscpl_hrms/images/om_logo.svg"

# These files are referenced by a fixed URL, so browsers are free to cache
# them indefinitely once fetched - editing the file doesn't change its URL,
# so a plain reload/migrate on the server doesn't guarantee anyone's browser
# actually re-fetches it (bit twice during development: a CSS edit looked
# "not applied" purely because the tab already had the old response cached).
# _v() appends each file's own mtime as a query string so the URL itself
# changes whenever the file does, forcing a fresh fetch automatically -
# same approach arjun_theme's hooks.py already uses.
import os


def _v(relpath):
	abs_path = os.path.join(os.path.dirname(__file__), "public", relpath)
	try:
		return str(int(os.path.getmtime(abs_path)))
	except OSError:
		return "0"


app_include_css = f"/assets/olscpl_hrms/css/olscpl_theme.css?v={_v('css/olscpl_theme.css')}"
app_include_js = [
	f"/assets/olscpl_hrms/js/desk_scroll_fix.js?v={_v('js/desk_scroll_fix.js')}",
	f"/assets/olscpl_hrms/js/dashboard_chart_company_filter.js?v={_v('js/dashboard_chart_company_filter.js')}",
	f"/assets/olscpl_hrms/js/attachment_delete_dialog.js?v={_v('js/attachment_delete_dialog.js')}",
	f"/assets/olscpl_hrms/js/signature_gate.js?v={_v('js/signature_gate.js')}",
	f"/assets/olscpl_hrms/js/om_loader.js?v={_v('js/om_loader.js')}",
]
extend_bootinfo = "olscpl_hrms.utils.payroll_constants.extend_bootinfo"
web_include_css = f"/assets/olscpl_hrms/css/olscpl_theme.css?v={_v('css/olscpl_theme.css')}"
web_include_js = f"/assets/olscpl_hrms/js/login_theme.js?v={_v('js/login_theme.js')}"

# Apps
# ------------------

# required_apps = []

# Each item in the list will be shown as an app in the apps page
# add_to_apps_screen = [
# 	{
# 		"name": "olscpl_hrms",
# 		"logo": "/assets/olscpl_hrms/logo.png",
# 		"title": "OLSCPL HRMS",
# 		"route": "/olscpl_hrms",
# 		"has_permission": "olscpl_hrms.api.permission.has_app_permission"
# 	}
# ]

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
# app_include_css = "/assets/olscpl_hrms/css/olscpl_hrms.css"
# app_include_js = "/assets/olscpl_hrms/js/olscpl_hrms.js"

# include js, css files in header of web template
# web_include_css = "/assets/olscpl_hrms/css/olscpl_hrms.css"
# web_include_js = "/assets/olscpl_hrms/js/olscpl_hrms.js"

# include custom scss in every website theme (without file extension ".scss")
# website_theme_scss = "olscpl_hrms/public/scss/website"

# include js, css files in header of web form
# webform_include_js = {"doctype": "public/js/doctype.js"}
# webform_include_css = {"doctype": "public/css/doctype.css"}

# include js in page
# page_js = {"page" : "public/js/file.js"}

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
doctype_list_js = {
	"Attendance": "public/js/attendance_list.js",
	"Job Applicant": "public/js/job_applicant_list.js",
}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Svg Icons
# ------------------
# include app icons in desk
# app_include_icons = "olscpl_hrms/public/icons.svg"

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
# 	"Role": "home_page"
# }

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# Jinja
# ----------

# add methods and filters to jinja environment
# jinja = {
# 	"methods": "olscpl_hrms.utils.jinja_methods",
# 	"filters": "olscpl_hrms.utils.jinja_filters"
# }

# Installation
# ------------

# before_install = "olscpl_hrms.install.before_install"
# Seeds HR-maintained masters (State Wage Master, PT, ESI, LWF, ...) on a FRESH site only.
# These are deliberately NOT in `fixtures` below - fixtures overwrite site data on every migrate.
after_install = "olscpl_hrms.seed_masters.seed_masters"

# Uninstallation
# ------------

# before_uninstall = "olscpl_hrms.uninstall.before_uninstall"
# after_uninstall = "olscpl_hrms.uninstall.after_uninstall"

# Migration
# ------------
# Patches only run once (tracked in the Patch Log), but bench migrate's own
# post-patch "Updating Dashboard for <app>" step re-syncs each app's stock
# Workspace fixtures afterwards - which was reverting Payroll's `roles`
# (set by setup_role_based_hr_access) back to empty on every migrate, even
# though every other workspace the same patch touches survives that step
# untouched. execute() is fully idempotent (every helper checks db.exists /
# dedupes before writing), so re-running it here after dashboard sync fixes
# this without needing a new patch each time.
after_migrate = [
	"olscpl_hrms.patches.v1_1.setup_role_based_hr_access.execute",
	"olscpl_hrms.patches.v1_1.add_careers_page_shortcuts.execute",
	"olscpl_hrms.patches.v1_1.setup_employee_separation_workflow.execute",
	"olscpl_hrms.patches.v1_1.add_job_opening_qr_button.execute",
	"olscpl_hrms.patches.v1_1.make_resume_attachment_public.execute",
	"olscpl_hrms.patches.v1_1.allow_guest_resume_uploads.execute",
	"olscpl_hrms.patches.v1_1.set_job_offer_default_print_format.execute",
	"olscpl_hrms.patches.v1_1.setup_company_letterheads.execute",
	"olscpl_hrms.patches.v1_1.set_email_footer_omone_atlas.execute",
	"olscpl_hrms.patches.v1_1.setup_applicant_resume_fields.execute",
	"olscpl_hrms.patches.v1_1.setup_job_offer_response_fields.execute",
	"olscpl_hrms.patches.v1_1.persist_employee_reports_to_index.execute",
	"olscpl_hrms.patches.v1_1.setup_job_application_reference_fields.execute",
	"olscpl_hrms.patches.v1_1.add_attendance_tracker_index.execute",
]

# Integration Setup
# ------------------
# To set up dependencies/integrations with other apps
# Name of the app being installed is passed as an argument

# before_app_install = "olscpl_hrms.utils.before_app_install"
# after_app_install = "olscpl_hrms.utils.after_app_install"

# Integration Cleanup
# -------------------
# To clean up dependencies/integrations with other apps
# Name of the app being uninstalled is passed as an argument

# before_app_uninstall = "olscpl_hrms.utils.before_app_uninstall"
# after_app_uninstall = "olscpl_hrms.utils.after_app_uninstall"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "olscpl_hrms.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# DocType Class
# ---------------
# Override standard doctype classes

override_doctype_class = {
	"Attendance": "olscpl_hrms.overrides.attendance.CustomAttendance",
	# Create Salary Slips: parallel chunks, per-slip commits, progress dialog
	"Payroll Entry": "olscpl_hrms.overrides.payroll_entry.CustomPayrollEntry",
	"Compensatory Leave Request": "olscpl_hrms.overrides.compensatory_leave_request.CustomCompensatoryLeaveRequest",
	"Leave Application": "olscpl_hrms.overrides.leave_application.CustomLeaveApplication",
	"Full and Final Statement": "olscpl_hrms.overrides.full_and_final_statement.CustomFullandFinalStatement",
	# "Use company email template" (Email Branding) on UI-made notifications
	"Notification": "olscpl_hrms.overrides.notification.CustomNotification",
}

# Jinja
# -----
# Methods callable by name from any Jinja template, including Print
# Formats - backs the "Letter of Intent" print format (Job Offer /
# Employee Onboarding) so its print preview renders the same
# letter+salary-structure HTML that generate_portal_link() emails.
jinja = {
	"methods": [
		"olscpl_hrms.api.letter_of_intent.get_letter_of_intent_print_html",
		# every outgoing mail in the Default (OM One ATLAS) branding - templates/emails/standard.html
		"olscpl_hrms.utils.email_layout.default_branded_email",
	]
}

# Document Events
# ---------------
# Hook on document methods and events

# doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
# 	}
# }

# Scheduled Tasks
# ---------------

scheduler_events = {
	"daily": [
		"olscpl_hrms.events.employee.send_probation_ending_reminders",
	],
}

# Testing
# -------

# before_tests = "olscpl_hrms.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "olscpl_hrms.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
override_doctype_dashboards = {
	"Attendance": "olscpl_hrms.overrides.attendance_dashboard.get_data",
}

# exempt linked doctypes from being automatically cancelled
#
# auto_cancel_exempted_doctypes = ["Auto Repeat"]

# Ignore links to specified DocTypes when deleting documents
# -----------------------------------------------------------

# ignore_links_on_delete = ["Communication", "ToDo"]

# Request Events
# ----------------
# before_request = ["olscpl_hrms.utils.before_request"]
# after_request = ["olscpl_hrms.utils.after_request"]

# Job Events
# ----------
# before_job = ["olscpl_hrms.utils.before_job"]
# after_job = ["olscpl_hrms.utils.after_job"]

# User Data Protection
# --------------------

# user_data_fields = [
# 	{
# 		"doctype": "{doctype_1}",
# 		"filter_by": "{filter_by}",
# 		"redact_fields": ["{field_1}", "{field_2}"],
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_2}",
# 		"filter_by": "{filter_by}",
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_3}",
# 		"strict": False,
# 	},
# 	{
# 		"doctype": "{doctype_4}"
# 	}
# ]

# Authentication and authorization
# --------------------------------

# auth_hooks = [
# 	"olscpl_hrms.auth.validate"
# ]

# Automatically update python controller files with type annotations for this app.
# export_python_type_annotations = True

# default_log_clearing_doctypes = {
# 	"Logging DocType Name": 30  # days to retain logs
# }

# Translation
# ------------
# List of apps whose translatable strings should be excluded from this app's translations.
# ignore_translatable_strings_from = []

doc_events = {
    "Job Opening": {
        "validate": "olscpl_hrms.events.job_opening.only_one_general_application",
    },
    "Salary Slip": {
        "validate": "olscpl_hrms.events.salary_slip.validate",
        "on_submit": "olscpl_hrms.events.salary_slip.on_submit",
        # progress count for the Payroll Entry cancel panel (counts only)
        "on_trash": "olscpl_hrms.api.payroll_entry.count_cancelled_slip",
    },
    "Attendance": {
        "validate": "olscpl_hrms.events.attendance.validate",
        "before_update_after_submit": "olscpl_hrms.events.attendance.before_update_after_submit",
        "on_update": "olscpl_hrms.events.attendance.on_update",
        "on_submit": "olscpl_hrms.events.attendance.relink_open_regularizations",
        "on_cancel": "olscpl_hrms.events.attendance.cancel_linked_regularizations",
    },
    "Monthly Attendance Tracker": {
        "before_validate": "olscpl_hrms.events.monthly_attendance_tracker.validate_uniqueness",
    },
    "Attendance Regularization": {
        "validate": ["olscpl_hrms.utils.reporting_person.enforce_reporting_person", "olscpl_hrms.events.attendance_regularization.validate"],
        "after_insert": "olscpl_hrms.events.attendance_regularization.after_insert",
        "on_update": [
            "olscpl_hrms.events.attendance_regularization.on_update",
            "olscpl_hrms.utils.reporting_person.share_with_reporting_person",
        ],
        "on_cancel": "olscpl_hrms.events.attendance_regularization.on_cancel",
    },
    "Notification Log": {
        "after_insert": "olscpl_hrms.utils.reporting_person.mirror_to_app",
    },
    "PWA Notification": {
        "before_insert": "olscpl_hrms.utils.reporting_person.humanize_notification_message",
    },
    "Work From Home Request": {
        "validate": ["olscpl_hrms.utils.reporting_person.enforce_reporting_person", "olscpl_hrms.events.work_from_home_request.validate"],
        "after_insert": "olscpl_hrms.events.work_from_home_request.after_insert",
        "on_update": [
            "olscpl_hrms.events.work_from_home_request.on_update",
            "olscpl_hrms.utils.reporting_person.share_with_reporting_person",
        ],
        "on_cancel": "olscpl_hrms.events.work_from_home_request.on_cancel",
    },
    "Visit": {
        "validate": ["olscpl_hrms.utils.reporting_person.enforce_reporting_person", "olscpl_hrms.events.visit.validate"],
        "after_insert": "olscpl_hrms.events.visit.after_insert",
        "on_update": [
            "olscpl_hrms.events.visit.on_update",
            "olscpl_hrms.utils.reporting_person.share_with_reporting_person",
        ],
        "on_cancel": "olscpl_hrms.events.visit.on_cancel",
    },
    "Loan Application": {
        "validate": "olscpl_hrms.events.loan_application.validate",
        "on_update": "olscpl_hrms.events.loan_application.on_update",
    },
    "Loan Skip Request": {
		"on_update": "olscpl_hrms.events.loan_skip_request.on_update",
	},
	"Loan Prepayment Request": {
		"validate": "olscpl_hrms.events.loan_prepayment_request.validate",
		"on_update": "olscpl_hrms.events.loan_prepayment_request.on_update",
	},
	"Leave Application": {
		"validate": ["olscpl_hrms.utils.reporting_person.enforce_reporting_person", "olscpl_hrms.events.leave_application.validate"],
		"on_update": [
			"olscpl_hrms.events.leave_application.on_update",
			"olscpl_hrms.utils.reporting_person.share_with_reporting_person",
		],
		"on_cancel": "olscpl_hrms.events.leave_application.on_cancel",
	},
	"Compensatory Leave Request": {
		"validate": ["olscpl_hrms.utils.reporting_person.enforce_reporting_person", "olscpl_hrms.events.compensatory_leave_request.set_approver"],
		"on_update": "olscpl_hrms.utils.reporting_person.share_with_reporting_person",
		"on_cancel": "olscpl_hrms.events.compensatory_leave_request.on_cancel",
	},
	"Employee": {
		"after_insert": [
			"olscpl_hrms.events.employee.sync_username",
			"olscpl_hrms.events.employee.copy_onboarding_attachments",
			"olscpl_hrms.events.employee.copy_onboarding_salary_annexure",
			"olscpl_hrms.events.iam_sync.on_employee_after_insert",
		],
		"on_update": [
			"olscpl_hrms.events.employee.sync_username",
			"olscpl_hrms.events.iam_sync.on_employee_update",
		],
	},
	"Employee Onboarding": {
		"validate": "olscpl_hrms.events.employee_onboarding.seed_onboarding_children",
	},
	"Job Applicant": {
		# Resume Attachment goes through core's own upload_file, saved under
		# whatever the candidate's device called it - rename it to
		# "Resume_<Applicant Name>" once the record (and its applicant_name)
		# actually exists. on_update too, not just after_insert: the web
		# form's guest save flow can attach the file on a later save than
		# the record's own insert, and HR can also swap the attachment from
		# the desk form afterwards.
		"validate": [
			"olscpl_hrms.events.job_applicant.set_department_and_position",
			"olscpl_hrms.events.job_applicant.set_channel_and_source",  # QR / Link / Website
		],
		"after_insert": "olscpl_hrms.events.job_applicant.rename_resume_attachment",
		"on_update": [
			"olscpl_hrms.events.job_applicant.rename_resume_attachment",
		],
	},
	"Job Offer": {
		# "OSBS Base-Salary-Based Structure" (RapidShyp) only: salary from its Excel sheet
		"validate": [
			"olscpl_hrms.api.rapidshyp.set_job_offer_salary",
			"olscpl_hrms.events.job_offer.validate_offer_letter_cc",
		],
		"before_submit": "olscpl_hrms.events.job_offer.require_sender_signature",
		"on_submit": "olscpl_hrms.events.job_offer.send_offer_letter",
		"on_update": "olscpl_hrms.events.employee_onboarding.sync_joining_date_from_offer",
		"on_update_after_submit": "olscpl_hrms.events.employee_onboarding.sync_joining_date_from_offer",
	},
	"Interview Feedback": {
		# Candidate Details: carried from the previous feedback, and written
		# into the Interview's Interview Summary as points
		"before_insert": "olscpl_hrms.events.interview_feedback.copy_previous_details",
		"on_update": "olscpl_hrms.events.interview_feedback.update_interview_summary",
		"on_submit": [
			"olscpl_hrms.events.interview_feedback.update_interview_summary",
			"olscpl_hrms.events.interview_feedback.sync_interview_status",  # Interview Status follows feedback
		],
		"on_cancel": "olscpl_hrms.events.interview_feedback.sync_interview_status",
		"on_update_after_submit": "olscpl_hrms.events.interview_feedback.update_interview_summary",
	},
	"Interview": {
		"validate": "olscpl_hrms.events.interview.sync_external_interviewers",  # outside panel members
		"after_insert": "olscpl_hrms.events.interview.after_insert",
		"on_update": "olscpl_hrms.events.interview.invite_external_interviewers",
	},
	"Employee Separation": {
		"validate": [
			"olscpl_hrms.events.employee_separation.default_separation_manager",
			"olscpl_hrms.events.employee_separation.sync_boarding_status",
		],
		"on_update": "olscpl_hrms.events.employee_separation.notify_on_workflow_action",
	},
	"Employee Separation Clearance": {
		"on_update": "olscpl_hrms.events.employee_separation.sync_clearance_completion",
	},
	"File": {
		# Deleting the attached File (from the Desk sidebar's own "x", or
		# any other route) doesn't touch the Document Checklist row that
		# pointed at it - nothing links them, so without this the row kept
		# showing "Submitted" with a link to a file that no longer exists,
		# on both the HR-facing form and the candidate's own portal page.
		"on_trash": "olscpl_hrms.events.employee_onboarding.clear_checklist_row_on_file_delete",
	},

}

permission_query_conditions = {
    "Attendance Regularization": "olscpl_hrms.permissions.queries.attendance_regularization",
    "Work From Home Request": "olscpl_hrms.permissions.queries.work_from_home_request",
    "Employee Separation": "olscpl_hrms.permissions.queries.employee_separation",
    "Employee Separation Clearance": "olscpl_hrms.permissions.queries.employee_separation_clearance",
}

has_permission = {
    "Attendance Regularization": "olscpl_hrms.permissions.queries.attendance_regularization_has_permission",
    "Employee Separation": "olscpl_hrms.permissions.queries.employee_separation_has_permission",
    "Employee Separation Clearance": "olscpl_hrms.permissions.queries.employee_separation_clearance_has_permission",
}

regional_overrides = {
    "India": {
        "hrms.hr.utils.calculate_annual_eligible_hra_exemption": "olscpl_hrms.overrides.tax_exemption.calculate_annual_eligible_hra_exemption",
    }
}

override_whitelisted_methods = {
    # impersonate without emailing the employee (Activity Log + in-app alert kept)
    "frappe.core.doctype.user.user.impersonate": "olscpl_hrms.overrides.user.impersonate",
    "get_attendance_regularization_details": "olscpl_hrms.api.regularization.get_details",
    "create_and_submit_regularization": "olscpl_hrms.api.regularization.create_and_submit_regularization",
    "action_regularization": "olscpl_hrms.api.regularization.action_regularization",
    "get_my_regularizations": "olscpl_hrms.api.regularization.get_my_regularizations",
    "get_team_regularizations": "olscpl_hrms.api.regularization.get_team_regularizations",
    "create_and_submit_leave_application": "olscpl_hrms.api.leave.create_and_submit_leave_application",
    "action_leave_application": "olscpl_hrms.api.leave.action_leave_application",
    "get_my_leave_applications": "olscpl_hrms.api.leave.get_my_leave_applications",
    "get_team_leave_applications": "olscpl_hrms.api.leave.get_team_leave_applications",
    "get_leave_application_details": "olscpl_hrms.api.leave.get_leave_application_details",
    "get_available_comp_off_dates": "olscpl_hrms.api.leave.get_available_comp_off_dates",
    "create_and_submit_compensatory_leave_request": "olscpl_hrms.api.compensatory_leave.create_and_submit_compensatory_leave_request",
    "action_compensatory_leave_request": "olscpl_hrms.api.compensatory_leave.action_compensatory_leave_request",
    "get_my_compensatory_leave_requests": "olscpl_hrms.api.compensatory_leave.get_my_compensatory_leave_requests",
    "get_team_compensatory_leave_requests": "olscpl_hrms.api.compensatory_leave.get_team_compensatory_leave_requests",
    "get_compensatory_leave_request_details": "olscpl_hrms.api.compensatory_leave.get_compensatory_leave_request_details",
    "hrms.hr.doctype.employee_onboarding.employee_onboarding.make_employee": "olscpl_hrms.overrides.employee_onboarding.make_employee",
    # Public careers API for the external career-page team - see
    # docs/careers_api.md. Short aliases only; the full dotted path
    # (olscpl_hrms.api.careers.get_jobs / .get_job) works too, same as
    # every whitelisted method always does in Frappe.
    "get_published_jobs": "olscpl_hrms.api.careers.get_jobs",
    "get_published_job": "olscpl_hrms.api.careers.get_job",
    "submit_job_application": "olscpl_hrms.api.careers.submit_job_application",
}

doctype_js = {
    "Payroll Entry": "public/js/payroll_entry.js",
    "Attendance": "public/js/attendance.js",
    "Job Offer": "public/js/job_offer.js",
    "Job Opening": "public/js/job_opening.js",
    "Interview": "public/js/interview.js",
    "Interview Feedback": "public/js/interview_feedback.js",
    "Employee": "public/js/employee.js",
    "User": "public/js/user.js",
    "Full and Final Statement": "public/js/full_and_final_statement.js",
}

fixtures = [
	{
		"dt": "Custom Field",
		"filters": [
			["dt", "in", ["Attendance", "Employee", "Shift Type", "Employee Checkin", "Salary Slip", "Compensatory Leave Request", "Leave Application", "Job Offer", "Employee Onboarding", "Job Requisition", "Full and Final Statement", "Interview", "KRA", "Goal"]]
		]
	},
	{
		"dt": "Role",
		"filters": [
			["name", "in", ["Onboarding Verifier"]]
		]
	},
	{
		"dt": "Custom DocPerm",
		"filters": [
			["parent", "in", ["Job Requisition", "Job Offer", "Compensatory Leave Request"]]
		]
	},
	{
		"dt": "Property Setter",
		"filters": [
			["doc_type", "in", ["Compensatory Leave Request", "Leave Application", "Full and Final Statement", "Interview", "Job Offer", "Employee Onboarding"]]
		]
	},
	{
		"dt": "DocType",
		"filters": [
			["name", "in", [
				"Attendance Regularization",
				"Attendance Regularization Tracker",
				"Income Tax Surcharge Rule",
				"Income Tax Surcharge Slab",
				"Bonus Payable",
				# "Payroll Changeable Component Item" is a standard doctype in
				# olscpl_hrms/doctype/ - listing it here made every fixture sync
				# fail ("Not in Developer Mode") and skip the fixtures after it.
				"State Wage Master",
				"Professional Tax Rule",
				"Professional Tax Slab",
				"LWF Configuration",
				"ESI Rule",
				"Employee ESI Coverage",
				"Loan Type",
				"Loan Application",
				"Employee Loan",
				"EMI Schedule",
                "Salary Slip Loan EMI",
                "Loan Skip Request",
				"Loan Prepayment Request",
                "LOI Allowance", "LOI Benefit",
                "LOI Benefit Rule",
				"LOI Deduction", "LOI Other Benefit", "LOI Salary Breakup",
				"Work From Home Request", "Work From Home Request Detail",
				"Visit",
			]]
		]
	},
	{
		"dt": "Workflow",
		"filters": [
			["name", "in", [
				"Attendance Regularization Workflow",
				"Loan Application Workflow",
                "Loan Skip Request Workflow",
				"Loan Prepayment Request Workflow",
				"Comp Off Approval",
				"Leave Application Approval",
				"Job Requisition Approval",
				"Work From Home Workflow",
				"Visit Workflow"
			]]
		]
	},
	{
		"dt": "Server Script",
		"filters": [
			["name", "in", ["Compensatory Off Approval", "Compensatory Leave Policy"]]
		]
	},
	{
		"dt": "Notification",
		"filters": [
			["name", "in", [
				"Leave Rejection Notification",
				"Leave Approved Notification",
				"Leave Pending Approval",
				"Comp OFF Rejected by Manager",
				"Comp OFF Approved By Manager",
				"Comp Off Alerts",
				"Expense Claim Pending Approval",
				"Expense Claim Approved Notification",
				"Expense Claim Rejection Notification",
				"Shift Request Pending Approval",
				"Shift Request Approved Notification",
				"Shift Request Rejection Notification",
				"Visit Approved Notification",
				"Visit Rejection Notification",
				"Work From Home Approved Notification",
				"Work From Home Rejection Notification"
			]]
		]
	},
	{
		"dt": "Workflow State",
		"filters": [
			["name", "in", [
				"Draft", "Pending", "Approved", "Rejected", "Open", "Cancelled",
				"Pending HOD Approval", "Pending HR Approval", "Open & Approved",
				"Filled", "On Hold", "Withdrawn"
			]]
		]
	},
	{
		"dt": "Workflow Action Master",
		"filters": [
			["name", "in", [
				"Submit", "Approve", "Reject",
				"HOD Approve", "HOD Reject", "HR Approve", "HR Reject",
				"Mark as Filled", "Put on Hold", "Resume", "Cancel", "Withdraw"
			]]
		]
	},
    {
		"dt": "Client Script",
		"filters": [
			["name", "in", ["Salary Slip Loan Offset Button", "Leave Application Comp Off Picker", "Job Offer Onboarding Link Button", "Employee Onboarding Request Changes Button", "Employee Separation Clearance Button", "Employee Separation Exit Dashboard Charts", "Work From Home Request Geolocation", "Interview Prefill Fix", "Job Applicant Onboarding Link Button"]]
		]
	},
    {
		"dt": "Print Format",
		"filters": [
			["name", "in", ["Letter of Intent", "Letter of Intent (Onboarding)", "Full and Final Settlement (Legacy)"]]
		]
	},
    {
		"dt": "Workspace",
		"filters": [
			["name", "in", ["Payroll", "Complete Flow", "Atlas Home", "Dashboards"]]
		]
	},
	{
		"dt": "Custom HTML Block",
		"filters": [
			["name", "=", "Recruitment to Exit Flow Diagram"]
		]
	},
	{
		# Single doctype - only ever one row, but still needs a fixture so
		# the "User Manual" navbar dropdown item's Route (set to /user-manual
		# below) actually deploys to other sites instead of only existing in
		# this dev database, same reasoning as the Atlas Home Workspace above.
		"dt": "Navbar Settings"
	}
]

