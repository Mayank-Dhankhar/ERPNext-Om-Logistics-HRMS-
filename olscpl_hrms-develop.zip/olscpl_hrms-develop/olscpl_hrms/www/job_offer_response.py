import frappe
from frappe.utils import format_date

from olscpl_hrms.events.job_offer import get_offer_by_key

no_cache = 1


def get_context(context):
	context.no_cache = 1
	context.metatags = {"color-scheme": "light"}
	offer, key = frappe.form_dict.get("offer"), frappe.form_dict.get("key")
	doc = get_offer_by_key(offer, key)

	context.valid_link = bool(doc)
	if not doc:
		return

	context.offer = doc
	# RapidShyp offers: RapidShyp header and name instead of OM One ATLAS
	from olscpl_hrms.api import rapidshyp

	context.rapidshyp = rapidshyp.is_rapidshyp(doc.company)
	context.company_label = rapidshyp.BRAND if context.rapidshyp else doc.company
	context.offer_key = key
	context.joining_date = format_date(doc.offer_date)
	action = frappe.form_dict.get("action")
	context.preselect = action if action in ("accept", "decline") else ""
