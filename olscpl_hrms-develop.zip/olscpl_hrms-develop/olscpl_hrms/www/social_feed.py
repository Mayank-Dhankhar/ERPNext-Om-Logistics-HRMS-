import frappe
import frappe.sessions

from olscpl_hrms.asset_version import asset_v

no_cache = 1


def get_context(context):
	if frappe.session.user == "Guest":
		frappe.local.flags.redirect_location = "/login?redirect-to=/social-feed"
		raise frappe.Redirect
	context.no_sidebar = 1
	context.v_css = asset_v("css/social_feed.css")
	context.v_js = asset_v("js/social_feed.js")
	# Website pages don't get a CSRF token for free the way the Desk shell
	# (www/app.py) does - social_feed.js's like/comment/post calls are all
	# mutating POSTs, so without this every one of them was rejected with
	# CSRFTokenError (the GET-only ess_dashboard/admin_dashboard pages
	# never hit this since Frappe doesn't enforce CSRF on reads).
	context.csrf_token = frappe.sessions.get_csrf_token()
