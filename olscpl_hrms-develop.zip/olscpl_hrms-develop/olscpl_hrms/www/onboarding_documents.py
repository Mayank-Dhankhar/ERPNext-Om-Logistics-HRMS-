import frappe

from olscpl_hrms.events.employee_onboarding import get_onboarding_by_key

no_cache = 1


def get_context(context):
	context.no_cache = 1
	# Stops Chrome's automatic dark-theming from re-coloring the canvas
	# signature pad (and any other raster content) - that heuristic reads
	# color-scheme, not the page's own CSS filters, so it has to be set
	# this early to reliably take effect.
	context.metatags = {"color-scheme": "light"}
	key = frappe.form_dict.get("key")
	doc = get_onboarding_by_key(key, allow_hr_view=True)

	context.valid_link = bool(doc)
	if not doc:
		return

	context.onboarding = doc
	context.portal_key = key
