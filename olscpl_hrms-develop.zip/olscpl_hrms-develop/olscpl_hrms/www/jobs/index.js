$(() => {
	const query_params = frappe.utils.get_query_params();
	update_ui_with_filters();

	$(".desktop-filters").change(function () {
		update_params(get_new_params(".desktop-filters"));
	});

	$("#apply-filters").on("click", function () {
		update_params(get_new_params(".mobile-filters"));
	});

	$("[name=clear-filters]").on("click", function () {
		update_params();
	});

	$("#filter").click(function () {
		scroll_up_and_execute(() => {
			$("#filters-drawer").css("bottom", 0);
			$("#overlay").show();
			$("html, body").css({
				overflow: "hidden",
				height: "100%",
			});
		});
	});

	$("[name=close-filters-drawer").click(function () {
		$("#filters-drawer").css("bottom", "-80vh");
		$("#overlay").hide();
		$("html, body").css({
			overflow: "auto",
			height: "auto",
		});
	});

	$("#search-box").bind("search", function () {
		update_params(get_new_params(".desktop-filters"));
	});

	$("#search-box").keyup(function (e) {
		if (e.keyCode == 13) {
			$(this).trigger("search");
		}
	});

	$("#sort").on("click", function () {
		const filters = $(".desktop-filters").serialize();
		query_params.sort === "asc"
			? update_params(filters)
			: update_params(filters + "&sort=asc");
	});

	$("[name=card]").on("click", function () {
		window.location.href = this.id;
	});

	// Let the small QR trigger and download icon do their own thing instead
	// of the click bubbling up to the card handler above and navigating the
	// page away (mid-download, or instead of opening the modal).
	$(".job-qr-trigger").on("click", function (e) {
		e.stopPropagation();
		open_qr_modal(this.dataset.url, this.dataset.title, this.dataset.job);
	});

	$(".job-qr-download-btn").on("click", function (e) {
		e.stopPropagation();
	});

	$(".job-copy-link-btn").on("click", function (e) {
		e.stopPropagation();
		copy_job_link(this);
	});

	$("#qr-modal-overlay").on("click", function (e) {
		if (e.target === this) close_qr_modal(); // clicked the backdrop itself, not the box
	});
	$("#qr-modal-close").on("click", close_qr_modal);

	$("[name=pagination]").on("click", function () {
		const filters = $(".desktop-filters").serialize();
		update_params(filters + "&page=" + this.id);
	});

	$("#previous").on("click", function () {
		const new_page = (Number(query_params?.page) || 1) - 1;
		const filters = $(".desktop-filters").serialize();
		update_params(filters + "&page=" + new_page);
	});

	$("#next").on("click", function () {
		const new_page = (Number(query_params?.page) || 1) + 1;
		const filters = $(".desktop-filters").serialize();
		update_params(filters + "&page=" + new_page);
	});

	function update_ui_with_filters() {
		const allowed_filters = Object.keys(
			JSON.parse($("#data").data("filters").replace(/'/g, '"')),
		);

		for (const filter in query_params) {
			if (filter === "query") $("#search-box").val(query_params["query"]);
			else if (filter === "page") disable_inapplicable_pagination_buttons();
			else if (allowed_filters.includes(filter)) {
				if (typeof query_params[filter] === "string") {
					$("#desktop-" + $.escapeSelector(query_params[filter])).prop("checked", true);
					$("#mobile-" + $.escapeSelector(query_params[filter])).prop("checked", true);
				} else
					for (const d of query_params[filter]) {
						$("#desktop-" + $.escapeSelector(d)).prop("checked", true);
						$("#mobile-" + $.escapeSelector(d)).prop("checked", true);
					}
			} else continue;
		}
	}

	function disable_inapplicable_pagination_buttons() {
		const no_of_pages = JSON.parse($("#data").data("no-of-pages"));
		const page_no = Number(query_params["page"]);
		if (page_no === no_of_pages) {
			$("#next").prop("disabled", true);
		} else if (page_no > no_of_pages || page_no <= 1) {
			$("#previous").prop("disabled", true);
		}
	}

	function get_new_params(filter_group) {
		return "sort" in query_params
			? $(filter_group).serialize() + "&" + $.param({ sort: query_params["sort"] })
			: $(filter_group).serialize();
	}
});

function update_params(params = "") {
	if ($("#filters-drawer").css("bottom") != "0px")
		return scroll_up_and_execute(() => (window.location.href = "/jobs?" + params));

	$("#filters-drawer").css("bottom", "-80vh");
	$("#filters-drawer").on("transitionend webkitTransitionEnd oTransitionEnd", () =>
		scroll_up_and_execute(() => (window.location.href = "/jobs?" + params)),
	);
}

function copy_job_link(btn) {
	// Built from the visitor's own origin instead of the server-rendered
	// data-url (frappe.utils.get_url), which follows the site's host_name
	// setting and can point at a host the visitor can't reach.
	const route = $(btn).closest("[name=card]").attr("id");
	// ?via=link: the application records it came through a shared link (Job Applicant > Application Channel)
	const url = window.location.origin + "/" + route + "?via=link";
	const done = () => {
		const $btn = $(btn);
		$btn.addClass("copied").attr("title", "Link copied");
		$btn.find(".job-copy-icon").hide();
		$btn.find(".job-copied-icon").show();
		setTimeout(() => {
			$btn.removeClass("copied").attr("title", "Copy job link");
			$btn.find(".job-copied-icon").hide();
			$btn.find(".job-copy-icon").show();
		}, 1500);
	};

	if (navigator.clipboard && window.isSecureContext) {
		navigator.clipboard.writeText(url).then(done);
		return;
	}
	// Plain-http fallback (navigator.clipboard needs a secure context).
	const ta = document.createElement("textarea");
	ta.value = url;
	ta.style.position = "fixed";
	ta.style.opacity = "0";
	document.body.appendChild(ta);
	ta.select();
	if (document.execCommand("copy")) done();
	document.body.removeChild(ta);
}

function open_qr_modal(url, title, job_opening) {
	// Rendered fresh at full size here rather than kept pre-rendered per
	// card - same deterministic library + same URL, so it's still the
	// exact same fixed code, just drawn large enough to actually scan.
	$("#qr-modal-title").text(title || "");
	$("#qr-modal-code").empty();
	new QRCode(document.getElementById("qr-modal-code"), {
		text: url,
		width: 220,
		height: 220,
		colorDark: "#1a1a1a",
		colorLight: "#ffffff",
		correctLevel: QRCode.CorrectLevel.M,
	});
	$("#qr-modal-download").attr(
		"href",
		"/api/method/olscpl_hrms.api.careers.download_qr_code?job_opening=" +
			encodeURIComponent(job_opening),
	);
	$("#qr-modal-overlay").addClass("show");
	$("html, body").css({ overflow: "hidden", height: "100%" });
}

function close_qr_modal() {
	$("#qr-modal-overlay").removeClass("show");
	$("html, body").css({ overflow: "auto", height: "auto" });
}

function scroll_up_and_execute(callback) {
	if (window.scrollY === 0) return callback();

	function execute_after_scrolling_up() {
		if (window.scrollY === 0) {
			callback();
			window.removeEventListener("scroll", execute_after_scrolling_up);
		}
	}

	window.scroll({
		top: 0,
		behavior: "smooth",
	});
	window.addEventListener("scroll", execute_after_scrolling_up);
}
