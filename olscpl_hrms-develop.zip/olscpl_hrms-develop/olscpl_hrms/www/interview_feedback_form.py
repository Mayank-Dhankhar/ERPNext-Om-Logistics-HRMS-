# /interview-feedback-form - no-login Interview Feedback for external interviewers
# (link emailed by events/interview.invite_external_interviewers). Data and
# submit: api/external_feedback.py.
import frappe

from olscpl_hrms.api.external_feedback import form_context

no_cache = 1


def get_context(context):
	context.no_cache = 1
	context.metatags = {"color-scheme": "light"}
	context.key = frappe.form_dict.get("key") or ""
	context.update(form_context(frappe.form_dict.get("interview"), context.key))
