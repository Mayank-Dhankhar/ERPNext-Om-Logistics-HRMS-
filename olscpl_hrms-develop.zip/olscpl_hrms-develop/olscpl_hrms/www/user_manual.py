import frappe
import frappe.sessions

from olscpl_hrms.asset_version import asset_v

no_cache = 1


def get_context(context):
	if frappe.session.user == "Guest":
		frappe.local.flags.redirect_location = "/login?redirect-to=/user-manual"
		raise frappe.Redirect
	context.no_sidebar = 1
	context.v_css = asset_v("css/user_manual.css")
	context.v_js = asset_v("js/user_manual.js")
	# Uploading (System Manager/HR Manager only, checked server-side too in
	# api/user_manual.py) and deleting are both mutating POSTs from this
	# bare website page, same CSRF requirement as social_feed.py.
	context.csrf_token = frappe.sessions.get_csrf_token()
