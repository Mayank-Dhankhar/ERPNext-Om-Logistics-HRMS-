"""
olscpl_hrms/utils/kafka_producer.py

Lightweight Kafka producer wrapper for publishing Employee lifecycle events
to the User IAM system.

Design notes:
- Uses `kafka-python` (pure Python, no librdkafka/C dependency — easiest to
  install on a frappe-bench VM without extra system packages). Swap for
  confluent-kafka later if throughput ever becomes a concern; the public
  API below (`publish_employee_event`) would not need to change.
- Broker config is read from site_config.json so dev / uat-copy.local /
  uaterp.omlogistics.co.in / hrms.omone.in each point at their own cluster
  without any code change.
- The producer is created lazily and cached at module level so we don't
  reconnect on every doc event inside a single worker process.
- Failures are logged via frappe.log_error and swallowed (never raise out
  of a doc_event hook) so a Kafka/broker outage never blocks HR from
  saving an Employee record. If you need delivery guarantees, add a
  outbox/retry table instead of raising here.

site_config.json keys expected (add to each site's site_config.json):
{
  "iam_kafka": {
    "bootstrap_servers": "kafkadev.omone.internal:9092",
    "enabled": 1,
    "security_protocol": "PLAINTEXT",   // or "SASL_SSL" for UAT/Prod once confirmed
    "sasl_mechanism": null,             // e.g. "PLAIN" if SASL is required
    "sasl_username": null,
    "sasl_password": null
  }
}
"""

import json
import logging
import uuid
from datetime import datetime

import frappe

_producer = None  # module-level cache, one per worker process
_logger = None  # module-level cache, one per worker process


def get_logger():
	"""frappe.logger() defaults to WARNING — our .info() calls below were
	silently swallowed until this was set explicitly (confirmed empty
	iam_kafka.log despite successful publishes during UAT testing on
	2026-09-15). Cache it so we don't re-set the level on every call."""
	global _logger
	if _logger is None:
		_logger = frappe.logger("iam_kafka", allow_site=True, file_count=5)
		_logger.setLevel(logging.INFO)
	return _logger


TOPIC_MAP = {
	"CREATION": "hrms.employee.created",
	"UPDATE": "hrms.employee.updated",
	"ACTIVATION": "hrms.employee.activated",
	"DELETION": "hrms.employee.deleted",
}


def get_kafka_config():
	"""Read the iam_kafka block from site_config.json."""
	config = frappe.conf.get("iam_kafka") or {}
	return {
		"bootstrap_servers": config.get("bootstrap_servers", "kafkadev.omone.internal:9092"),
		"enabled": config.get("enabled", 0),
		"security_protocol": config.get("security_protocol", "PLAINTEXT"),
		"sasl_mechanism": config.get("sasl_mechanism"),
		"sasl_username": config.get("sasl_username"),
		"sasl_password": config.get("sasl_password"),
	}


def _get_producer():
	global _producer
	if _producer is not None:
		return _producer

	from kafka import KafkaProducer

	config = get_kafka_config()

	kwargs = {
		"bootstrap_servers": config["bootstrap_servers"],
		"value_serializer": lambda v: json.dumps(v).encode("utf-8"),
		"key_serializer": lambda k: k.encode("utf-8") if k else None,
		"security_protocol": config["security_protocol"],
		"retries": 3,
		"acks": "all",
		"linger_ms": 50,
	}

	if config["security_protocol"] in ("SASL_SSL", "SASL_PLAINTEXT"):
		kwargs.update(
			{
				"sasl_mechanism": config["sasl_mechanism"] or "PLAIN",
				"sasl_plain_username": config["sasl_username"],
				"sasl_plain_password": config["sasl_password"],
			}
		)

	_producer = KafkaProducer(**kwargs)
	return _producer


def publish_employee_event(event_type: str, employee_payload: dict):
	"""
	Publish one employee lifecycle event to the appropriate Kafka topic.

	event_type: one of "CREATION", "UPDATE", "ACTIVATION", "DELETION"
	employee_payload: dict already shaped to the agreed IAM contract, e.g.
		{
		  "employeeId": "OLSC0001",
		  "username": "sumit.gupta@olsc.in",
		  "firstName": "Sumit",
		  "lastName": "Gupta",
		  "email": "sumit.gupta@olsc.in",
		  "phoneNumber": "+91XXXXXXXXXX",
		  "departmentCode": "IT",
		  "designationCode": "TPM",
		  "activeStatus": true,
		  "companyCode": "400021",
		  "branchCode": "1306",
		  "metadata": {}
		}
	"""
	config = get_kafka_config()
	if not config["enabled"]:
		get_logger().info(
			f"iam_kafka disabled in site_config — skipping {event_type} event for "
			f"{employee_payload.get('employeeId')}"
		)
		return

	if event_type not in TOPIC_MAP:
		frappe.throw(f"Unknown IAM event type: {event_type}")

	topic = TOPIC_MAP[event_type]
	message = {
		"eventId": str(uuid.uuid4()),
		"type": event_type,
		"timestamp": datetime.now().astimezone().isoformat(),
		"employee": employee_payload,
	}

	try:
		producer = _get_producer()
		future = producer.send(topic, key=employee_payload.get("employeeId"), value=message)
		# block briefly for delivery confirmation so failures surface in the
		# request/job log instead of silently vanishing; keep the timeout
		# short so a slow broker doesn't stall Employee saves.
		record_metadata = future.get(timeout=5)
		get_logger().info(
			f"Published {event_type} event for {employee_payload.get('employeeId')} to "
			f"{topic} (partition={record_metadata.partition}, offset={record_metadata.offset})"
		)
	except Exception:
		get_logger().error(
			f"Failed to publish {event_type} event for {employee_payload.get('employeeId')} to {topic}",
			exc_info=True,
		)
		frappe.log_error(
			title=f"IAM Kafka publish failed ({event_type})",
			message=frappe.get_traceback(),
		)
