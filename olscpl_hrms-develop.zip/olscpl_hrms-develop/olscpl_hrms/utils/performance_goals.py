"""
Utility: olscpl_hrms/utils/performance_goals.py
Frappe HR / ERPNext v15.9

Creates an Appraisal Cycle (if missing) with the given employees as appraisees,
then creates one Goal per KRA per employee (the "goalsheet").

Run on a FRESH bench console / bench execute (never a stale session):

  bench --site dev.local execute olscpl_hrms.utils.performance_goals.run \
	  --kwargs "{'employees': ['HR-EMP-00001'], 'dry_run': 1}"

Then re-run with 'dry_run': 0 to actually create records.
"""
import frappe

TEMPLATE = "Software Developer"

# KRA title -> (Goal name, KPI target)
GOALSHEET = {
	"Development and Delivery": ("Deliver sprint commitments on time", ">= 90% sprint commitment met"),
	"Code Quality": ("Maintain code quality and test coverage", ">= 70% unit-test coverage on new code"),
	"Production Support and Bug Resolution": ("Resolve production issues within SLA", "P1 100% / P2 >= 90% in SLA"),
	"Performance and Optimization": ("Optimize slow queries and APIs", "At least 3 fixes per half-year"),
	"Documentation and Knowledge Sharing": ("Keep documentation current and share knowledge", "1 session per quarter"),
	"Learning and Upskilling": ("Complete agreed trainings", "2 trainings/certifications per year"),
	"Collaboration and Ownership": ("Collaborate effectively with team", "Positive peer/stakeholder feedback"),
}


def run(
	employees=None,
	cycle_name="Annual Appraisal FY 2026-27",
	start_date="2026-04-01",
	end_date="2027-03-31",
	company="OM Logistics Supply Chain Pvt. Ltd.",
	dry_run=1,
):
	employees = employees or []
	if isinstance(employees, str):
		employees = frappe.parse_json(employees)
	dry_run = int(dry_run)

	if not employees:
		print("No employees passed.")
		return

	ensure_cycle(cycle_name, start_date, end_date, company, employees, dry_run)

	created = skipped = 0
	for emp in employees:
		for kra, (goal_name, target) in GOALSHEET.items():
			exists = frappe.db.exists(
				"Goal",
				{"employee": emp, "kra": kra, "appraisal_cycle": cycle_name},
			)
			if exists:
				skipped += 1
				continue
			if dry_run:
				print("DRY RUN would create goal:", emp, "|", kra)
				created += 1
				continue
			frappe.get_doc(
				{
					"doctype": "Goal",
					"goal_name": goal_name,
					"employee": emp,
					"kra": kra,
					"appraisal_cycle": cycle_name,
					"start_date": start_date,
					"end_date": end_date,
					"kpi_target": target,
					"progress": 0,
				}
			).insert(ignore_permissions=True)
			created += 1

	if not dry_run:
		frappe.db.commit()
	print("Goals created: {0}, skipped (already exist): {1}".format(created, skipped))


def ensure_cycle(cycle_name, start_date, end_date, company, employees, dry_run):
	if frappe.db.exists("Appraisal Cycle", cycle_name):
		print("Appraisal Cycle exists:", cycle_name)
		return
	if dry_run:
		print("DRY RUN would create Appraisal Cycle:", cycle_name)
		return
	frappe.get_doc(
		{
			"doctype": "Appraisal Cycle",
			"cycle_name": cycle_name,
			"company": company,
			"start_date": start_date,
			"end_date": end_date,
			"kra_evaluation_method": "Automated Based on Goal Progress",
			"appraisees": [
				{"employee": e, "appraisal_template": TEMPLATE} for e in employees
			],
		}
	).insert(ignore_permissions=True)
