# olscpl_hrms/utils/branch_hr_import.py
#
# Loads "HR EMPCODE,BRANCH_CODE" rows (data/regional_hr.csv, from HR) into
# Branch.custom_branch_hrs. Only valid rows are applied: the HR must be an
# active employee with a login (matched on Employee ID or employee number)
# and the branch code must exist (custom_branch_code, or the "CODE - NAME"
# prefix; a code shared by duplicate Branch records goes on all of them).
# Additive and idempotent - re-run after HR fixes the file:
#   bench --site <site> execute olscpl_hrms.utils.branch_hr_import.run
import csv
import os

import frappe

DEFAULT_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "regional_hr.csv")


def run(path=None):
	path = path or DEFAULT_FILE
	with open(path, newline="") as f:
		rows = [(r["HR EMPCODE"].strip(), r["BRANCH_CODE"].strip()) for r in csv.DictReader(f) if r.get("HR EMPCODE")]

	employees = {}
	for e in frappe.get_all("Employee", fields=["name", "employee_number", "status", "user_id"]):
		employees.setdefault(e.name, e)
		if e.employee_number:
			employees.setdefault(str(e.employee_number).strip(), e)

	branches = {}
	for b in frappe.get_all("Branch", fields=["name", "custom_branch_code"]):
		code = (b.custom_branch_code or b.name.split(" - ")[0]).strip()
		branches.setdefault(code, []).append(b.name)

	wanted, skipped = {}, []
	for hr_code, branch_code in rows:
		emp = employees.get(hr_code)
		if not emp:
			skipped.append((hr_code, branch_code, "HR code not found"))
		elif emp.status != "Active":
			skipped.append((hr_code, branch_code, "HR not active"))
		elif not emp.user_id:
			skipped.append((hr_code, branch_code, "HR has no login"))
		elif branch_code not in branches:
			skipped.append((hr_code, branch_code, "Branch code not found"))
		else:
			for branch in branches[branch_code]:
				wanted.setdefault(branch, set()).add(emp.name)

	added = 0
	for branch, hrs in wanted.items():
		doc = frappe.get_doc("Branch", branch)
		have = {r.employee for r in doc.get("custom_branch_hrs") or []}
		new = sorted(hrs - have)
		for employee in new:
			doc.append("custom_branch_hrs", {"employee": employee})
		if new:
			doc.flags.ignore_permissions = True
			doc.save()
			added += len(new)
	frappe.db.commit()

	result = {
		"rows": len(rows),
		"applied_rows": len(rows) - len(skipped),
		"branches_set": len(wanted),
		"assignments_added": added,
		"skipped": len(skipped),
		"skipped_by_reason": {r: sum(1 for s in skipped if s[2] == r) for r in {s[2] for s in skipped}},
	}
	print(result)
	return result


def reconcile(path=None):
	"""Like run(), but makes each covered branch's custom_branch_hrs match the
	file EXACTLY - adds what's missing AND removes any HR not in the file for
	that branch. Only touches branches the file actually mentions; every
	other branch's HR list is left untouched. Use this when the file is the
	authoritative full list for its branches (not just new additions) - e.g.
	after a company-wide Regional HR spreadsheet refresh.
	  bench --site <site> execute olscpl_hrms.utils.branch_hr_import.reconcile
	"""
	path = path or DEFAULT_FILE
	with open(path, newline="") as f:
		rows = [(r["HR EMPCODE"].strip(), r["BRANCH_CODE"].strip()) for r in csv.DictReader(f) if r.get("HR EMPCODE")]

	employees = {}
	for e in frappe.get_all("Employee", fields=["name", "employee_number", "status", "user_id"]):
		employees.setdefault(e.name, e)
		if e.employee_number:
			employees.setdefault(str(e.employee_number).strip(), e)

	branches = {}
	for b in frappe.get_all("Branch", fields=["name", "custom_branch_code"]):
		code = (b.custom_branch_code or b.name.split(" - ")[0]).strip()
		branches.setdefault(code, []).append(b.name)

	wanted, skipped = {}, []
	for hr_code, branch_code in rows:
		emp = employees.get(hr_code)
		if not emp:
			skipped.append((hr_code, branch_code, "HR code not found"))
		elif emp.status != "Active":
			skipped.append((hr_code, branch_code, "HR not active"))
		elif not emp.user_id:
			skipped.append((hr_code, branch_code, "HR has no login"))
		elif branch_code not in branches:
			skipped.append((hr_code, branch_code, "Branch code not found"))
		else:
			for branch in branches[branch_code]:
				wanted.setdefault(branch, set()).add(emp.name)

	added, removed, branches_touched = 0, 0, 0
	for branch, hrs in wanted.items():
		doc = frappe.get_doc("Branch", branch)
		have = {r.employee for r in doc.get("custom_branch_hrs") or []}
		if have == hrs:
			continue
		doc.set("custom_branch_hrs", [{"employee": e} for e in sorted(hrs)])
		doc.flags.ignore_permissions = True
		doc.save()
		added += len(hrs - have)
		removed += len(have - hrs)
		branches_touched += 1
	frappe.db.commit()

	result = {
		"rows": len(rows),
		"applied_rows": len(rows) - len(skipped),
		"branches_in_file": len(wanted),
		"branches_touched": branches_touched,
		"assignments_added": added,
		"assignments_removed": removed,
		"skipped": len(skipped),
		"skipped_by_reason": {r: sum(1 for s in skipped if s[2] == r) for r in {s[2] for s in skipped}},
	}
	print(result)
	return result


def assign_unmanaged_to_branch_hr():
	"""Sets Reports To = the branch's HR for active employees with no Reports
	To whose branch has exactly ONE active HR (not themselves). Branches with
	2+ HRs are skipped until HR decides who covers whom. Skips anything that
	would create a reporting loop. Writes an undo file (old/new per employee)
	to the site's private/files folder, then rebuilds the Employee tree."""
	hr_by_branch = {}
	for employee, branch in frappe.db.sql("select employee, parent from `tabBranch HR` where parenttype='Branch'"):
		hr_by_branch.setdefault(branch, []).append(employee)
	manager_of = dict(frappe.db.sql("select name, reports_to from `tabEmployee`"))
	active = set(frappe.get_all("Employee", {"status": "Active"}, pluck="name"))

	def leads_back_to(start, target):
		cur, seen = start, set()
		while cur and cur not in seen:
			if cur == target:
				return True
			seen.add(cur)
			cur = manager_of.get(cur)
			if cur == start:
				break
		return False

	changes, skipped = [], {"multiple HRs": 0, "no HR": 0, "no branch": 0, "would loop": 0}
	for e in frappe.get_all("Employee", {"status": "Active", "reports_to": ["is", "not set"]}, ["name", "branch"]):
		if not e.branch:
			skipped["no branch"] += 1
			continue
		hrs = [h for h in hr_by_branch.get(e.branch, []) if h in active and h != e.name]
		if not hrs:
			skipped["no HR"] += 1
		elif len(hrs) > 1:
			skipped["multiple HRs"] += 1
		elif leads_back_to(hrs[0], e.name):
			skipped["would loop"] += 1
		else:
			changes.append({"employee": e.name, "old": None, "new": hrs[0]})
			manager_of[e.name] = hrs[0]

	result = {"assigned": len(changes), "skipped": skipped, "undo_file": _apply_reports_to(changes, "branch_hr")}
	print(result)
	return result


def _apply_reports_to(changes, tag):
	"""Writes the undo file (see undo_branch_hr_assignment), sets reports_to,
	rebuilds the Employee tree. Returns the undo file path, or None."""
	import json

	from frappe.utils import now_datetime
	from frappe.utils.nestedset import rebuild_tree

	if not changes:
		return None
	path = frappe.get_site_path("private", "files", f"reports_to_{tag}_undo_{now_datetime():%Y%m%d_%H%M%S}.json")
	with open(path, "w") as f:
		json.dump(changes, f, indent=1)
	for c in changes:
		frappe.db.set_value("Employee", c["employee"], "reports_to", c["new"], update_modified=False)
	rebuild_tree("Employee")
	frappe.db.commit()
	return path


def assign_uncovered_to(fallback):
	"""Active employees with no Reports To and no active HR on their branch
	(or no branch at all) report to `fallback`. Self-reporting heads are left
	alone, as is anything that would create a loop. Undo file like above."""
	from olscpl_hrms.utils.reporting_person import branch_hrs

	if frappe.db.get_value("Employee", fallback, "status") != "Active":
		print(f"{fallback} is not an active employee - nothing done")
		return
	manager_of = dict(frappe.db.sql("select name, reports_to from `tabEmployee`"))
	changes, looped = [], 0
	for name in frappe.get_all("Employee", {"status": "Active", "reports_to": ["is", "not set"], "name": ["!=", fallback]}, pluck="name"):
		if branch_hrs(name):
			continue
		cur, seen = fallback, set()  # would `name` end up above itself?
		while cur and cur not in seen and cur != name:
			seen.add(cur)
			cur = manager_of.get(cur)
		if cur == name:
			looped += 1
			continue
		changes.append({"employee": name, "old": None, "new": fallback})
		manager_of[name] = fallback

	result = {"assigned": len(changes), "would loop": looped, "undo_file": _apply_reports_to(changes, f"fallback_{fallback}")}
	print(result)
	return result


def undo_branch_hr_assignment(undo_file):
	"""Reverts assign_unmanaged_to_branch_hr using its undo file - only rows
	still pointing at the value it set are reverted."""
	import json

	from frappe.utils.nestedset import rebuild_tree

	with open(undo_file) as f:
		changes = json.load(f)
	reverted = 0
	for c in changes:
		if frappe.db.get_value("Employee", c["employee"], "reports_to") == c["new"]:
			frappe.db.set_value("Employee", c["employee"], "reports_to", c["old"], update_modified=False)
			reverted += 1
	rebuild_tree("Employee")
	frappe.db.commit()
	print({"reverted": reverted})
	return reverted
