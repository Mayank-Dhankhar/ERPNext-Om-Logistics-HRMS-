# olscpl_hrms/utils/reporting_person.py
#
# One rule for the five self-service requests (Leave, Comp Off, Visit, Work
# From Home, Attendance Regularization): only the employee's Reporting Person
# approves - their Reports To manager, or FALLBACK_APPROVER when none is set.
# It is set by the server (enforce_reporting_person), not chosen by the
# employee. The workflows' Approve/Reject conditions enforce who may act (plus
# System Manager); this module shares the request with that person (every
# login is user-permission-restricted to its own Employee record, so they
# couldn't open it otherwise) and the app's Team Requests lists show what's
# shared with you.
import frappe

# Approves for everyone with no Reports To on file: Jagdish Chander
FALLBACK_APPROVER = "14966"

# doctype -> (field holding the chosen person, what it links to)
REPORTING_FIELD = {
	"Visit": ("reporting_person", "Employee"),
	"Work From Home Request": ("reporting_person", "Employee"),
	"Attendance Regularization": ("reporting_person", "Employee"),
	"Leave Application": ("leave_approver", "User"),
	"Compensatory Leave Request": ("custom_approver", "User"),
}

# doctype -> (start date field, end date field) - what a PWA Notification's
# message should show instead of the bare doc id (HR-LAP-2026-22810 means
# nothing to whoever's reading it; the date it's about does).
NOTIFICATION_DATE_FIELD = {
	"Leave Application": ("from_date", "to_date"),
	"Visit": ("from_date", "to_date"),
	"Attendance Regularization": ("for_date", "for_date"),
	"Work From Home Request": ("date", "date"),
	"Compensatory Leave Request": ("work_from_date", "work_end_date"),
}

# doctype -> field actually holding its open/closed state - only Leave
# Application uses a plain "status" field, the other four are workflow-driven
# and track it in "workflow_state" instead (mirrors the mobile app's own
# STATUS_FIELDNAME in notificationFeed.js).
STATUS_FIELDNAME = {
	"Leave Application": "status",
	"Attendance Regularization": "workflow_state",
	"Visit": "workflow_state",
	"Work From Home Request": "workflow_state",
	"Compensatory Leave Request": "workflow_state",
}
FINISHED_STATUSES = {"Approved", "Rejected", "Cancelled", "Withdrawn"}


def is_system_manager(user=None):
	"""The see-all/approve-anything override for these five requests."""
	user = user or frappe.session.user
	return user == "Administrator" or bool(frappe.db.exists("Has Role", {"parent": user, "role": "System Manager"}))


def chosen_user(doc):
	"""Login of the request's chosen Reporting Person, or None."""
	fieldname, links_to = REPORTING_FIELD[doc.doctype]
	value = doc.get(fieldname)
	if not value:
		return None
	return value if links_to == "User" else frappe.db.get_value("Employee", value, "user_id")


def my_value(doctype, user=None):
	"""What the reporting field holds when `user` is the chosen person."""
	user = user or frappe.session.user
	_, links_to = REPORTING_FIELD[doctype]
	return user if links_to == "User" else frappe.db.get_value("Employee", {"user_id": user}, "name")


def branch_hrs(employee):
	"""Active HR people of `employee`'s Sitting Branch - where they actually
	work - falling back to Branch when none is set (never the employee themselves)."""
	sitting, branch = frappe.db.get_value("Employee", employee, ["custom_sitting_branch", "branch"]) or (None, None)
	branch = sitting or branch
	if not branch:
		return []
	hrs = frappe.get_all("Branch HR", {"parenttype": "Branch", "parent": branch}, pluck="employee")
	return [
		h for h in hrs
		if h != employee and frappe.db.get_value("Employee", h, "status") == "Active"
	]


def approver_users(doc):
	"""Logins that may see/approve `doc`: its Reporting Person only."""
	users = {chosen_user(doc)}
	users.discard(None)
	users.discard(frappe.db.get_value("Employee", doc.employee, "user_id"))
	return users


def share_with_reporting_person(doc, method=None):
	"""doc_events on_update for all five doctypes: share with the chosen
	Reporting Person (read/write/submit, no email)."""
	# bulk_workflow's Oracle migration creates already-approved history - not shared.
	if doc.docstatus != 0 or frappe.flags.skip_reporting_share:
		return
	for user in approver_users(doc):
		frappe.share.add_docshare(
			doc.doctype, doc.name, user, read=1, write=1, submit=1, flags={"ignore_share_permission": True}, notify=0
		)


def shared_with_me(doctype, user=None):
	"""Names of `doctype` records shared with `user` - the Team Requests scope."""
	return frappe.get_all(
		"DocShare", {"share_doctype": doctype, "user": user or frappe.session.user, "read": 1}, pluck="share_name"
	)


def team_request_names(doctype, user=None):
	"""Team Requests scope: shared with `user` (new requests) plus older ones
	where `user` is the Reporting Person."""
	user = user or frappe.session.user
	fieldname, _ = REPORTING_FIELD[doctype]
	mine = frappe.get_all(doctype, {fieldname: my_value(doctype, user) or "-"}, pluck="name")
	return list(set(shared_with_me(doctype, user) + mine)) or [""]


def team_pending_filters(doctype):
	"""Team Requests shows only requests still awaiting approval, raised in
	the current payroll cycle (26th-25th) or the one before."""
	from olscpl_hrms.events.attendance_regularization_steps import get_payroll_cycle

	cycle_start, _ = get_payroll_cycle(frappe.utils.nowdate())
	state_field, pending = ("status", "Open") if doctype == "Leave Application" else ("workflow_state", "Pending")
	return {state_field: pending, "creation": [">=", frappe.utils.add_months(cycle_start, -1)]}


def approver_employee(employee):
	"""The one approver: Reports To, else FALLBACK_APPROVER (never the employee)."""
	manager = frappe.db.get_value("Employee", employee, "reports_to")
	if not manager or manager == employee:
		manager = FALLBACK_APPROVER
	return None if manager == employee else manager


def default_reporting_value(doctype, employee):
	"""approver_employee() in the doctype's reporting field (Employee or User)."""
	manager = approver_employee(employee)
	if not manager:
		return None
	_, links_to = REPORTING_FIELD[doctype]
	return manager if links_to == "Employee" else frappe.db.get_value("Employee", manager, "user_id")


def enforce_reporting_person(doc, method=None):
	"""doc_events validate for all five: while the request is open, its
	Reporting Person is always the employee's approver - whatever was sent."""
	if doc.docstatus != 0 or not doc.get("employee") or frappe.flags.skip_reporting_share:
		return
	fieldname, _ = REPORTING_FIELD[doc.doctype]
	doc.set(fieldname, default_reporting_value(doc.doctype, doc.employee))


def mirror_to_app(log, method=None):
	"""doc_events after_insert on Notification Log: the mobile app's bell
	(and phone push) only reads PWA Notification, which HRMS writes for
	Leave itself but nobody wrote for the other four - so their "new
	request" / "approved" / "rejected" alerts never reached the app."""
	if log.document_type not in REPORTING_FIELD or log.document_type == "Leave Application":
		return
	# Alerts are logged by a background job that can run before the request's
	# own save is committed - so build the app copy in a job of its own.
	frappe.enqueue(
		"olscpl_hrms.utils.reporting_person.make_app_notification",
		log_name=log.name,
		enqueue_after_commit=True,
		now=frappe.flags.in_test,
	)


def humanize_notification_message(doc, method=None):
	"""doc_events before_insert on PWA Notification: both HRMS core's own
	Leave messages and make_app_notification() above write the bare doc id
	as plain text in the message ("... for approval: HR-LAP-2026-22810",
	"Your Leave Application HR-LAP-... has been Approved by ..."), never
	wrapped in bold() - so it's a literal substring, safe to swap for the
	date the request is actually about."""
	fields = NOTIFICATION_DATE_FIELD.get(doc.reference_document_type)
	if not fields or not doc.reference_document_name or doc.reference_document_name not in (doc.message or ""):
		return
	start_field, end_field = fields
	values = frappe.db.get_value(doc.reference_document_type, doc.reference_document_name, [start_field, end_field])
	if not values or not values[0]:
		return
	start, end = values
	date_text = frappe.utils.formatdate(start, "d MMM")
	if end and end != start:
		date_text += f" – {frappe.utils.formatdate(end, 'd MMM')}"
	doc.message = doc.message.replace(doc.reference_document_name, date_text)


def make_app_notification(log_name):
	import time

	from frappe import bold

	log = frappe.get_doc("Notification Log", log_name)
	# ponytail: the request may still be mid-save; wait up to ~5s for it.
	for _ in range(10):
		doc = frappe.db.get_value(
			log.document_type, log.document_name, ["employee", "employee_name", "workflow_state"], as_dict=True
		)
		if doc:
			break
		frappe.db.rollback()  # fresh snapshot so the committed request becomes visible
		time.sleep(0.5)
	else:
		return
	# Same wording as HRMS's Leave messages (hrms/mixins/pwa_notifications.py)
	if log.for_user == frappe.db.get_value("Employee", doc.employee, "user_id"):
		if doc.workflow_state not in ("Approved", "Rejected", "Cancelled"):
			return
		by = frappe.db.get_value("User", log.from_user, "full_name") or log.from_user
		message = f"{bold('Your')} {bold(log.document_type)} {log.document_name} has been {bold(doc.workflow_state)} by {bold(by)}"
	else:
		# Only a genuine new-submission share (type "Alert", from share_with_-
		# reporting_person's frappe.share.add_docshare) is "a new request" -
		# other Notification Log entries addressed to the approver on these
		# doctypes (e.g. "Assignment" when cancel_linked_regularizations
		# clears their To Do on an auto-cancelled request) aren't a new
		# request at all; reusing this wording for those misled the approver
		# into thinking a cancelled request was freshly raised again.
		if log.type != "Alert":
			return
		message = f"{bold(doc.employee_name)} raised a new {bold(log.document_type)} for approval: {log.document_name}"
	frappe.get_doc({
		"doctype": "PWA Notification",
		"from_user": log.from_user,
		"to_user": log.for_user,
		"message": message,
		"reference_document_type": log.document_type,
		"reference_document_name": log.document_name,
	}).insert(ignore_permissions=True)


def _is_pending_on_me(doctype, name, user):
	"""Still open AND `user` is its actual Reporting Person (approver) - not
	just "not the owner of the request", which merely being able to read
	this doctype through a broad role (HR Manager, HR User, Leave Approver,
	...) also satisfies. Those roles grant company-wide read access
	independent of this app's own per-request routing, so an owner-based
	guess would wrongly treat someone else's request - one this user has no
	actual authority to act on - as theirs to approve."""
	status_field = STATUS_FIELDNAME.get(doctype)
	fieldname, links_to = REPORTING_FIELD.get(doctype, (None, None))
	if not status_field or not fieldname:
		return False
	row = frappe.db.get_value(doctype, name, [status_field, "docstatus", fieldname], as_dict=True)
	if not row:
		return False
	if row.docstatus != 0 or row.get(status_field) in FINISHED_STATUSES:
		return False
	value = row.get(fieldname)
	if not value:
		return False
	approver = value if links_to == "User" else frappe.db.get_value("Employee", value, "user_id")
	return approver == user


@frappe.whitelist()
def pending_for_me(doctype, names):
	"""Which of `names` (this doctype's records) are genuinely still pending
	the current user's approval - used by the mobile app to decide whether
	to show Approve/Reject, since being able to read a request (e.g. via a
	broad HR role) is not the same as being its actual approver."""
	if isinstance(names, str):
		names = frappe.parse_json(names)
	user = frappe.session.user
	return [n for n in names if _is_pending_on_me(doctype, n, user)]


@frappe.whitelist()
def get_notification_counts():
	"""Two separate counts for the mobile app's notification bell:
	- pending: requests genuinely still waiting on the user's approval - the
	  same count Team Requests shows, independent of any notification's own
	  read flag, so it stays put until the request is actually approved or
	  rejected (never just because it was "seen").
	- unread_other: everything else still unread (status updates, informa-
	  tional alerts) - this is what "Mark all read" actually clears."""
	user = frappe.session.user

	pending = 0
	for doctype in REPORTING_FIELD:
		names = team_request_names(doctype, user)
		if names == [""]:
			continue
		filters = dict(team_pending_filters(doctype))
		filters["name"] = ["in", names]
		pending += frappe.db.count(doctype, filters)

	rows = frappe.get_all(
		"PWA Notification",
		filters={"to_user": user, "read": 0},
		fields=["reference_document_type", "reference_document_name"],
	)
	unread_other = sum(
		1
		for r in rows
		if not (
			r.reference_document_type
			and r.reference_document_name
			and _is_pending_on_me(r.reference_document_type, r.reference_document_name, user)
		)
	)
	return {"pending": pending, "unread_other": unread_other}


@frappe.whitelist()
def mark_all_notifications_as_read():
	"""Marks every one of the current user's unread PWA Notifications as
	read, in one go, server-side - except a notification about a request
	that's still genuinely pending on them, which has to stay unread (and
	keep counting) until it's actually approved or rejected. Replaces the
	stock hrms.api.mark_all_notifications_as_read, which marked everything
	indiscriminately, pending requests included."""
	user = frappe.session.user
	rows = frappe.get_all(
		"PWA Notification",
		filters={"to_user": user, "read": 0},
		fields=["name", "reference_document_type", "reference_document_name"],
	)
	to_mark = [
		r.name
		for r in rows
		if not (
			r.reference_document_type
			and r.reference_document_name
			and _is_pending_on_me(r.reference_document_type, r.reference_document_name, user)
		)
	]
	if to_mark:
		frappe.db.set_value("PWA Notification", {"name": ["in", to_mark]}, "read", 1, update_modified=False)


# --- OMSTAFF Android app APIs (api/leave.py, visit.py, work_from_home.py,
# compensatory_leave.py, regularization.py): same rule, keyed by the
# caller's Employee ID instead of the session user.
def _user_of(employee):
	return frappe.db.get_value("Employee", employee, "user_id")


def omstaff_can_approve(doc, caller_employee):
	user = _user_of(caller_employee)
	return bool(user) and (is_system_manager(user) or user in approver_users(doc))


def omstaff_team_filters(doctype, caller_employee, employee=None):
	"""Team list scope: everything for System Manager, else what's shared
	with the caller (their Reporting Person)."""
	user = _user_of(caller_employee)
	if user and is_system_manager(user):
		filters = {}
	else:
		filters = {"name": ["in", team_request_names(doctype, user) if user else [""]]}
	if employee:
		filters["employee"] = employee
	return filters
