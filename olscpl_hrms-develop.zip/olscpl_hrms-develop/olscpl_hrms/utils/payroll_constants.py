import re


# ============================================================
# Payroll Rule Engine — Shared Constants
# Used across salary_slip_steps.py functions
# ============================================================

# --- LWP Bridge (Attendance -> LWP) ---
LATE_COMING_FREE_LIMIT = 4          # late comings allowed before LWP penalty
LATE_COMING_LWP_RATE = 0.5          # LWP days per excess late coming
SHORT_LEAVE_FREE_LIMIT_HRS = 4      # short leave hours allowed before LWP penalty
SHORT_LEAVE_LWP_FLAT = 0.5          # flat LWP added when short leave exceeded

HALF_DAY_EXCLUDED_VIOLATION_TYPES = [
	"Late Coming Limit Exceeded (5th+)",
	"Late Coming Limit Exceeded",
	"Late Coming OK, But Short Leave Exhausted",
	"Short Leave Balance Exhausted",
	"Short Leave Exhausted",
]

MONTH_MAP = {
	1: "January", 2: "February", 3: "March",
	4: "April", 5: "May", 6: "June",
	7: "July", 8: "August", 9: "September",
	10: "October", 11: "November", 12: "December",
}

PAYROLL_CYCLE_START_DAY = 26        # payroll cycle: 26th -> 25th

#17-09-2026
NO_PF_ESI_DESIGNATIONS_ON_MANUAL = ["DRIVER", "SUPERVISOR", "SUPERVISOR-2"]

# --- Salary Structure Names ---
OSBS_SALARY_STRUCTURE = "OSBS Base-Salary-Based Structure"
MANUAL_SALARY_STRUCTURE_KEYWORD = "manual"
BASE_SALARY_STRUCTURE_KEYWORD = "salary based structure"


def _normalize_salary_structure_name(name):
	return " ".join(re.sub(r"[^a-z0-9]+", " ", str(name or "").lower()).split())


def is_manual_salary_structure(name):
	return MANUAL_SALARY_STRUCTURE_KEYWORD in _normalize_salary_structure_name(name).split()


def is_base_salary_structure(name):
	return BASE_SALARY_STRUCTURE_KEYWORD in _normalize_salary_structure_name(name)

# --- OSBS Salary Calculation ---
OSBS_MIN_BASIC_AMOUNT = 21100

# --- Salary Split Percentages ---
BASE_BASIC_RATE = 0.60
BASE_HRA_RATE = 0.40

OSBS_BASIC_RATE = 0.50
OSBS_HRA_RATE = 0.40
OSBS_CONVEYANCE_RATE = 0.10


# --- Gratuity / Leave Encashment (employer benefit, monthly provision) ---
GRATUITY_DIVISOR = 26               # Basic / 26 working days
LEAVE_ENCASHMENT_DIVISOR = 30       # Basic / 30 days
ENCASHMENT_DAYS = 15                # 15 days per year
MONTHS_IN_YEAR = 12


def calc_gratuity(basic):
	return round((float(basic or 0) / GRATUITY_DIVISOR) * (ENCASHMENT_DAYS / MONTHS_IN_YEAR), 2)


def calc_leave_encashment(basic):
	return round((float(basic or 0) / LEAVE_ENCASHMENT_DIVISOR) * (ENCASHMENT_DAYS / MONTHS_IN_YEAR), 2)

# --- One-time salary components ---
ONE_TIME_COMPONENTS = [
	"Leave Encashment",
	"Incentive",
	"Performance Bonus",
	"Bonus",
	"Arrear",
]

def extend_bootinfo(bootinfo):
	bootinfo.one_time_components = [component.lower() for component in ONE_TIME_COMPONENTS]
	bootinfo.no_deduction_employment_types = NO_DEDUCTION_EMPLOYMENT_TYPES
	bootinfo.salary_structure_keywords = {
		"manual": MANUAL_SALARY_STRUCTURE_KEYWORD,
		"base": BASE_SALARY_STRUCTURE_KEYWORD,
	}
	bootinfo.payroll_rates = {
		"base_basic": BASE_BASIC_RATE,
		"base_hra": BASE_HRA_RATE,
		"osbs_basic": OSBS_BASIC_RATE,
		"osbs_hra": OSBS_HRA_RATE,
		"osbs_conveyance": OSBS_CONVEYANCE_RATE,
		"gratuity_divisor": GRATUITY_DIVISOR,
		"leave_encashment_divisor": LEAVE_ENCASHMENT_DIVISOR,
		"encashment_days": ENCASHMENT_DAYS,
		"months_in_year": MONTHS_IN_YEAR,
	}

# --- Employer PF Rates ---
EMPLOYEE_PF_RATE_DEFAULT = 0.12
EMPLOYER_PF_RATE_DEFAULT = 0.12
OSBS_PF_RATE = 0.12
OSBS_EMPLOYER_PF_RATE = OSBS_PF_RATE


#21-10-2026
# Employment Types that get the flat 60/40 Basic/HRA split and ZERO deductions
NO_DEDUCTION_EMPLOYMENT_TYPES = ["OUTSOURCED", "APPRENTICE"]


def is_no_deduction_employment_type(employment_type):
	return str(employment_type or "").strip().upper() in NO_DEDUCTION_EMPLOYMENT_TYPES
