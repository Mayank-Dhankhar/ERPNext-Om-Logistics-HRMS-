# olscpl_hrms/utils/email_layout.py
#
# One branded ATLAS shell for every email this app sends (interview, offer/
# onboarding, appointment letter, rejection, HR alerts), matching the login
# page's OmOne ATLAS panel.
#
# The header is a pre-rendered image (public/images/atlas_email_header.jpg,
# made from the login page's own CSS) because gradient text, radial glows and
# the dot texture can't be done in Gmail/Outlook HTML. On a public site (atlas)
# it's a plain hosted URL - an inline cid: attachment would show up as an
# attachment chip in Gmail. Only a non-public host (local dev like
# "om-hrms:8004", unreachable from Gmail) falls back to Frappe's
# <img embed="..."> inline attachment. The image is wrapped in a link, which
# also stops Gmail's download/Drive hover buttons on large images. A navy
# background + white alt text cover clients that block images.
#
# Everything else is table layout + inline styles. The <style> block only adds
# extras (entrance animation, pulsing dot, mobile padding) for clients that
# support them - Apple Mail / iOS Mail; Gmail and Outlook ignore it and show
# the same static design. Callers keep their own greeting and sign-off inside
# `body_html`; pass signoff=True only for bodies that don't have one.
from urllib.parse import urlparse

import frappe
from frappe import _
from frappe.utils import escape_html, get_url

HEADER_PATH = "assets/olscpl_hrms/images/atlas_email_header.jpg"
RAPIDSHYP_LOGO_PATH = "assets/olscpl_hrms/images/rapidshyp_logo_white.png"


def _header_img_attr(path=HEADER_PATH):
	# email_asset_host (site config, optional): a public site to load the
	# header image from - lets a dev/local site (whose own address mail
	# clients can't reach) link to e.g. https://atlas.omone.in instead of
	# attaching the image, which Gmail lists as an attachment on every mail.
	site = (frappe.conf.get("email_asset_host") or get_url()).rstrip("/")
	host = urlparse(site).hostname or ""
	is_public = "." in host and host not in ("localhost", "127.0.0.1")
	return f'src="{site}/{path}"' if is_public else f'embed="{path}"'

STYLE = """
<style>
@keyframes atl-rise { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }
@keyframes atl-pulse { 0%, 100% { box-shadow: 0 0 0 0 rgba(53,201,143,.55); } 60% { box-shadow: 0 0 0 7px rgba(53,201,143,0); } }
.atl-card { animation: atl-rise .7s cubic-bezier(.22,1,.36,1) both; }
.atl-body { animation: atl-rise .7s .15s cubic-bezier(.22,1,.36,1) both; }
.atl-dot { animation: atl-pulse 2.2s ease-out infinite; }
@media (max-width: 600px) { .atl-pad { padding-left: 22px !important; padding-right: 22px !important; } }
@media (prefers-reduced-motion: reduce) { .atl-card, .atl-body, .atl-dot { animation: none !important; } }
</style>"""


def branded_email(label, body_html, signoff=False):
	signoff_html = (
		"<table role='presentation' cellpadding='0' cellspacing='0' style='margin-top:26px;'><tr>"
		"<td style='width:3px; background-color:#6e86ff; background:linear-gradient(180deg,#6e86ff,#5ad19a); border-radius:2px;'></td>"
		"<td style='padding-left:12px; font-size:14px; line-height:21px; color:#4c4e6b;'>Thank you,<br>"
		"<span style='font-weight:700; color:#16264f;'>Team ATLAS</span><br>"
		"<span style='color:#9a9cb8; font-size:12px;'>OM Logistics &middot; Work Hub</span></td>"
		"</tr></table>"
		if signoff
		else ""
	)
	return f"""{STYLE}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#eef1f8; padding:36px 0; font-family:Inter,'Segoe UI',Helvetica,Arial,sans-serif;">
  <tr><td align="center">
    <table role="presentation" class="atl-card" width="800" cellpadding="0" cellspacing="0" style="width:800px; max-width:96%; background-color:#ffffff; border-radius:18px; overflow:hidden; border:1px solid #e3e7f3; box-shadow:0 18px 40px -12px rgba(22,38,79,0.25);">
      <tr><td style="background-color:#172e7a; line-height:0; font-size:0;">
        <a href="{get_url()}" target="_blank" style="display:block; text-decoration:none;"><img {_header_img_attr()} alt="OM One ATLAS" width="800" style="display:block; width:100%; max-width:800px; height:auto; border:0; outline:none; color:#ffffff; font-size:22px; font-weight:800; line-height:60px; text-align:left;"></a>
      </td></tr>
      <tr><td style="height:4px; line-height:4px; font-size:0; background-color:#6e86ff; background:linear-gradient(90deg,#6e86ff,#5ad19a);">&nbsp;</td></tr>
      <tr><td class="atl-pad atl-body" style="padding:34px 44px 34px 44px;">
        <span style="display:inline-block; background-color:#eef1ff; border:1px solid #dfe4ff; color:#3d3f9e; font-size:11.5px; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; padding:6px 13px 6px 11px; border-radius:999px;">
          <span class="atl-dot" style="display:inline-block; width:7px; height:7px; border-radius:50%; background-color:#35c98f; margin-right:7px; vertical-align:1px;"></span>{escape_html(label)}
        </span>
        <div style="margin-top:22px; font-size:15px; line-height:25px; color:#3f4263;">{body_html}{signoff_html}</div>
      </td></tr>
      <tr><td class="atl-pad" style="background-color:#f7f8fc; padding:18px 44px; border-top:1px solid #eceef5; text-align:center;">
        <span style="font-size:11.5px; color:#9a9cb8;">&copy; OM Logistics &middot; Sent via <span style="color:#3d3f9e; font-weight:700;">OM One ATLAS</span></span><br>
        <span style="font-size:10.5px; color:#b4b6cc;">This is an automated message from ATLAS.</span>
      </td></tr>
    </table>
  </td></tr>
</table>"""


def rapidshyp_email(label, body_html):
	"""RapidShyp's own version of the same card (job offer / onboarding mails to
	RapidShyp candidates - api/rapidshyp.py): RapidShyp purple header with the
	white logo, yellow accent, RapidShyp footer - no OM / ATLAS branding. The
	body carries its own greeting and sign-off."""
	return f"""{STYLE}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f1f7; padding:36px 0; font-family:Inter,'Segoe UI',Helvetica,Arial,sans-serif;">
  <tr><td align="center">
    <table role="presentation" class="atl-card" width="800" cellpadding="0" cellspacing="0" style="width:800px; max-width:96%; background-color:#ffffff; border-radius:18px; overflow:hidden; border:1px solid #e8e2ee; box-shadow:0 18px 40px -12px rgba(62,26,81,0.25);">
      <tr><td class="atl-pad" style="background-color:#3e1a51; padding:30px 44px;">
        <img {_header_img_attr(RAPIDSHYP_LOGO_PATH)} alt="RapidShyp" width="220" style="display:block; width:220px; max-width:60%; height:auto; border:0; outline:none; color:#ffffff; font-size:24px; font-weight:800;">
      </td></tr>
      <tr><td style="height:4px; line-height:4px; font-size:0; background-color:#f6c938; background:linear-gradient(90deg,#f6c938,#f9e569);">&nbsp;</td></tr>
      <tr><td class="atl-pad atl-body" style="padding:34px 44px 34px 44px;">
        <span style="display:inline-block; background-color:#f5eff9; border:1px solid #e7dcef; color:#3e1a51; font-size:11.5px; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; padding:6px 13px 6px 11px; border-radius:999px;">
          <span style="display:inline-block; width:7px; height:7px; border-radius:50%; background-color:#f6c938; margin-right:7px; vertical-align:1px;"></span>{escape_html(label)}
        </span>
        <div style="margin-top:22px; font-size:15px; line-height:25px; color:#3a3346;">{body_html}</div>
      </td></tr>
      <tr><td class="atl-pad" style="background-color:#faf8fc; padding:18px 44px; border-top:1px solid #efeaf3; text-align:center;">
        <span style="font-size:11.5px; color:#9a8fa6;">&copy; RapidShyp &middot; Open Source Business Solutions Pvt. Ltd.</span><br>
        <span style="font-size:10.5px; color:#b9b0c3;">www.rapidshyp.com</span>
      </td></tr>
    </table>
  </td></tr>
</table>"""


def company_email(company, label, body_html, signoff=False):
	"""Recruitment mails in the hiring company's look: RapidShyp's template for
	a RapidShyp opening / offer / onboarding, the ATLAS one for everyone else."""
	from olscpl_hrms.api.rapidshyp import BRAND, is_rapidshyp

	if is_rapidshyp(company):
		sign = (
			"<p style='margin-top:26px;'>Thank you,<br>"
			f"<span style='font-weight:700; color:#3e1a51;'>Team {BRAND}</span></p>" if signoff else ""
		)
		return rapidshyp_email(label, body_html + sign)
	return branded_email(label, body_html, signoff=signoff)


# ── Email Branding (UI) ─────────────────────────────────────────────────────
# For new mails set up in the UI: a Notification with "Use company email
# template" (overrides/notification.py) is wrapped in the company's Email
# Branding record. The built-in mails above keep their own fixed templates.
# These values seed the two records (setup_email_branding patch) and are the
# fallback when no record exists.
DEFAULT_BRANDING = frappe._dict(
	brand_name="OM One ATLAS", header_style="Banner Image", header_image="/" + HEADER_PATH, header_logo=None,
	header_colour="#172e7a", accent_from="#6e86ff", accent_to="#5ad19a", label_colour="#3d3f9e", page_background="#eef1f8",
	signoff_team="Team ATLAS", signoff_tagline="OM Logistics \u00b7 Work Hub",
	footer_line_1="\u00a9 OM Logistics \u00b7 Sent via OM One ATLAS", footer_line_2="This is an automated message from ATLAS.",
)
RAPIDSHYP_BRANDING = frappe._dict(
	brand_name="RapidShyp", header_style="Logo on Colour", header_image=None, header_logo="/" + RAPIDSHYP_LOGO_PATH,
	header_colour="#3e1a51", accent_from="#f6c938", accent_to="#f9e569", label_colour="#3e1a51", page_background="#f4f1f7",
	signoff_team="Team RapidShyp", signoff_tagline="",
	footer_line_1="\u00a9 RapidShyp \u00b7 Open Source Business Solutions Pvt. Ltd.", footer_line_2="www.rapidshyp.com",
)

def get_branding(company=None):
	"""The Email Branding for this company, else the Default one, else the built-in design."""
	records = frappe.cache().get_value("email_branding", lambda: [
		frappe._dict(r) for r in frappe.get_all("Email Branding", {"enabled": 1}, ["*"])
	] if frappe.db.table_exists("Email Branding") else [])
	if company:
		match = next((r for r in records if r.company == company), None)
		if match:
			return match
		from olscpl_hrms.api.rapidshyp import is_rapidshyp

		if is_rapidshyp(company) and not records:
			return RAPIDSHYP_BRANDING
	return next((r for r in records if r.is_default), None) or DEFAULT_BRANDING


def _img_path(url):
	return (url or "").lstrip("/")


def render_branded(b, label, body_html, signoff=False):
	"""The branded card: header (banner image or logo on colour), accent bar,
	label badge, body, optional team sign-off and footer - all from Email Branding `b`."""
	esc = escape_html
	grad = f"background-color:{b.accent_from}; background:linear-gradient(90deg,{b.accent_from},{b.accent_to or b.accent_from});"
	if b.header_style == "Logo on Colour" and b.header_logo:
		header = (f'<tr><td class="atl-pad" style="background-color:{b.header_colour}; padding:30px 44px;">'
			f'<img {_header_img_attr(_img_path(b.header_logo))} alt="{esc(b.brand_name)}" width="220" style="display:block; width:220px; '
			f'max-width:60%; height:auto; border:0; outline:none; color:#ffffff; font-size:24px; font-weight:800;"></td></tr>')
	else:
		header = (f'<tr><td style="background-color:{b.header_colour}; line-height:0; font-size:0;">'
			f'<a href="{get_url()}" target="_blank" style="display:block; text-decoration:none;"><img {_header_img_attr(_img_path(b.header_image or "/" + HEADER_PATH))} '
			f'alt="{esc(b.brand_name)}" width="800" style="display:block; width:100%; max-width:800px; height:auto; border:0; outline:none; '
			f'color:#ffffff; font-size:22px; font-weight:800; line-height:60px; text-align:left;"></a></td></tr>')
	signoff_html = (
		"<table role='presentation' cellpadding='0' cellspacing='0' style='margin-top:26px;'><tr>"
		f"<td style='width:3px; {grad} border-radius:2px;'></td>"
		"<td style='padding-left:12px; font-size:14px; line-height:21px; color:#4c4e6b;'>Thank you,<br>"
		f"<span style='font-weight:700; color:{b.label_colour};'>{esc(b.signoff_team or b.brand_name)}</span>"
		+ (f"<br><span style='color:#9a9cb8; font-size:12px;'>{esc(b.signoff_tagline)}</span>" if b.signoff_tagline else "")
		+ "</td></tr></table>"
	) if signoff else ""
	footer = "<br>".join(
		f"<span style='font-size:{size}; color:#9a9cb8;'>{esc(t)}</span>"
		for t, size in ((b.footer_line_1, "11.5px"), (b.footer_line_2, "10.5px")) if t
	)
	return f"""{STYLE}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:{b.page_background}; padding:36px 0; font-family:Inter,'Segoe UI',Helvetica,Arial,sans-serif;">
  <tr><td align="center">
    <table role="presentation" class="atl-card" width="800" cellpadding="0" cellspacing="0" style="width:800px; max-width:96%; background-color:#ffffff; border-radius:18px; overflow:hidden; border:1px solid #e3e7f3; box-shadow:0 18px 40px -12px rgba(22,38,79,0.25);">
      {header}
      <tr><td style="height:4px; line-height:4px; font-size:0; {grad}">&nbsp;</td></tr>
      <tr><td class="atl-pad atl-body" style="padding:34px 44px 34px 44px;">
        <span style="display:inline-block; background-color:{b.page_background}; border:1px solid #e3e7f3; color:{b.label_colour}; font-size:11.5px; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; padding:6px 13px 6px 11px; border-radius:999px;">
          <span class="atl-dot" style="display:inline-block; width:7px; height:7px; border-radius:50%; background-color:{b.accent_to or b.accent_from}; margin-right:7px; vertical-align:1px;"></span>{esc(label)}
        </span>
        <div style="margin-top:22px; font-size:15px; line-height:25px; color:#3f4263;">{body_html}{signoff_html}</div>
      </td></tr>
      {f'<tr><td class="atl-pad" style="background-color:#f7f8fc; padding:18px 44px; border-top:1px solid #eceef5; text-align:center;">{footer}</td></tr>' if footer else ""}
    </table>
  </td></tr>
</table>"""


def default_branded_email(content, subject=None):
	"""Jinja method for templates/emails/standard.html (our override of Frappe's
	wrapper for every outgoing mail): mails not already branded go out in the
	Default Email Branding (OM One ATLAS), the subject as the badge. Returns
	None for mails that already carry a branded card (the built-in HR mails,
	RapidShyp ones, ticked Notifications) - those keep Frappe's plain wrapper."""
	content = str(content or "")
	if not content.strip() or "atl-card" in content:
		return None
	label = " ".join((subject or "").split()) or "Notification"
	if len(label) > 60:
		label = label[:57].rstrip() + "..."
	return render_branded(get_branding(None), label, content)


@frappe.whitelist()
def branding_usage(branding):
	"""Email Branding > Used By: which emails this record dresses."""
	frappe.has_permission("Email Branding", "read", branding, throw=True)
	b = frappe.get_doc("Email Branding", branding)
	scope = (_("Used by ticked Notifications for every company that has no Email Branding of its own.") if b.is_default
		else _("Used by ticked Notifications for documents of {0}.").format(b.company))
	notifications = frappe.get_all("Notification", {"custom_use_company_template": 1, "enabled": 1}, pluck="name") \
		if frappe.get_meta("Notification").has_field("custom_use_company_template") else []
	return {"scope": scope, "notifications": notifications}


@frappe.whitelist()
def preview_branding(branding):
	frappe.has_permission("Email Branding", "read", branding, throw=True)
	b = frappe._dict(frappe.get_doc("Email Branding", branding).as_dict())
	body = ("<p>Dear Candidate,</p><p>This is how emails look with this branding. Interview, offer and onboarding "
		"details appear here.</p>")
	html = render_branded(b, "Interview Scheduled", body, signoff=True)
	return html.replace('embed="', 'src="/')  # inline attachments only work in sent mail


def sender_cc(recipients=()):
	"""CC for recruitment mails: whoever's action sent it (frappe.session.user),
	so the HR user has a copy in their own inbox. None for Administrator /
	Guest (not real addresses) or when they're already a recipient."""
	user = frappe.session.user
	if "@" not in user or user in (recipients or ()):
		return None
	return [user]
