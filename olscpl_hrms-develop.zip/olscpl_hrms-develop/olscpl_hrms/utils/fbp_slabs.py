# olscpl_hrms/utils/fbp_slabs.py
#
# Flexi Benefit Plan (FBP) - RapidShyp (OPEN SOURCE BUSINESS SOLUTIONS PVT LTD)
# only. One place for the FBP names, the Basic / HRA rule and HR's slabs, shared
# by the FBP Declaration doctype, its form API, the setup patch and the salary
# slip steps.
#
# How a flexi employee's gross (the Base of the Salary Structure Assignment,
# MONTHLY) is split - HR's "RapidShyp-Salary Structure.xlsx" (Kuldeep Singh):
#   Basic            = 50% of gross (the sheet's 21,100 floor never bites: the
#                      plan is only for gross >= 1,00,000)
#   HRA              = 40% of gross
#   FBP bucket       = the sheet's "Flexi Pay" line, 10% of gross; 12 months of
#                      what is left (gross - Basic - HRA)
# Below 1,00,000 gross HR's sheet has no Flexi Pay (it pays a Conveyance
# Allowance), so those employees do not use this plan.
#   each FBP benefit = the amount the employee chose / 12, up to its slab cap
#   Special Allowance = whatever part of the bucket is not chosen (taxable)
#
# Slab caps are HR's "RapidShyp-Flexi Pay (FBP Entitlement)" mail of
# 21-Oct-2026 (Kuldeep Singh), case by case; F_GROSS_CTC there is the MONTHLY
# gross (the sheet's Conveyance / Driver amounts confirm it). Every entitlement
# here is an ANNUAL amount.
#
# Driver is the one slab that FALLS as gross rises (2,40,000 under 3L,
# 1,80,000 for 3L-5L). That is how HR's payroll sheet pays it too, so it is
# kept as written.
#
# Mobile Allowance Entitlement is 0 for every gross in HR's mail, so it is not a
# component: add it to COMPONENT_FIELD_MAP, FBP_COMPONENT_ABBR and
# get_fbp_entitlements() (and an FBP field on Salary Structure Assignment) the
# day HR gives it a value.
import frappe
from frappe.utils import flt

FBP_COMPANY = "OPEN SOURCE BUSINESS SOLUTIONS PVT LTD"
FLEXI_SALARY_STRUCTURE = "OSBS Flexi Benefit Structure"

BASIC_RATE = 0.5  # Basic = 50% of gross
HRA_RATE = 0.4  # HRA = 40% of gross
MIN_FLEXI_GROSS = 100000  # monthly gross from which HR opens the FBP plan

BASIC_COMPONENT = "Basic"
HRA_COMPONENT = "House Rent Allowance"
# paid as taxable cash: the part of the bucket the employee does not allocate
BALANCE_COMPONENT = "Special Allowance"
TOTAL_FIELD = "fbp_opted_total"

# Salary Component -> field on Salary Structure Assignment holding the
# employee's chosen ANNUAL amount (the Salary Structure formulas read these).
# These are the same components the OSBS Manual structure already pays, so slips
# read the same way; the setup patch only creates one that does not exist yet.
COMPONENT_FIELD_MAP = {
	"Uniform Allowance": "fbp_uniform",
	"FOOD COUPON": "fbp_food_coupon",
	"INTERNET ALLOWANCE": "fbp_internet",
	"Child Education Allowance": "fbp_children_edu",
	"BOOKS AND PERIODICALS": "fbp_books",
	"Conveyance": "fbp_conveyance",
	"HELPER ALLOWANCE": "fbp_helper",
	"DRIVER ALLOWANCE": "fbp_driver",
	"SCHOLARSHIP ALLOWANCE": "fbp_scholarship",
}

# abbreviation used only if the setup patch has to create the component
FBP_COMPONENT_ABBR = {
	"Uniform Allowance": "UNIFORMALL",
	"FOOD COUPON": "FOODCOUPON",
	"INTERNET ALLOWANCE": "INTNETALL",
	"Child Education Allowance": "CHILDEDUALL",
	"BOOKS AND PERIODICALS": "BOOKS",
	"Conveyance": "CONVEYANCE",
	"HELPER ALLOWANCE": "HELPERALL",
	"DRIVER ALLOWANCE": "DRIVERALL",
	"SCHOLARSHIP ALLOWANCE": "SCHOLARALL",
}

# every earning of a flexi-structure slip, in slip order - the salary slip steps
# keep exactly these (besides what they already keep) on such a slip
FLEXI_EARNING_COMPONENTS = (
	[BASIC_COMPONENT, HRA_COMPONENT] + list(COMPONENT_FIELD_MAP) + [BALANCE_COMPONENT]
)


def is_flexi_salary_structure(name):
	return name == FLEXI_SALARY_STRUCTURE


def get_basic(gross):
	"""Monthly Basic: 50% of the monthly gross, to the rupee (same rounding as
	the Salary Structure formula)."""
	return round(flt(gross) * BASIC_RATE)


def get_hra(gross):
	"""Monthly HRA: 40% of gross."""
	return round(flt(gross) * HRA_RATE)


def get_monthly_pool(gross):
	"""Monthly gross left for FBP benefits + Special Allowance."""
	return flt(gross) - get_basic(gross) - get_hra(gross)


def get_fbp_bucket(gross):
	"""Annual FBP bucket: 12 months of what is left after Basic and HRA."""
	return get_monthly_pool(gross) * 12


def monthly_amount(annual):
	"""What a chosen ANNUAL amount pays per month - the formula's chosen / 12,
	to the rupee."""
	return round(flt(annual) / 12)


def _four_band(gross, above_5l, above_3l, from_2l, below_2l):
	"""HR's nested case: >5L, then >3L, then >=2L, else (<2L)."""
	if gross > 500000:
		return above_5l
	if gross > 300000:
		return above_3l
	if gross >= 200000:
		return from_2l
	return below_2l


def get_fbp_entitlements(gross):
	"""Annual cap per component for a MONTHLY gross: {component: amount}."""
	gross = flt(gross)
	flat = gross > 100000  # Uniform, Food, Internet, Education, Books

	# Driver: >5L, then >=3L (not >3L like the others), else <3L.
	if gross > 500000:
		driver = 300000
	elif gross >= 300000:
		driver = 180000
	else:
		driver = 240000

	return {
		"Uniform Allowance": 60000 if flat else 0,
		"FOOD COUPON": 105600 if flat else 0,
		"INTERNET ALLOWANCE": 14400 if flat else 0,
		"Child Education Allowance": 36000 if flat else 0,
		"BOOKS AND PERIODICALS": 30000 if flat else 0,
		"Conveyance": _four_band(gross, 360000, 300000, 240000, 120000),
		"HELPER ALLOWANCE": _four_band(gross, 180000, 120000, 90000, 60000),
		"DRIVER ALLOWANCE": driver,
		"SCHOLARSHIP ALLOWANCE": _four_band(gross, 180000, 120000, 96000, 60000),
	}


# Uniform Allowance is already exempt in full under the old regime by the TDS step
# (no proof asked), so it is left out here to avoid counting it twice.
_ALREADY_EXEMPT = ("Uniform Allowance",)


def get_verified_fbp_exemption(employee, fy_start_date):
	"""Annual old-regime exemption for an employee's flexi benefits: the total
	Verified Amount (bills accepted by HR) on the submitted FBP Declaration of
	the fiscal year starting on fy_start_date, never above what was chosen."""
	fiscal_year = frappe.db.get_value("Fiscal Year", {"year_start_date": fy_start_date}, "name")
	if not fiscal_year:
		return 0
	rows = frappe.db.sql(
		"""
		SELECT i.component, i.opted_amount, i.verified_amount
		FROM `tabFBP Declaration Item` i
		INNER JOIN `tabFBP Declaration` d ON d.name = i.parent
		WHERE d.employee = %s AND d.fiscal_year = %s AND d.docstatus = 1
		  AND i.proof_status = 'Verified'
		""",
		(employee, fiscal_year),
		as_dict=True,
	)
	return sum(
		min(flt(r.verified_amount), flt(r.opted_amount))
		for r in rows
		if r.component not in _ALREADY_EXEMPT
	)
