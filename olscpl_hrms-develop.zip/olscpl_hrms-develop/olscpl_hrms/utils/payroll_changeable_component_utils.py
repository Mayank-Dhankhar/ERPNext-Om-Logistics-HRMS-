import frappe


def get_component_value(component_name, as_on_date):
	"""Returns the amount effective on the given date, checking
	both current component values and the audit trail."""
	row = frappe.db.sql(
		"""
		SELECT amount FROM (
			SELECT amount, effective_date
			FROM `tabPayroll Changeable Component Item`
			WHERE component_name = %(name)s

			UNION ALL

			SELECT amount, effective_date
			FROM `tabPayroll Changeable Component Audit`
			WHERE component_name = %(name)s
		) combined
		WHERE effective_date <= %(as_on)s
		ORDER BY effective_date DESC
		LIMIT 1
		""",
		{"name": component_name, "as_on": as_on_date},
		as_dict=True,
	)
	return frappe.utils.flt(row[0].amount) if row else None